/* eslint-disable */

function scrollTo(scrollTarget) {
  const targetElement = scrollTarget
  if (targetElement) {
    const startPosition = window.pageYOffset;
    const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset;

    // const distance = targetPosition -startPosition - 10;
    const distance = targetPosition -startPosition - 118;
    const duration = 800;
    let startTime = null;

    function animation(currentTime) {
      if (startTime === null) startTime = currentTime;
      const timeElapsed = currentTime - startTime;

      const progress = Math.min(timeElapsed / duration, 1);
      const ease = easeInOutQuad(progress)

      window.scrollTo(0, startPosition + distance * ease);
      if (timeElapsed < duration) {
        requestAnimationFrame(animation)
      }
    }
    function easeInOutQuad(t){
      return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
    }
    requestAnimationFrame(animation)
  }
}


export default function scrollMenu() {
  const array_menu = document.querySelectorAll('.js--at-header-menu-2025')
  array_menu.forEach(link => {
    link.addEventListener('click', function (e) {
      e.preventDefault();
      if (this.hasAttribute('data-link')) {
        let href = this.getAttribute('data-link');
        const scrollTarget = document.getElementById(href);
        scrollTo(scrollTarget)
      }
    })
  })
}
