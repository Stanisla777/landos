/* eslint-disable */
import Vue from 'vue';
import Swiper, { Navigation, Pagination } from 'swiper';
import paginationSlider_s from '../redesign-site/paginationSlider';
Swiper.use([Navigation, Pagination]);

let resizeTimeOut;



export default function speakerInit() {

  const app = new Vue({
    el: '#another-thing-speaker',
    data: {
      html_tooltip:null,
      mySwiper:null

    },

    computed: {

    },


    methods:{

      appraisalSlider() {
        // eslint-disable-next-line no-unused-vars
        this.mySwiper = new Swiper('.js--another-thing-speaker', {
          init: true,
          loop: false,
          slidesPerView: 4,
          spaceBetween: 16,
          simulateTouch: true,
          autoHeight: false,
          resizeObserver:true,
          observeParents:true,
          observer:true,
          // observeSlideChildren:true,

          pagination: {
            el: '.js--pagination-speaker',
            clickable: true,
          },
          navigation: {
            nextEl: '.js--swiper-speaker-right',
            prevEl: '.js--swiper-speaker-left',
          },
          breakpoints: {
            0: {
              slidesPerView: 1,
            },
            690: {
              slidesPerView: 2,
            },
            1100: {
              slidesPerView: 3,
            },
            1375: {
              slidesPerView: 4,
            }
          },
          on: {
            beforeInit:(el)=>{

            },
            afterInit: function (el) {
              if(el.$el && el.$el[0].closest('.js--general-style-slider.before-init')) {
                el.$el[0].closest('.js--general-style-slider').classList.remove('before-init')
              }
              paginationSlider_s(el)
            },
            resize:function (el){
              paginationSlider_s(el);
              setTimeout(()=>{
                // mySwiper.update()
                // mySwiper.updateSlides()
                // mySwiper.updateAutoHeight();
              },300)


            }
          },
        });
      },
      destroySwiper() {
        if (this.mySwiper) {
          this.mySwiper.destroy(true,true);
          this.mySwiper=null
        }
      },



      receiveHtml(el){
        const element = el.currentTarget
        let html_tooltip = element.getAttribute('html-tooltip')
        if (html_tooltip){
          try{
            this.html_tooltip = html_tooltip
            this.$refs.refModal.classList.add('open')
            this.AddClassBody()
          } catch (error) {
            console.log('Ошибка при парсинге');
          }
        }

      },
      closeModal(){
        this.$refs.refModal.classList.remove('open')
        this.RemoveClassBody()
      },
      closeModalBody(e){
        if(e.target===this.$refs.refModal){
          this.$refs.refModal.classList.remove('open')
          this.RemoveClassBody()
        }
      },
      AddClassBody() {
        document.body.classList.add('body-modal');
        document.body.classList.add('body-additional-class');
        document.body.setAttribute('style', `top:-${window.scrollY}px;position: fixed;`);
        document.ontouchmove = (e) => {
          e.preventDefault();
        };
      },
      RemoveClassBody() {
        if (!document.body.classList.contains('body-modal-modals')) {
          document.body.classList.remove('body-modal');
          document.body.classList.remove('body-additional-class');
        }
        const scrollY = document.body.style.top;
        document.body.style.position = '';
        document.body.style.top = '';
        window.scrollTo(0, parseInt(scrollY || '0') * -1);
      },
      setupEventListeners() {
        const element = this.$refs.refModal.querySelector('.js--another-thing-close-modal');
        if (element) {
          element.addEventListener('click', this.closeModal)
        }
      },
    },
    mounted() {
      this.appraisalSlider();
      this.setupEventListeners();
      window.addEventListener('resize', () => {
        clearTimeout(resizeTimeOut)
        resizeTimeOut = setTimeout(() => {
          this.destroySwiper();
          this.appraisalSlider()
        })
      })
    },
    updated() {
      this.setupEventListeners();
    },
    beforeDestroy() {
      const element = this.$refs.refModal.querySelector('.js--another-thing-close-modal');
      if (element) {
        element.removeEventListener('click', this.closeModal)
      }
    }

  });
}
