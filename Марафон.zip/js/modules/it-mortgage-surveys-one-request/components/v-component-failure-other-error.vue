<template lang="pug">
  .mortgage-surveys__final-block-refusal
    p По техническим причинам сервис временно недоступен.
    p Приносим извинения за неудобства.
    p По вопросам участия в программе вы можете проконсультироваться по телефону горячей линии Консультационного Центра
      | !{' '}
      a.mortgage-surveys__tele(:href="`tel:${phone}`") {{phone_formatted}}
      | .
    p.
      Вы можете ознакомиться с другими <a href="/tag/mortgage_support/">мерами поддержки</a>.

</template>
<script>

import Storage from '../development-tools/state.vue';

export default {
  name: 'v-component-it-failure-not-found',
  props:['phone','phone_formatted'],
  data(){
    return {
      output:[]

    }
  },
  methods:{


  },
  mounted(){

  },
  computed:{




  },
  watch:{
  },
  components:{

  },


  created() {

  }
};
</script>
<style scoped>
</style>
