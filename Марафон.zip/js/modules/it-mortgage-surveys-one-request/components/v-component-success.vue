<template lang="pug">
  .mortgage-surveys__final-block
    p.mortgage-surveys__sucsess-final.
      <span>Поздравляем!</span> Компания включена в реестр аккредитованных. Теперь необходимо проверить, пользуется ли она налоговыми льготами. Эту информацию можно получить у вашего работодателя или обратившись в один из банков-участников.
    .mortgage-surveys__final-block-wrp
      .mortgage-surveys__wr-banks.js-accordion-parent
        p.mortgage-surveys__title-banks Перечень <a href="/instructions/spisok-bankov-uchastnikov-programmy-lgotnaya-ipoteka-dlya-it-spetsialistov/" > банков-участников</a>
        ul.mortgage-surveys__list-banks.calculator_s__stylized-list.js-accordion-body
          li(v-for="item in massive_bank")
            a(
              v-bind:href="item.link"
              target="_blank"
            ) {{item.name}}

        .mortgage-surveys__banks-list-btn(@click="banksList")
          p
          .mortgage-surveys__banks-list-icon
            svg(width='14', height='8', viewbox='0 0 14 8', fill='none', xmlns='http://www.w3.org/2000/svg')
              path(d='M1 1L6.29289 6.29289C6.68342 6.68342 7.31658 6.68342 7.70711 6.29289L13 1', stroke='#1C1B28', stroke-width='2', stroke-linecap='round')

      .mortgage-surveys__wr-documents
        .mortgage-surveys__documents
          p.mortgage-surveys__documents-title Чем регулируется программа
          ul.mortgage-surveys__documents-list
            li.mortgage-surveys__documents-list-item(v-for="item in massive_documents")
              a(
                v-bind:href="item.link"
                target="_blank"
              ) {{item.name}}

</template>
<script>
import dropDown from '../../dropDown';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-component-it-success',
  data(){
    return {
      output:[]

    }
  },
  methods:{
    banksList(el) {
      const element = el.currentTarget
      if(element.classList.contains('active')){
        element.classList.remove('active')
        const scrollTarget = element.closest('#v-mortgage-surveys-one-request');
        const elementPosition = scrollTarget.getBoundingClientRect().top;
        console.log(elementPosition);
        window.scrollBy({
          top: elementPosition - 20,
          behavior: 'smooth'
        });
      }
      else{
        element.classList.add('active')
      }

      dropDown(element, 88);
    }
  },
  mounted(){

  },
  computed:{
    massive_bank(){
      return Storage.getters.MASSIVE_BANK
    },
    massive_documents(){
      return Storage.getters.MASSIVE_DOCUMENTS
    },

  },
  watch:{
  },
  components:{

  },


  created() {

  }
};
</script>
<style scoped>
</style>
