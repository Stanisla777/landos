<template lang="pug">
  div
    template
      v-component-it-company
    template
      v-component-it-success(
        v-if="status_success"
      )
    template
      v-component-it-failure-not-found(
        v-if="status_failure"
        :phone ="phone"
        :phone_formatted ="phone_formatted"
      )
    template
    v-component-it-failure-other-error(
      v-if="status_failure_other_error"
      :phone ="phone"
      :phone_formatted ="phone_formatted"
    )


</template>
<script>
import Vue from 'vue';
import Storage from './development-tools/state.vue';
import vComponentItCompany from './components/v-component-it-company.vue';
import vComponentItSuccess from './components/v-component-success.vue';
import vComponentItFailureNotFound from './components/v-component-failure-not-found.vue';
import vComponentItFailureOtherError from './components/v-component-failure-other-error.vue';


export default {
  name: 'ItMortgageSurveysOneRequest',
  data(){
    return {
      final_result:true,
      phone:'',
      phone_formatted:''
    }
  },
  methods:{
    callingCallToAPI(){
      // Storage.dispatch('axiosGetObjectBanks_Company')
    },


  },
  mounted(){
    this.callingCallToAPI()
    if (typeof conf !== 'undefined' && conf !== null && conf.hasOwnProperty('UF_PHONE')) {
      this.phone = conf.UF_PHONE
    }
    if (typeof conf !== 'undefined' && conf !== null && conf.hasOwnProperty('UF_PHONE_formatted')) {
      this.phone_formatted = conf.UF_PHONE_formatted
    }
  },
  computed:{
    status_failure(){
      return Storage.getters.STATUS_FAILURE
    },
    status_success(){
      return Storage.getters.STATUS_SUCCESS
    },
    status_failure_other_error(){
      return Storage.getters.STATUS_FAILURE_OTHER_ERROR
    },

  },
  watch:{
  },
  components:{
    vComponentItCompany,
    vComponentItSuccess,
    vComponentItFailureNotFound,
    vComponentItFailureOtherError
  },


  created() {

  }
};
</script>
<style scoped>
</style>
