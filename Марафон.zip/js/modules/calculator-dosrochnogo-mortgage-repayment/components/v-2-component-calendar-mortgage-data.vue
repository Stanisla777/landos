<template lang="pug">
  .calc-tax-deduc-new__container-block.mor-rep-calculators__parent-tooltip-mobile.js--calc-row-input.js--container-block.js--tooltip-parent
    .calc-tax-deduc-new__row-title-container
      p.calc-tax-deduc-new__row-title Дата получения
      span.content-note.desctop.content-note__center.js--content-note(v-if="tooltip_information['date-receipt']!==''")
        span.content-note__text {{tooltip_information["date-receipt"]}}
      span.content-note.mobile(
        v-if="tooltip_information['date-receipt']!==''"
        @click="openTooltipMobile"
      )
    div(v-if="tooltip_information['date-receipt']!==''")
      .select__background.modal-special-background(@click="closeTooltipMobile")
      .select-list__selection-window.modal-special-styles.js--openlist-body
        .select-list__head
          p Дата получения
          .select-list__head-close(@click="closeTooltipMobile")
            svg(width='10', height='10', viewbox='0 0 10 10', fill='none', xmlns='http://www.w3.org/2000/svg')
              path(fill-rule='evenodd', clip-rule='evenodd', d='M0.209209 0.209209C0.488155 -0.0697365 0.940416 -0.0697365 1.21936 0.209209L5 3.98985L8.78064 0.209209C9.05958 -0.0697365 9.51184 -0.0697365 9.79079 0.209209C10.0697 0.488155 10.0697 0.940416 9.79079 1.21936L6.01015 5L9.79079 8.78064C10.0697 9.05958 10.0697 9.51184 9.79079 9.79079C9.51184 10.0697 9.05958 10.0697 8.78064 9.79079L5 6.01015L1.21936 9.79079C0.940416 10.0697 0.488155 10.0697 0.209209 9.79079C-0.0697365 9.51184 -0.0697365 9.05958 0.209209 8.78064L3.98985 5L0.209209 1.21936C-0.0697365 0.940416 -0.0697365 0.488155 0.209209 0.209209Z', fill='#252628')
        .select-list__wr-search.mor-rep-calculators__wr-search
          p {{tooltip_information["date-receipt"]}}

    .calc-tax-deduc-new__col-input.js--credit-calendar-input.js--tex-deduc-input.js--for-clear-field.js--calendar-data
      //input.property-calculator__value.js--calendar-field.js-mor-required.js--calendar-data-info(
        //type="text"
        //placeholder="ММ.ГГГГ"
        //inputmode="numeric"
        //@keyup="fieldNotEmpty"
        //ref="inputData"
        //@input = "handleInput"
        //@click ="showCalendar"
        //@blur="replaceMonth"
        //@focus="replaceMonthFocus"
      //)

      input.property-calculator__value.js--calendar-field.js-mor-required.js--calendar-data-info(
        type="text"
        placeholder="ММ.ГГГГ"
        inputmode="numeric"
        @keyup="fieldNotEmpty"
        ref="inputData"
        @input = "changeDate"
        @click ="showCalendar"
        @blur="inputBlur"
        @focus="replaceMonthFocusNew"
        @keydown="inputKeyDown"
      )
      .js__vanilla-calendar-calc.vanilla-calendar-style-new.property-calculator__vanilla-calendar.js-calendar-date-receipt(
        @click.stop ="showCalendar"
      )
      .mor-rep-calculators__calendar-container-icon
        .calc-tax-deduc-new__input-clear.js--clear-calc-tax(
            @click="clearInputCalendarData"
          )
        .property-calculator__input-additional-elem(
          @click ="showCalendar"
        )
          svg(width='16', height='16', viewbox='0 0 16 16', fill='none', xmlns='http://www.w3.org/2000/svg')
            path(fill-rule='evenodd', clip-rule='evenodd', d='M4.66699 0.666687C5.03518 0.666687 5.33366 0.965164 5.33366 1.33335V2.00002H10.667V1.33335C10.667 0.965164 10.9655 0.666687 11.3337 0.666687C11.7018 0.666687 12.0003 0.965164 12.0003 1.33335V2.00002H14.0609C14.696 2.00002 15.3337 2.47837 15.3337 3.21214V14.1212C15.3337 14.855 14.696 15.3334 14.0609 15.3334H1.93972C1.30462 15.3334 0.666992 14.855 0.666992 14.1212V3.21214C0.666992 2.47837 1.30462 2.00002 1.93972 2.00002H4.00033V1.33335C4.00033 0.965164 4.2988 0.666687 4.66699 0.666687ZM4.00033 3.33335H2.00033V6.00002H14.0003V3.33335H12.0003V4.00002C12.0003 4.36821 11.7018 4.66669 11.3337 4.66669C10.9655 4.66669 10.667 4.36821 10.667 4.00002V3.33335H5.33366V4.00002C5.33366 4.36821 5.03518 4.66669 4.66699 4.66669C4.2988 4.66669 4.00033 4.36821 4.00033 4.00002V3.33335ZM14.0003 7.33335H2.00033V14H14.0003V7.33335Z', fill='#252628')
    p.mor-rep-calculators__input-error.js--required-error.display-none Это поле обязательное для заполнения
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';

// import VanillaCalendar from '../../vanilla-calendar2';
import numberFormatting from '../mixin/numberFormatting.js';
import IMask from 'imask';
import VanillaCalendar from 'vanilla-calendar-pro';
let maskCalendarMortgageData
export default {
  name: 'v-2-component-calendar',
  mixins: [numberFormatting],
  props:['tooltip_information','answers'],
  data(){
    return {
      calendar:null,
      imask:null,
      rawValue:'',
      formattedValue:'',
      isReadonly:true,
      lastValueOnFocus:'',
      month:['январь', 'февраль', 'март', 'апрель', 'май', 'июнь', 'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь'],
      minYear:new Date().getFullYear() - 30,
      maxYear:new Date().getFullYear() + 1,
      minMonth:1,
      maxMonth:12,
      originalValue:'',
      modalIsOpen:false,
      minDate: {month:1,year:new Date().getFullYear() - 30},
      maxDate: {month:12,year:new Date().getFullYear() + 1},

      //Дополнительно
      activeCalendar: null,
      viewportHandler: null,
      isMobile: false


    }
  },
  methods:{

    //убрать содержание поля инпут в календаре блока данные об ипотеке
    clearInputCalendarData(e){
      const element = e.currentTarget;
      const parent = element.closest('.js--tex-deduc-input');
      if (element.closest('.js--for-clear-field')
        && element.closest('.js--for-clear-field').querySelector('.js-mor-required')) {
        element.closest('.js--for-clear-field').querySelector('.js-mor-required').classList.remove('js-filled')
      }

      if (parent) {
        parent.querySelector('input').value='';
        parent.querySelector('input').classList.remove('active')
        element.classList.remove('active')
      }
      // this.initPluginCalendarVanillaData();
      this.resetCalendar()
      // eventBus.$emit('emitClearCalendarHolidaysPayment')
      //родителю календаря сказал, что поле очищено
      this.$emit('sendClearDateReceive')
      this.$emit('sendTimeDataLoan',0)
    },
    // inputCalendar(){
    //   const input_status = document.querySelectorAll('.js--calendar-data input');
    //   const maskOptions = {
    //     mask: 'MM.YYYY',
    //     lazy: true,
    //     blocks: {
    //       MM: {
    //         mask: IMask.MaskedRange,
    //         from: 1,
    //         to: 12,
    //         maxLength:2
    //       },
    //       YYYY: {
    //         mask: IMask.MaskedRange,
    //         from: 1995,
    //         to: new Date().getFullYear() + 1
    //       },
    //     }
    //   };
    //   for (const item of input_status) {
    //     // eslint-disable-next-line no-new
    //     maskCalendarMortgageData = IMask(item, maskOptions);
    //   }
    // },
    initPluginCalendarVanillaData(month,year){
      const key_word_this=this
      this.calendar = new VanillaCalendar('.js-calendar-date-receipt', {
        type: 'year',
        selectedMonth:null,
        selectedYear:null,
        settings: {
          lang: 'ru',
          range: {
            min: `${new Date().getFullYear() - 30}-01-01`,
            max: `${new Date().getFullYear() + 1}-12-31`
          },

          selected: {
            // dates: dates,
            month: month,
            year:year
          },
          selection: {

          },
        },
        actions: {

          clickMonth(e, dates) {
            if (dates.length !== 0) {
              const parent = e.target.closest('.js--credit-calendar-input');
              const container = e.target.closest('.js__vanilla-calendar-calc')
              const array_month = [ 'январь', 'февраль', 'март', 'апрель', 'май', 'июнь', 'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь']
              let title_month;
              let title_year;
              if (container && container.querySelector('.vanilla-calendar-year')) {
                title_year = container.querySelector('.vanilla-calendar-year').textContent
              }
              if(parent){
                e.target.closest('.js__vanilla-calendar-calc').classList.remove('active');
                parent.querySelector('input').value = `${array_month[dates.selectedMonth]}, ${dates.selectedYear}`;

                if (e.target.closest('.js--calc-row-input')) {
                  e.target.closest('.js--calc-row-input').querySelector('.js--clear-calc-tax').classList.add('active')
                }
                if(parent.querySelector('input').classList.contains('js-mor-required')) {
                  parent.querySelector('input').classList.add('js-filled')
                }
                if (parent.closest('.js--container-block')
                  && parent.closest('.js--container-block').querySelector('.js--required-error')) {
                  parent.closest('.js--container-block').querySelector('.js--required-error').classList.add('display-none')
                }
                if (parent.closest('.js--for-clear-field')) {
                  parent.closest('.js--for-clear-field').classList.remove('input_error')
                }

                const time_data_loan = (parseInt(dates.selectedYear) * 12) + (parseInt(dates.selectedMonth)+1)
                key_word_this.$emit('sendTimeDataLoan',time_data_loan)


                key_word_this.$emit('sendDateLoanReceipt',[dates.selectedMonth,dates.selectedYear])
                this.modalIsOpen=false
              }
            }
            dates.type = 'year'
          },
          clickYear(event, self) {
            const selectedYear = self.selectedYear;
            self.type = 'month'
            self.settings.selected.year = selectedYear
          },
        }
      })
      this.calendar.init();
    },
    CalendarVanillaClose() {
      let count = 0;
      const handler = () => {
        const array_parent = document.querySelectorAll('.js--credit-calendar-input');
        const array_element = document.querySelectorAll('.js__vanilla-calendar-calc.active');
        for (const item of array_parent) {
          item.onclick = function (w) {
            w.stopImmediatePropagation();
          };
        }
        if (count > 0) {
          for (let i = 0; i < array_element.length; i++) {
            array_element[i].classList.remove('active');
          }
        }
        if (count < 1) {
          count += 1;
        }
      };
      document.body.addEventListener('click', handler);
    },
    changeDate(e) {
      const target = e.target;
      if (target.value.length >0) {
        if (target.closest('.js--container-block')
          && target.closest('.js--container-block').querySelector('.js--required-error')) {
          target.closest('.js--container-block').querySelector('.js--required-error').classList.add('display-none');
        }
        if (target.closest('.js--for-clear-field')) {
          target.closest('.js--for-clear-field').classList.remove('input_error');
        }

        if (target.classList.contains('js-mor-required')) {
          target.classList.add('js-filled');
        }
      }
      let value = target.value.replace(/[^\d.]/g, '');
      let parts = value.split('.')
      let monthPart = parts[0].substring(0,2);
      let yearPart = parts[1] ? parts[1].substring(0,4) : '';

      let newValue = monthPart;
      if (monthPart.length>=2 || (parts.length > 1 && yearPart.length > 0)) {
        newValue += '.' + yearPart
      }
      if (newValue !== target.value) {
        const cursorPos = target.selectionStart;
        target.value = newValue;
        target.setSelectionRange(cursorPos, cursorPos)
      }

      if (target.value.length === 3 && newValue[2] === '.') {
        target.setSelectionRange(3,3)
      }

      if (target.value.replace(/(_|\s)+/g, "").length===7) {
        let [monthStr, yearStr] = e.target.value.split('.')
        let month = parseInt(monthStr, 10) || 0;
        let year = parseInt(yearStr, 10) || 0;
        if (month < 1 || month >12) month = Math.min(Math.max(month, 1), 12);

        if (year < this.minDate.year) {
          year = this.minDate.year;
          month = this.minDate.month;
        } else if (year >this.maxDate.year) {
          year = this.maxDate.year;
          month = this.maxDate.month
        }
        if (year === this.minDate.year) month = Math.max(month, this.minDate.month);
        if (year === this.maxDate.year) month = Math.min(month, this.maxDate.month);
        const current = {month,year};
        if (this.dateToNumber(current) < this.dateToNumber(this.minDate)) {
          Object.assign(current,this.minDate);
        } else if (this.dateToNumber(current) > this.dateToNumber(this.maxDate)) {
          Object.assign(current,this.maxDate);
        }
        e.target.value = this.formatDate(current.month, current.year)
        e.target.setAttribute('data-calendar',`[${current.month},${current.year}]`)

        // this.$emit('sendDateLoanReceipt',[current.month,current.year])


      }

      if (target.value.replace(/(_|\s)+/g, "").length===7) {

        const month = parseInt(target.value.replace(/(_|\s)+/g, "").substr(0, 2) -1);
        const year = target.value.replace(/(_|\s)+/g, "").substr(3, 6)


        this.calendar.destroy()
        this.calendar=null
        this.initPluginCalendarVanillaData(month,year)
        this.$emit('sendDateLoanReceipt',[month,parseInt(year)])




        setTimeout(()=>{
          target.closest('.js--credit-calendar-input').querySelector('.js__vanilla-calendar-calc').classList.remove('active')
        },300)

      }
    },
    inputKeyDown(e){
      const target = e.target;
      if (e.key === 'Backspace' && target.selectionStart === 3) {
        target.setSelectionRange(2,2)
      }
    },
    replaceMonthFocusNew(e){
      let element;
      if (e instanceof Event) {
        element = e.currentTarget;
      }
      else if(e instanceof HTMLElement ) {
        element = e;
      }
      const currentValue = element.value;
      const parts = currentValue.split(', ');

      if (parts.length === 2) {
        const [monthName, year] = parts;
        const monthIndex = this.month.indexOf(monthName)
        if (monthIndex !== -1 && year.length === 4) {
          element.value = `${String(monthIndex + 1).padStart(2, '0')}.${year}`;
        }
      }
    },
    inputBlur(e){
      const target = e.target;
      let [monthStr, yearStr] = e.target.value.split('.')
      let month = parseInt(monthStr, 10) || 0;
      let year = parseInt(yearStr, 10) || 0;
      if (!monthStr || !yearStr || monthStr.length !==2 || yearStr.length!==4) {
        e.target.value = ''
        if (target.classList.contains('js-mor-required')) {
          target.classList.remove('js-filled');
        }
        if (target.closest('.js--for-clear-field')) {
          target.closest('.js--for-clear-field').querySelector('.js--clear-calc-tax').classList.remove('active')
        }
      } else {

        if (target.closest('.js--container-block')
          && target.closest('.js--container-block').querySelector('.js--required-error')) {
          target.closest('.js--container-block').querySelector('.js--required-error').classList.add('display-none');
        }
        if (target.closest('.js--for-clear-field')) {
          target.closest('.js--for-clear-field').classList.remove('input_error');
        }

        if (target.classList.contains('js-mor-required')) {
          target.classList.add('js-filled');
        }


        const time_data_loan = (parseInt(year) * 12) + parseInt(month)
        this.$emit('sendTimeDataLoan',time_data_loan)





      }
      this.replaceMonthNew(target)
    },
    formatDate(month, year){
      return `${String(month).padStart(2, '0')}.${String(year).padStart(4,'0')}`
    },
    dateToNumber(date){
      return date.year * 12 + (date.month - 1);
    },

    //ДОПОЛНИТЕЛЬНО
    showCalendar(el) {
      const element = el.currentTarget;
      const calendars = document.querySelectorAll('.js__vanilla-calendar-calc');

      calendars.forEach(calendar => calendar.classList.remove('active'));

      const calendar = element.closest('.js--credit-calendar-input')
        .querySelector('.js__vanilla-calendar-calc');
      calendar.classList.add('active');
      this.activeCalendar = calendar;


      // Для мобильных: добавляем обработчик клавиатуры
      if (this.isMobile) {
        this.addViewportListener();
      }
    },
    addViewportListener() {
      // Убедимся, что обработчик только один
      this.removeViewportListener();

      this.viewportHandler = () => {
        if (!this.activeCalendar) return;
        this.$nextTick(() => {
          this.scrollCalendarIntoView();
        });
      };

      // Используем visualViewport для мобильных устройств
      if (window.visualViewport) {
        window.visualViewport.addEventListener('resize', this.viewportHandler);
      }
    },
    removeViewportListener() {
      if (this.viewportHandler && window.visualViewport) {
        window.visualViewport.removeEventListener('resize', this.viewportHandler);
        this.viewportHandler = null;
      }
    },
    scrollCalendarIntoView() {
      if (!this.activeCalendar || !window.visualViewport) return;

      const calendarRect = this.activeCalendar.getBoundingClientRect();
      const viewportHeight = window.visualViewport.height;
      const calendarBottom = calendarRect.bottom - window.visualViewport.offsetTop;

      // Если календарь скрыт клавиатурой
      if (calendarBottom > viewportHeight) {
        // Вычисляем необходимую величину скролла
        const scrollOffset = calendarBottom - viewportHeight + 10;
        window.scrollBy({
          top: scrollOffset,
          behavior: 'smooth'
        });
      }
    },
    handleDocumentClick(e) {
      // Закрытие календаря при клике вне его области
      if (
        this.activeCalendar &&
        !e.target.closest('.js__vanilla-calendar-calc') &&
        !e.target.closest('.js--calendar-field')
      ) {
        this.activeCalendar.classList.remove('active');
        this.activeCalendar = null;
        this.removeViewportListener();
      }
    },
    resetCalendar() {
      if (this.calendar) {
        try {
          this.calendar.destroy();
        } catch (e) {
          console.warn('Error destroying calendar:', e);
        }
        this.calendar = null;
      }

      // Небольшая задержка перед повторной инициализацией
      setTimeout(() => {
        this.initPluginCalendarVanillaData();
      }, 50);
    },
    inputMaskData() {
      const key = this
      if(this.imask) this.imask.destroy()
      this.imask = IMask(this.$refs.inputData, {
        mask: 'MM.YYYY',
        blocks: {
          MM: {
            mask: IMask.MaskedRange,
            from: 1,
            to: 12,
            // maxLength: 2,
            autofix:true
          },
          YYYY: {
            mask: IMask.MaskedRange,
            from: this.minYear,
            to: this.maxYear,
            autofix:true
            // maxLength: 4
          }
        }
      });
      this.imask.on('accept', () => {
        this.rawValue = this.imask.value
        this.correctDate()
      })
      this.imask.on('complete', () => {

        if (this.imask.value!==this.lastValueOnFocus){

          if (this.imask.value !==this.originalValue && this.modalIsOpen){
            setTimeout(() => {
              this.$refs.inputData.closest('.js--credit-calendar-input')
                .querySelector('.js__vanilla-calendar-calc')
                .classList
                .remove('active')
            }, 400)
            this.modalIsOpen=false
          }

          const month = parseInt(this.imask.value.replace(/(_|\s)+/g, "").substr(0, 2) -1);
          const year = this.imask.value.replace(/(_|\s)+/g, "").substr(3, 6)
          this.calendar.destroy()
          this.calendar=null
          this.initPluginCalendarVanillaData(month,year)
          this.$emit('sendDateLoanReceipt',[month,year])
          // setTimeout(() => {
          //   this.$refs.inputData.closest('.js--credit-calendar-input')
          //     .querySelector('.js__vanilla-calendar-calc')
          //     .classList
          //     .remove('active')
          // }, 400)
        }
      })
    },
    correctDate(){
      if (!this.imask.masked.isComplete) return
      let [month, year] = this.imask.value.split('.').map(Number)
      let newYear = Math.max(this.minYear, Math.min(this.maxYear, year))
      let newMonth = month;

      if (newYear ===this.minYear ) {
        newMonth = Math.max(this.minMonth, Math.min(12, newMonth))
      } else if (newYear ===this.maxYear) {
        newMonth = Math.max(1, Math.min(this.maxMonth, newMonth))
      } else {
        newMonth = Math.max(1, Math.min(12, newMonth))
      }

      if(newYear !== year || newMonth !==month) {
        const formattedDate = `${String(newMonth).padStart(2,'0')}.${String(newYear).padStart(4,'0')}`
        this.imask.value = formattedDate
        this.$nextTick(() => this.$emit('input',formattedDate))
      }



    },
    handleInput(){
      this.$emit('input', this.imask.value)
    },
    replaceMonthNewNew(e){
      let element;
      if (e instanceof Event) {
        element = e.currentTarget;
      }
      else if(e instanceof HTMLElement ) {
        element = e;
      }

      if (element.closest('.js--container-block')
        && element.closest('.js--container-block').querySelector('.js--required-error')) {
        element.closest('.js--container-block').querySelector('.js--required-error').classList.add('display-none');
      }
      if (element.closest('.js--for-clear-field')) {
        element.closest('.js--for-clear-field').classList.remove('input_error');
      }

      const [month,year] = this.rawValue.split('.')
      if(month && year && year.length === 4) {
        const monthNum = parseInt(month, 10);
        if (monthNum >=1 && monthNum <=12) {
          this.formattedValue = `${this.month[monthNum - 1]}, ${year}`;
          this.$refs.inputData.value = this.formattedValue;
        }
        if (element.classList.contains('js-mor-required')) {
          element.classList.add('js-filled');
        }
      }
      if (this.rawValue.length!==7) {
        // this.$refs.inputData.value = '';
        if (element.classList.contains('js-mor-required')) {
          element.classList.remove('js-filled');
        }
        if (element.closest('.js--for-clear-field')) {
          element.closest('.js--for-clear-field').querySelector('.js--clear-calc-tax').classList.remove('active')
        }
      }
    },
    replaceMonthNew(e) {
      let element;
      if (e instanceof Event) {
        element = e.currentTarget;
      }
      else if(e instanceof HTMLElement ) {
        element = e;
      }

      const value = element.value.trim();
      const parts=value.split('.')
      if (parts.length!==2) return;
      const monthPart = parts[0].trim()
      const yearPart = parts[1].trim()
      const monthNumber = parseInt(monthPart,10)
      if (isNaN(monthNumber) || monthNumber < 1 ||monthNumber > 12) return;
      element.value = `${this.month[monthNumber - 1]}, ${yearPart}`;
    },
    replaceMonthNewFocus(e){
      this.originalValue = this.imask.value
      this.lastValueOnFocus = this.imask.value
      this.isReadonly = false;
      let raw = '';
      const currentValue = this.$refs.inputData.value;

      const parts = currentValue.split(', ');

      if (parts.length === 2) {
        const [monthName, year] = parts;
        const monthIndex = this.month.indexOf(monthName)
        if (monthIndex !== -1 && year.length === 4) {
          raw = `${String(monthIndex + 1).padStart(2, '0')}.${year}`;
        }

      }
      this.rawValue = raw;
      // this.inputMaskData();
      // this.$nextTick(() => {
      //   this.imask.value = this.rawValue;
      // })
    },
    getMonthName(month) {
      return this.month[month - 1] ||'...';
    }
  },
  beforeDestroy() {
    document.removeEventListener('click', this.handleDocumentClick);
    this.removeViewportListener();
  },
  mounted(){
    this.$nextTick(() => {
      //Дополнительно
      this.isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
      // Обработчик закрытия календаря
      document.addEventListener('click', this.handleDocumentClick);
      this.initPluginCalendarVanillaData();
      this.CalendarVanillaClose();

      if(this.answers.length > 0 && this.answers[0]){
        if(this.answers[0].dateReceipt) {
          const dateReceipt = JSON.parse(this.answers[0].dateReceipt);

          // Уничтожаем предыдущий календарь и инициализируем с нужной датой
          if (this.calendar) {
            this.calendar.destroy();
            this.calendar = null;
          }

          this.initPluginCalendarVanillaData(dateReceipt[0], dateReceipt[1]);

          // Устанавливаем значение в input
          this.$refs.inputData.value = `${String(dateReceipt[0] + 1).padStart(2, '0')}.${dateReceipt[1]}`;
          this.$refs.inputData.setAttribute('data-calendar', `[${dateReceipt[0]},${dateReceipt[1]}]`);

          if (this.$refs.inputData.classList.contains('js-mor-required')) {
            this.$refs.inputData.classList.add('js-filled');
          }

          this.replaceMonthNew(this.$refs.inputData);
          this.$emit('sendDateLoanReceipt', [dateReceipt[0], dateReceipt[1]]);
          this.fieldNotEmpty(this.$refs.inputData);
        }
      }
    });
  },
  computed:{

  },

  watch:{

  },
  components:{

  },
  created(){
  //  Тут помещаюстя Шина событий
    eventBus.$on('emitClearCalendarHolidaysPayment', () => {
      this.resetCalendar()
      // this.initPluginCalendarVanillaData()
    })



  }
};
</script>
<style scoped>
</style>
