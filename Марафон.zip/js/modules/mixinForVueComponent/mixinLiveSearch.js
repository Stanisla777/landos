/* eslint-disable */
// родитель с блоком поиском должен иметь класс .js--search-container,
// пукты по которым идёт поиск должны иметь класс js--searh-item
// пример html housing-cooperative-request.pug
// подключение миксина izhs-send-form.js
export default {
  props: {
  },
  data() {
    return {
    };
  },
  watch: {
  },
  created() {
  },
  methods: {
    // eslint-disable-next-line camelcase
    sampleliveSearch(input_search) {
      const parent = input_search.closest('.js--search-container');
      if (parent) {
        // const val = input_search.getAttribute('data-search');
        const val = input_search.value;
        // eslint-disable-next-line camelcase
        const array_label = parent.querySelectorAll('.js--searh-item');
        for (let i = 0; i < array_label.length; i++) {
          const reg = new RegExp(val, 'gi');
          const text = array_label[i].textContent;

          if (!array_label[i].classList.contains('js--select-item-checkbox')){
            const box = array_label[i];
            let text_box = box.innerHTML;
            text_box = text.replace(/(<span class="highlight">|<\/span>)/gim, '');
            box.innerHTML = text_box.replace(reg, '<span class="highlight">$&</span>');
          }

          if (text.match(reg)) {
            array_label[i].style.display = 'block';
            array_label[i].classList.add('active');
          } else {
            array_label[i].style.display = 'none';
            array_label[i].classList.remove('active');
          }
        }
        // eslint-disable-next-line max-len,camelcase
        const array_label_active = parent.querySelectorAll('.js--searh-item.active');
        // eslint-disable-next-line camelcase
        const array_error = parent.querySelectorAll('.js--search-error');
        if (array_label_active.length === 0) {
          // eslint-disable-next-line no-shadow,no-undef,camelcase
          const wrapper_list = parent.querySelector('.js--select-list');

          if (array_error.length === 0) {
            // eslint-disable-next-line camelcase
            const element_error = document.createElement('li');
        // eslint-disable-next-line max-len
            element_error.classList.add('select__list-item', 'js--search-error', 'error');
            element_error.innerHTML += 'Ничего не найдено';
            wrapper_list.append(element_error);
          }
        } if (array_label_active.length !== 0 && array_error.length !== 0) {
          // eslint-disable-next-line no-undef
          parent.querySelector('.js--search-error').remove();
        }
      }
    },
  },
  mounted() {
  }
};
