/* eslint-disable */
export default function atBeesender() {
  const i = setInterval(() => {
    const btn = document.querySelector('.body-another-thing #beesenderchat-widget-startbutton')
    const close = document.querySelector('.body-another-thing #beesenderchat-closebutton')
    let step = 0;
    if(btn){
      clearInterval(i);

      btn.addEventListener('click', (el)=> {
        const element = el.currentTarget
        const data_atrr = element.closest('.beesender-chat-at').getAttribute('data-user')
        if(data_atrr!==null&&step===0){

          if(data_atrr!==''){
            ym(47257560, 'reachGoal', 'btn_chat_auth',{userId: data_atrr})
          }
          else {
            ym(47257560, 'reachGoal', 'btn_chat_no_auth',{userId: null})
          }
          step+=1
        }


        document.body.classList.add('body-modal-bs')
        document.ontouchmove = (e) => {
          e.preventDefault();
        };
      })
      if(close){
        close.addEventListener('click', () => {

          document.body.classList.remove('body-modal-bs');
          document.ontouchmove =  (e)=> {
            return true;
          }

        });
      }
    }

  })




}
