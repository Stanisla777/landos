<template lang="pug">
  div.slider-stories
    template
      slider-main-page-stories(
        v-on:eventopenModal="openModal"
      )
    template
      stories-modal(
        v-if="massive_carousels_slider.status==true||massive_carousels_slider.status=='open'"
        v-on:eventcloseModal="closeModal"
      )

</template>
<script>
import eventBus from './development-tools/eventBus.vue';
import Storage from './development-tools/state.vue';

import sliderMainPageStories from './components/SliderMainPageStories.vue';
import storiesModal from './components/ModalWindow.vue';

export default {
  name: 'vStories',
  data(){
    return {
      modal_show:false,
      modal:'jjj'
    }
  },
  methods:{
    callingCallToAPI(){
      Storage.dispatch('axiosGetParametr')
    },
    openModal(){
      this.modal_show=true
      document.body.classList.add('body-modal')
    },
    closeModal(){
      this.modal_show=false
      document.body.classList.remove('body-modal')
    },



  },
  mounted(){
    const block_stories = document.querySelector('.block-stories')
    if(block_stories){
      setTimeout(()=>{
        block_stories.classList.add('active')
      },1000)
    }
    this.callingCallToAPI()

  },
  computed:{
    massive_carousels_slider(){
      return Storage.getters.MASSIVECAROUSELSSLIDERCLICK
    },
  },
  created(){
    // eventBus.$on('eventcheckboxChanged',(param)=>{
    //   this.other_means=param
    // })
  },
  watch:{
  },
  components:{
    sliderMainPageStories,
    storiesModal
  }
};
</script>
<style scoped>
</style>
