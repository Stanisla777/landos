<template lang="pug">
  div.block-stories
    template
      block-stories

</template>
<script>
const BlockStories = () => import ("./Stories.vue");


export default {
  name: 'StoriesPointEntry',
  data(){
    return {

    }
  },
  methods:{
  },
  mounted(){
  },
  computed:{
  },
  watch:{
  },
  components:{
    BlockStories
  }
};
</script>
<style scoped>
</style>
