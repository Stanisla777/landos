function hoverColorSquare() {
  // eslint-disable-next-line camelcase
  const color_square = document.querySelector('.header__logo-colored-square');
  // eslint-disable-next-line camelcase
  if (color_square) {
    // eslint-disable-next-line func-names
    color_square.onmouseover = function () {
      this.classList.remove('unactive');
      this.classList.add('active');
      this.querySelector('.header__logo-colored-square-item:first-child').classList.add('active');
      this.querySelector('.header__logo-colored-square-item:nth-child(2)').classList.add('active');
      this.querySelector('.header__logo-colored-square-item:nth-child(3)').classList.add('active');
      this.querySelector('.header__logo-colored-square-item:nth-child(4)').classList.add('active');
    };
    // eslint-disable-next-line func-names
    color_square.onmouseout = function () {
      this.classList.remove('active');
      this.querySelector('.header__logo-colored-square-item:first-child').classList.remove('active');
      this.querySelector('.header__logo-colored-square-item:nth-child(2)').classList.remove('active');
      this.querySelector('.header__logo-colored-square-item:nth-child(3)').classList.remove('active');
      this.querySelector('.header__logo-colored-square-item:nth-child(4)').classList.remove('active');
    };
  }
}
function sideBar() {
  const button = document.querySelector('.header__logo-colored-square');
  const sidebar = document.querySelector('.sidebar-directions');
  const close = document.querySelector('.sidebar-directions__close');
  // eslint-disable-next-line camelcase
  const lean_overlay = document.querySelector('#lean_overlay');
  if (button && sidebar) {
    // eslint-disable-next-line func-names
    button.onclick = function () {
        sidebar.classList.add('active');
        lean_overlay.setAttribute('style', 'display:block');
        if (!document.body.classList.contains('body-additional-class')) {
          document.body.classList.add('body-modal');
        }
    };
  }
  if (close && sidebar) {
    // eslint-disable-next-line func-names
    close.onclick = function () {
      sidebar.classList.remove('active');
      lean_overlay.setAttribute('style', 'display:none');
      if (!document.body.classList.contains('body-additional-class')) {
        document.body.classList.remove('body-modal');
      }
    };
  }
  // eslint-disable-next-line camelcase,no-empty
  if (lean_overlay && sidebar) {
    // eslint-disable-next-line func-names
    lean_overlay.onclick = function () {
        sidebar.classList.remove('active');
        lean_overlay.setAttribute('style', 'display:none');
      if (!document.body.classList.contains('body-additional-class')) {
        document.body.classList.remove('body-modal');
      }
    };
  }
}
export default function leftSideBar() {
  hoverColorSquare();
  sideBar();
}
