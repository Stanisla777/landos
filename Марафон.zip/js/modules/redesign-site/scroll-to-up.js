/* eslint-disable */

// Функция плавности easeInOutCubic
function easeInOutCubic(t) {
  return t < 0.5
    ? 4 * t * t * t
    : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

export default function scrollToUp() {
  const scrollBtn = document.querySelector('.js--btn-to-up');
  if (scrollBtn) {
    scrollBtn.style.opacity = window.scrollY > 300 ? '1' : '0';
    window.addEventListener('scroll', () => {
      scrollBtn.style.opacity = window.scrollY > 300 ? '1' : '0';
    });
    // Плавная прокрутка к верху
    scrollBtn.addEventListener('click', () => {
      const duration = 800; // Длительность анимации в мс
      const start = window.scrollY;
      const startTime = performance.now();

      function scrollStep(timestamp) {
        const elapsed = timestamp - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const ease = easeInOutCubic(progress);

        window.scrollTo(0, start - start * ease);

        if (progress < 1) {
          requestAnimationFrame(scrollStep);
        }
      }

      requestAnimationFrame(scrollStep);
    });
  }
}

