/* eslint-disable */
export default function arrowSlider(el) {
  if (el.el.closest('.general-style-slider') && el.el.closest('.general-style-slider').querySelector('.js--slider-arrow')) {
    const array = el.el.closest('.general-style-slider').querySelectorAll('.swiper-button-disabled');
    if(array.length ===2) {
      el.el.closest('.general-style-slider').querySelector('.js--slider-arrow').classList.add('unactive')
    }
    else {
      el.el.closest('.general-style-slider').querySelector('.js--slider-arrow').classList.remove('unactive')
    }
  }

}
