/* eslint-disable */
import AddClassBody from './disallow-body-scrolling';

export default function bodyLockMobileFilter(el) {
  const dropDownList = el.querySelector('.js--openlist-body');
  if (dropDownList) {
    const styles = window.getComputedStyle(dropDownList);
    if (styles.position === 'fixed') {
      AddClassBody();
    }
  }
}

