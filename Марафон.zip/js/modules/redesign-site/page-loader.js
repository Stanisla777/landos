/* eslint-disable */
export default function pageLoader() {
  const loader = document.querySelector('.js--preloader');
  if (loader) {
    setTimeout(() => {
      loader.classList.remove('active');
    },3000)
  }
}
