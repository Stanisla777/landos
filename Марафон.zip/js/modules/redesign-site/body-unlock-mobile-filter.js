/* eslint-disable */
import RemoveClassBody from './allow-body-scrolling';

export default function bodyUnlockMobileFilter(el) {
  const dropDownList = el.querySelector('.js--openlist-body');
  if (dropDownList) {
    const styles = window.getComputedStyle(dropDownList);
    if (styles.position === 'fixed') {
      RemoveClassBody();
    }
  }
}

