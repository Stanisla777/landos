<template lang="pug">
  div
    template
      test-n-entry(
        :userId="userId"
        :idTask="idTask"

      )

</template>
<script>
import Storage from './development-tools/state.vue';
const TestNEntry = () => import ("./TestNEntry.vue");


export default {
  name: 'TestNEntryPointEntry',
  data(){
    return {
      userId:null,
      idTask:null,
      dataOpen:null,
      dataState:null
    }
  },
  methods:{

  },
  mounted(){
    if (this.$attrs.dataopen){
      // this.dataOpen = this.$attrs.dataopen
      Storage.dispatch('ActionStatusTest',parseInt(this.$attrs.dataopen))
    }
    if (this.$attrs.datastate){
      Storage.dispatch('ActionStateTest',parseInt(this.$attrs.datastate))
    }
    if (this.$attrs.datanickname){
      Storage.dispatch('ActionNickName',this.$attrs.datanickname)
    }

    if (this.$attrs.userid){
      this.userId = this.$attrs.userid
    }
    if (this.$attrs.id){
      this.idTask = this.$attrs.id
    }
    let marathon_page_url = this.$el.getAttribute('data-marathonpageurl')
    if (marathon_page_url){
      try{
        Storage.dispatch('ActionMarathonPageUrl',marathon_page_url)
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }

    let marathon_vk_url = this.$el.getAttribute('data-vkappurl')
    if (marathon_vk_url){
      try{
        Storage.dispatch('ActionMarathonVkUrl',marathon_vk_url)
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }



  },
  computed:{
  },
  watch:{
  },
  components:{
    TestNEntry
  }
};
</script>
<style scoped>
</style>
