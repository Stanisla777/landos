<template lang="pug">
  .test-a__slider-btn-container
    .test-a__slider-btn(
      v-if="modal===true"
    )

      .btn_s.black(
        v-if="btn_next&&((status_internet===true&&status_btn===false)||(status_internet===false&&status_btn===false)||(status_internet===true&&status_btn===true)) &&time_end!==true"
        @click="btnNext"
      ) Ответить
      .btn_s.black.disabled(
        v-if="!btn_next||((status_btn&&status_internet===false) ) ||time_end===true "
      ) Ответить
      .btn_s.transparent_black_border(
        v-if="time_end&&count_question!==current_slide"
        @click="btnNext"
      ) Следующий вопрос
      .btn_s.transparent_black_border(
        v-if="time_end&&count_question===current_slide"
        @click="btnNext"
      ) Завершить тест
    p.test-a__error-hint(v-if="status_internet===false") Нет интернета
    p.test-a__error-hint(v-if="error_sand_variant") {{error_sand_variant_text}}
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';

export default {
  name: 'buttom',
  props:['modal','status_internet','btn_next','status_btn','btn_prev','error_sand_variant','error_sand_variant_text'],
  data(){
    return {


    }
  },
  methods: {
    btnNext(){
      this.count=0
      Storage.dispatch('ActionSendVariantPost')
      eventBus.$emit('eventbtnNext')
    },
  },
  computed: {
    time_end() {
      return Storage.getters.TIMEEND;
    },
    count_question(){
      return Storage.getters.COUNTQUESTION
    },
    current_slide(){
      return Storage.getters.CURRENTSLIDE
    },


  },
  mounted() {
  },
};
</script>
<style scoped>
</style>
