// eslint-disable-next-line no-unused-vars
import IMask from 'imask';

export function checkStatusPinInput() {
  // eslint-disable-next-line camelcase,no-unused-vars
  const input_status = document.querySelectorAll('.js--status-input'); // относится к моему
  const inputs = document.querySelectorAll('.js--pin-input');// не относится к моему
  const inputsArray = [...inputs];// не относится к моему
  const hiddenInput = document.querySelector('.js--pin-input-hidden');
  const buttonStepTwo = document.querySelector('.js--check-status-button-step-2');
  input_status.forEach((item) => {
    const input = item;
    // eslint-disable-next-line no-unused-vars
    input.addEventListener('input', (event) => {
      const targetVal = event.target;
      const position = targetVal.selectionStart; // Capture initial position
      // console.log(position);
      targetVal.selectionEnd = position;
    });
  });
  inputsArray.forEach((item) => {
    const input = item;
    input.addEventListener('keydown', (e) => {
      if (e.keyCode !== 13) {
        input.value = '';
      }
    });

    input.addEventListener('keyup', (e) => {
      const { value } = e.target;
      const nextInput = inputsArray[inputsArray.indexOf(input) + 1];
      const prevInput = inputsArray[inputsArray.indexOf(input) - 1];
      const lastInput = inputsArray.indexOf(input) === 3;
      const enterOnLastInput = e.keyCode === 13 && lastInput;
      if (e.keyCode === 8) {
        input.value = '';
        if (prevInput) {
          prevInput.focus();
        }
      }
      if (enterOnLastInput) {
        e.target.blur();
        buttonStepTwo.click();
      }
      if (value === value.replace(/[0-9]/, '')) {
        input.value = '';
        return false;
      }
      if (nextInput) {
        nextInput.focus();
      }

      let fullval = '';
      inputsArray.forEach((i) => {
        fullval += (parseInt(i.value, 10) || '0');
      });
      hiddenInput.value = fullval;
    });
  });
}

export function checkStatusValidation() {
  // eslint-disable-next-line no-unused-vars
  [].forEach.call(document.querySelectorAll('.js--status-input'), (input) => {
    const buttonStepOne = document.querySelector('.js--check-status-button-step-1');

    // eslint-disable-next-line no-restricted-globals
    function mask(event) {
      if (!(event.keyCode)) {
        // eslint-disable-next-line no-undef,no-unused-vars
        const { keyCode } = event;
      }
      if (event.type === 'blur' && this.value.length < 5) {
        this.value = '';
      }
      if (buttonStepOne && event.keyCode === 13) {
        event.target.blur();
        buttonStepOne.click();
      } // это нужно, чтобы клик внутри инпута считался кликом по кнопке
      // eslint-disable-next-line eqeqeq
    }

    input.addEventListener('input', mask, false);
    input.addEventListener('focus', mask, false);
    input.addEventListener('blur', mask, false);
    input.addEventListener('keydown', mask, false);
  });
  // eslint-disable-next-line camelcase
  const input_status = document.querySelectorAll('.js--status-input');

  // Маска, где пользователь мог вбивать е
  // const maskOptions = {
  //   mask: '[#]00000.00.0000',
  //   definitions: {
  //     '#': /['e','E','е','Е']/
  //   },
  //   lazy: true
  // };

  // Маска, только с числами
  const maskOptions = {
    mask: '00000.00.0000',
    lazy: true
  };

  // eslint-disable-next-line no-restricted-syntax,camelcase,no-undef
  for (const item of input_status) {
    // eslint-disable-next-line no-new
    new IMask(item, maskOptions);
  }
}

export function checkStatusTimer() {
    const timeout = 60;
    const timerPane = document.querySelector('.js--timer');
    const additionalBlocks = document.querySelectorAll('.js--timer-additional');
    const additionalBlocksArray = [...additionalBlocks];
    if (!timerPane) return false;
    let timeLeft = parseInt(timerPane.innerHTML, 10);

    if (timeLeft === 1) {
        timerPane.innerHTML = timeout;

        timerPane.style.display = 'inline';
        additionalBlocksArray.forEach((item) => {
            const block = item;
            block.style.display = 'inline';
        });

        checkStatusTimer();
    } else if (timeLeft === timeout) {
        const timer = setInterval(() => {
            if (--timeLeft > 0) {
                timerPane.innerHTML = timeLeft;
            } else {
                timerPane.style.display = 'none';
                additionalBlocksArray.forEach((item) => {
                    const block = item;
                    block.style.display = 'none';
                });
                clearInterval(timer);
            }
        }, 1000);
    }
}
