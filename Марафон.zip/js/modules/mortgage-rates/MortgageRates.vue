<template  lang="pug">
  div
    template
      v-container-tabs
    .v-mortgage__container-rates
      template
        v-container-common-rate

      template
        v-container-separate-rate
</template>
<script>
import Vue from 'vue';
import Storage from './development-tools/state.vue';

import vContainerTabs from './components/v-component-container-tabs.vue';
import vContainerCommonRate from './components/v-component-container-common-rate.vue';
import vContainerSeparateRate from './components/v-component-container-separate-rate.vue';

export default {
  name: 'MortgageRates',
  data(){
    return {
    }
  },
  methods:{


  },
  mounted(){
    document.onreadystatechange = () => {
      if (document.readyState == "complete") {

        // const bunner = document.querySelector('.v-mortgage__wrap-bunner')
        // const wrapper = document.querySelector('.v-mortgage__container-separate-rate')
        // debugger
        // if(bunner&&wrapper){
        //   wrapper.append(bunner)
        //   bunner.setAttribute('style','display:block')
        // }
      }
    }

  },
  computed:{

  },
  watch:{
  },
  components:{
    vContainerTabs,
    vContainerCommonRate,
    vContainerSeparateRate
  },


  created() {

  }
};
</script>
<style scoped>
</style>
