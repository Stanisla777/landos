<template>
</template>
<script>
export default {
  name: 'shedule',
  data(){
    return {
      //То что не работает но со стилями правильными
      chartOptions: {
        xaxis: {
          categories: this.props_common_name_month_half_year,
          labels:{
            show: false,
            rotate: 0,
            rotateAlways: false,
            trim: true
          },
          tooltip:{
            enabled: false
          }
        },
        yaxis: {
          tickAmount: 8,
          labels:{
            show: false
          }
        },
        grid: {
          borderColor: '#b1b4ba',
          strokeDashArray: 2,
          xaxis: {
            lines: {
              show: true
            }
          }, //линии пересечения на графике
          yaxis: {
            lines: {
              show: true
            }

          },
          row: {
          },
          column: {
          }
        },
        tooltip: {
          enabled: true,
          fixed: {
            enabled: true,
            position: 'topRight',
            // offsetX: 0,
            // offsetY: 0,
          },
        },
        fill: {
          colors: ['#b8b9ba', '#e0e1e2', '#eeefef']
        },
        markers: {
          colors: '#000',
          strokeColors: '#8BC540',
          strokeWidth: 0,
          // shape: "square",
          discrete: [],
          radius: 2,
          offsetX: 0,
          offsetY: 0,
          onClick: undefined,
          onDblClick: undefined,
          showNullDataPoints: true,
          hover: {}
        },
        colors: ['#000'],
        chart: {
          toolbar: {
            show: false,
          },
          // id: 'fff',
          animations: {
            speed: 500
          },
          zoom:{
            enabled:false
          },
          type: 'area',
        },
        dataLabels: {
          enabled: false,
        },
        plotOptions: {
          bar: {
            distributed: true
          }
        },
        legend: {
          show: false
        },
        zoom: {
          enabled: false
        },
        stroke: {
          curve: 'straight',
          width: 1,
        }
      },

    }
  }
};
</script>
<style scoped>
</style>
