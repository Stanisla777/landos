<template lang="pug">
  .v-mortgage__schedule.v-mortgage__seperate-schedule
    .v-mortgage__loader-schedule
      img(src="/dist/img/tail-spin.svg")
    .v-mortgage__period-time.js__period-time(@touchmove.stop)
      .v-mortgage__period-time-item.active(data-period="6")(
        @click ="changeDataSchedule"
      ) 6 месяцев
      .v-mortgage__period-time-item(data-period="1")(
        @click ="changeDataSchedule"
      ) год
    div.v-mortgage__container_shedule
      Chart(
        :series="series"
        :options="chartOptions"

      )
      ChartYear(
        :series="series_year"
        :options="chartOptionsYear"
        )
</template>
<script>
import Chart from './LineChart.vue';
import ChartYear from './LineChartYear.vue';
import eventBus from '../development-tools/eventBus.vue';

export default {
  name: 'v-component-schedule-separate',
  props: ['props_rate_year','props_rate_date'],
  data() {
    return {
      //пол-года
      series: [
        {
          data: Object.values(this.props_rate_year).slice(Math.max(Object.values(this.props_rate_year).length - 6, 0))
        }
      ],
      chartOptions: {
        xaxis: {
          categories: this.props_rate_date.slice(Math.max(this.props_rate_date.length - 6, 0)),
          labels:{
            show: false,
            rotate: 0,
            rotateAlways: false,
            trim: true
          },
          tooltip:{
            enabled: false
          },
          crosshairs: {
            show: true,
            width: 1,
            position: 'front',
            opacity: 1,
            stroke: {
              color: '#000',
              width: 1,
              dashArray: 0,
            },
            fill: {
              type: 'solid',
              color: '#000',
              gradient: {
                colorFrom: '#000',
                colorTo: '#000',
                stops: [0, 100],
                opacityFrom: 1,
                opacityTo: 1,
              },
            },
            dropShadow: {
              enabled: false,
              top: 0,
              left: 0,
              blur: 1,
              opacity: 1,
            },
          },
        },
        yaxis: {
          decimalsInFloat:1,
          tickAmount: 3,
          labels:{
            show: false
          }
        },
        tooltip: {
          style: {
            fontSize: '24px',
            fontFamily: 'Gilroy-Bold'
          },
          enabled: true,
          fixed: {
            enabled: true,
            position: 'topRight',
          },
          marker: {
            show: false,
          },
          y: {
            formatter: (value) => { return value + "%" },
          },
        },
        fill: {
          colors: ['#c2c5cb', '#dadce2', '#e5e8ef']
        },
        markers: {
          colors: '#000',
          strokeColors: '#8BC540',
          strokeWidth: 0,
          // shape: "square",
          discrete: [],
          radius: 2,
          offsetX: 0,
          offsetY: 0,
          onClick: undefined,
          onDblClick: undefined,
          showNullDataPoints: true,
          hover: {}
        },
        colors: ['#000'],
        chart: {
          redrawOnWindowResize:true,
          redrawOnParentResize: true,
          toolbar: {
            show: false,
          },
          // id: 'fff',
          animations: {
            speed: 200
          },
          zoom:{
            enabled:false
          },
          type: 'area',

        },
        dataLabels: {
          enabled: false,
        },
        plotOptions: {
          bar: {
            distributed: true
          }
        },
        legend: {
          show: false
        },
        zoom: {
          enabled: false
        },
        grid: {
          borderColor: '#6a6969',
          strokeDashArray: 2,
          xaxis: {
            lines: {
              show: true
            }
          }, //линии пересечения на графике
          yaxis: {
            lines: {
              show: true
            }

          },
          row: {
            colors: ['#e5e8ef', '#e5e8ef', '#e5e8ef']
          },
          column: {
            colors: ['#e5e8ef', '#e5e8ef', '#e5e8ef']
          }
        },
        stroke: {
          curve: 'straight',
          width: 1,
        }
      },
      //год
      series_year: [
        {
          data: Object.values(this.props_rate_year)
        }
      ],
      chartOptionsYear: {
        xaxis: {
          categories: this.props_rate_date,
          labels:{
            show: false,
            rotate: 0,
            rotateAlways: false,
            trim: true
          },
          tooltip:{
            enabled: false
          },
          crosshairs: {
            show: true,
            width: 1,
            position: 'front',
            opacity: 1,
            stroke: {
              color: '#000',
              width: 1,
              dashArray: 0,
            },
            fill: {
              type: 'solid',
              color: '#000',
              gradient: {
                colorFrom: '#000',
                colorTo: '#000',
                stops: [0, 100],
                opacityFrom: 1,
                opacityTo: 1,
              },
            },
            dropShadow: {
              enabled: false,
              top: 0,
              left: 0,
              blur: 1,
              opacity: 1,
            },
          },
        },
        yaxis: {
          decimalsInFloat:1,
          tickAmount: 3,
          labels:{
            show: false
          }
        },
        tooltip: {
          enabled: true,
          fixed: {
            enabled: true,
            position: 'topRight',
            // offsetX: 0,
            // offsetY: 0,
          },
          marker: {
            show: false,
          },
          y: {
            formatter: (value) => { return value + "%" },
          },
        },
        fill: {
          colors: ['#c2c5cb', '#dadce2', '#e5e8ef']
        },
        markers: {
          colors: '#000',
          strokeColors: '#8BC540',
          strokeWidth: 0,
          // shape: "square",
          discrete: [],
          radius: 2,
          offsetX: 0,
          offsetY: 0,
          onClick: undefined,
          onDblClick: undefined,
          showNullDataPoints: true,
          hover: {}
        },
        colors: ['#000'],
        chart: {
          toolbar: {
            show: false,
          },
          // id: 'fff',
          animations: {
            speed: 200
          },
          zoom:{
            enabled:false
          },
          type: 'area',
        },
        dataLabels: {
          enabled: false,
        },
        plotOptions: {
          bar: {
            distributed: true
          }
        },
        legend: {
          show: false
        },
        zoom: {
          enabled: false
        },
        grid: {
          borderColor: '#6a6969',
          strokeDashArray: 2,
          xaxis: {
            lines: {
              show: true
            }
          }, //линии пересечения на графике
          yaxis: {
            lines: {
              show: true
            }

          },
          row: {
            colors: ['#e5e8ef', '#e5e8ef', '#e5e8ef']
          },
          column: {
            colors: ['#e5e8ef', '#e5e8ef', '#e5e8ef']
          }
        },
        stroke: {
          curve: 'straight',
          width: 1,
        }
      },
    };
  },

  methods: {

    changeDataSchedule(el) {
      const element = el.currentTarget
      const data = element.getAttribute('data-period')
      if (!element.classList.contains('active')) {
        const parent = element.closest('.js__period-time')
        const arrow_btn = parent.querySelectorAll('.active')
        for (let item of arrow_btn) {
          item.classList.remove('active')
        }
        element.classList.add('active')

        const parent_schedule = element.closest('.v-mortgage__schedule')
        const array_shedule = parent_schedule.querySelectorAll('.v-mortgage__vue-apexcharts')
        for (let item of array_shedule) {
          item.classList.add('event-point')
          parent_schedule.querySelector('.v-mortgage__loader-schedule').classList.add('active')
          setTimeout(()=>{
            item.classList.remove('active');
            const data_period = item.getAttribute('data-period');
            if (data_period === data) {
              item.classList.add('active');
              item.classList.remove('event-point')
              parent_schedule.querySelector('.v-mortgage__loader-schedule').classList.remove('active')
            }
          },1000)
          setTimeout(()=>{
            // item.classList.remove('event-point')
          },2000)
        }
      }
    },

  },
  mounted() {


  },
  computed: {},

  components: {
    Chart,
    ChartYear
  },

};
</script>
<style scoped>
</style>
