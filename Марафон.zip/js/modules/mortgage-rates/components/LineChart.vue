<template  lang="pug">
  //внутри div.v-mortgage__vue-apexcharts было (@mouseover="sheduleHover")
  div.v-mortgage__vue-apexcharts.active(data-period="6")(@mouseover="sheduleHover" @touchmove="toolTip" @touchend="endToolTip")
    .v-mortgage__average_rate_country(@mouseover.stop)
      p.v-mortgage__average_rate_country_day {{options.xaxis.categories[options.xaxis.categories.length - 1]}}
      p.v-mortgage__average_rate_country_rate <span>{{series[0].data[series[0].data.length - 1]}}</span>%
    apexcharts(width='100%' height='100%' :options='options' :series='series')
</template>

<script>
// import VueApexCharts from "vue-apexcharts";
import eventBus from '../development-tools/eventBus.vue';
const VueApexCharts = () => import ("vue-apexcharts");

export default {
  props:['series','options'],
  name: "Chart",
  components: {
    apexcharts: VueApexCharts
  },
  data: function() {
    return {

    };
  },
  methods: {
    sheduleHover(el){
      const element = el.currentTarget
      const parent = document.querySelector('.apexcharts-gridlines-horizontal')
      element.querySelector('.v-mortgage__average_rate_country').classList.add('unactive')
    },
    toolTip(el){
      document.body.classList.add('body-modal')
      const element = el.currentTarget
      if(!element.classList.contains('unactive')){
        element.querySelector('.v-mortgage__average_rate_country').classList.add('unactive')
      }
      else {
        return false
      }
    },
    endToolTip(){
      document.body.classList.remove('body-modal')
    }

  },
  computed:{

  },
  created() {

  },
  mounted() {

  }
};
</script>
