<template lang="pug">

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
export default {
  name: 'v-container-tabs',
  data(){
    return {

    }
  },
  methods:{

  },
  mounted(){

  },
  computed:{},
  watch:{
  },
  components:{}
};
</script>
<style scoped>
</style>
