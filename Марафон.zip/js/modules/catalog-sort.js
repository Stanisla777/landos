export default function catalogSort() {
    let currentNum = 0;
    const sort = document.querySelector('.js--ctlg-srt');

    if (!sort) return;

    sort.addEventListener('click', (e) => {
        if (!(e.target.closest('.js--catalog-sort'))) return;

      e.preventDefault();

        currentNum++;
        if (currentNum === 3) currentNum = 0;

        const sortLinks = e.target.closest('.js--catalog-sort').querySelectorAll('.catalog-sort__item');
        for (let i = 0; i < sortLinks.length; i++) {
            sortLinks[i].classList.remove('show');
            if (i === currentNum) sortLinks[i].classList.add('show');
        }
    });
}
