<template lang="pug">
  .gameddreg__wrapper(
    ref="gamedd_wrapper"
  )
    template
      registration-close

    .gameddreg__mail-notification-true(v-if="user_data_state.MAIL_NOTIFICATION==='success'")
      .gameddreg__finish-alarm-img
        img(src="/dist/img/mail-confirmed.png")
      p.gameddreg__title  Почта подтверждена
      p.gameddreg__sub-title.margin.
        Вы успешно подтвердили свой email
      p.gameddreg__confirmed-mail {{user_data_state.EMAIL}}
      .gameddreg__btn-imail-notification
        a(href="/мысчитаем/личныйкабинет/профиль/").test-a__add-zone-btn.green.test-a__btn Перейти в личный кабинет

    .gameddreg__mail-notification-true(v-if="user_data_state.MAIL_NOTIFICATION==='error_time'")
      .gameddreg__finish-alarm-img
        img(src="/dist/img/mail-error.png")
      p.gameddreg__title  Почта не подтверждена
      p.gameddreg__sub-title.margin.
        Время на подтверждение email истекло, необходимо запросить письмо еще раз
      p.gameddreg__not-confirmed-mail {{user_data_state.EMAIL}}
      p.gameddreg__finish-change-mail(
        @click="changeMail"
      ) Изменить почту
      .gameddreg__btn-imail-notification
        .gameddreg__btn-request(
          @click="sendPost"
        ) Отправить письмо еще раз
        p.gameddreg__input-error.gameddreg__input-error-hint(ref="hintText")

    .gameddreg__mail-notification-true(v-if="user_data_state.MAIL_NOTIFICATION==='error'")
      .gameddreg__finish-alarm-img
        img(src="/dist/img/mail-error.png")
      p.gameddreg__title  Почта не подтверждена
      p.gameddreg__sub-title.margin.
        К сожалению, нам не удалось подтвердить адрес почты. Вы можете запросить письмо еще раз
      p.gameddreg__not-confirmed-mail {{user_data_state.EMAIL}}
      p.gameddreg__finish-change-mail(
        @click="changeMail"
      ) Изменить почту
      .gameddreg__btn-imail-notification
        .gameddreg__btn-request(
          @click="sendPost"
        ) Отправить письмо еще раз
        p.gameddreg__input-error.gameddreg__input-error-hint(ref="hintText")
</template>

<script>
import IMask from 'imask';
import Storage from '../development-tools/state.vue';
import RegistrationClose from './RegistrationClose.vue';
import inputField from '../mixin/inputField';
import axios from 'axios';
let mask;

export default {
  name: 'RegistrationMailNotification',

  props: {


  },
  data() {
    return {
      active_btn:false,
      InputName:'',
      InputSurName:'',
      InputMail:'',
      InputTel:'',
      error:false,
      error_tel:false,
    }
  },

  methods: {
    changeMail(el){
      const element = el.currentTarget
      Storage.dispatch('ActionStep','change_mail_notification')
    },


    sendPost(){
      //как и везде передаю объект
      const obj={}
      obj.EMAIL=this.user_data_state.EMAIL


      axios({
        method:'post',
        // url:'https://httpbin.org/post', //для раЗРАБОТКИ
        url:'/api/local/gamedd/profile/user/',

        headers: {
          "Content-type": "application/json; charset=UTF-8",
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        },
        data:obj
      })
        // Если запрос успешен
        .then((res) => {
          Storage.dispatch('ActionStep','finish')
          this.$refs.hintText.textContent=''
        })
        // Если запрос с ошибкой
        //вот тут в переменную  буду записывать ошибки, которые будет возвращать бэк
        // и в зависимости от неё выводить ошибку(неправильный код и так далее)
        .catch((error)=> {
          if(error.response){
            console.log(error.response);
            if(error.response.data.error!=undefined&&error.response.data.error.description!=undefined){
              this.$refs.hintText.textContent = error.response.data.error.description
            }
          }
        });

    },
  },

  computed: {
    user_data_state(){
      return Storage.getters.USERDATA
    },
  },
  watch: {

  },
  mounted() {

  },
  updated() {

  },
  components:{
    RegistrationClose
  }

}
</script>
