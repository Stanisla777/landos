<template lang="pug">
  .gameddreg__wrapper(
    ref="gamedd_wrapper"
  )
    template
      registration-close
    p.gameddreg__title  Игра доступна только для пользователей Вконтакте
    p.gameddreg__sub-title.gameddreg__sub-title-vk.
      Нажимая «Войти через VK ID», вы даете согласие
      на&nbsp;<a href="/user-agreement/#soglasie-na-obrabotku-personalnykh-dannykh-uchastnikov-onlayn-igry-po-finansovoy-gramotnosti-myschit" target="_blank">обработку персональных данных</a> и&nbsp;соглашаетесь
      с&nbsp;<a href="/мысчитаем/правилаучастия/" target="_blank">правилами игры</a>
    p.gameddreg__sub-title.gameddreg__sub-title-vk.
      Игра доступна участникам сервиса  «Другое Дело». Регистрируясь в&nbsp;личном кабинете игры,
      вы соглашаетесь с&nbsp;<a target="_blank" href="https://drugoedelo.ru/terms">положением</a> программы развития «Другое Дело»


    .gameddreg__btb-to-vk(
      v-if="status_btn"
      @click="buttonPress"
    )

      .gameddreg__btb-to-vk-ic
        svg(width='17', height='10', viewbox='0 0 17 10', fill='none', xmlns='http://www.w3.org/2000/svg')
          path(d='M8.71995 9.99488C3.24995 9.99488 0.13 6.24488 0 0.00488281H2.74C2.83 4.58488 4.84995 6.52488 6.44995 6.92488V0.00488281H9.03005V3.95488C10.6101 3.78488 12.2699 1.98488 12.8299 0.00488281H15.4099C14.9799 2.44488 13.1799 4.24488 11.8999 4.98488C13.1799 5.58488 15.23 7.15488 16.01 9.99488H13.1699C12.5599 8.09488 11.0401 6.62488 9.03005 6.42488V9.99488H8.71995Z', fill='#2D81E0')
      p Войти через VK ID
    .gameddreg__btb-to-vk.unactive(
      v-if="! status_btn"
    ) Войти через VK ID
      .gameddreg__btb-to-vk-ic
        svg(width='17', height='10', viewbox='0 0 17 10', fill='none', xmlns='http://www.w3.org/2000/svg')
          path(d='M8.71995 9.99488C3.24995 9.99488 0.13 6.24488 0 0.00488281H2.74C2.83 4.58488 4.84995 6.52488 6.44995 6.92488V0.00488281H9.03005V3.95488C10.6101 3.78488 12.2699 1.98488 12.8299 0.00488281H15.4099C14.9799 2.44488 13.1799 4.24488 11.8999 4.98488C13.1799 5.58488 15.23 7.15488 16.01 9.99488H13.1699C12.5599 8.09488 11.0401 6.62488 9.03005 6.42488V9.99488H8.71995Z', fill='#2D81E0')

</template>

<script>
import { Config, Connect} from '@vkontakte/superappkit';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import RegistrationClose from './RegistrationClose.vue';

export default {
  name: 'RegistrationLoginViaVK',

  props: ['vk_address','vk_app_id'],
  data() {
    return {
      status_btn:true,
    }
  },
  computed: {

  },
  methods: {
    buttonPress(el){
      const element = el.currentTarget
      // console.log('VK ID авторизация',this.vk_address,this.vk_app_id);
      Config.init({
        appId: this.vk_app_id, // идентификатор приложения
        appSettings: {
          agreements: '',
          promo: '',
          vkc_behavior: '',
          vkc_auth_action: '',
          vkc_brand: '',
          vkc_display_mode: '',
        },
      });

      Connect.redirectAuth({
        url: this.vk_address, // url для обратного вызова
        state: 'auth',
        source: 'gamedd',
        action: undefined,
        screen: undefined,
      });

    },




  },
  mounted() {

  },
  created(){},
  updated() {

  },
  components:{
    RegistrationClose

  }

}
</script>
