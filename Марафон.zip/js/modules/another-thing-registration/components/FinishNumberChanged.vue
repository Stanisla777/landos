<template lang="pug">
  .gameddreg__wrapper
    template
      registration-close
    .gameddreg__finish-alarm-img
      img(src="/dist/img/all-right.png")
    p.gameddreg__title  Номер изменен
    p.gameddreg__sub-title.margin.
      Вы успешно заменили старый номер телефона

</template>

<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import RegistrationClose from './RegistrationClose.vue'
export default {
  name: 'FinishNumberChanged',

  props: {

  },
  data() {
    return {
      status_btn:false,
    }
  },
  computed: {

  },
  methods: {


  },
  created(){


  },
  updated() {

  },
  components:{
    RegistrationClose

  }

}
</script>
