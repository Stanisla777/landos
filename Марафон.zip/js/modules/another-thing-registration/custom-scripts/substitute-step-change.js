/* eslint-disable */
export default function substituteStepChange() {
  // const btn = document.querySelector('.js--call-game-task[data-step="change_number_account"]')
  // if(btn){
  //   btn.onclick=()=>{
  //     const vue_application=document.querySelector('#v-gamedd-registration')
  //     if(vue_application){
  //       vue_application.querySelector('.gameddreg__container').setAttribute('step','change_number_account')
  //     }
  //   }
  // }

}
