/* eslint-disable */
export default function progressBarNew() {
  const progressBar = document.querySelector('.js--progress-bar-new');
  if (!progressBar) {
    return false;
  }

  const progressBarLine = document.querySelector('.js--progress-bar-line-new');
  const pageContent = document.querySelector('.js--wr-container');

  const myFunction = () => {
    let scroll_page = self.pageYOffset || (document.documentElement && document.documentElement.scrollTop) || (document.body && document.body.scrollTop);
    const header = document.querySelector('.js--header');
    const headerHeight = header.offsetHeight;
    if (scroll_page > headerHeight) {
      progressBar.classList.add('is-scrolled');
    } else {
      progressBar.classList.remove('is-scrolled');
    }

    var winScroll = document.body.scrollTop || document.documentElement.scrollTop;
    var height = document.documentElement.scrollHeight - document.documentElement.clientHeight;

    const contentHeight = pageContent.offsetHeight;
    const contentOffssetTop = pageContent.offsetTop;

    var scrolled = (winScroll / height) * 100;
    let ScrollBarWidth;
    const diff = winScroll - contentOffssetTop;
    if (diff <= 0) {
      ScrollBarWidth = 0;
    } else {
      //check if we hav reached div bottom
      if ((winScroll + 100) <= (contentOffssetTop + contentHeight)) {
        ScrollBarWidth = (diff / contentHeight) * 100;
      } else {
        ScrollBarWidth = 100;
      }
    }

    var scrollHeight = Math.max(
      document.body.scrollHeight, document.documentElement.scrollHeight,
      document.body.offsetHeight, document.documentElement.offsetHeight,
      document.body.clientHeight, document.documentElement.clientHeight
    );

    if (window.scrollY >= scrollHeight - innerHeight) {
      ScrollBarWidth = 100;
      progressBarLine.style.transitionDuration = '0.5s';
    } else {
      progressBarLine.style.transitionDuration = '.3s';
    }

    progressBarLine.style.width = ScrollBarWidth + '%';
  };


  document.addEventListener('scroll', myFunction);
  setTimeout(()=>{

  },600)
  // myFunction();

}
