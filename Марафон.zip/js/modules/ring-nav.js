export default function ringNav() {
    const menu = document.querySelector('.js--ring-nav');
    if (!menu) { return false; }
    const btn = menu.querySelector('.ring-nav__button');

    btn.addEventListener('click', () => {
        menu.classList.toggle('open');
        document.body.classList.toggle('menu-opened');
        document.documentElement.classList.toggle('menu-opened');
    });
}
