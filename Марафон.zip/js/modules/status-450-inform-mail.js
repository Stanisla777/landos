export default function status450InformMail() {
  // eslint-disable-next-line camelcase
  const btn_support_measures = document.querySelector('.check-status__information-mail .js--support-measures');
  // eslint-disable-next-line camelcase
  const tooltip_window = document.querySelector('.check-status__information-mail-window');
  // eslint-disable-next-line camelcase
  if (btn_support_measures) {
    btn_support_measures.onclick = (e) => {
      e.preventDefault();
      btn_support_measures.querySelector('.check-status__information-mail-tooltip').classList.add('active');
      btn_support_measures.closest('.check-status__information-mail').querySelector('.check-status__information-mail-window').classList.add('active');
    };
    // eslint-disable-next-line func-names
  }

  // eslint-disable-next-line camelcase
  if (tooltip_window && btn_support_measures) {
    tooltip_window.onclick = () => {
      // eslint-disable-next-line eqeqeq,max-len
      btn_support_measures.querySelector('.check-status__information-mail-tooltip').classList.remove('active');
      btn_support_measures.closest('.check-status__information-mail').querySelector('.check-status__information-mail-window').classList.remove('active');
    };
  }
}
