export default function initIpoteka() {
    const iframe = document.getElementsByTagName('iframe')[0];

    if (iframe) {
        iframe.onload = () => {
            console.log('load iframe');
            const heightIframe = iframe.contentWindow.document.body.scrollHeight;
            iframe.style.height = `${heightIframe}px`;
            // // iframe.style.height = '600px';
        };
    }
}
