/* eslint-disable */
import Vue from 'vue';
import axios from 'axios';
import Storage from './development-tools-rating/state.vue';


export default function marathon2024TestInn() {
  const app = new Vue({
    el: '#marathon-rating',
    data: {
      // rating_main:false,
      // rating_other:false,

      // rating:[],
      active_rating:false,
      successfully_found:false,
      unsuccessfully_found:false,

      found_position:null,
      found_name:null,
      found_points:null,
      its_you:null,
      show_button:false,
      error_text_under_button:'Ошибка отправки',
      field_error:false,
      // not_found:false,

    //  объект, который получаю
      data_participants:{
        "topRating":[ // ТОП-10 участников
          {
            "position":1,
            "points":23,
            "name":"Марафонец 77",
            "active":true, // отметка искомого или текущего (ИНН в куки) участника
            "isCurrent":false, // отметка ТОЛЬКО текущего (ИНН в куки) участника - для надписи "Это Вы!"
          }
        ],
        "other":[
          { //объект заполняется только, если искомый или текущий (ИНН в куки) участник НЕ в ТОПЕ
            "position":1,
            "points":23,
            "name":"Марафонец 77",
            "active":true, // отметка искомого или текущего (ИНН в куки) участника
            "isCurrent":false, // отметка ТОЛЬКО текущего (ИНН в куки) участника - для надписи "Это Вы!"
          }

        ],
        "notFound":true, // true вывожу УПС
      }


    },
    methods: {
      // sendRequest(token = ''){
      sendRequest(){
        axios({
          method:'post',
          url:'/api/local/marathon/rating/',
          headers: {
            "Content-type": "application/json; charset=UTF-8",
            'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
          },

          data:{
            // grecaptcharesponse: token,
            nickname:this.$refs.InputInn.value,
            year: this.$refs.Rating && this.$refs.Rating.hasAttribute('data-year')
              ? parseInt(this.$refs.Rating.getAttribute('data-year'))
              : 0
          },
        })
          // Если запрос успешен
          .then((res)=>{
            this.field_error=false
            Storage.dispatch('ActionRating',res.data.result)


            if (res.data.result.topRating.length >= 10) {
              Storage.dispatch('ActionRatingMain',true)
            } else {
              Storage.dispatch('ActionRatingMain',false)
            }
            if (res.data.result.other.length > 0) {
              Storage.dispatch('ActionRatingOther',true)
            } else {
              Storage.dispatch('ActionRatingOther',false)
            }
            Storage.dispatch('ActionNotFound',res.data.result.notFound)


          })
          // Если запрос с ошибкой
          .catch((error)=> {
            if(error.response){
              if (error.response.data.description!=undefined){
                this.field_error=true
                this.error_text_under_button=error.response.data.description
                Storage.dispatch('ActionNotFound',false)
              }
            }
            console.log(error);
          });
      },
      sendPost(){
        //Бой
        this.sendRequest()

        //Вместо гугл рекаптчи теперь используется яндекс рекаптча
        //Если в марафоне 2025 будет использоваться этот код переписать для яндексрекаптчи


        // let key = conf.reCAPTCHA_site_key
        // if (key && typeof window.grecaptcha !== 'undefined') {
        //   window.grecaptcha.ready(() => {
        //     window.grecaptcha.execute(key)
        //       .then((token) => {
        //         this.sendRequest(token)
        //       })
        //   })
        // } else {
        //   this.sendRequest()
        // }


        //разработка
        // axios({
        //   method:'post',
        //   // url:'',
        //   url:'http://localhost:3000/result3', //убрать
        //   headers: {
        //     "Content-type": "application/json; charset=UTF-8",
        //     // 'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        //   },
        //
        //   data: {nickname:this.$refs.InputInn.value}
        // })
        //   .then((res)=>{
        //     //разработка
        //     const rating = {
        //       "topRating": [ // ТОП-10 участников
        //         {
        //           "position": 1,
        //           "points": 100,
        //           "name": "Марафонец 111",
        //           "active": true, // отметка искомого или текущего (ИНН в куки) участника
        //           "isCurrent": true, // отметка ТОЛЬКО текущего (ИНН в куки) участника - для надписи "Это Вы!"
        //         },
        //         {
        //           "position": 2,
        //           "points": 90,
        //           "name": "Марафонец 222",
        //           "active": false, // отметка искомого или текущего (ИНН в куки) участника
        //           "isCurrent": false, // отметка ТОЛЬКО текущего (ИНН в куки) участника - для надписи "Это Вы!"
        //         },
        //         {
        //           "position": 3,
        //           "points": 80,
        //           "name": "Марафонец 333",
        //           "active": false, // отметка искомого или текущего (ИНН в куки) участника
        //           "isCurrent": false, // отметка ТОЛЬКО текущего (ИНН в куки) участника - для надписи "Это Вы!"
        //         }
        //       ],
        //       "other": [
        //         { //объект заполняется только, если искомый или текущий (ИНН в куки) участник НЕ в ТОПЕ
        //           "position": 1254,
        //           "points": 23,
        //           "name": "Марафонец 2020",
        //           "active": true, // отметка искомого или текущего (ИНН в куки) участника
        //           "isCurrent": false, // отметка ТОЛЬКО текущего (ИНН в куки) участника - для надписи "Это Вы!"
        //         }
        //       ],
        //       "notFound":true
        //     }
        //
        //     Storage.dispatch('ActionRating',rating)
        //
        //     if (rating.topRating.length >= 2) { //2 исправить на 10
        //       Storage.dispatch('ActionRatingMain',true)
        //     } else {
        //       Storage.dispatch('ActionRatingMain',false)
        //     }
        //     if (rating.other.length > 0) {
        //       Storage.dispatch('ActionRatingOther',true)
        //     } else {
        //       Storage.dispatch('ActionRatingOther',false)
        //     }
        //
        //     Storage.dispatch('ActionNotFound',rating.notFound)
        //     //-----END---------------
        //
        //     this.field_error=false
        //   })
        //
        //   // Если запрос с ошибкой
        //   .catch((error)=> {
        //     if(error.response){
        //       if (error.response.data.description!=undefined){
        //         this.field_error=true
        //         this.error_text_under_button=error.response.data.description
        //       }
        //     }
        //     console.log(error);
        //   });
      },
      fieldCalculation(e){
        const element = e.currentTarget;
        const parent = element.closest('.js--test-input')
        if (element.value.length > 0) {
          this.show_button=true
          element.classList.add('active')
          parent.querySelector('.js--clear-calc-tax').classList.add('active')
        } else {
          this.show_button=false
          element.classList.remove('active')
          parent.querySelector('.js--clear-calc-tax').classList.remove('active')
        }

      },
      clearInput(e){
        const element = e.currentTarget;
        const parent = element.closest('.js--test-input')
        parent.querySelector('input').value='';
        element.classList.remove('active')
        this.show_button=false
      },

    },
    filters: {

    },
    computed: {
      rating(){
        return Storage.getters.RATINGTEST
      },
      rating_main(){
        return Storage.getters.RATINGMAIN
      },
      rating_other(){
        return Storage.getters.RATINGOTHER
      },
      not_found(){
        return Storage.getters.NOTFOUND
      },



    },
    watch: {

    },
    mounted() {
      if (this.$refs.Rating && this.$refs.Rating.hasAttribute('data-participants')) {
        // this.rating = JSON.parse(this.$el.getAttribute('data-participants'));
        Storage.dispatch('ActionRating',JSON.parse(this.$el.getAttribute('data-participants')))


        if (this.rating.topRating.length >0) { //2 исправить на 10
          // this.rating_main = true;
          Storage.dispatch('ActionRatingMain',true)
        } else {
          // this.rating_main = false;
          Storage.dispatch('ActionRatingMain',false)
        }



        if (this.rating.other.length > 0) {
          // this.rating_other = true;
          Storage.dispatch('ActionRatingOther',true)
        } else {
          // this.rating_other = false;
          Storage.dispatch('ActionRatingOther',false)
        }
      }
    }
  });
}
