/* eslint-disable */
/**
 * Плавный скролл к элементу
 * @param {HTMLElement|string} target - Элемент или селектор
 * @param {object} options - Опции
 * @param {number} [options.duration=1000] - Длительность анимации (мс)
 * @param {number} [options.offset=0] - Смещение от верха элемента (px)
 * @param {string} [options.easing='easeInOutQuad'] - Функция плавности
 */

/*
Пользоваться
// Скролл к элементу с ID "section"
smoothScrollTo('#section', {
  duration: 800,
  offset: 20,
  easing: 'easeInOutCubic'
});




 */
export default function  smoothScrollTo(target, options = {}) {
  const {
    duration = 1000,
    offset = 0,
    easing = 'easeInOutQuad'
  } = options;

  // Поддержка разных easing-функций
  const easingFunctions = {
    linear(t) {
      return t;
    },
    easeInQuad(t) {
      return t * t;
    },
    easeOutQuad(t) {
      return t * (2 - t);
    },
    easeInOutQuad(t) {
      return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
    },
    easeInCubic(t) {
      return t * t * t;
    },
    easeOutCubic(t) {
      return (--t) * t * t + 1;
    },
    easeInOutCubic(t) {
      return t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1;
    }
  };

  const easingFn = easingFunctions[easing] || easingFunctions.easeInOutQuad;

  // Получаем целевой элемент
  const element = typeof target === 'string'
    ? document.querySelector(target)
    : target;

  if (!element) {
    console.warn('Smooth scroll: target element not found');
    return;
  }

  const startPos = window.pageYOffset;
  const targetPos = getElementPosition(element) - offset;
  const distance = targetPos - startPos;
  let startTime = null;

  function getElementPosition(el) {
    const rect = el.getBoundingClientRect();
    return rect.top + window.pageYOffset;
  }

  function animation(currentTime) {
    if (startTime === null) startTime = currentTime;
    const timeElapsed = currentTime - startTime;
    const progress = Math.min(timeElapsed / duration, 1);

    window.scrollTo(0, startPos + distance * easingFn(progress));

    if (timeElapsed < duration) {
      window.requestAnimationFrame(animation);
    }
  }

  // iOS требует использование requestAnimationFrame
  window.requestAnimationFrame(animation);
}

// Полифилл для requestAnimationFrame
(function() {
  const vendors = ['ms', 'moz', 'webkit', 'o'];
  for (let x = 0; x < vendors.length && !window.requestAnimationFrame; ++x) {
    window.requestAnimationFrame = window[`${vendors[x]}RequestAnimationFrame`];
    window.cancelAnimationFrame =
      window[`${vendors[x]}CancelAnimationFrame`] ||
      window[`${vendors[x]}CancelRequestAnimationFrame`];
  }

  if (!window.requestAnimationFrame) {
    let lastTime = 0;
    window.requestAnimationFrame = function(callback) {
      const currTime = new Date().getTime();
      const timeToCall = Math.max(0, 16 - (currTime - lastTime));
      const id = window.setTimeout(() => {
        callback(currTime + timeToCall);
      }, timeToCall);
      lastTime = currTime + timeToCall;
      return id;
    };
  }

  if (!window.cancelAnimationFrame) {
    window.cancelAnimationFrame = function(id) {
      clearTimeout(id);
    };
  }
}());



// Экспортируем для использования без Vue
export { smoothScrollTo};
