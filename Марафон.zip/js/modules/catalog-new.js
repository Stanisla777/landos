/* eslint-disable */
import closeList from './TemplateScript/close-list';
let wrapSize;

import dropDown from './dropDown';
import selectItemList from './TemplateScript/select-item-list';
import openList from './TemplateScript/open-list';
import removeAllCheckboxes from './TemplateScript/remove-all-checkboxes';
//программы по регионом - аккордеон для блока "программы по регионам"
function dropDownRegion() {
  const btn = document.querySelector('.js--region-btn-else')
  if (btn) {
    btn.onclick = (ev) => {
      const element = ev.currentTarget;
      dropDown(element, 167);
    };
  }
}

//открытие окна со списком в типе программ в мобильной версии (Все программы, Региональные, Федеральные)
function openListDirectory() {
  const arrayOpenListBtn = document.querySelectorAll('.js--openlist-btn');
  for(let item of arrayOpenListBtn) {
    item.onclick = (ev) => {
      openList(ev)
    }
  }
}

function closeSelectList() {
  const arrayCloseListBtn = document.querySelectorAll('.js--select-list-close');
  for(let item of arrayCloseListBtn) {
    item.onclick = (ev) => {
      closeList(ev)
    }
  }
}

//фильтр по типу программ в мобильной версии (Все программы, Региональные, Федеральные)
function clickSelectItem() {
  const arraySelectItem = document.querySelectorAll('.js--openlist-item');
  for(let item of arraySelectItem) {
    item.onclick = (ev) => {
      //вызовов функции Выбор нужного пункта в выпадающем окне
      selectItemList(ev)
      //если пункт в выпадающем окне ещё и является табом


      const parent = item.closest('.js--container-filter');
      if (parent) {
        const desctop_tab = parent.querySelector('.js--desctop-tab');
        if (desctop_tab) {
          const data = item.getAttribute('data-tab-value');
          desctop_tab.querySelector(`.js--tab-catalog[data-tab-value="${data}"]`).classList.add('active')
        }
      }
    }
  }
}

//ширина экрана

//оборачиваю элементы вблоке "Программы по регионам" доработать, когда меняется ширина экрана
function wrappingElements() {
  /* получаем контейнер */
  const container = document.querySelector('.js--wr-region');
  if (container) {
    /* получаем item-ы у контейнера */
    const allElements = Array.from(container.getElementsByClassName("js--region-item"));

    let wrapSize;
    if (window.innerWidth > 970) {
      wrapSize = Math.round(allElements.length / 4);
    }
    if (window.innerWidth <= 970 && window.innerWidth > 660) {
      wrapSize = Math.round(allElements.length / 3);
    }
    if (window.innerWidth <= 660 && window.innerWidth > 570) {
      wrapSize = Math.round(allElements.length / 2);
    }
    if (window.innerWidth <= 570) {
      wrapSize = Math.round(allElements.length);
    }


    for (let i = 0; i < allElements.length; i += wrapSize) {

      /* создаём врап */
      const wrap = document.createElement("div");
      wrap.classList.add("program-directory__region-wrap");

      /* наполняем нужным количеством элементов */
      for (let j = 0; j < wrapSize; j++) {
        if (i + j < allElements.length) {
          wrap.appendChild(allElements[i + j]);
        }
      }

      /* добавляем в контейнер */
      container.appendChild(wrap);
    }
  }


}

//детальная программы раскрытие списка с документами программа регулируется
function  openingListDocuments() {

  const array_wr_document = document.querySelectorAll('.js--information-block-document');
  for(let container of array_wr_document) {
    const array_document = container.querySelectorAll('.js--information-document');
    let heightItem = 0;
    let count;
    if (container.classList.contains('js--aside-block-link')) {
      count=4
    }
    else {
      count= 2;
    }
    if (container.classList.contains('js--aside-block-link') && array_document.length<=4) {
      container.closest('.js-accordion-parent').querySelector('.js--information-btn-else').classList.add('unactive')
    }
    else {
      for (let i = 0; i<count; i++) {
        if (array_document[i]) {
          heightItem += array_document[i].offsetHeight;
        }
      }
      container.setAttribute('style', `max-height:${heightItem}px;`);
      if (array_document.length > count && container.closest('.js-accordion-parent') &&
      container.closest('.js-accordion-parent').querySelector('.js--information-btn-else')) {
        container.closest('.js-accordion-parent').querySelector('.js--information-btn-else').classList.add('active')
      }
      const btn = container.closest('.js-accordion-parent').querySelector('.js--information-btn-else');
      if (btn) {
        btn.onclick = (ev) => {
          dropDown(btn, heightItem);
        };
      }
      container.closest('.js-accordion-parent').classList.add('block-active')
    }
  }

}

//Убрать все выбранные чекбоксы
function filterRemoveAllCheckboxes() {
  const array_btn = document.querySelectorAll('.js--list-checkbox-reset');
  for (let item of array_btn) {
    item.onclick = () => {
      if (item.closest('.js--container-select')
        && item.closest('.js--container-select').querySelector('.js--select-list')) {
        const container = item.closest('.js--container-select').querySelector('.js--select-list')
        // removeAllCheckboxes(container);
      }
    }
  }
}

//закрыть выпадающий селект при клике вне области, когда нет .js--openlist-background

function closeSelectListNoneOpenlistBackground() {
  const arrayModal = document.querySelectorAll('.js--modal-main-content');
  for (let item of arrayModal) {
    if (!item.querySelector('.js--openlist-background')) {
      item.onclick = (ev) => {
        if (item.querySelector('.js--select.open') && !ev.target.closest('.js--select') &&
          !ev.target.classList.contains('js--select')) {
          item.querySelector('.js--select.open').classList.remove('open')
          item.classList.remove('unactive-scroll')
        }
      }
    }
  }
}

export default function catalogNew() {
  dropDownRegion();
  clickSelectItem();
  openListDirectory();
  wrappingElements();
  openingListDocuments();
  closeSelectList();
  window.addEventListener('resize', openingListDocuments);
  closeSelectListNoneOpenlistBackground();
}
