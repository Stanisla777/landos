<template lang="pug">
  .block(v-cloak)
    .block-with-aside.block-with-aside_mortgage-calculation.mc
      .block-with-aside__main

        h2.mc__title
          | Цель кредита
        .mc__row
          .round-cards.round-cards_gray.round-cards_mb-none
            button.round-cards__item(
              v-for="(item, idx) in creditTarget"
              @click.prevent="handlerTarget(idx)"
              :class="{active: item.isActive}"
              :disabled="item.isDisabled"
              :key="idx"
            ) {{ item.name }}

        .mc__row(
          v-for="(select, idx) in selectArr"
          :key="idx")
          .select.select_disabled(v-if="targetSlide === 'dfo' && idx === 1")
            .select__choosen.select__choosen_bordered
              | Дальневосточный
          .select(
            v-else
            :class="{open: select.show}"
          )
            .select__background(@click="closeSelect(select.id)")
            .select__choosen.select__choosen_bordered(
              v-if="select.list.length"
              @click="handlerToggleSelect(idx)"
            )
              | {{ setSelectLabel(select.list) }}
            .select__list-wrapper
              ul.select__list
                li.select__list-item(
                  v-for="item in select.list"
                  @click="handlerSelect(item.id, select.id)"
                  :key="item.id"
                )
                  | {{ item.name }}
        // SLIDER BLOCK
        .mc__row(v-show="showSliderProgram")
          .mc-slider(v-show="activeMortgageTabs === 'buy'")
            #mortgage-slider.swiper-container(:class="{'mobile-hide': !showAllProgram}")
              .swiper-wrapper
                .swiper-slide(
                  v-for="item in creditProgram"
                  @click="choiceCreditProgram(item.id)"
                  :key="item.id"
                )
                  .mc-type(:class="{'active': item.isActive}")
                    span.mc-type__title {{ item.name }}
                    .mc-type__img
                      img(:src="`/dist/img/${item.img}`", alt="")
            .icon-round.icon-round_gray.swiper-button-prev.mc-slider__prev
              svg(width='28' height='28' viewBox='0 0 28 28' fill='none' xmlns='http://www.w3.org/2000/svg')
                path(fill-rule='evenodd' clip-rule='evenodd' d='M11.9589 7.9594C12.3494 7.56887 12.9826 7.56887 13.3731 7.9594C13.7636 8.34992 13.7636 8.98309 13.3731 9.37361L9.74689 12.9998H20.666C21.2183 12.9998 21.666 13.4476 21.666 13.9998C21.666 14.5521 21.2183 14.9998 20.666 14.9998H9.7469L13.3731 18.6261C13.7636 19.0166 13.7636 19.6498 13.3731 20.0403C12.9826 20.4308 12.3494 20.4308 11.9589 20.0403L6.62624 14.7076C6.62384 14.7052 6.62145 14.7028 6.61908 14.7004C6.44193 14.52 6.33268 14.2727 6.33268 13.9998C6.33268 13.8642 6.35967 13.735 6.40856 13.6171C6.457 13.5 6.52863 13.3902 6.62346 13.2949M11.9589 7.9594L6.62584 13.2925L11.9589 7.9594Z')
            .icon-round.icon-round_gray.swiper-button-next.mc-slider__next
              svg(width='28' height='28' viewBox='0 0 28 28' fill='none' xmlns='http://www.w3.org/2000/svg')
                path(fill-rule='evenodd' clip-rule='evenodd' d='M16.0411 20.0406C15.6506 20.4311 15.0174 20.4311 14.6269 20.0406C14.2364 19.6501 14.2364 19.0169 14.6269 18.6264L18.2531 15.0002L7.33399 15.0002C6.7817 15.0002 6.33399 14.5524 6.33399 14.0002C6.33399 13.4479 6.7817 13.0002 7.33399 13.0002L18.2531 13.0002L14.6269 9.37394C14.2364 8.98341 14.2364 8.35025 14.6269 7.95972C15.0174 7.5692 15.6506 7.5692 16.0411 7.95972L21.3738 13.2924C21.3762 13.2948 21.3786 13.2972 21.3809 13.2996C21.5581 13.48 21.6673 13.7273 21.6673 14.0002C21.6673 14.1358 21.6403 14.265 21.5914 14.3829C21.543 14.5 21.4714 14.6098 21.3765 14.7051M16.0411 20.0406L21.3742 14.7075L16.0411 20.0406Z')
            .swiper-pagination.mc-slider__pagination

            button.mc-slider__show-all(
              @click.prevent="handlerShowAllProgram(true)"
              :class="{hidden: showAllProgram}"
            )
              | Все программы
              svg(viewBox='0 0 70 36')
                path(d='M7.6739 31.8153H63.0244C65.5269 31.8152 80.5358 9.31529 32.4998 12.81531C-16.1598 18.2025 0.894099 33.9766 32.9922 34.3153C104.062 32.3153 52.5169 8.31531 29.489 17.31527')
          .mc-slider(v-show="activeMortgageTabs === 'refin'")
            .swiper-container
              .swiper-wrapper
                .swiper-slide
                  .mc-type.mc-type_alone(:class="{'active': creditProgram[1].isActive}" @click="choiceCreditProgram(creditProgram[1].id)")
                    span.mc-type__title {{ creditProgram[1].name }}
                    .mc-type__img
                      img(:src="`/dist/img/${creditProgram[1].img}`", alt="")

        // RANGE BLOCK
        .mc__range-input.range-input
          span.range-input__title Стоимость<span v-show="!showSliderProgram"> имеющейся</span> недвижимости
          .range-input__wrapper
            input.range-input__value(
              v-model="realtyPrice"
              type="text"
              ref="realtyInput"
            )
            .range-input__slider(ref="mortgagePrice")
          .range-input__diapason
            span {{ stgMin | format }}
            span {{ stgMax | format }}

        .mc__range-input.range-input(v-show="!pledgeShow")
          span.range-input__title
            span(v-show="activeMortgageTabs === 'pledge'") Сумма кредита
            span(v-show="activeMortgageTabs === 'refin'") Остаток долга
          .range-input__wrapper(ref="loanInputWrap")
            input.range-input__value(
              v-model="loanAmount"
              type="text"
              ref="loanInput"
            )
            .range-input__slider(ref="mortgageLoan")
          .range-input__diapason
            span {{ amountMin | format }}
            span(v-show="activeMortgageTabs !== 'pledge'") {{ realtyPrice | format }}
            span(v-show="activeMortgageTabs === 'pledge'") {{ pledgeMaxRealty | format }}

        .mc__range-input.range-input(v-show="pledgeShow")
          span.range-input__title Первоначальный взнос
          .range-input__wrapper(:class="{'is-disabled': matcap}")
            input.range-input__value(
              v-model="pledge"
              :disabled="matcap"
              type="text"
              ref="pledgeInput"
            )
            span.range-input__value-per {{ prvPercent }}%
            .range-input__slider(ref="mortgagePledge" :disabled="matcap")
          .range-input__diapason
            span {{ pledgeMin | format }}
            span {{ pledgeMax | format }}

        .mc__range-input(v-show="targetsCode === 'product_building' || targetsCode === 'product_ready'")
          label.check
            input.check__input(v-model="matcap" type="checkbox")
            span.check__box
            | Использовать материнский капитал
          .mc__range-row(v-show="matcap")
            .mc__range-col
              .input
                label.lbl Материнский капитал
                input.inp(
                  v-model="maternalCapital"
                  type="text"
                  ref="matcapInput"
                )
            .mc__range-col
              .input
                label.lbl Личные средства
                input.inp(
                  v-model="money"
                  type="text"
                  ref="moneyInput"
                )

        .mc__range-input.range-input
          span.range-input__title(v-if="activeMortgageTabs !== 'refin'") Срок кредита
          span.range-input__title(v-else) Оставшийся срок кредита
          .range-input__wrapper
            input.range-input__value(
              type="text"
              v-model="period"
              ref="periodInput"
            )
            .range-input__slider(ref="mortgagePeriod")
          .range-input__diapason
            span {{ periodMin }} {{ pluralize(periodMin, ['год', 'года', 'лет']) }}
            span {{ periodMax }} {{ pluralize(periodMax, ['год', 'года', 'лет']) }}
        // ADDITIONAL
        .mc-additional(v-if="showAddOptions")
          span.mc-additional__title Дополнительные опции
          span.mc-additional__subtitle Возможен выбор нескольких опций

          label.mc-additional__item(
            v-for="item in parseAddOptions(options)"
            :key="item.id"
            v-show="showOption(item)"
          )
            .checkbox
              input(
                type="checkbox"
                v-model="item.check"
                @change="handlerOptionsCheck(item)"
              )
              div
            .mc-additional__item-content
              span.mc-additional__item-title {{ item.title }}
              span.mc-additional__item-desc {{ item.desc }}
      // ASIDE BLOCK
      .block-with-aside__aside
        .mc-output.pos-sticky
          .mc-output__list
            .mc-output__list-item
              span.mc-output__list-title программа кредитования
              span.mc-output__list-value {{ targets }}
            .mc-output__list-item
              span.mc-output__list-title платеж в месяц
              span.mc-output__list-value {{ monthlyPay | format }} &#8381;
            .mc-output__list-item
              span.mc-output__list-title ставка
              span.mc-output__list-value {{ rate }}%
          .mc-output__result
            .mc-output__result-item
              span.mc-output__result-title Сумма кредита
              span.mc-output__result-value {{ loanAmount | format }}
            .mc-output__result-item.mc-output__result-item_error(v-show="realtyPriceNumber - pledgeNumber > amountMaxRegion")
              span.mc-output__result-title Максимальная сумма кредита
              span.mc-output__result-value {{ amountMaxRegion | format }}&nbsp;&#8381;
            .mc-output__result-item
              span.mc-output__result-title Необходимый доход
              span.mc-output__result-value {{ income | format }} &#8381;
          a(href="https://xn--h1alcedd.xn--d1aqf.xn--p1ai/instructions/kak-poluchit-ipotechnyy-kredit-poshagovaya-instruktsiya/").mc-output__button
            | Как взять ипотеку?
          button.mc-output__button.mc-output__button_green.js--modal-opener(data-modal='#modalchat' aria-label="Задать вопрос")
            | Задать вопрос

          p.footnote-calculators.
            Результат расчета предварительный, сформирован в ознакомительных целях на основе предоставленных сведений и не
            является официальным заключением, офертой, индивидуальной оценкой. Для получения подробной информации и
            индивидуальной оценки рекомендуем обратиться в кредитную организацию.



</template>

<script>
import Vue from 'vue';
import Swiper, { Navigation, Pagination } from 'swiper';
import noUiSlider from 'nouislider';
import axios from 'axios';
import { closeModal } from './modals';

Swiper.use([Navigation, Pagination]);
let mySwiper;

const apiUrl = 'https://domrfbank.ru/upload/apix/products.json';

export default {
  name: 'MortgageCalc',
  data() {
    return {
      apix: null,

      targets: 'Льготная ипотека на новостройки',
      targetsCode: 'product_preferential', // Служебная переменная для отслеживания текущего кода продукта
      targetOptions: {}, // Продукт для дополнительных опций
      programName: 'Квартира в новостройке', // программа кредитования
      targetSlide: 'pref', // Показываемый слайд - нужен для связки с целью кредита
      creditTarget: [
        {
          name: 'покупка',
          isActive: true,
          isDisabled: false,
          key: 'buy',
          targetList: [
            {
              id: 0,
              name: 'Квартира в новостройке',
              isActive: true,
              const: 'product_building'
            },
            {
              id: 1,
              name: 'Квартира готовая',
              isActive: false,
              const: 'product_ready'
            },
            {
              id: 2,
              name: 'Дом готовый',
              isActive: false,
              const: 'product_house'
            },
            {
              id: 3,
              name: 'Дом строящийся',
              isActive: false,
              const: 'product_building_house'
            },
            {
              id: 4,
              name: 'Льготное индивидуальное строительство жилого дома',
              isActive: false,
              const: 'product_building_house'
            },
            {
              id: 5,
              name: 'Залоговая недвижимость',
              isActive: false,
              const: 'product_ready'
            }
          ]
        },
        {
          name: 'рефинансирование',
          isActive: false,
          isDisabled: false,
          key: 'refin',
          targetList: [
            {
              id: 0,
              name: 'Квартира в новостройке',
              isActive: true,
              const: 'product_building'
            },
            {
              id: 1,
              name: 'Квартира готовая',
              isActive: false,
              const: 'product_ready'
            }
          ]
        },
        {
          name: 'под залог',
          isActive: false,
          isDisabled: false,
          key: 'pledge',
          targetList: [
            {
              id: 0,
              name: 'Квартира готовая',
              isActive: true,
              const: 'product_secured_loan'
            },
            {
              id: 1,
              name: 'Залоговая недвижимость',
              isActive: false,
              const: 'product_ready'
            }
          ]
        }
      ], // цель кредита
      creditProgram: [
        {
          id: 0,
          name: 'Льготная ипотека',
          img: 'preferential-mortgage-icon.png',
          isActive: true,
          const: 'pref'
        },
        {
          id: 2,
          name: 'Семейная ипотека',
          img: 'family-mortgage-icon.png',
          isActive: false,
          const: 'family',
          targetList: [
            {
              id: 0,
              name: 'Квартира в новостройке',
              isActive: true,
              const: 'product_family'
            },
            {
              id: 1,
              name: 'Квартира готовая',
              isActive: false,
              const: 'product_family'
            },
            {
              id: 2,
              name: 'Жилой дом',
              isActive: false,
              const: 'product_family'
            }
          ]
        },
        {
          id: 3,
          name: 'Дальневосточная ипотека',
          img: 'mortgage-calculation-type.png',
          isActive: false,
          const: 'dfo',
          targetList: [
            {
              id: 0,
              name: 'Квартира в новостройке',
              isActive: true,
              const: 'product_far_east'
            },
            {
              id: 1,
              name: 'Квартира готовая',
              isActive: false,
              const: 'product_far_east'
            },
            {
              id: 2,
              name: 'Дом готовый',
              isActive: false,
              const: 'product_far_east'
            },
            {
              id: 3,
              name: 'Дом строящийся',
              isActive: false,
              const: 'product_far_east_house'
            }
          ]
        }
      ], // кредитные программы
      electronicFlag: false,
      selectArr: [
        {
          id: 0,
          show: false,
          list: []
        },
        {
          id: 1,
          show: false,
          list: [
            {
              name: 'Москва и МО',
              isActive: true,
              id: 0
            },
            {
              name: 'Санкт-Петербург и ЛО',
              isActive: false,
              id: 1
            },
            {
              name: 'Другой регион',
              isActive: false,
              id: 2
            }
          ]
        }
      ], // массив select-ов
      showAllProgram: false, // показать/скрыть все кредитные программы (для мобилок)
      width: 0, // ширина окна просмотра
      swiperInit: false, // инициализация swiper-a, в зависимости от размера окна
      realtySlider: '', // Слайдер "Стоимость недвижимости"
      realtyPrice: 5000000, // Стоимость недвижимости
      pledge: 2000000, // Первоначальный взнос
      step: 1000, // Шаг для range инпутов
      stgMin: 625000, // Минимальное значение поля стоимости
      stgMiddle: 27000000, // Значение по середине (стоимость)
      stgMax: 55000000, // Максимальное значение поля стоимости
      pledgeMin: 0, // Минимальный первоначальный взнос
      pledgeMiddle: 1, // Значение по середине (первоначальный взнос)
      pledgeMax: 2, // Максимальное значение первоначального взноса
      pledgeMinPrv: 0, // Минимальный первоначальный взнос в процентах
      pledgeMaxPrv: 100, // Максимальный первоначальный взнос в процентах
      loanAmount: 0, // Сумма кредита
      amountMin: 625000, // Сумма кредита минимальная
      amountMax: 20000000, // Сумма кредита максимальная
      amountMiddle: 10000000, // Значение по середине (Сумма кредита)
      amountMaxRegion: 6000000, // Максимальная сумма кредита для региона
      pledgeMaxRealty: 1, // Максимальное значение поля "Сумма кредита" в слайдере под залог
      matcap: false, // Мат. капитал
      maternalCapital: 466617, // Размер материнского капитала
      matcapMax: 617000, // Макс. мат. капитал
      matcapMin: 10000, // Мин. мат. капитал
      money: 0, // Личные средства
      prvPercent: 0, // Первоначальный взнос для показа в инпуте
      period: 15, // Срок кредита
      periodMin: 3, // Минимальный срок кредита
      periodMiddle: 15, // Значение по середине (срок кредита)
      periodMax: 30, // Максимальное значение срока кредита
      periodSlider: '', // Слайдер "Срок кредита"
      loanSlider: '', // Слайдер "Сумма кредита"
      pledgeSlider: '', // Слайдер "Первоначальный взнос"
      products: {}, // Актуальный в данный момент продукт
      productsActual: ['product_building', 'product_ready', 'product_house', 'product_building_house', 'product_family', 'product_military',
        'product_military_family', 'product_far_east', 'product_far_east_house', 'product_refinancing', 'product_secured_loan', 'product_preferential'], // Актуальные продукты для показа в калькуляторе
      productsList: {}, // Сформированный из АПИКСа объект с продуктами
      actionOptions: ['easy_mortgage', 'maternal_capital', 'trade-in', 'parking', 'apartments'], // Коды доступные на табе "Спецпредложение"
      rate: 0, // Ставка
      kz: 0, // Значение параметра "Кредит-залог"
      rateSecond: 0, // Ставка - ставка ниже
      income: 0, // Необходимый доход
      monthlyPay: 0, // Ежемесячный платеж
      realty: 'product_preferential', // Служебная переменная для комбинации выбора цели кредита
      rateDeduction: 0, // Вычет для опций (получаем из АПИКС)
      options: [
        {
          id: 0,
          title: 'Подтверждение дохода ПФР',
          desc: 'Снижение процентной ставки на -0,4 п. п.',
          rate: -0.4,
          check: false,
          code: ['product_preferential', 'product_building', 'product_ready', 'product_house', 'product_building_house', 'product_family', 'product_secured_loan', 'product_refinancing']
        },
        {
          id: 1,
          title: 'Зарплатные проекты',
          desc: 'Снижение процентной̆ ставки на -0,4 п. п.',
          rate: -0.4,
          check: false,
          code: ['product_preferential', 'product_house', 'product_building_house', 'product_family', 'product_secured_loan']
        },
        {
          id: 2,
          title: 'Зарплатные клиенты',
          desc: 'Снижение процентной ставки на -0,6 п. п. и размера первоначального взноса до 10%.',
          rate: -0.6,
          check: false,
          code: ['product_building', 'product_ready', 'product_refinancing']
        },
        {
          id: 3,
          title: 'Будущий зарплатный клиент Банка',
          desc: 'Снижение процентной ставки на 0,6 п. п. при оформлении зарплатной карты и подтверждении дохода выпиской из ПФР',
          rate: -0.6,
          check: false,
          code: ['product_building', 'product_ready', 'product_house', 'product_building_house', 'product_secured_loan', 'product_refinancing']
        },
        {
          id: 5,
          title: 'Застройщики на ПФ для продукта Льготная ипотека',
          desc: '',
          rate: -0.2,
          check: false,
          code: ['product_preferential']
        },
        {
          id: 6,
          title: 'Схема Трейд Ин',
          desc: 'Покупка квартиры при передаче имеющейся квартиры застройщику в счет первоначального взноса.',
          rate: 0,
          check: false,
          code: ['product_preferential', 'product_building', 'product_family']
        }
      ], // Опции, которые отбираем для показа
      optionsShow: [],
      showAddOptions: false, // показывать-скрыть Доп. опции
      currentRegion: 0, // Регион
    };
  },
  filters: {
    format: (val) => `${val}`.replace(/(\d)(?=(\d{3})+([^\d]|$))/g, '$1 '),
  },
  computed: {
    showSliderProgram() {
      return !this.creditTarget.find((el) => el.key === 'pledge').isActive;
    },
    activeMortgageTabs() {
      return this.creditTarget.find((el) => el.isActive).key;
    },
    pledgeShow() {
      return this.creditTarget.find((el) => el.key === 'buy').isActive;
    },
    loanNumber() {
      return +this.clearString(this.loanAmount);
    },
    realtyPriceNumber() {
      return +this.clearString(this.realtyPrice);
    },
    pledgeNumber() {
      return +this.clearString(this.pledge);
    },
    periodNumber() {
      return +this.clearPeriod(this.period);
    },
    matCapitalNumber() {
      return +this.clearString(this.maternalCapital);
    },
    moneyNumber() {
      return +this.clearString(this.money);
    },
  },
  watch: {
    width(newVal) {
      if (newVal >= 1243) {
        if (!this.swiperInit) {
          this.initSlider();
        }
      } else if (this.swiperInit) {
        this.destroySwiper();
      }
    },
    targetSlide(newVal, oldVal) {
      if (this.activeMortgageTabs === 'buy') {
        const list = this.creditProgram.find((el) => el.const === newVal);
        if (list && list.targetList) {
          this.selectArr[0].list = list.targetList;
        } else {
          this.selectArr[0].list = this.creditTarget[0].targetList;
        }
        if (newVal === '' && oldVal === 'pref') {
          if (this.realty === 'product_preferential') {
            this.handlerSelect(0, 0);
          }
        } else if (newVal === 'pref') {
          this.realty = 'product_preferential';
        } else {
          this.handlerSelect(0, 0);
        }
      } else {
        this.setProgram(this.activeMortgageTabs);
      }
    },
    realty() {
      this.setProgram(this.activeMortgageTabs);
    },
    currentRegion(val) {
      this.checkCurrentRegion(val)
    },
    matcap(val) {
      if (val) {
        this.updatePrvSlider();
        // this.activeCodes.push('maternal_capital');
      } else {
        // eslint-disable-next-line max-len
        // this.activeCodes = this.activeCodes.filter((val) => val !== 'maternal_capital');
      }
    }
  },
  created() {
    window.addEventListener('resize', this.updateWidth);
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.updateWidth);
  },
  mounted() {
    this.$nextTick(() => {
      this.setData();
      this.updateWidth();
      this.getApi();
      this.pledgeMaxRealty = this.realtyPrice * 0.65;
      this.handlerButtonQs();
      // this.setMatCapital(this.maternalCapital, 'maternalCapital');
      // this.setMatCapital(this.money, 'money');
    });
  },
  methods: {
    getApi() {
      axios.get(apiUrl)
          .then((response) => {
            // handle success
            console.log(response);
            this.apix = response.data;
          })
          .catch((error) => {
            // handle error
            console.log(error);
            // this.apix = apixTemp;
          })
          .then(() => {
            this.getActualProducts();
            this.getApixValues(this.targetsCode);
            this.setInputsValues();
            this.initRange();
            this.getCalculationsFunctions();
          });
    },
    /**
     * установка первоначальных значений
     */
    setData() {
      this.selectArr[0].list = this.creditTarget[0].targetList;
    },
    /**
     * обновляет значение ширины экрана
     */
    updateWidth() {
      this.width = window.innerWidth;
    },
    /**
     * обрабока выбора Цели кредита
     * @param {Number} idx - позиция эл-та в массиве объектов цели (creditTarget)
     */
    handlerTarget(idx) {
      if (!this.creditTarget[idx].isActive) {
        for (let i = 0; i < this.creditTarget.length; i += 1) {
          this.creditTarget[i].isActive = false;
        }
        this.creditTarget[idx].isActive = true;
        this.selectArr[0].list = this.creditTarget[idx].targetList;
        const elem = this.creditProgram.find((el) => el.isActive === true);
        if (elem) {
          this.choiceCreditProgram(elem.id);
        }

        if (this.realty === this.creditTarget[idx].targetList[0].const) {
          this.setProgram(this.creditTarget[idx].key);
        } else {
          this.realty = this.creditTarget[idx].targetList[0].const;
        }
      }
    },
    /**
     * установка заголовка для активного Селекта
     * @param {Array<Object>} data - массив объектов выпадающего списка селекта
     * @returns {String} - наименование активного option
     */
    setSelectLabel(data) {
      for (let i = 0; i < data.length; i += 1) {
        if (data[i].isActive) {
          return data[i].name;
        }
      }
    },
    /**
     * обработка открытия/закрытия селекта
     * @param {Number} idx - позиция в массиве селектов (selectArr)
     */
    handlerToggleSelect(idx) {
      this.selectArr[idx].show = !this.selectArr[idx].show;
    },
    /**
     * закрывает выбранный селект
     * @param {Number} id - id в массиве селектов (selectArr)
     */
    closeSelect(id) {
      this.findToID(id, this.selectArr).show = false;
    },
    /**
     * обработка выбора селекта
     * @param {Number} id - позиция выбранного эл-та из массива option
     * @param {Number} idSelect - позиция в массиве селектов (selectArr)
     */
    handlerSelect(id, idSelect) {
      if (id !== 0 && this.targetSlide === 'pref') {
        this.choiceCreditProgram(0);
      }
      const activeSelect = this.findToID(idSelect, this.selectArr);
      const listArr = activeSelect.list;
      const activeList = this.findToID(id, listArr);
      this.removeClass(listArr);
      activeSelect.show = false;
      activeList.isActive = true;
      // TODO: узкое место, подумать как по другому
      if (activeSelect.id === 1) {
        this.currentRegion = activeList.id;
      }
      this.realty = activeList.const;
      this.matcap = false;
    },
    /**
     * обработка показа всех кредитных программ
     * @param {Boolean} data - флаг для показа/скрытия всех программ
     */
    handlerShowAllProgram(data) {
      this.showAllProgram = data;
    },
    /**
     * инициализация слайдера
     */
    initSlider() {
      mySwiper = new Swiper('#mortgage-slider', {
        loop: false,
        slidesPerView: 2,
        spaceBetween: 24,
        simulateTouch: false,
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
        },
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev'
        }
      });
      this.swiperInit = true;
    },
    /**
     * удаление слайдера
     */
    destroySwiper() {
      mySwiper.destroy(true, false);
      this.swiperInit = false;
    },
    /**
     * обработка выбора типа кредита
     * @param {Number} idx - позиция в массиве типов кредита (creditType)
     */
    handlerTypeCredit(idx) {
      this.removeClass(this.creditType);
      this.creditType[idx].isActive = true;
    },
    /**
     * выбор кредитной программы
     * @param {Number} id - id кредитной программы (creditProgram)
     */
    choiceCreditProgram(id) {
      const activeObj = this.findToID(id, this.creditProgram);
      if (!activeObj.isActive) {
        this.removeClass(this.creditProgram);
      }
      if (this.targetSlide === activeObj.const) {
        this.targetSlide = '';
      } else {
        this.targetSlide = activeObj.const;
      }
      activeObj.isActive = !activeObj.isActive;
      // this.setProgram(this.activeMortgageTabs);
    },
    /**
     * смена активного эл-та в массиве
     * @param {Object[]} data - массив объектов
     * @param {Boolean} data[].isActive - флаг для активного состояния
     */
    removeClass(data) {
      const arr = data;
      for (let i = 0; i < arr.length; i += 1) {
        arr[i].isActive = false;
      }
    },
    /**
     * поиск в массиве по id
     * @param {Number} id
     * @param {Array} arr
     * @returns {*}
     */
    findToID(id, arr) {
      return arr.find((el) => el.id === id);
    },
    /**
     * Инициализация range input
     */
    initRange() {
      this.initRealtySlider();
      this.initLoanSlider();
      this.initPledgeSlider();
      this.initPeriodSlider();
    },
    /**
     * Инициализация слайдера недвижимости
     */
    initRealtySlider() {
      this.realtySlider = noUiSlider.create(this.$refs.mortgagePrice, {
        start: [this.realtyPriceNumber],
        connect: 'lower',
        step: this.step,
        initial: this.realtyPrice,
        range: {
          min: this.stgMin,
          max: this.stgMax
        },
        format: {
          to: (value) => `${value},-`,
          from: (value) => Number(value.replace(',-', ''))
        }
      });

      this.realtySlider.on('change', (val) => {

        this.changeRealtyVal(val);
      });

      this.realtySlider.on('update', (val) => {
        const NumVal = Math.round(Number(val[0].replace(',-', '')));
        this.realtyPrice = `${this.addDigits(NumVal)} ₽`;
      });

      this.$refs.realtyInput.addEventListener('change', () => {
        this.changeRealtyVal(this.realtyPrice);
      });
    },
    /**
     * изменения значения инпута Недвижимости
     * @param val
     */
    changeRealtyVal(val) {
      let value = val;
      if (typeof value !== 'string') {
        value = val[0];
      }
      let NumVal = Math.floor(Number(value.replace(',-', '')));

      this.realtyPrice = NumVal;
      this.$nextTick(() => {
        this.getCalculationsFunctions();
      });
      this.realtySlider.set(this.realtyPrice);
      if (NumVal > this.stgMax) {
        NumVal = this.stgMax;
      }
      if (NumVal < this.stgMin) {
        NumVal = this.stgMin;
      }
      this.updatePrvSlider();
      this.pledgeSlider.set(this.pledge);
      this.getPrvPercent();

      if (this.activeMortgageTabs === 'refin' || this.activeMortgageTabs === 'pledge') {
        this.$nextTick(() => {
          this.loanSlider.set(this.loanAmount);
        });
        if (this.realtyPriceNumber === this.stgMin) {
          this.$refs.loanInput.setAttribute('disabled', 'disabled');
          this.$refs.loanInputWrap.classList.add('is-disabled');
        } else if (this.$refs.loanInput.getAttribute('disabled') === 'disabled') {
          this.$refs.loanInputWrap.classList.remove('is-disabled');
          this.$refs.loanInput.removeAttribute('disabled');
        }
      }

      if (this.activeMortgageTabs === 'pledge') {
        this.pledgeMaxRealty = this.realtyPriceNumber * 0.65;
        // eslint-disable-next-line max-len
        this.amountMin = this.realtyPriceNumber === this.stgMin ? this.realtyPriceNumber * 0.65 : this.stgMin;

        this.$nextTick(() => {
          this.loanSlider.updateOptions({
            range: {
              min: this.amountMin,
              // eslint-disable-next-line max-len
              max: this.realtyPriceNumber === this.stgMin ? this.realtyPriceNumber * 0.65 + 1 : this.realtyPriceNumber * 0.65
            }
          });
        });
      } else {
        this.$nextTick(() => {
          this.loanSlider.updateOptions({
            range: {
              min: this.amountMin,
              // eslint-disable-next-line max-len
              max: this.realtyPriceNumber === this.stgMin ? this.realtyPriceNumber + 1 : this.realtyPriceNumber
            }
          });
        });
      }
    },
    /**
     * инициализация слайдера Первоначального взноса
     */
    initLoanSlider() {
      this.loanSlider = noUiSlider.create(this.$refs.mortgageLoan, {
        start: [this.loanNumber],
        connect: 'lower',
        step: this.step,
        initial: this.loanAmount,
        range: {
          min: this.amountMin,
          max: this.realtyPriceNumber
        },
        format: {
          to: (value) => `${value},-`,
          from: (value) => Number(value.replace(',-', ''))
        }
      });

      this.loanSlider.on('change', (val) => {
        const NumVal = Math.floor(Number(val[0].replace(',-', '')));
        // this.loanAmount = NumVal;
        this.loanAmount = `${this.addDigits(NumVal)} ₽`;
        this.getKZ();
        this.getRate();
        this.getMonthlyPay();
        this.getIncome();
      });

      this.loanSlider.on('update', (val) => {
        const NumVal = Math.floor(Number(val[0].replace(',-', '')));
        this.loanAmount = `${this.addDigits(NumVal)} ₽`;
      });

      this.$refs.loanInput.addEventListener('change', () => {
        if (this.loanNumber > this.realtyPriceNumber) {
          this.loanNumber = this.realtyPriceNumber;
        }
        this.getKZ();
        this.getRate();
        this.getMonthlyPay();
        this.getIncome();
        this.loanSlider.set(this.loanAmount);
      });
    },
    /**
     * инициализация слайдера залога
     */
    initPledgeSlider() {
      this.pledgeSlider = noUiSlider.create(this.$refs.mortgagePledge, {
        start: [this.pledgeNumber],
        connect: 'lower',
        step: this.step,
        initial: this.pledgeNumber,
        range: {
          min: this.pledgeMin,
          max: this.pledgeMax
        },
        format: {
          to: (value) => `${value},-`,
          from: (value) => Number(value.replace(',-', ''))
        }
      });

      this.pledgeSlider.on('change', (val) => {
        const NumVal = Math.floor(Number(val[0].replace(',-', '')));
        // this.pledge = NumVal;
        this.pledge = `${this.addDigits(NumVal)} ₽`;

        this.getPrvPercent();
        this.getKZ();
        this.getMonthlyPay();
        this.getLoanAmount();
        this.getIncome();
      });

      this.pledgeSlider.on('update', (val) => {
        const NumVal = Math.floor(Number(val[0].replace(',-', '')));
        this.pledge = `${this.addDigits(NumVal)} ₽`;
        this.setMatCapital(this.money, 'money');
      });

      this.$refs.pledgeInput.addEventListener('change', () => {
        const NumVal = this.clearString(this.pledge);
        this.pledgeSlider.set(+NumVal);

        this.getPrvPercent();
        this.getKZ();
        this.getMonthlyPay();
        this.getLoanAmount();
        this.getIncome();

        if (this.pledge > this.pledgeMin) {
          this.pledge = this.pledgeMax;
        }
        if (this.pledge < this.pledgeMin) {
          this.pledge = this.pledgeMax;
        }
      });

      // мат. капитал
      this.$refs.matcapInput.addEventListener('change', () => {
        if (this.matCapitalNumber > this.matcapMax) {
          this.maternalCapital = this.matcapMax;
        }
        if (this.matCapitalNumber < this.matcapMin) {
          this.maternalCapital = this.matcapMin;
        }
        this.money = this.pledgeNumber - this.matCapitalNumber;
        if (this.pledgeNumber < this.pledgeMin) {
          this.pledge = this.pledgeMin;
          this.money = this.pledgeNumber - this.matCapitalNumber;
        }
        if (this.pledgeNumber > this.pledgeMax) {
          this.pledge = this.pledgeMax;
        }
        this.setMatCapital(this.maternalCapital, 'maternalCapital');
        this.setMatCapital(this.money, 'money');
      });

      // собств. средства
      this.$refs.moneyInput.addEventListener('change', () => {
        if (this.moneyNumber > this.pledgeMax) {
          this.money = this.pledgeMax - this.matCapitalNumber;
        }
        if (this.moneyNumber < this.moneyMin) {
          this.moneyNumber = this.pledgeMax;
        }
        this.pledge = this.matCapitalNumber + this.moneyNumber;
        if (this.pledgeNumber < this.pledgeMin) {
          this.pledge = this.pledgeMin;
          this.money = this.pledgeNumber - this.matCapitalNumber;
        }
        if (this.pledgeNumber > this.pledgeMax) {
          this.pledge = this.pledgeMax;
        }
        this.pledgeSlider.set(this.pledgeNumber);
        this.getPrvPercent();
        this.$nextTick(() => {
          this.getCalculationsFunctions();
        });
        this.setMatCapital(this.money, 'money');
      });
    },
    /**
     * инициализация слайдера срока кредита
     */
    initPeriodSlider() {
      this.periodSlider = noUiSlider.create(this.$refs.mortgagePeriod, {
        start: [this.periodNumber],
        connect: 'lower',
        step: 1,
        initial: this.period,
        range: {
          min: this.periodMin,
          max: this.periodMax
        },
        format: {
          to: (value) => `${value},-`,
          from: (value) => Number(value.replace(',-', ''))
        }
      });

      this.periodSlider.on('change', (val) => {
        const NumVal = Math.floor(Number(val[0].replace(',-', '')));
        // this.period = NumVal;
        this.period = `${NumVal} ${this.pluralize(NumVal, ['год', 'года', 'лет'])}`;
      });

      this.periodSlider.on('update', (val) => {
        const NumVal = Math.floor(Number(val[0].replace(',-', '')));
        this.$refs.periodInput.value = NumVal;
        this.period = `${NumVal} ${this.pluralize(NumVal, ['год', 'года', 'лет'])}`;
        this.getMonthlyPay();
        this.getIncome();
      });

      this.$refs.periodInput.addEventListener('change', () => {
        this.periodSlider.set(this.periodNumber);
        this.getMonthlyPay();
        this.getIncome();

        if (this.periodNumber > this.periodMax) {
          this.period = this.periodMax;
        }
        if (this.periodNumber < this.periodMin) {
          this.period = this.periodMin;
        }
      });
    },
    /**
     * склонение для периода
     * @param  {Number} count quantity for word
     * @param  {Array} words Array of words. Example:
     * ['депутат', 'депутата', 'депутатов'], ['коментарий', 'коментария', 'комментариев']
     * @return {String} Count + plural form for word
     */
    pluralize(count, words) {
      const cases = [2, 0, 1, 1, 1, 2];
      return words[(count % 100 > 4 && count % 100 < 20)
          ? 2
          : cases[Math.min(count % 10, 5)]];
    },
    /**
     * устанавливает и обновляет инпуты мат. капитала
     * @param {Number, String} val - значение инпута
     * @param {String} data - название переменной из data
     */
    setMatCapital(val, data) {
      let NumVal = val;
      if (typeof NumVal !== 'number') {
        NumVal = this.clearString(NumVal);
      }
      this[data] = `${this.addDigits(+NumVal)} ₽`;
    },
    /**
     * расставляет пробелы по разрядам
     * @param {Number} val
     * @returns {string}
     */
    addDigits(val) {
      return `${val}`.replace(/(\d)(?=(\d{3})+([^\d]|$))/g, '$1 ');
    },
    /**
     * чистит строку от пробелов и знака рубля
     * @param {String} val
     * @returns {String}
     */
    clearString(val) {
      if (typeof val !== 'string') {
        return val;
      }
      return val.replace(/ /g, '')
          .replace('₽', '');
    },
    /**
     * берез из строки - число
     * @param {String} val
     * @return {*}
     */
    clearPeriod(val) {
      if (typeof val !== 'string') return val;
      return val.split(' ')[0];
    },
    /**
     * забираем актуальные продукты для калькулятора
     */
    getActualProducts() {
      try {
        for (let i = 0; i < this.apix.length; i += 1) {
          if (this.productsActual.indexOf(this.apix[i].code) !== -1) {
            this.productsList[this.apix[i].code] = this.apix[i];
          }
        }
      } catch (err) {
        // this.catchCalculatorError();
      }
    },
    /**
     * устанавливает значения для основных переменных, из данных apix
     * @param {String} val - ключ кредитной программы
     */
    getApixValues(val) {
      try {
        // eslint-disable-next-line max-len
        [this.targetOptions, this.products, this.targets, this.targetsCode] = [this.productsList[val].options, this.productsList[val].product, this.productsList[val].name, val];
        // this.targetOptionsOld = this.targetOptionsFirst = this.targetOptions;
        this.sortOptions();
      } catch (err) {
        // this.catchCalculatorError();
      }
    },
    // пока не понял для чего это
    sortOptions() {
      this.$nextTick(() => {
        try {
          this.targetOptions.sort((a, b) => a.index - b.index);
          this.checkCurrentRegion(this.currentRegion);
        } catch (err) {
          // this.catchCalculatorError();
        }
      });
    },
    /**
     * рассчет и установка значений для range, согласно полученным данным
     */
    setInputsValues() {
      try {
        // const { realtyPrice } = this;
        // if (typeof this.realtyPrice !== 'number') {
        //     console.log('not-number');
        //     realtyPrice = +this.clearString(this.realtyPrice);
        // }
        // console.log('foo', this.realtyPriceNumber);
        this.pledgeMin = this.realtyPriceNumber * (this.products.parameters.minDebtToPledge / 100);
        this.pledgeMax = this.realtyPriceNumber * (this.products.parameters.maxDebtToPledge / 100);
        this.pledgeMinPrv = this.products.parameters.minDebtToPledge;
        this.pledgeMaxPrv = this.products.parameters.maxDebtToPledge;
        this.pledgeMiddle = this.pledgeMax / 2;
        this.periodMin = this.products.parameters.minCreditCalcPeriod / 12;
        this.periodMax = this.products.parameters.maxCreditCalcPeriod / 12;
        this.periodMiddle = this.periodMax / 2;
        // this.borrowermin = this.products.borrowerReqs.minAge;
        // this.borrowermax = this.products.borrowerReqs.maxAge;
      } catch (err) {
        // this.catchCalculatorError();
        console.log('что-то пошло не так setInputsValues');
      }
    },
    /**
     * выбор и установка подходящей программы кредитования
     * @param {String} val - название активного таба цели кредита
     */
    setProgram(val) {
      this.activeAllTarget();
      if (val === 'buy') {
        if (this.targetSlide === 'family') {
          this.getApixValues(this.realty);
          this.disabledTarget(['pledge']);
        } else if (this.targetSlide === 'pref') {
          this.getApixValues('product_preferential');
        } else if (this.targetSlide === 'dfo') {
          this.disabledTarget(['refin', 'pledge']);
          this.getApixValues(this.realty);
        } else {
          this.getApixValues(this.realty);
          if (this.realty === 'product_building_house') {
            this.prefHouseModifications();
          }
        }
      } else if (val === 'refin') {
        if (this.targetSlide === 'pref') {
          this.realty = 'product_refinancing';
          this.getApixValues('product_refinancing');
          this.rateDeduction = 0;
          this.targetSlide = '';
          this.targets = 'Рефинансирование';
        } else if (this.targetSlide === 'family') {
          this.getApixValues('product_family');
          this.disabledTarget(['pledge']);
        } else {
          this.realty = 'product_refinancing';
          this.getApixValues('product_refinancing');
          this.targets = 'Рефинансирование';
        }
      } else {
        this.getApixValues(this.realty);
      }
      this.getCalculationsFunctions();
    },
    /**
     * дизаблед для слайдов с программами ипотеки, которые не исопльзуются
     * @param {Array <String>} arr - массив с названием ключей для программ ипотеки
     */
    disabledTarget(arr) {
      arr.forEach((el) => {
        this.creditTarget.find((target) => target.key === el).isDisabled = true;
      });
    },
    /**
     * активиует все слайды с кредитными программами
     */
    activeAllTarget() {
      // eslint-disable-next-line no-param-reassign,no-return-assign
      this.creditTarget.forEach((el) => el.isDisabled = false);
    },
    // /**
    //  * показывать|скрывать слайд с программой
    //  * @param {Number} id - id слайда кредитной программы
    //  */
    // showSlide(id) {
    //     const slide = this.findToID(id, this.creditProgram);
    //     return (!(this.activeMortgageTabs === 'refin' && slide.const !== 'family'));
    // },
    getLoanAmount() {
      const price = +this.clearString(this.realtyPrice);
      const pledge = +this.clearString(this.pledge);
      this.loanAmount = Math.round(price - pledge);
      try {
        if (this.loanAmount > this.amountMaxRegion) {
          this.loanAmount = this.amountMaxRegion;
        }
        if (this.loanAmount < this.products.parameters.minCreditAmount) {
          this.loanAmount = this.products.parameters.minCreditAmount;
        }
      } catch (err) {
        console.log('что-то пошло не так');
        // this.catchCalculatorError();
      }
      this.loanSlider.set(this.loanAmount);
      // this.getRate();
    },
    getRate() {
      try {
        for (let i = 0; i < this.products.interestAmount.length; i += 1) {
          // eslint-disable-next-line max-len
          if (!this.products.interestAmount[i].minCreditToPledge && !this.products.interestAmount[i].maxCreditToPledge) {
            // eslint-disable-next-line max-len
            this.rate = this.products.interestAmount[i].interestPercent + this.rateDeduction;
          } else {
            // eslint-disable-next-line max-len,no-lonely-if
            if ((this.kz >= this.products.interestAmount[i].minCreditToPledge && this.kz <= this.products.interestAmount[i].maxCreditToPledge)
                // eslint-disable-next-line max-len
                || (this.kz >= this.products.interestAmount[i].minCreditToPledge && this.kz > this.products.interestAmount[i].maxCreditToPledge)) {
              // eslint-disable-next-line max-len
              this.rate = this.products.interestAmount[i].interestPercent + this.rateDeduction;
            }
          }
        }
        if (this.electronicFlag) {
          this.rate -= 0.3;
        }
      } catch (err) {
        console.log('ошибка в getRate');
        // this.catchCalculatorError();
      }
    },
    getPrvPercent() {
      this.prvPercent = Math.round((this.pledgeNumber / this.realtyPriceNumber) * 100);
    },
    getKZ() {
      if (this.activeMortgageTabs === 'buy') {
        // eslint-disable-next-line no-mixed-operators,max-len
        this.kz = (this.realtyPriceNumber - this.pledgeNumber) / this.realtyPriceNumber * 100;
      } else {
        this.kz = (this.loanNumber / this.realtyPriceNumber) * 100;
      }
      return this.kz;
    },
    getMonthlyPay() {
      let payment;
      if (this.activeMortgageTabs === 'refin' || this.activeMortgageTabs === 'pledge') {
        // eslint-disable-next-line no-mixed-operators,max-len,no-restricted-properties
        payment = ((this.loanNumber) * this.rate / 100 / 12) / (1 - Math.pow((1 + this.rate / 100 / 12), -(this.periodNumber * 12 - 1 - 1)));
      } else {
        // eslint-disable-next-line max-len,no-mixed-operators,no-restricted-properties
        payment = ((this.realtyPriceNumber - this.pledgeNumber) * this.rate / 100 / 12) / (1 - Math.pow((1 + this.rate / 100 / 12), -(this.periodNumber * 12 - 1 - 1)));
      }

      if (payment < 0) {
        payment = 0;
      }
      // eslint-disable-next-line no-return-assign
      return this.monthlyPay = Math.round(payment);
    },
    getIncome() {
      this.income = Math.round(this.monthlyPay / 0.6);
    },
    checkInputs() {
      if (this.pledge > this.pledgeMax) {
        this.pledge = this.pledgeMax;
      }
    },
    /**
     * запуск перерасчета всех показателей
     */
    getCalculationsFunctions() {
      this.checkInputs();
      this.getLoanAmount();
      this.getPrvPercent();
      this.getKZ();
      this.getRate();
      this.getMonthlyPay();
      this.getIncome();
    },
    updatePrvSlider() {
      try {
        if (this.targetsCode !== 'product_building' && this.targetsCode !== 'product_ready') {
          // eslint-disable-next-line max-len
          this.products.parameters.minDebtToPledge = 100 - this.products.parameters.maxDebtToPledge;
        }
        if (this.targetsCode === 'product_far_east' && this.realtyCode === 'product_house') {
          this.products.parameters.minDebtToPledge = 40;
        }

        // eslint-disable-next-line max-len
        this.pledgeMin = Math.round(this.realtyPriceNumber * (this.products.parameters.minDebtToPledge / 100));
        // eslint-disable-next-line max-len
        this.pledgeMax = Math.round(this.realtyPriceNumber * (this.products.parameters.maxDebtToPledge / 100));
        if (this.pledgeNumber < this.pledgeMin) {
          this.pledge = this.pledgeMin;
        }
        if (this.realtyPriceNumber - this.pledgeNumber >= this.amountMaxRegion) {
          this.pledge = Math.round(this.realtyPriceNumber - this.amountMaxRegion);
        }
        // eslint-disable-next-line max-len
        if (this.realtyPriceNumber - this.pledgeNumber < this.products.parameters.minCreditAmount) {
          // eslint-disable-next-line max-len
          this.pledge = Math.round(this.realtyPriceNumber - this.products.parameters.minCreditAmount);
        }
        if (this.matcap) {
          if (this.pledgeNumber !== this.money + parseInt(this.maternalCapital.replace(/\s/g, ''))) {
            this.money = this.pledgeNumber - parseInt(this.maternalCapital.replace(/\s/g, ''));
          }
        }
        this.pledgeSlider.updateOptions({
          range: {
            min: this.pledgeMin,
            max: this.pledgeMax
          }
        });
      } catch (err) {
        console.log('ошибка в updatePrvSlider');
        // this.catchCalculatorError();
      }
    },
    /**
     * модификация для программы "Льготное инд. строительство жилого дома"
     */
    prefHouseModifications() {
      this.targetOptions = this.productsList.product_building_house.options.filter((val) => val.code !== 'new_year_action');
      this.products = this.productsList.product_building_house.product;
      this.products.parameters.maxCreditCalcPeriod = 240;
      this.products.maxCreditAmount[0].maxCreditAmount = 6000000;
      // eslint-disable-next-line max-len,no-multi-assign
      this.products.maxCreditAmount[1].maxCreditAmount = this.products.maxCreditAmount[2].maxCreditAmount = this.products.maxCreditAmount[3].maxCreditAmount = this.products.maxCreditAmount[4].maxCreditAmount = 12000000;
      // eslint-disable-next-line max-len,no-multi-assign
      this.products.interestAmount[0].interestPercent = this.products.interestAmount[1].interestPercent = this.products.interestAmount[2].interestPercent = 6.5;
    },
    /**
     * простановка доп. опций
     * @param {Object} value - доп. опции
     * @return {*}
     */
    parseAddOptions(value) {
      const arr = [];
      if (value) {
        for (let i = 0; i < value.length; i += 1) {
          if (value[i].code.indexOf(this.realty) !== -1) {
            arr.push(value[i]);
          }
        }
      }
      return arr;
    },
    /**
     * обработка клика по доп. опциям
     * @param {Object} option - доп. опция
     */
    handlerOptionsCheck(option) {
      if (option.check) {
        this.rate = (this.rate * 10 + option.rate * 10) / 10;
      } else {
        this.rate = (this.rate * 10 - option.rate * 10) / 10;
      }
      this.getMonthlyPay();
    },
    /**
     * логика для отображения под.опций
     * @param {Object} option - доп. опции
     * @return {boolean}
     */
    showOption(option) {
      if (option.rate < -0.2 && !option.check) {
        const arr = this.options.filter((el) => el.rate < -0.2);
        for (let i = 0; i < arr.length; i += 1) {
          if (arr[i].check) {
            return false;
          }
        }
      }
      return true;
    },
    /**
     * значения для регионов
     * @param {Number} value - id выбраноного региона
     */
    checkCurrentRegion(value) {
      try {
        const regions = this.products.maxCreditAmount.filter(function(val) { return val.region });
        const moscowReg = regions.filter(function(val) { return val.region.code === '77' || val.region.code === '50' });
        const spbReg = regions.filter(function(val) { return val.region.code === '78' || val.region.code === '47' });
        const yamalReg = regions.filter(function(val) { return val.region.code === '89'});
        const otherRegion = this.products.maxCreditAmount.filter(function (val) { return val.hasOwnProperty('region') === false });
        switch(value.toString()) {
          case '0':
            this.amountMaxRegion = moscowReg[0].maxCreditAmount;
            break;
          case '1':
            this.amountMaxRegion = spbReg[0].maxCreditAmount;
            break;
          case '3':
            this.amountMaxRegion = this.products.maxCreditAmount[0].maxCreditAmount;
            break;
          case '2':
            this.amountMaxRegion = otherRegion[0].maxCreditAmount;
            break;
          case '5':
            this.amountMaxRegion = yamalReg[0].maxCreditAmount;
            break;
        }
      }
      catch(err) {
        console.log('что-то пошло не так в выборе регионов');
        // this.catchCalculatorError();
      }
    },
    /**
     * обработка кнопки Задать вопрос
     */
    handlerButtonQs() {
      const modalWindows = document.querySelectorAll('.modal');
      const modalOpeners = document.querySelectorAll('.js--modal-opener');

      for (let i = 0; i < modalOpeners.length; i++) {
        modalOpeners[i].addEventListener('click', () => {
          const modal = document.querySelector(modalOpeners[i].dataset.modal);
          modal.classList.add('open');
          const select = modal.querySelector('.js--select');
          const inp = select.querySelector('input');
          const lbl = select.querySelector('.js--select-place');
          inp.value = 'Ипотека';
          lbl.textContent = 'Ипотека';
          document.body.classList.add('modal-opened');
        });
      }

      for (let j = 0; j < modalWindows.length; j++) {
        modalWindows[j].addEventListener('click', (e) => {
          if (e.target.closest('.js--modal-closer')) {
            closeModal(modalWindows[j].id);
          }
        });
      }
    },
  }
};
</script>
