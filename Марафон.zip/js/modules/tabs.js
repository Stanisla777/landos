/* eslint-disable */
export function tabInstructions() {
    const tabs = document.querySelectorAll('.js--tab-inst');
    const tabPanels = document.querySelectorAll('.js--tab-panel-inst');

    for (let i = 0; i < tabs.length; i++) {
        tabs[i].addEventListener('click', () => {
            for (let j = 0; j < tabs.length; j++) {
                tabs[j].classList.remove('active');
            }

            for (let k = 0; k < tabPanels.length; k++) {
                tabPanels[k].style.display = 'none';
            }

            tabs[i].classList.add('active');
            for (let f = 0; f < tabPanels.length; f++) {
                if (tabPanels[f].dataset.tabPanel === tabs[i].dataset.tabValue) {
                    tabPanels[f].style.display = 'block';
                }
            }
        });
    }
}

export function tabDocuments() {
    const tabs = document.querySelectorAll('.js--tab-doc');
    const tabPanels = document.querySelectorAll('.js--tab-panel-doc');

    for (let i = 0; i < tabs.length; i++) {
        tabs[i].addEventListener('click', () => {
            for (let j = 0; j < tabs.length; j++) {
                tabs[j].classList.remove('active');
            }

            for (let k = 0; k < tabPanels.length; k++) {
                tabPanels[k].style.display = 'none';
            }

            tabs[i].classList.add('active');
            for (let f = 0; f < tabPanels.length; f++) {
                if (tabPanels[f].dataset.tabPanel === tabs[i].dataset.tabValue) {
                    tabPanels[f].style.display = 'block';
                }
            }
        });
    }
}

export function tabNews() {
    const tabs = document.querySelectorAll('.js--tab-news');
    const tabPanels = document.querySelectorAll('.js--tab-panel-news');
    const showAllTabs = document.querySelector('.js--round-cards-show-all');
    const showAllNews = document.querySelectorAll('.js--news-list-more-wrapper');

    if (tabs) {
        for (let i = 0; i < tabs.length; i++) {
            tabs[i].addEventListener('click', () => {
                for (let j = 0; j < tabs.length; j++) {
                    tabs[j].classList.remove('active');
                }

                for (let k = 0; k < tabPanels.length; k++) {
                    tabPanels[k].style.display = 'none';
                }

                tabs[i].classList.add('active');
                for (let f = 0; f < tabPanels.length; f++) {
                    if (tabPanels[f].dataset.tabPanel === tabs[i].dataset.tabValue) {
                        tabPanels[f].style.display = 'block';
                    }
                }
            });
        }

        if (showAllTabs) {
            showAllTabs.addEventListener('click', () => {
                showAllTabs.style.display = 'none';
                showAllTabs.closest('.round-cards').classList.remove('hidden');
            });
        }

        for (let j = 0; j < showAllNews.length; j++) {
            showAllNews[j].addEventListener('click', (e) => {
                if (e.target.classList.contains('js--news-list-more')) {
                    e.target.style.display = 'none';
                    e.target.closest('.js--tab-panel-news').querySelector('.news-list').classList.remove('hidden');
                }
            });
        }
    }
}

export function tabFAQ() {
    const tabs = document.querySelectorAll('.js--tab-faq');
    const tabPanels = document.querySelectorAll('.js--tab-panel-faq');

    for (let i = 0; i < tabs.length; i++) {
        tabs[i].addEventListener('click', () => {
            for (let j = 0; j < tabs.length; j++) {
                tabs[j].classList.remove('active');
            }

            for (let k = 0; k < tabPanels.length; k++) {
                tabPanels[k].style.display = 'none';
            }

            tabs[i].classList.add('active');
            for (let f = 0; f < tabPanels.length; f++) {
                if (tabPanels[f].dataset.tabPanel === tabs[i].dataset.tabValue) {
                    tabPanels[f].style.display = 'block';
                }
            }
        });
    }
}

export function tabCatalog() {
    const tabs = document.querySelectorAll('.js--tab-catalog');
    const tabPanels = document.querySelectorAll('.js--tab-panel-catalog');

  if (tabs) {
    for (let i = 0; i < tabs.length; i++) {
      tabs[i].addEventListener('click', () => {
        for (let j = 0; j < tabs.length; j++) {
          tabs[j].classList.remove('active');
        }

        for (let k = 0; k < tabPanels.length; k++) {
          tabPanels[k].style.display = 'none';
        }

        tabs[i].classList.add('active');
        const parent = tabs[i].closest('.js--container-filter');
        if (parent) {
          const mob_body = parent.querySelector('.js--openlist-body');
          const mob_btn = parent.querySelector('.js--openlist-btn p');
          const data = tabs[i].getAttribute('data-tab-value');
          let content = tabs[i].textContent;
          content = content.replace(/^\s\s*/, '').replace(/\s\s*$/, '');
          if (mob_body && mob_btn) {
            mob_body.querySelector(`.js--tab-catalog[data-tab-value="${data}"]`).classList.add('active')
            mob_btn.innerHTML = content
          }
        }

        for (let f = 0; f < tabPanels.length; f++) {
          if (tabPanels[f].dataset.tabPanel === tabs[i].dataset.tabValue) {
            tabPanels[f].style.display = 'block';
          }
        }
      });
    }
  }
}
