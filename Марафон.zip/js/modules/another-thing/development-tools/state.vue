<script>
import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios';

Vue.use(Vuex);

export default new Vuex.Store({
  state:{
    userId:null,
    id:null,

    post_answer:null, // сюда записывается ответ от посто запроса
    bonus_window:false,

    finish_window:false,
    final_win_target:false,

    btn_next_slider:false, // активная или нет кнопка слайдера Дальше

    temporary_data_radio:{},
    temporary_data_dual:{},
    temporary_data_check:{},
    temporary_data_slider:{},
    temporary_data_img:{},
    temporary_data_multi_radio:{},

    selected_data_check:[],
    selected_data_radio:[],
    selected_data_multi_radio:[],
    selected_data_dual:[],
    selected_data_slider:[],
    selected_data_img:[],

    selected_data_check_temp:[],

    objectPost:{
      id:null,
      userId:null,
      items:[
      ]
    },
    call_button_lock:false,
    status_internet:true,
    status_btn:false,

    attempt:0,
    hint:''
  },
  getters:{
    FINISHWINDOW(state){
      return state.finish_window
    },
    POSTANSWER(state){
      return state.post_answer
    },
    BONUSWINDOW(state){
      return state.bonus_window
    },
    BTNNEXT(state){
      return state.btn_next_slider
    },
    FINAL_WIN_TARGET(state){
      return state.final_win_target
    },
    CALL_BUTTON_LOCK(state){
      return state.call_button_lock
    },
    STATUSINTERNET(state){
      return state.status_internet
    },
    STATUSBTN(state){
      return state.status_btn
    },
    HINT(state){
      return state.hint
    },




  },
  mutations:{

    mutationVariantRadio(state,received_perem){
      let main_obj = {}
      state.temporary_data_radio= {}
      let key = received_perem[0];
      Vue.set(state.temporary_data_radio,'id_question',key)
      Vue.set(state.temporary_data_radio,'id_answer', { 'id':received_perem[1],value:true })
    },
    mutationVariantDual(state,received_perem){
      let main_obj = {}
      state.temporary_data_dual= {}
      let key = received_perem[0];
      Vue.set(state.temporary_data_dual,'id_question',key)
      Vue.set(state.temporary_data_dual,'id_answer', { 'id':received_perem[1],value:true })
    },
    mutationVariantChec(state,received_perem){
      let main_obj = {}
      state.temporary_data_check= {}
      let key = received_perem[0];
      Vue.set(state.temporary_data_check,'id_question',key)
      Vue.set(state.temporary_data_check,'id_answer', [{ 'id':received_perem[1],value:true }])
      state.selected_data_check.push(state.temporary_data_check)
    },
    mutationVariantChecDelete(state,received_perem){
      const id = received_perem[0]
      const id_answer = received_perem[1]
      for(let i=0;i<state.selected_data_check.length;i++){
        if(state.selected_data_check[i].id_question==id&&state.selected_data_check[i].id_answer[0].id==id_answer){
          const index = state.selected_data_check.findIndex(n => n.id_question === id&&n.id_answer[0].id===id_answer);
          if (index !== -1) {
            state.selected_data_check.splice(index, 1);
          }
        }
      }
    },
    mutationVariantMultiRadio(state,received_perem){
      let main_obj = {}
      // state.selected_data_check= []
      state.temporary_data_multi_radio= {}
      let key = received_perem[0];
      Vue.set(state.temporary_data_multi_radio,'id_question',key)
      Vue.set(state.temporary_data_multi_radio,'id_answer', [{ 'id':received_perem[1],value:received_perem[2] }])
      const id = received_perem[0]
      const id_answer = received_perem[1]
      for(let i=0;i<state.selected_data_multi_radio.length;i++){
        if(state.selected_data_multi_radio[i].id_question==id&&state.selected_data_multi_radio[i].id_answer[0].id==id_answer){
          const index = state.selected_data_multi_radio.findIndex(n => n.id_question === id&&n.id_answer[0].id===id_answer);
          if (index !== -1) {
            state.selected_data_multi_radio.splice(index, 1);
          }
        }
      }
      state.selected_data_multi_radio.push(state.temporary_data_multi_radio)
    },
    mutationVariantMultiRadioDelete(state,received_perem){
      const id = received_perem[0]
      const id_answer = received_perem[1]
      for(let i=0;i<state.selected_data_multi_radio.length;i++){
        if(state.selected_data_multi_radio[i].id_question==id&&state.selected_data_multi_radio[i].id_answer[0].id==id_answer){
          const index = state.selected_data_multi_radio.findIndex(n => n.id_question === id&&n.id_answer[0].id===id_answer);
          if (index !== -1) {
            state.selected_data_multi_radio.splice(index, 1);
          }
        }
      }
    },
    mutationVariantSlider(state,received_perem){
      let main_obj = {}
      state.temporary_data_slider= {}
      let key = received_perem[0];
      Vue.set(state.temporary_data_slider,'id_question',key)
      Vue.set(state.temporary_data_slider,'id_answer', { 'id':received_perem[1],value:true })
      // console.log(state.temporary_data_slider);
    },
    mutationInitializationSlider(state,received_perem){
      let main_obj = {}
      state.temporary_data_slider= {}
      let key = received_perem[0];
      Vue.set(state.temporary_data_slider,'id_question',key)
      Vue.set(state.temporary_data_slider,'id_answer', { 'id':received_perem[1],value:true })
      state.selected_data_slider.push(state.temporary_data_slider)
    },

    mutationVariantImg(state,received_perem){
      let main_obj = {}
      state.temporary_data_img= {}
      let key = received_perem[0];
      Vue.set(state.temporary_data_img,'id_question',key)
      Vue.set(state.temporary_data_img,'id_answer', [{ 'id':received_perem[1],value:true }])
      state.selected_data_img.push(state.temporary_data_img)
    },
    mutationVariantImgDelete(state,received_perem){
      const id = received_perem[0]
      const id_answer = received_perem[1]
      for(let i=0;i<state.selected_data_img.length;i++){
        if(state.selected_data_img[i].id_question==id&&state.selected_data_img[i].id_answer[0].id==id_answer){
          const index = state.selected_data_img.findIndex(n => n.id_question === id&&n.id_answer[0].id===id_answer);
          if (index !== -1) {
            state.selected_data_img.splice(index, 1);
          }
        }
      }
    },

    mutationClickBack(state){
      //Радиокнопка
      const id = state.temporary_data_radio.id_question
      for(let i=0;i<state.selected_data_radio.length;i++){
        if(state.selected_data_radio[i].id_question==id){

          const index = state.selected_data_radio.findIndex(n => n.id_question === id);
          if (index !== -1) {
            state.selected_data_radio.splice(index, 1);
          }
        }
      }
      if(Object.entries(state.temporary_data_radio).length!==0){

        state.selected_data_radio.push(state.temporary_data_radio)
      }
      state.temporary_data_radio= {}
      // console.log(state.selected_data_radio);
    },

    mutationClickForward(state){
      const array_question=[]
      //Радиокнопка
      const id = state.temporary_data_radio.id_question
      for(let i=0;i<state.selected_data_radio.length;i++){
        if(state.selected_data_radio[i].id_question==id){

          const index = state.selected_data_radio.findIndex(n => n.id_question === id);
          if (index !== -1) {
            state.selected_data_radio.splice(index, 1);
          }
        }
      }
      if(Object.entries(state.temporary_data_radio).length!==0){

        state.selected_data_radio.push(state.temporary_data_radio)
      }
      state.temporary_data_radio= {}

      //Слайдер
      const id_slider = state.temporary_data_slider.id_question
      for(let i=0;i<state.selected_data_slider.length;i++){
        if(state.selected_data_slider[i].id_question==id_slider){

          const index = state.selected_data_slider.findIndex(n => n.id_question === id_slider);
          if (index !== -1) {
            state.selected_data_slider.splice(index, 1);
          }
        }
      }
      if(Object.entries(state.temporary_data_slider).length!==0){
        state.selected_data_slider.push(state.temporary_data_slider)
      }
      state.temporary_data_slider= {}

      const id_dual = state.temporary_data_dual.id_question
      for(let i=0;i<state.selected_data_dual.length;i++){
        if(state.selected_data_dual[i].id_question==id_dual){

          const index = state.selected_data_dual.findIndex(n => n.id_question === id_dual);
          if (index !== -1) {
            state.selected_data_dual.splice(index, 1);
          }
        }
      }
      if(Object.entries(state.temporary_data_dual).length!==0){
        state.selected_data_dual.push(state.temporary_data_dual)
      }
      state.temporary_data_dual= {}

      // console.log(state);

    },
    mutationSendPost(state){
      if(state.attempt===0) {
        state.attempt = 1

        //Радиокнопки
        let obj_radio = {}
        let obj_2_radio = {}
        let array_radio = []
        for (let i = 0; i < state.selected_data_radio.length; i++) {
          Vue.set(obj_radio, state.selected_data_radio[i].id_answer.id, state.selected_data_radio[i].id_answer.value)
          array_radio.push(obj_radio)
          Vue.set(obj_2_radio, state.selected_data_radio[i].id_question, array_radio)
          state.objectPost.items.push(obj_2_radio)
          array_radio = []
          obj_radio = {}
          obj_2_radio = {}
        }

        //Чекбоксы
        // console.log(state.selected_data_check);
        // console.log(state.selected_data_check_temp);
        var output = [];
        let output_2 = []
        let obj_3 = {}


        state.selected_data_check.forEach(function (item) {
          var existing = output.filter(function (v, i) {
            return v.id_question == item.id_question;
          });
          if (existing.length) {
            var existingIndex = output.indexOf(existing[0]);
            output[existingIndex].id_answer = output[existingIndex].id_answer.concat(item.id_answer);
          } else {
            if (typeof item.id_answer == 'string')
              item.id_answer = [item.id_answer];
            output.push(item);
          }
        });
        state.selected_data_check = []
        state.selected_data_check = output

        for (let i = 0; i < state.selected_data_check.length; i++) {

          state.selected_data_check[i].id_answer.forEach(function (item) {
            Vue.set(obj_3, item.id, item.value)
            output_2.push(obj_3)
          })
          output_2.splice(1, output_2.length - 1)
          Vue.set(state.selected_data_check[i], state.selected_data_check[i].id_question, output_2)
          delete state.selected_data_check[i].id_question;
          delete state.selected_data_check[i].id_answer;
          output_2 = []
          obj_3 = {}
        }
        for (let i = 0; i < state.selected_data_check.length; i++) {
          state.objectPost.items.push(state.selected_data_check[i])
        }
        output = [];
        output_2 = [];
        obj_3 = {};

        //Мульти радиокнопки

        state.selected_data_multi_radio.forEach(function (item) {
          var existing = output.filter(function (v, i) {
            return v.id_question == item.id_question;
          });
          if (existing.length) {
            var existingIndex = output.indexOf(existing[0]);
            output[existingIndex].id_answer = output[existingIndex].id_answer.concat(item.id_answer);
          } else {
            if (typeof item.id_answer == 'string')
              item.id_answer = [item.id_answer];
            output.push(item);
          }
        });
        state.selected_data_multi_radio = []
        state.selected_data_multi_radio = output

        for (let i = 0; i < state.selected_data_multi_radio.length; i++) {

          state.selected_data_multi_radio[i].id_answer.forEach(function (item) {
            Vue.set(obj_3, item.id, item.value)
            output_2.push(obj_3)
          })
          output_2.splice(1, output_2.length - 1)
          Vue.set(state.selected_data_multi_radio[i], state.selected_data_multi_radio[i].id_question, output_2)
          delete state.selected_data_multi_radio[i].id_question;
          delete state.selected_data_multi_radio[i].id_answer;
          output_2 = []
          obj_3 = {}
        }
        for (let i = 0; i < state.selected_data_multi_radio.length; i++) {
          state.objectPost.items.push(state.selected_data_multi_radio[i])
        }
        output = [];
        output_2 = [];
        obj_3 = {};

        //Кнопки Да - Нет
        let obj_dual_btn = {}
        let obj_2_btn = {}
        let array_btn = []
        for (let i = 0; i < state.selected_data_dual.length; i++) {
          Vue.set(obj_dual_btn, state.selected_data_dual[i].id_answer.id, state.selected_data_dual[i].id_answer.value)
          array_btn.push(obj_dual_btn)
          Vue.set(obj_2_btn, state.selected_data_dual[i].id_question, array_btn)
          state.objectPost.items.push(obj_2_btn)
          array_btn = []
          obj_dual_btn = {}
          obj_2_btn = {}
        }

        //Слайдер
        let obj_slider = {}
        let obj_2_slider = {}
        let array_slider = []
        for (let i = 0; i < state.selected_data_slider.length; i++) {
          Vue.set(obj_slider, state.selected_data_slider[i].id_answer.id, state.selected_data_slider[i].id_answer.value)
          array_slider.push(obj_slider)
          Vue.set(obj_2_slider, state.selected_data_slider[i].id_question, array_slider)
          state.objectPost.items.push(obj_2_slider)
          array_slider = []
          obj_slider = {}
          obj_2_slider = {}
        }

        //Картинки
        state.selected_data_img.forEach(function (item) {
          var existing = output.filter(function (v, i) {
            return v.id_question == item.id_question;
          });
          if (existing.length) {
            var existingIndex = output.indexOf(existing[0]);
            output[existingIndex].id_answer = output[existingIndex].id_answer.concat(item.id_answer);
          } else {
            if (typeof item.id_answer == 'string')
              item.id_answer = [item.id_answer];
            output.push(item);
          }
        });
        state.selected_data_img = []
        state.selected_data_img = output

        for (let i = 0; i < state.selected_data_img.length; i++) {
          state.selected_data_img[i].id_answer.forEach(function (item) {
            Vue.set(obj_3, item.id, item.value)
            output_2.push(obj_3)
          })
          output_2.splice(1, output_2.length - 1)
          Vue.set(state.selected_data_img[i], state.selected_data_img[i].id_question, output_2)
          delete state.selected_data_img[i].id_question;
          delete state.selected_data_img[i].id_answer;
          output_2 = []
          obj_3 = {}
        }
        for (let i = 0; i < state.selected_data_img.length; i++) {
          state.objectPost.items.push(state.selected_data_img[i])
        }

        output = [];
        output_2 = [];
        obj_3 = {};

        // console.log(state.objectPost);

        axios({
          method: 'post',
          // url:'https://httpbin.org/post',
          url: '/api/local/gamedd/task/',

          timeout: 10000,
          headers: {
            "Content-type": "application/json; charset=UTF-8",
            'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
          },

          data: state.objectPost,//превращаем собранные данные в json
        })
          // Если запрос успешен
          .then((res) => {
            state.post_answer = null
            state.objectPost.items = []
            state.hint = ''

            state.post_answer = res.data.result

            // state.post_answer = { //для разработки
            //   "id":1,
            //   "score":123, // баллы ДД
            //   "points":100, // наши очки
            //   "rightAnswers":9,
            //   "wrongAnswers":14,
            //   "showFinancialLevel": false, // выводить ли уровень фин.грамотности ТОЛЬКО для теста "фин.грамотности"
            //   "financialLevel": 1, // null | 1 | 2 | 3 - уровень фин.грамотности ТОЛЬКО для теста "фин.грамотности"
            // }

            state.finish_window = true
            //для блокировки кнопки на детальной странице
            state.call_button_lock = true

          })
          // Если запрос с ошибкой
          .catch((error) => {
            if (error) {
              state.objectPost.items = []
            }
            // state.attempt=0
            if (error.response) {
              console.log(error.response);
              if (error.response.status == 401 || error.response.status == 403) {
                state.hint = `Время сессии истекло, перезагрузите страницу`
              } else {
                if (error.response && error.response.data.error != undefined && error.response.data.error.code) {
                  state.hint = `Ошибка ${error.response.data.error.code}. Обратитесь в колл-центр`
                } else {
                  state.hint = `Ошибка. Обратитесь в колл-центр`
                }
              }

              // if(error.response.status==404||error.response.status==522||error.response.status==524||error.response.status==523||error.response.status==503){
              //   state.hint=`Нет связи с сервером`
              // }
            } else if (error.request) {
              console.log(error.request);
              state.hint = `Нет связи с сервером`

            }
          });

      }
    },

    mutationBonusWindow(state){
      state.bonus_window=true
    },
    mutationCommonInfo(state,received_perem){
      state.objectPost.id=received_perem[0]
      state.objectPost.userId=received_perem[1]
    },

    mutationFinansialAdd(state,received_perem){
      // console.log(received_perem);

      if(state.attempt===0) {
        state.attempt = 1


        axios({
          method:'post',
          // url:'https://httpbin.org/post', //для раЗРАБОТКИ
          url:'/api/local/gamedd/task/',

          timeout: 10000,
          headers: {
            "Content-type": "application/json; charset=UTF-8",
            'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
          },

          data:{
            userId:state.objectPost.userId,
            id: state.objectPost.id,
            itemId:received_perem[0],
            itemValue:received_perem[1]
          },
        })
          // Если запрос успешен
          .then((res) => {
            state.post_answer = null
            state.finish_window = true
            state.post_answer = res.data.result
            state.hint=''

            // state.post_answer = { //для разработки
            //   "id":1,
            //   "score":700, // баллы ДД
            //   "points":600, // наши очки
            //   "rightAnswers":9,
            //   "wrongAnswers":14,
            //   "showFinancialLevel": false, // выводить ли уровень фин.грамотности ТОЛЬКО для теста "фин.грамотности"
            //   "financialLevel": 1, // null | 1 | 2 | 3 - уровень фин.грамотности ТОЛЬКО для теста "фин.грамотности"
            // }
          })
          // Если запрос с ошибкой
          .catch((error)=> {
            if (error.response) {
              console.log(error.response);
              if (error.response.status == 401 || error.response.status == 403) {
                state.hint = `Время сессии истекло, перезагрузите страницу`
              } else {
                if (error.response && error.response.data.error != undefined && error.response.data.error.code) {
                  state.hint = `Ошибка ${error.response.data.error.code}. Обратитесь в колл-центр`
                } else {
                  state.hint = `Ошибка. Обратитесь в колл-центр`
                }
              }

              // if(error.response.status==404||error.response.status==522||error.response.status==524||error.response.status==523||error.response.status==503){
              //   state.hint=`Нет связи с сервером`
              // }
            } else if (error.request) {
              console.log(error.request);
              state.hint = `Нет связи с сервером`

            }
            state.attempt=0
          });


      }


    },

    mutationBonus(state,received_perem){
      // console.log(received_perem);
      axios({
        method:'post',
        // url:'https://httpbin.org/post', //для раЗРАБОТКИ
        url:'/api/local/gamedd/task/',

        timeout: 10000,
        headers: {
          "Content-type": "application/json; charset=UTF-8",
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        },

        data:{
          userId:state.objectPost.userId,
          id: received_perem[0],
          itemValue:received_perem[1]
        },
      })
        // Если запрос успешен
        .then((res) => {
          state.post_answer = null
          state.finish_window = true
          state.post_answer = res.data.result

          // state.post_answer = { //для разработки
          //   "id":1,
          //   "score":700, // баллы ДД
          //   "points":600, // наши очки
          //   "rightAnswers":9,
          //   "wrongAnswers":14,
          //   "showFinancialLevel": false, // выводить ли уровень фин.грамотности ТОЛЬКО для теста "фин.грамотности"
          //   "financialLevel": 1, // null | 1 | 2 | 3 - уровень фин.грамотности ТОЛЬКО для теста "фин.грамотности"
          // }
        })
        // Если запрос с ошибкой
        .catch((error)=> {
          console.log(error);
        });

    },
    mutatioBtnSlider(state,received_perem){
      state.btn_next_slider=received_perem
    },
    mutatioInternet(state,received_perem){
      state.status_internet=received_perem
    },
    mutatioStatusBtn(state,received_perem){
      state.status_btn=received_perem
    },


  },
  actions:{

    //кликнули по варианту ответа радиокнопка
    ActionVariantRadio({commit,state},param){
      commit('mutationVariantRadio',param)
    },
    //клик по чекбоксу
    ActionVariantChec({commit,state},param){
      commit('mutationVariantChec',param)
    },
    //клик по чекбоксу которые ранее был выбран
    ActionVariantChecDelete({commit,state},param){
      commit('mutationVariantChecDelete',param)
    },
    //данные от компонента слайдер-ползунок ghb инициалтзации
    ActionInitializationSlider({commit,state},param){
      commit('mutationInitializationSlider',param)
    },
    //данные от компонента слайдер-ползунок
    ActionVariantSlider({commit,state},param){
      commit('mutationVariantSlider',param)
    },


    //клик по чекбоксу
    ActionVariantImg({commit,state},param){
      commit('mutationVariantImg',param)
    },
    //клик по чекбоксу которые ранее был выбран
    ActionVariantImgDelete({commit,state},param){
      commit('mutationVariantImgDelete',param)
    },

    //Клик в элементе две кнопки
    ActionVariantDual({commit,state},param){
      commit('mutationVariantDual',param)
    },




    //кликнули по варианту ответа мульти-радиокнопка
    ActionVariantMultiRadio({commit,state},param){
      commit('mutationVariantMultiRadio',param)
    },


    ActionClickBack({commit,state}){
      commit('mutationClickBack')
    },

    //клик по кнопке вперёд
    ActionClickForward({commit,state},param){
      if(param===false){
        commit('mutationClickForward')
      }
      else{
        commit('mutationClickForward')
        commit('mutationSendPost')
      }

    },

    //Вызов бонусного окна
    ActionBonusWindow({commit,state}){
      commit('mutationBonusWindow')
    },
    ActionCommonInfo({commit,state},param){
      commit('mutationCommonInfo',param)
    },
    ActionFinansialAdd({commit,state},param){
      commit('mutationFinansialAdd',param)
    },
    ActionBonus({commit,state},param){
      commit('mutationBonus',param)
    },


  //  Отправка данных на сервер
    ActionSendPost({commit,state},param){
      commit('mutatioSendPost',param)
    },
    ActionBtnSlider({commit,state},param){
      commit('mutatioBtnSlider',param)
    },

  //  проверка есть ли интернет
    ActionInternet({commit,state},param){
      commit('mutatioInternet',param)
    },
    ActionStatusBtn({commit,state},param){
      commit('mutatioStatusBtn',param)
    },





  },
})
</script>
