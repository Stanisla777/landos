<template lang="pug">
  .test-a__container-final-win
    .test-a__text-center
      p.test-a__question.test-a__final-window-question.
        Результат прохождения теста
      p.test-a__final-description.
        Вы завершили тест, а значит еще немного приблизились к своей цели
    .test-a__final-wr-result
      .test-a__final-result-col
        .test-a__final-result-label.true
          p Правильных ответов:<span>{{post_answer!=undefined?post_answer.rightAnswers:0}}</span>
          .test-a__final-result-icon
            svg(width='13', height='9', viewbox='0 0 13 9', fill='none', xmlns='http://www.w3.org/2000/svg')
              path(d='M11.4766 1.42822L4.92895 7.97584L1.95276 4.99965', stroke='white', stroke-width='2', stroke-linecap='round', stroke-linejoin='round')
        .test-a__final-result-label.false
          p Неправильных ответов:<span>{{post_answer!=undefined?post_answer.wrongAnswers:0}}</span>
          .test-a__final-result-icon
            svg(width='16', height='16', viewbox='0 0 16 16', fill='none', xmlns='http://www.w3.org/2000/svg')
              path(d='M11.5716 4.42822L4.42871 11.5711', stroke='white', stroke-width='2', stroke-linecap='round', stroke-linejoin='round')
              path(d='M4.42871 4.42822L11.5716 11.5711', stroke='white', stroke-width='2', stroke-linecap='round', stroke-linejoin='round')

      .test-a__final-result-col
          .test-a__final-result-label-row
            p Вы заработали:
          .test-a__final-result-wr-count
            .test-a__final-result-unit
              p.test-a__final-result-val +{{post_answer!=undefined?post_answer.score:0}}
              .test-a__final-result-unit-icon
                img(src="/dist/img/scored-icon1.png")
              p.test-a__final-result-key баллов

            .test-a__final-result-unit
              p.test-a__final-result-val +{{post_answer!=undefined?post_answer.points:0}}
              .test-a__final-result-unit-icon
                img(src="/dist/img/scored-icon2.png")
              p.test-a__final-result-key очков
    .test-a__final-wr-btn.test-a__final-win-wr-btn
      //Тут возможно нужны два варианта кнопок
      .test-a__btn.test-a__final-win-button.green(
        v-if="param===undefined||param===null||param===''"
        @click="closeModal"

      ) Завершить
      .test-a__btn.test-a__final-win-button.green(
        v-else
        @click="callBonusWindow"
      ) Далее


</template>
<script>
import Storage from '../development-tools/state.vue';

export default {
  name: 'FinalWindow',
  props:['param'],
  data(){
    return {

    }
  },
  methods: {
    callBonusWindow(){
      Storage.dispatch('ActionBonusWindow')
    },
    closeModal(el){
      const element = el.currentTarget
      element.closest('.modal-for-polls').classList.remove('open')
      document.body.classList.remove('body-unactive')
      document.body.classList.remove('body-modal')

      const scrollY = document.body.style.top;
      document.body.style.position = '';
      document.body.style.top = '';
      window.scrollTo(0, parseInt(scrollY || '0') * -1);

      document.ontouchmove =  (e)=> {
        return true;
      }
    }
  },
  computed: {
    post_answer(){
      return Storage.getters.POSTANSWER
    },
  },

};
</script>
<style scoped>
</style>
