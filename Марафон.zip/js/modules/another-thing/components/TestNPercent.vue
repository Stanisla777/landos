<template lang="pug">
  .test-n-percent
    label.test-n-percent__row(
      v-for="(answer, index) in options.answers"
      :class="setRowClasses(index)"
      :key="answer.text"
    )
      .test-n-checkbox.test-n-percent__checkbox(v-show="!isAnswered")
        input(
          v-model="answerValues[index]"
          :disabled="isAnswered"
          type="checkbox"
        )
        .test-n-checkbox__icon
      p.test-n-percent__text {{ answer.text }}
      p.test-n-percent__amount(v-if="isAnswered") {{ calculatePercentAmount(index) }}%
        span.test-n-percent__amount-description(v-if="isCheckboxWasPressed(index)")  ответили как вы
</template>

<script>
import testNComponent from '../mixin/testNComponent.js';

export default {
  name: 'TextNPercent',
  mixins: [testNComponent],
  props: {
    options: {
      type: Object,
      required: true
    },
  },
  computed: {
    textsOfChosenValues() { // выбранные ответы в текстовом виде
      const texts = [];
      if (this.isAnswered) {
        this.answerValues.forEach((isChosen, index) => {
          if (isChosen) texts.push(this.options.answers[index].text); // если вариант был выбран, его текст добавляется в массив
        })
      }
      return texts;
    },
    amountOfChosenValues() { // количество отмеченных ответов
      return this.answerValues.reduce((amount, value) => value ? ++amount : amount, 0)
    }
  },
  methods: {
    /**
     * Рассчитывает количество процентов голосов
     * @param {Number} index - индекс ответа
     */
    calculatePercentAmount(index) {
      if (!this.options.enough_data) {
        return this.answerValues[index] ? Math.round(100 / this.amountOfChosenValues) : 0;
      }
      return this.options.answers[index].percentAmount;
    },
    /**
     * Устанавливает длинну для массива ответов и задаёт дефолтные значения для них
     */
     setDefaultValues() {
      this.answerValues = new Array(this.options.answers.length);
      this.answerValues.fill(false);
    },
    /**
     * Устанавливает классы для отображения правильных/неправильных ответов
     * @param {Number} index - индекс ответа/вопроса
     */
    setRowClasses(index) {
      const classesObj = {
        'test-n-percent__row_bordered': true, // класс для смены состояния
        'test-n-percent__row_correct': this.answerValues[index] === true && this.answerValues[index] === this.options.answers[index].isCorrect, // если чекбокс отмечен и это верно
        'test-n-percent__row_uncorrect': this.answerValues[index] === true && this.answerValues[index] !== this.options.answers[index].isCorrect, // если чекбокс отмечен и это неверно
        'test-n-percent__row_should-be-answered': this.answerValues[index] === false && this.answerValues[index] !== this.options.answers[index].isCorrect, // если чекбокс не отмечен, хотя должен быть отмечен
      };
      return this.isAnswered ? classesObj : {};
    },
    /**
     * Был ли прожат чекбокс (был выбран ответ)
     * @param {Number} index - индекс вопроса
     */
    isCheckboxWasPressed(index) {
      return this.answerValues[index] === true;
    },
    /**
     * Подготавливает необходимые данные и вызывает событие для отправки
     */
    prepareDataForSend() {
      const data = {
        textsOfChosenValues: this.textsOfChosenValues
      };
      this.$emit('readyForDataSending', data);
    }
  }
}
</script>
