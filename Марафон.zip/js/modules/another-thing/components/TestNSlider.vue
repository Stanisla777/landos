<template lang="pug">
  .test-a__container(
    ref="test_container"
  )
    .test-a__body(
      ref="BodyLabel"
    )
      .test-n-slider.test-a__slider
        vue-slider(
          v-model="answerValue"
          ref="slider"
          :marks="this.array_param"
          :max="maxValue"
          :min="minValue"
          :process="false"
          :tooltip="'none'"
          :dot-size="32"
          :dot-style="{ height: '32px', width: '32px' }"
          :label-style="{ marginTop: '20px' }"
          :height="15"

          contained
          included
          silent
        )
    .test-a__slider-btn(
      v-if="modal===true"
    )
      .test-a__btn.white(
        v-if="btn_prev"
        @click="btnPrev"
      ) Назад
      .test-a__btn.green(
        v-if="btn_next&&((status_internet===true&&status_btn===false)||(status_internet===false&&status_btn===false)||(status_internet===true&&status_btn===true))"
        @click="btnNext"
      ) Далее
      .test-a__btn.unactive(
        v-if="!btn_next||(status_btn&&status_internet===false)"
      ) Далее
      p.test-a__error-hint(v-if="status_internet===false") Нет интернета
      p.test-a__error-hint(v-if="hint!=''") {{hint}}
</template>

<script>
import VueSlider from 'vue-slider-component';
import Storage from '../development-tools/state.vue';
import Vue from 'vue';
import eventBus from '../development-tools/eventBus.vue';

export default {
  name: 'TextNSlider',
  components: {
    VueSlider,
  },
  props: {
    param_component:Object,
    modal:Boolean
  },
  data() {
    return {
      answerValue: null,
      isAnswerValueCorrect: null,
      btn_next:true,
      btn_prev:true,
      count:0,
      count_slide:0,

      array_param:{}

    }
  },
  computed: {
    minValue() {
      return +Object.keys(this.array_param)[0]; // минимальное значение, первое значение из массива ответов
    },
    maxValue() {
      return +Object.keys(this.array_param).at(-1); // максимальное значение, первое значение из массива ответов
    },

    status_internet() {
      return Storage.getters.STATUSINTERNET;
    },
    status_btn() {
      return Storage.getters.STATUSBTN;
    },
    hint() {
      return Storage.getters.HINT;
    },

  },

  methods: {
    //В этом компоненте миксин расчёт высоты не подключал, так тут ингдивидуально

    autoHeight() {
      if (document.documentElement.clientWidth < 470) {
        const parent = this.$refs.test_container.closest('.js--test-cont');
        const title_height = parent.querySelector('.test-a__question').offsetHeight;
        parent.querySelector('.test-a__container')
          .setAttribute('style', `min-height:calc(100vh - 32px - 26px - 24px - ${title_height}px - 65px)`);
      }
    },
    btnNext(){
      this.count=0
      eventBus.$emit('eventbtnNext')
    },
    btnPrev(){
      this.count=0
      eventBus.$emit('eventbtnPrev')
    },
    fullnessCheck(){
      const array_label = this.$refs.BodyLabel.querySelectorAll('.js--percent-row input:checked');
      if(array_label.length!==0){
        this.btn_next=true
      }
    },
    /**
     * Проставляем класс active для лейбла выбранного значения, убираем у остальных
     */
    setActiveLabel() {
      const sliderEl = this.$refs.slider.$el;
      const labelEls = sliderEl.querySelectorAll('.vue-slider-mark-label');
      const param = this.array_param[this.answerValue]

      if (document.documentElement.clientWidth > 767) {
        labelEls.forEach((labelEl) => {
          labelEl.classList.remove('active');
          const text = labelEl.textContent
          if(text==param){
            labelEl.classList.add('active')
          }
        });
      }
      else if(document.documentElement.clientWidth <= 767){
        for(let i=0;i<labelEls.length;i++) {
          labelEls[0].textContent=param;
        }
      }


    },

    mobileActiveLabel(){
      const sliderEl = this.$refs.slider.$el;
      const labelEls = sliderEl.querySelectorAll('.vue-slider-mark-label');
      const param = this.array_param[this.answerValue]

    },


    checkAnswerValue() {
      this.isAnswerValueCorrect = this.answerValue === this.options.correctAnswer;
    },
    setDefault() {
      this.answerValue = null;
      this.isAnswerValueCorrect = null;
      this.$emit('valuesIsUnchosen');
    },
    /**
     * Подготавливает необходимые данные и вызывает событие для отправки
     */
    prepareDataForSend() {
      const data = {
        answerValue: this.answerValue,
        isAnswerValueCorrect: this.isAnswerValueCorrect
      };
      this.$emit('readyForDataSending', data);
    },

    dataTransformation(){
      for(let i = 0; i<this.param_component.options.length;i++){
        Vue.set(this.array_param,this.param_component.options[i].id,this.param_component.options[i].name)
      }
    }
  },
  watch: {
    answerValue() {
      this.setActiveLabel()
      // this.mobileActiveLabel()
      Storage.dispatch('ActionVariantSlider',[this.param_component.id,this.answerValue])

    },

  },
  mounted() {
    // this.autoHeight()
    this.dataTransformation();
    Storage.dispatch('ActionInitializationSlider',[this.param_component.id,this.minValue])
  },
  created(){
    eventBus.$on('slideReachBeginning',()=>{
      // if(this.count_reach===0){
      this.btn_prev=false
      //   this.count_reach=1
      // }
    })
    eventBus.$on('slideFromEdge',()=>{
      // if(this.count_reach===0){
      this.btn_prev=true
      //   this.count_reach=1
      // }
    })
  },
  updated() {
    // this.autoHeight()
    if(this.count_slide===0){
      const label = this.$refs.slider.$el.querySelectorAll('.vue-slider-mark-label');
      label[0].classList.add('active')
      this.count_slide=1;
    }

  }
}
</script>
