<template lang="pug">
  .test-a__counter
    p.test-a__counter-des.
      Вопрос <span>1</span> из {{count_slide}}
</template>
<script>
export default {
  name: 'SlideCalculator',
  props:['count_slide'],
  data(){
    return {

    }
  }
};
</script>
<style scoped>
</style>
