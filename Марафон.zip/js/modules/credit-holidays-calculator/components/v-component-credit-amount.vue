<template lang="pug">
  .calculator_s__calculator-row
    .calculator_s__period-input-wrapper
      p.calculator_s__calculator-label Сумма кредита
      .calculator_s__period-input-wrap-icon
        svg(width='6' height='9' viewbox='0 0 6 9' fill='none' xmlns='http://www.w3.org/2000/svg')
          path(d='M2.29615 5.82809V5.87809H2.34615H3.38128H3.43128V5.82809C3.43128 5.17718 3.88001 4.74316 4.37092 4.26834C4.3939 4.24612 4.41697 4.2238 4.44009 4.20137C4.95161 3.70514 5.47928 3.15761 5.47928 2.27748C5.47928 1.56616 5.1798 1.02591 4.72144 0.664646C4.26438 0.304406 3.65179 0.123828 3.0251 0.123828C1.94115 0.123828 0.916704 0.644209 0.518245 1.74851L0.503822 1.78848L0.540948 1.80916L1.42025 2.2989L1.47368 2.32866L1.49223 2.27038C1.60592 1.91305 1.80522 1.65293 2.06481 1.48165C2.32489 1.31005 2.64868 1.22557 3.01397 1.22557C3.39653 1.22557 3.72964 1.31585 3.96588 1.49634C4.20027 1.67543 4.34415 1.94688 4.34415 2.322C4.34415 2.63879 4.22214 2.90106 4.03445 3.14622C3.87409 3.35566 3.66836 3.5496 3.45209 3.75346C3.41356 3.78978 3.37469 3.82642 3.33569 3.86351C2.82303 4.3511 2.29615 4.90943 2.29615 5.82809ZM2.85815 8.28226C3.29809 8.28226 3.63162 7.93659 3.63162 7.50879C3.63162 7.08098 3.29809 6.73531 2.85815 6.73531C2.42984 6.73531 2.08467 7.08048 2.08467 7.50879C2.08467 7.9371 2.42984 8.28226 2.85815 8.28226Z' fill='#1C1B28' stroke='#1C1B28' stroke-width='0.1')
      template
        tool-tip(
          :hint_text="hint_text"
        )
    .range-input__wrapper.calculator_s__wrapper-cost-apartment.js--number-cost(
      @click="inputFocus"
      :class="[region_restriction!==true?'error':false]"
      )
      input.range-input__value(inputmode="numeric")(
        @keydown="inputField"
        @keyup="inputUp"
        v-model="realtyPrice"
        type="text"
        ref="realtyInput"
        @input="showEnter"
        @change ="inputValue"
      )
      .calculator_s__enter-button(

        @click="enteredData"
        v-show="input_salary"
      )
        svg(width='20' height='20' viewbox='0 0 20 20' fill='none' xmlns='http://www.w3.org/2000/svg')
          path(d='M4.64119 12.5L7.51402 15.2038C7.81565 15.4877 7.83004 15.9624 7.54615 16.264C7.26226 16.5657 6.78761 16.58 6.48598 16.2961L2.23598 12.2961C2.08539 12.1544 2 11.9568 2 11.75C2 11.5432 2.08539 11.3456 2.23598 11.2038L6.48598 7.20385C6.78761 6.91996 7.26226 6.93435 7.54615 7.23598C7.83004 7.53761 7.81565 8.01226 7.51402 8.29615L4.64118 11L14.75 11C15.7165 11 16.5 10.2165 16.5 9.25V4.75C16.5 4.33579 16.8358 4 17.25 4C17.6642 4 18 4.33579 18 4.75V9.25C18 11.0449 16.5449 12.5 14.75 12.5L4.64119 12.5Z' fill='#8bc540')
      .range-input__slider(ref="mortgagePrice")
    .calculator_s__cost-flat
      p.calculator_s__cost-flat-min {{String(stgMin).slice(0,2)}} тыс.
      p.calculator_s__cost-flat-min {{unit_currency}}
      //p.calculator_s__cost-flat-min {{max_sum}}

    //p.calculator_s__input-error(v-if="!region_restriction") Максимальная сумма кредита превышена

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import noUiSlider from 'nouislider';
import Storage from '../development-tools/state.vue';
import IMask from 'imask';
import ToolTip from '../components/v-component-tooltip.vue';
export default {
  name: 'v-component-credit-amount',
  data(){
    return {
      stgMin: 20000, // Минимальное значение поля стоимости
      stgMax: 20000000, // Максимальное значение поля стоимости
      input_salary:false,
      realtyPrice: 0, // Стоимость недвижимости
      realtyPriceForCalculation: 0,
      error_input:true,
      hint_text:`
        <div class="calculator_s__tooltip-item">
         <p class="calculator_s__tooltip-title">Размер максимальной суммы ипотечного кредита:</p>
         <p class="calculator_s__tooltip-des">
          <span>Москва – 6 млн рублей;</span>
          <span>Московская область, Санкт-Петербург и регионы, входящие в Дальневосточный федеральный округ – 4 млн рублей;</span>
          <span>остальные регионы – 3 млн рублей.</span>
         </p>
        </div>
        <div class="calculator_s__tooltip-item">
         <p class="calculator_s__tooltip-title">Для остальных кредитов:</p>
         <p class="calculator_s__tooltip-des">
          <span>автокредит – 700 тыс. рублей;</span>
          <span>потребительские займы – 300 тыс. рублей (для ИП – 350 тыс. рублей);</span>
          <span>кредитные карты –100 тыс. рублей.</span></p>
         </div>
      `,
      unit_currency:'50 тыс'
    }
  },
  methods:{
    initRealtySlider() {
      this.realtySlider = noUiSlider.create(this.$refs.mortgagePrice, {
        start: [this.stgMin],
        connect: 'lower',
        step: this.stepApartment,
        initial: this.stgMin,
        range: {
          min: this.stgMin,
          max: this.max_sum
        },
      });

      this.realtySlider.on('update', (val,handle) => {
        this.input_salary = false
        this.realtyPrice = parseInt(val[handle]).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ') + ' ₽'
        this.realtyPriceForCalculation = parseInt(val[handle]).toFixed(0)
      });

    },
    inputCost(){
      const input_status = document.querySelectorAll('.js--number-cost input');
      const maskOptions = {
        mask: Number,
        thousandsSeparator: ' ',
        // max:this.max_sum

      };
      for (const item of input_status) {
        new IMask(item, maskOptions);
      }
    },
    enteredData(el){
      const element = el.currentTarget
      const parent = element.closest('.js--number-cost')
      let value = parent.querySelector('input').value
      value = parseInt(value.replace(/\s/g, ''));
      this.realtySlider.set(value);
    },
    showEnter(el){
      const element = el.currentTarget
      this.input_salary=true
      let val = parseInt(element.value.replace(/\s/g, ''))
      if (val >this.max_sum) {
        this.realtyPrice=this.max_sum
      }
    },
    inputFocus(el){
      const element = el.currentTarget
      element.querySelector('input').focus()
    },
    //Ввод значения пользователем
    inputField(event){
      const element = event.currentTarget
      let value = element.value
      const selection_start = element.selectionStart;
      var arr = Array.from(value);
      if(arr[selection_start-1]=="₽"){
        // event.preventDefault();
      }

      value = parseInt(value.replace(/\s/g, ''));
      // Разрешаю ввод только цифр и некоторых других клавиш
      // if ( event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 ||
      //   // Разрешаем: Ctrl+A
      //   (event.keyCode == 65 && event.ctrlKey === true) ||
      //   // Разрешаем: home, end, влево, вправо
      //   (event.keyCode >= 35 && event.keyCode <= 39)) {
      //
      //   // Ничего не делаем
      //   return;
      // } else {
      //   // Запрещаем все, кроме цифр на основной клавиатуре, а так же Num-клавиатуре
      //   if ((event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105 )) {
      //     event.preventDefault();
      //   }
      // }
      if(event.keyCode == 13){
        const parent = element.closest('.js--number-cost')
        let value = parent.querySelector('input').value
        value = parseInt(value.replace(/\s/g, ''));
        this.realtySlider.set(value);
      }
      if(value>this.max_sum){
        // element.value = this.max_sum
        event.preventDefault();
      }
    },
    inputUp(){},

    // расчет ндфл стоимости квартиры и отправка данных о квартире в компоненту с итоговой суммой
    calculationPageLoad(){
      Storage.dispatch('ActionCreditAmount',parseInt(this.realtyPriceForCalculation))
    },
    inputValue(el){
      const element = el.currentTarget;
      let value = element.value
      value = parseInt(value.replace(/\s/g, ''));
      const parent = element.closest('.range-input__wrapper')
      // parent.querySelector('.calculator_s__enter-button').click()
      if(this.realtyPrice=='NaN'){
        this.realtyPrice=''
      }
      this.realtyPriceForCalculation = value
      this.calculationPageLoad()
      // this.realtySlider.set(value);
    },
    formationUnitCurrency(param){

      const len = String(param).length;
      let new_param;
      if(len>6){
        new_param = param.toString();
        new_param = new_param.slice(0, -6);
        new_param = parseInt(new_param) + ' млн.';
      }
      else {
        new_param = param.toString();
        new_param = new_param.slice(0, -3);
        new_param = parseInt(new_param) + ' тыс.';
      }
      this.unit_currency = new_param
    }
  },
  mounted(){
    this.initRealtySlider()
    this.inputCost()
  },
  computed:{
    region_restriction(){
      return Storage.getters.SOLUTION_REGION
    },
    max_sum(){
      return Storage.getters.MAX_SUMM
    }
  },
  watch:{
    //как только стоимость квартиры изменилась, вызываю функцию
    realtyPrice(){
      this.calculationPageLoad()
    },
    max_sum(){
      this.realtySlider.updateOptions({
        range: {
          'min': this.stgMin,
          'max': this.max_sum
        }
      });
      this.formationUnitCurrency(this.max_sum)

    }

  },
  created(){

  },

  components:{
    ToolTip
  }
};
</script>
<style scoped>
</style>
