<template lang="pug">
  .calculator_s__calculator-row.credit-holiday__every-month-salary.js--every-month-salary
    .credit-holiday__salary-item(
      v-for="item in months"
    )
      p.calculator_s__calculator-label {{item}}
      .calculator_s__calculator-input.calculator_s__placeholder-numeric-set.js--salary-per-year(
        @click="inputFocus"
      )
        .credit-holiday__salary-month-wr
          input(type="text" inputmode="numeric" placeholder="Введите сумму")(
            @input="inputValue"
            @keyup="inp_sum"
            @keydown="inp_sum"
            @paste="inp_sum"
            @focus="inp_sum"
          )
          p.currency-salary ₽

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import numberFormatting from '../custom-scripts/number-formatting.js'
import IMask from 'imask';
import Storage from '../development-tools/state.vue';
export default {
  name: 'v-component-salary-monthly',
  data(){
    return {
      stgMax:900000,
      months:['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь',],
      currency:false
    }
  },
  methods:{
    inp_sum(e){
      const e_field = e.currentTarget
      numberFormatting(e_field)
    },
    inputCost(){
      const input_status = document.querySelectorAll('.js--salary-per-year input');
      const maskOptions = {
        mask: Number,
        thousandsSeparator: ' ',
        // max:this.stgMax,
      };
      for (const item of input_status) {
        new IMask(item, maskOptions);
      }
    },
    inputValue(el){
      const element = el.currentTarget;
      element.style.width = 0+'px';

      if(element.value.length>0){
        element.setAttribute('placeholder',0)
        element.closest('.credit-holiday__salary-item').querySelector('.currency-salary').setAttribute('style','display:block;')
        Storage.dispatch('ActionInputPerYear',true)
      }
      else {
        element.setAttribute('placeholder','Введите сумму')
        element.closest('.credit-holiday__salary-item').querySelector('.currency-salary').setAttribute('style','display:none;')
        element.style.width=100+"%"

        const array_borrower = document.querySelectorAll('.calculator_s__wrap-borrower')

        let arr_salary = [];
        for (let item of array_borrower) {

          let array_input_salary = item.querySelectorAll('.js--salary-per-year input');

          for (let elem of array_input_salary) {

            let input_salary = elem.value;
            if (input_salary == '') {
              input_salary = 0;
            } else {
              input_salary = parseInt(input_salary.replace(/\s/g, ''));
            }
            arr_salary.push(input_salary);
            arr_salary = arr_salary.filter(function(f) { return f !== 0 })

            // if(!elem.closest('.calculator_s__wrap-borrower').classList.contains('salary-option')){
            //   arr_salary.splice(1);
            // }
          }
        }
        if(arr_salary.length==0){
          Storage.dispatch('ActionInputPerYear',false)
        }

      }
      if(element.value.length==0){
        element.style.width = element.scrollWidth + 15 + 'px';
      }
      else if(element.value.length==4){
        element.style.width = element.scrollWidth + 8 + 'px';
      }
      else if(element.value.length==8){
        element.style.width = element.scrollWidth + 4 + 'px';
        let val = element.value.replace(/\s/g, '')
        // return false
      }

      else {
        element.style.width = element.scrollWidth + 4 + 'px';
      }
      let val = element.value.replace(/\s/g, '')
    },
    sendInputChange(param){

    },
    inputFocus(el){
      const element = el.currentTarget
      element.querySelector('input').focus()
    },
  },
  mounted(){
    // this.inputCost()
  },
  computed:{},
  watch:{
  },
  created(){

  },
  components:{}
};
</script>
<style scoped>
</style>
