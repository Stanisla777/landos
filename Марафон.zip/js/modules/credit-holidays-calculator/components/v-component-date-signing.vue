<template lang="pug">
  .calculator_s__calculator-row
    .calculator_s__period-input-wrapper
      p.calculator_s__calculator-label Дата заключения кредитного договора (до 01.03.2022)
    .calculator_s__calculator-input.js--calendar-input(
      :class="[error_input===true?'error':false]"
    )
      input(type="text" placeholder="дд.мм.гггг")(
        @input="changeDate"
      )
    p.calculator_s__input-error(v-if="error_input") Дата не соответствует условиям
</template>
<script>
import IMask from 'imask';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import PopUp from '../components/v-component-pop-up.vue';
export default {
  name: 'v-date-signing',
  data(){
    return {
      error_input:false,
      error_count:0
    }
  },
  methods:{
    inputCalendar(){
      const input_status = document.querySelectorAll('.js--calendar-input input');
      const maskOptions = {
        mask: Date,
        min: new Date(1982, 0, 1),
        max:new Date(2022, 1, 28),
        // lazy:false
      };
      // eslint-disable-next-line no-restricted-syntax,camelcase,no-undef
      for (const item of input_status) {
        // eslint-disable-next-line no-new
        new IMask(item, maskOptions);
      }
    },
    changeDate(el) {
      const element = el.currentTarget;
      const container = element.closest('.js--tax-deduction_calculations');
      this.error_input = false;
      if (element.value.length == 10&&element.value.includes('_')==false||(element.value.length == 11&&element.value.includes('_')==true)) {

        let substr_year = element.value.substring(element.value.length - 4, element.value.length);
        substr_year = parseInt(substr_year);

        let substr_month = element.value.substring(element.value.length - 7, element.value.length - 5);
        substr_month = parseInt(substr_month);

        let substr_day = element.value.substring(0, 2);
        substr_day = parseInt(substr_day);


        if ((substr_year == 2022 && substr_month >= 3)||substr_year > 2022) {
          this.error_input = true;
          Storage.dispatch('ActionInputDate', false);

        }



        else {
          this.error_input = false;
          Storage.dispatch('ActionInputDate', true);
        }

      }
      else if(element.value.length < 10 ||(element.value.length == 10)){
        Storage.dispatch('ActionInputDate', false);
      }
      else {
        return false
        Storage.dispatch('ActionInputDate', false);
      }
    }
  },
  mounted(){
    this.inputCalendar()
  },
  computed:{},
  watch:{
  },
  components:{
    PopUp
  }
};
</script>
<style scoped>
</style>
