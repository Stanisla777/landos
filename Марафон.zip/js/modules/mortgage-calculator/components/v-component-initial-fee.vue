<template lang="pug">
  .property-calculator__row.margin
    p.property-calculator__row-label Первоначальный взнос, ₽
    .property-calculator__input-field.mortgage-calculator__initial-fee.js--initial-fee(
      :class="{unactive:activeInput}"
      @click="inputFocus"
    )
      input.property-calculator__value(inputmode="numeric" placeholder="Введите сумму")(
        v-model="dataField"
        type="text"
        ref="realtyInput"
        @keydown="inputField"
        @keyup="keyUp"
        @change="inputValue"
        @paste="inputPast"
      )
      .range-input__slider(ref="mortgagePrice")
    .calculator_s__cost-flat
      .property-calculator__wr-range
        p.property-calculator__range {{stgMin}}
        p.property-calculator__range {{String(stgMax).slice(0,2)}} млн

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import numberFormatting from '../custom-scripts/number-formatting.js'
import onlyNumbers from '../custom-scripts/only-numbers.js'
import IMask from 'imask';
import Storage from '../development-tools/state.vue';
import noUiSlider from 'nouislider';
export default {
  name: 'v-component-initial-fee',
  props:[],
  data(){
    return {
      activeInput:false,
      realtySlider: '', // Слайдер "Стоимость недвижимости"
      dataField: 0, // Стоимость недвижимости
      dataFieldForCalculation: 0,
      subsidies: 0,
      stepApartment: 1, // Шаг для range инпутов
      stgMin: 0, // Минимальное значение поля стоимости
      stgMiddle: 27000000, // Значение по середине (стоимость)
      stgMax: 56000000, // Максимальное значение поля стоимости
      input_salary:false
    }
  },
  methods:{
    initRealtySlider() {
      this.realtySlider = noUiSlider.create(this.$refs.mortgagePrice, {
        start: [this.stgMin],
        connect: 'lower',
        step: this.stepApartment,
        initial: this.stgMin,
        range: {
          min: this.stgMin,
          max: this.stgMax
        },
      });

      this.realtySlider.on('update', (val,handle) => {
        this.dataField = parseInt(val[handle]).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        this.dataFieldForCalculation = parseInt(val[handle]).toFixed(0)
      });
      this.realtySlider.on('end', (val,handle) => {
        // this.dataField = parseInt(val[handle]).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        // this.dataFieldForCalculation = parseInt(val[handle]).toFixed(0)
      });

    },
    //Ввод значения пользователем
    inputField(event){
      const element = event.currentTarget
      let value = element.value

      value = parseInt(value.replace(/\s/g, ''));
      if ( event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 ||
        // Разрешаем: Ctrl+A
        (event.keyCode == 65 && event.ctrlKey === true) ||
        // Разрешаем: home, end, влево, вправо
        (event.keyCode >= 35 && event.keyCode <= 39)) {

        // Ничего не делаем
        return;
      } else {
        // Запрещаем все, кроме цифр на основной клавиатуре, а так же Num-клавиатуре
        if ((event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105 )) {
          event.preventDefault();
        }
      }

      if(event.keyCode == 13){
        const parent = element.closest('.js--number-cost')
        let value = parent.querySelector('input').value
        value = parseInt(value.replace(/\s/g, ''));
        this.realtySlider.set(value);
      }
      if(value>this.stgMax){
        event.preventDefault();
      }
    },

    keyUp(e){
      const element = e.currentTarget

      if(element.value!==''&&(parseInt(element.value.replace(/\s/g, ''))>=this.stgMin)&&parseInt(element.value.replace(/\s/g, ''))<=this.stgMax){
        this.realtySlider.set(parseInt(element.value.replace(/\s/g, '')));
      }
      else if(parseInt(element.value.replace(/\s/g, ''))>this.stgMax)  {
        this.realtySlider.set(this.stgMax);
      }


      let val = parseInt(element.value.replace(/\s/g, ''))

      if(val>=this.limit_init_fee){
        e.preventDefault()
        this.realtySlider.set(this.limit_init_fee);
        // element.value = this.limit_init_fee

      }

    },

    inputPast(el){
      const element = el.currentTarget;
      let element_val = (el.clipboardData || window.clipboardData).getData('text');
      if ( element_val.search(/[^0-9]/g) != -1 ) {
        el.preventDefault();
      }
    },

    inputValue(el){
      const element = el.currentTarget;
      let value = element.value
      value = parseInt(value.replace(/\s/g, ''));

      if(value<this.stgMin)  {
        this.dataFieldForCalculation = this.stgMin
        this.realtySlider.set(this.stgMin);
      }
    },

    inputFocus(el){
      const element = el.currentTarget
      element.querySelector('input').focus()
    },
    calculationPageLoad(param){
      Storage.dispatch('ActionInitialFee',parseInt(this.dataFieldForCalculation))
    },
  },
  mounted(){
    this.initRealtySlider()

  },
  computed:{
    limit_init_fee(){
      return Storage.getters.LIMITINITFEE
    },
    init_fee(){
      return Storage.getters.INITIALFEE
    },
    init_fee_show(){
      return Storage.getters.INITIALFESHOW
    },
    checkbox_status(){
      return Storage.getters.CHECKBOXSTATUS
    },
  },
  watch:{
    limit_init_fee(){
      this.realtySlider.updateOptions({
        range: {
          min: this.stgMin,
          max: this.limit_init_fee
        }
      });
    },
    init_fee(){
      this.checkbox_status
      if(this.checkbox_status===true){
        this.realtySlider.set(this.init_fee);
      }
    },
    dataField(){
      this.calculationPageLoad()
    }

  },
  created(){
    eventBus.$on('realtyPrice',(param)=>{
      this.stgMax=parseInt(param)
    })
    eventBus.$on('eventcheckboxChanged',(param)=>{
      this.activeInput=param
      const input = document.querySelector('.js--initial-fee input')

    })
  },
  components:{}
};
</script>
<style scoped>
</style>
