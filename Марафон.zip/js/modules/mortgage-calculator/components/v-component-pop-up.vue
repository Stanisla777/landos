<template lang="pug">
  .property-calculator__modal-container.refinancing-calc__modal-container
    .property-calculator__modal-wrapper.refinancing-calc__modal-wrapper(
      v-bind:class="modal_state?'active':''"
    )
      .calculator_s__tooltip-icon-close(@click="closePopUp")
        svg(width='48', height='48', viewbox='0 0 48 48', fill='none', xmlns='http://www.w3.org/2000/svg')
          circle(cx='24', cy='24', r='23', fill='#F1F2F4', stroke='#F1F2F4', stroke-width='2')
          path(d='M16.2227 31.7782C15.8322 31.3876 15.8322 30.7545 16.2227 30.3639L30.3649 16.2218C30.7554 15.8313 31.3886 15.8313 31.7791 16.2218C32.1696 16.6123 32.1696 17.2455 31.7791 17.636L17.6369 31.7782C17.2464 32.1687 16.6133 32.1687 16.2227 31.7782Z', fill='#1C1B28')
          path(d='M31.7774 31.7784C31.3869 32.1689 30.7537 32.1689 30.3632 31.7784L16.2211 17.6362C15.8305 17.2457 15.8305 16.6125 16.2211 16.222C16.6116 15.8315 17.2448 15.8315 17.6353 16.222L31.7774 30.3642C32.1679 30.7547 32.1679 31.3878 31.7774 31.7784Z', fill='#1C1B28')

        svg(width='32', height='32', viewbox='0 0 32 32', fill='none', xmlns='http://www.w3.org/2000/svg')
          circle(cx='16', cy='16', r='15', fill='#F1F2F4', stroke='#F1F2F4', stroke-width='2')
          path(d='M10.8152 21.1855C10.5548 20.9251 10.5548 20.503 10.8152 20.2426L20.2432 10.8146C20.5036 10.5542 20.9257 10.5542 21.1861 10.8146C21.4464 11.0749 21.4464 11.497 21.1861 11.7574L11.758 21.1855C11.4976 21.4458 11.0755 21.4458 10.8152 21.1855Z', fill='#1C1B28')
          path(d='M21.1843 21.1856C20.9239 21.4459 20.5018 21.4459 20.2415 21.1856L10.8134 11.7575C10.553 11.4971 10.553 11.075 10.8134 10.8147C11.0737 10.5543 11.4959 10.5543 11.7562 10.8147L21.1843 20.2428C21.4446 20.5031 21.4446 20.9252 21.1843 21.1856Z', fill='#1C1B28')


      template
        component-payment-list
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import ComponentPaymentList from './v-component-payment-list.vue';
import Storage from '../development-tools/state.vue';

export default {
  name: 'pop-up',
  props:['paramText'],
  data(){
    return {

    }
  },
  methods:{
    closePopUp(){
      Storage.dispatch('ActionModal',false)
      document.body.classList.remove('body-modal')
    }
  },
  mounted(){

  },
  computed:{
    modal_state(){
      return  Storage.getters.MODAL_STATE
    },
  },
  watch:{
  },
  components:{
    ComponentPaymentList
  }
};
</script>
<style scoped>
</style>
