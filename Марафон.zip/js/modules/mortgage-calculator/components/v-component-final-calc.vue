<template lang="pug">
  .property-calculator__final-calc
    .refinancing-calc__final-item-block
      p.refinancing-calc__final-item-value {{loan_amount}} ₽
      p.property-calculator__final-item-key Сумма кредита
    .refinancing-calc__final-item-block
      .property-calculator__final-item-row(
        v-bind:class="type_payment=='def'?'mortgage-calculator__def-payment':''"
      )
        .credit-calc__final-item-col
          p.refinancing-calc__final-item-value(
            v-if='type_payment=="ann"'
          ) {{annuity_monthly_payment}} ₽
          p.refinancing-calc__final-item-value(
            v-if='type_payment=="def"&&annuity_monthly_payment.length>0'
          ) {{annuity_monthly_payment[0].toLocaleString('ru')}} ... {{annuity_monthly_payment[annuity_monthly_payment.length-1].toLocaleString('ru')}} ₽
          p.property-calculator__final-item-key Ежемесячный платеж
        .credit-calc__final-item-col
          p.refinancing-calc__final-item-value {{share_percent_small_chart}} %
          p.property-calculator__final-item-key Начисленные проценты
    .refinancing-calc__final-item-block
      .property-calculator__final-item-row
        .credit-calc__final-item-col
          p.refinancing-calc__final-item-value {{annuity_debt_plus_interest}} ₽
          p.property-calculator__final-item-key Долг + проценты
        .credit-calc__final-item-col
          p.refinancing-calc__final-item-value {{necessary_income}} ₽
          p.property-calculator__final-item-key Необходимый доход
    button(type="button").property-calculator__final-btn-call-schedule(
      @click="callModal"
    ) График платежей
</template>
<script>
import Vue from 'vue';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-component-final-calc',
  props:[],
  data(){
    return {
      data_type_payment:null
    }
  },
  methods:{
    callModal(){
      Storage.dispatch('ActionModal',true)
      document.body.classList.add('body-modal')


    },

  },
  mounted(){

  },
  computed:{
    annuity_monthly_payment(){
      //по условию, если платёж аннуетный в переменную записыватся данные переменной из state state.annuity_monthly_payment
      //если платёж дифференцированный, то из state.differentiated_monthly_payment
      if (this.type_payment=='ann'){
        return Storage.getters.ANNUITYMONTHLYPAYMENT.toLocaleString('ru')
      }
      else {
        return Storage.getters.DIFFERENTIATEDPAYMENT
      }

    },
    annuity_overpayment(){
      return Storage.getters.ANNUITYOVERPAYMENT.toLocaleString('ru')
    },
    annuity_debt_plus_interest(){
      return Storage.getters.ANNUITYDEBTPLUSINTEREST.toLocaleString('ru')
    },
    necessary_income(){
      return Storage.getters.NECESSARYINCOME.toLocaleString('ru')
    },
    type_payment(){
      return Storage.getters.TYPECREDIT
    },
    loan_amount(){
      return Storage.getters.LOAN_AMOUNT.toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
    },
    share_percent_small_chart(){
      return Storage.getters.SHAREPERCENTSMALLCHART
    },


  },
  watch:{
  },
  created(){
    eventBus.$on('receivePaymentType',(param)=>{
      this.data_type_payment=param
    })
  },

  components:{}
};
</script>
<style scoped>
</style>
