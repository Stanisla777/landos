<template lang="pug">
  .property-calculator__wrapper-detailed-result.black.js-scroll
    template
      final-calc


    //template
    //  payment-list
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import ToolTip from './v-component-tooltip.vue';
import FinalCalc from './v-component-final-calc.vue';
import ChartDebtInterest from './v-component-chart-debt-to-interest.vue';
import PaymentList from './v-component-payment-list.vue';
export default {
  name: 'v-component-final-result',
  data(){
    return {

    }
  },
  methods:{

  },
  mounted(){
  },
  computed:{
  //  Сюда помещаются в том числе GETTTERS
    arr_data_small_debt(){
      return  Storage.getters.ARRDATASMALLDEBT
    }
  },

  watch:{

  },
  components:{
    ToolTip,
    FinalCalc,
    PaymentList,
    ChartDebtInterest
  },
  created(){
  //  Тут помещаюстя Шина событий
  }
};
</script>
<style scoped>
</style>
