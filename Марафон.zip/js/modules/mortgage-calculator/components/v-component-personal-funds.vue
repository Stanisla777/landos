<template lang="pug">
  .property-calculator__row.property-calculator__several-columns_col.margin
    p.property-calculator__row-label Личные средства
    .property-calculator__input-field.mortgage-calculator__personal-funds.js--personal-funds(
      @click="inputFocus"
      ref="realtyInput"
    )
      input.property-calculator__value(inputmode="numeric" placeholder="Введите сумму")(
        v-model="dataField"
        type="text"
        @keydown="inputField"
        @keyup="keyUp"
        @change="inputValue"
        @paste="inputPast"

      )
      .range-input__slider(ref="mortgagePrice")
    .property-calculator__wr-range
      p.property-calculator__range {{stgMin}}
      p.property-calculator__range {{String(stgMax).slice(0,2)}} млн

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import numberFormatting from '../custom-scripts/number-formatting.js'
import onlyNumbers from '../custom-scripts/only-numbers.js'
import IMask from 'imask';
import Storage from '../development-tools/state.vue';
import noUiSlider from 'nouislider';
export default {
  name: 'v-component-personal-funds',
  props:[],
  data(){
    return {
      currency:false,
      personalFunds:0,

      realtySlider: '', // Слайдер "Стоимость недвижимости"
      dataField: 0, // Стоимость недвижимости
      dataFieldForCalculation: 0,
      subsidies: 0,
      stepApartment: 1, // Шаг для range инпутов
      stgMin: 0, // Минимальное значение поля стоимости
      stgMax: 56000000, // Максимальное значение поля стоимости
      input_salary:false,
      start:0
    }
  },
  methods:{
    initRealtySlider() {
      this.realtySlider = noUiSlider.create(this.$refs.mortgagePrice, {
        start: [this.start],
        connect: 'lower',
        step: this.stepApartment,
        initial: this.stgMin,
        range: {
          min: this.stgMin,
          max: this.stgMax
        },
      });
      this.realtySlider.on('update', (val,handle) => {
        this.dataField = parseInt(val[handle]).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        this.dataFieldForCalculation = parseInt(val[handle]).toFixed(0)
      });

      this.realtySlider.on('end', (val,handle) => {

      });

    },
    inputField(event){
      const element = event.currentTarget
      let value = element.value

      value = parseInt(value.replace(/\s/g, ''));
      if ( event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 ||
        // Разрешаем: Ctrl+A
        (event.keyCode == 65 && event.ctrlKey === true) ||
        // Разрешаем: home, end, влево, вправо
        (event.keyCode >= 35 && event.keyCode <= 39)) {

        // Ничего не делаем
        return;
      } else {
        // Запрещаем все, кроме цифр на основной клавиатуре, а так же Num-клавиатуре
        if ((event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105 )) {
          event.preventDefault();
        }
      }

      if(event.keyCode == 13){
        const parent = element.closest('.js--number-cost')
        let value = parent.querySelector('input').value
        value = parseInt(value.replace(/\s/g, ''));
        this.realtySlider.set(value);
      }
      if(value>this.stgMax){
        event.preventDefault();
      }
    },



    keyUp(e){
      const element = e.currentTarget

      if(element.value!==''&&(parseInt(element.value.replace(/\s/g, ''))>=this.stgMin)&&parseInt(element.value.replace(/\s/g, ''))<=this.stgMax){
        this.realtySlider.set(parseInt(element.value.replace(/\s/g, '')));
      }

      else if(parseInt(element.value.replace(/\s/g, ''))>this.stgMax)  {
        this.realtySlider.set(this.stgMax);
      }


      let val = parseInt(element.value.replace(/\s/g, ''))

      if(val>=this.limitpersonalfunds){
        e.preventDefault()
        this.realtySlider.set(this.limitpersonalfunds);
      }
    },
    inputPast(el){
      const element = el.currentTarget;
      let element_val = (el.clipboardData || window.clipboardData).getData('text');
      if ( element_val.search(/[^0-9]/g) != -1 ) {
        el.preventDefault();
      }
    },
    inputValue(el){
      const element = el.currentTarget;
      let value = element.value
      value = parseInt(value.replace(/\s/g, ''));

      if(value<this.stgMin)  {
        this.dataFieldForCalculation = this.stgMin
        this.realtySlider.set(this.stgMin);
      }
    },

    inputFocus(el){
      const element = el.currentTarget
      element.querySelector('input').focus()
    },
    calculationPageLoad(param){
      Storage.dispatch('ActionPersonalFunds',parseInt(this.dataFieldForCalculation))
    },
  },
  mounted(){
    this.initRealtySlider()

  },
  computed:{
    limitpersonalfunds(){
      return Storage.getters.LIMITPERSONALFUNDS
    },
    personalfunds(){
      return  Storage.getters.PERSONALFUNDSHOW
    },
    checkbox_status(){
      return Storage.getters.CHECKBOXSTATUS
    },
    initial_fee(){
      return Storage.getters.INITIALFEE
    }

  },
  watch:{
    checkbox_status(){
      if(this.checkbox_status===true){
        this.realtySlider.set(this.initial_fee);
      }
    },
    limitpersonalfunds(){
      if(this.limitpersonalfunds!==0){
        this.realtySlider.updateOptions({
          range: {
            min: this.stgMin,
            max: this.limitpersonalfunds
          }
        });
      }
      else if(this.limitpersonalfunds===0){
        this.$refs.realtyInput.classList.add('unactive')
      }
      if(this.limitmaterialcapital!==0&&this.$refs.realtyInput.classList.contains('unactive')){
        this.$refs.realtyInput.classList.remove('unactive')
      }

    },
    dataField(){
      this.calculationPageLoad()
    }
  },
  created(){
    eventBus.$on('eventcheckboxChanged',(el)=>{

      if(el[1]==false){
        this.currency=false
      }
    })
  },
  components:{}
};
</script>
<style scoped>
</style>
