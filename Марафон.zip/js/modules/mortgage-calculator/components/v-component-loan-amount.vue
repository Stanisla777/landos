<template lang="pug">
  .calculator_s__loan-amount.mortgage-calculator__loan-amount
    p.calculator_s__loan-amount-title Сумма кредита
    p.calculator_s__loan-amount-total {{loan_amount}} ₽

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import numberFormatting from '../custom-scripts/number-formatting.js'
export default {
  name: 'v-component-loan-amount',
  props:[],
  data(){
    return {
      count:3476000
    }
  },
  methods:{

  },
  mounted(){
    // this.inputCost()
  },
  computed:{
    loan_amount(){
      return Storage.getters.LOAN_AMOUNT.toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
    },
  },
  watch:{

  },
  created(){
    // eventBus.$on('eventcheckboxChanged',(el)=>{
    //
    // })
  },
  components:{}
};
</script>
<style scoped>
</style>
