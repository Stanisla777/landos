<template lang="pug">
  div.calc-tax-deduc-new__block.mobile-padding.grey
    .calc-tax-deduc-new__result-container-title
      h3.calc-tax-deduc-new__block-title.big Данные о погашении
    .calc-tax-deduc-new__result-body
      .calc-tax-deduc-new__result-row.two-column
        template
          component-tooltip(:tooltip="'data-loan-amount'" :infoValue="loanAmount" title-text="Сумма кредита")
        template
          component-tooltip(:tooltip="'data-interest-rate'" :infoValue="parseFloat(annualInterestRate)" title-text="Ставка")

      .calc-tax-deduc-new__result-row.two-column
        template
          component-tooltip(:tooltip="'data-monthly-payment'" :infoValue="firstPayment" title-text="Ежемесячный платеж")
        template
          component-tooltip(:tooltip="'data-debt-interest'" :infoValue="debt_interest" title-text="Долг и проценты")


      .calc-tax-deduc-new__result-row.two-column
        template
          component-tooltip(:tooltip="'data-tax-deduction'" :infoValue="total_tax_deduction" title-text="Налоговый вычет")
        template
          component-tooltip(:tooltip="'data-required-income'" :infoValue="required_income" title-text="Необходимый доход")





</template>
<script>
import Vue from 'vue';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import numberFormatting from '../mixin/numberFormatting.js';
import ComponentTooltip from '../components/v-component-tooltip.vue';

export default {
  name: 'v-component-final-calc',
  mixins: [numberFormatting],
  props:[],
  data(){
    return {
      //временные данные
    }
  },
  filters: {
  },

  methods:{


  },
  mounted(){


  },
  computed:{
    transfer_tooltip(){
      return Storage.getters.TRANSFERTOOLTIP
    },
    loanAmount(){
      return Storage.getters.LOANAMOUNT
    },
    annualInterestRate(){
      return Storage.getters.ANNUALINTERESTRATE
    },
    // shedule(){
    //   return Storage.getters.SHEDULE
    // },
    debt_interest(){
      return Storage.getters.DEBTINTEREST
    },
    total_tax_deduction(){
      return Storage.getters.TOTALTAXDEDUCTION
    },
    required_income(){
      return Storage.getters.REQUIREDINCOME
    },


    shedule() {
      return Storage.getters.SHEDULE
    },
    firstPayment() {
      return this.shedule.length > 0 ? this.shedule[0].payment : 0;
    }
  },
  watch:{

  },
  created(){

  },

  components:{
    ComponentTooltip
  }
};
</script>
<style scoped>
</style>
