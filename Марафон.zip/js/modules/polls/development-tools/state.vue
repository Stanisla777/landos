<script>
import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios';

Vue.use(Vuex);

export default new Vuex.Store({
  state:{
    thanks_window:false,
    main_window:true
  },
  getters:{
    THANKSWINDOW(state){
      return state.thanks_window
    },
    MAINWINDOW(state){
      return state.main_window
    },
  },
  mutations:{
    mutationThanksWindow(state) {
      state.thanks_window = true
      state.main_window=false
    },
    mutationCloseThanksWindow(state) {
      state.thanks_window = false
      state.main_window=true
    },

  },
  actions:{
//вызывается, когда вбивается срок кредита
    ActionThanksWindow({commit,state}){
      commit('mutationThanksWindow')
    },
    ActionCloseThanksWindow({commit,state}){
      commit('mutationCloseThanksWindow')
    },


  },
})
</script>
