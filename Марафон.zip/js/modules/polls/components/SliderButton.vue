<template lang="pug">
  .test-window__slider-btn
    div.btn.btn_gray-bor-black.test-button-prev(@click="pass_clickBtnPrev($event)") Назад
    div.btn.test-button-next(
      v-show="!btn_result"
      @click="pass_clickBtnNext"
      ) Дальше
    div.button.btn.btn_green-n-white.test-button-resultt(
      v-show="btn_result"
      @click="pass_clickResulted"
    ) Результаты
</template>

<script>
export default {
  name: 'SliderButton',
  data(){
    return {
      buton_result:this.btn_result
    }
  },
  props:['btn_result'],
  methods:{
    pass_clickBtnPrev(el){
      const element = el.currentTarget
      this.$emit('event_clickBtnPrev',element)
    },
    pass_clickBtnNext(){
      this.$emit('event_clickBtnNext')
    },
    pass_clickResulted(el){
      const element = el.currentTarget
      this.$emit('event_clickResulted',element)
    }

  }
};
</script>

<style scoped>

</style>
