<template lang="pug">
  .polls__window.js--window
    template
      window-stub
    //p.polls__call-action {{title_text}}
    .polls__wrapper-question.js--wrapper-question(
      v-for="(slide,key,ind) in QUESTIONS"
      :class="[key===0?'polls__wrapper-question-first':'']"
      )
      template(
        v-if="slide.FIELD_TYPE==='0'"
      )
        radio-btn(
          :question="slide.QUESTION"
          :variants="slide.ANSWERS"
          :item_key="parseInt(key)+1"
          :required="slide.REQUIRED"
          :id_question="slide.ID"
          v-on:event_clickVariant ="clickVariantRadio($event)"
          v-on:event_SelectRadioForButton ="mutationSelectRadioForButton($event)"
          v-on:event_actionSelectRadioForSend ="mutationSelectRadioForSend($event)"
        )
      template(
        v-if="slide.FIELD_TYPE==='1'"
      )
        check-box(
          :question="slide.QUESTION"
          :variants="slide.ANSWERS"
          :item_key="parseInt(key)+1"
          :required="slide.REQUIRED"
          :id_question="slide.ID"
          :views_test="views_test"
          v-on:event_clickVariant ="clickVariantCheckBox($event)"
          v-on:event_SelectCheckboxAdd ="mutationCheckboxAdd($event)"
          v-on:event_SelectCheckboxDelete ="mutationCheckboxDelete($event)"
          v-on:event_SelectCheckForButton ="mutationSelectCheckForButton($event)"
        )
      template(
        v-if="slide.FIELD_TYPE==='99999'"
      )
        text-field(
          :question="slide.QUESTION"
          :variants="slide.ANSWERS"
          :item_key="parseInt(key)+1"
          :required="slide.REQUIRED"
          v-on:event_SelectTextFieldForButton ="mutationSelectTextFieldForButton($event)"
          v-on:event_inputAnswer ="inputAnswer($event)"
        )
    template
      button-check(
        v-on:event_verificationAnswers ="verificationAnswers($event)"
        v-on:event_repeatPolls ="repeatPolls($event)"
        :button_text="button_text"
        :massive_required="massive_required"
      )
</template>
<script>
import Vue from 'vue';
import Storage from '../development-tools/state.vue';
import eventBus from '../development-tools/eventBus.vue';
import RadioBtn from './v-component-radio-btn.vue';
import CheckBox from './v-component-checkbox.vue';
import TextField from './v-component-text-field.vue';
import ButtonCheck from './v-component-button.vue';
import WindowStub from './v-component-window-stub.vue';
import axios from 'axios';
export default {
  name: 'v-component-step-polls',
  props:['idTest','QUESTIONS','id_correct_answers','massive_required','sessid','idTest','VOTE_ID','button_text','title_text','views_test'],
  data(){
    return {
      selected_answers:[],
      massive_selected_required_radio:[],
      massive_selected_required_checkbox:[],
      massive_selected_required_checkbox_2:[],
      massive_total_selected_required:[],
      massive_select_correct_answer:[],
      button_status:false,
      checBox_temporary:[],
      sending_data_server:{},
      stats: {
        vote: "Y",
        PUBLIC_VOTE_ID:null,
        VOTE_ID:null,
        sessid:null,
        sum_vote:null
      },
      checBox:[]
    }
  },
  methods:{
    verificationAnswers(el){
      const promice = new Promise((resolve)=> {
        const array_block_answers = el.closest('.js--window').querySelectorAll('.js--list-variant')
        for (let item of array_block_answers){
          let data_id = item.getAttribute('data-sort')
          data_id = parseInt(data_id)
          if(item.classList.contains('status-true')){
            if(this.id_correct_answers.indexOf(data_id) > -1) {
              item.classList.add('true')
              this.mutationCorrectAnswer()
            } else {
              item.classList.add('false')
            }
          }
          else {
            if(this.id_correct_answers.indexOf(data_id) > -1) {
              item.classList.add('true')
            }
          }
        }
        resolve()
      }).then(()=>{
        return new Promise((resolve)=> {
          this.mutationSendingResultsServer(el)
          resolve()
        })
      }).then(()=>{
        return new Promise((resolve)=> {
          this.postParametrApi()
          resolve()
        })
      })

    },
    repeatPolls(el) {
      this.selected_answers = []
      this.massive_selected_required_radio = []
      this.massive_selected_required_checkbox = []
      this.massive_total_selected_required = []
      this.massive_select_correct_answer = []
      this.checBox_temporary = []
      this.sending_data_server = {}
      this.checBox=[]
      this.stats.sum_vote=null
      const array_key = Object.keys(this.stats)
      for (let item of array_key){
        if(item!='sum_vote'&&item!='sessid'&&item!='VOTE_ID'&&item!='PUBLIC_VOTE_ID'&&item!='vote'){
          delete this.stats[item]
        }
      }
      el.classList.remove('active')
      el.closest('.js--window').querySelector('.js--window-stub').classList.remove('active')
      const array_block_variant = el.closest('.js--window').querySelectorAll('.js--polls-component-radio')
      for(let item of array_block_variant){
        item.classList.remove('mandatory-selected')
      }
      const array_variant = el.closest('.js--window').querySelectorAll('.js--list-variant')
      for(let item of array_variant){
        item.classList.remove('status-true')
        item.classList.remove('true')
        item.classList.remove('false')
        item.querySelector('input').checked = false
      }
      const array_textarea = el.closest('.js--window').querySelectorAll('.polls__textarea')
      for(let item of array_textarea){
        item.querySelector('textarea').value=''
      }
      const yOffset = -40;
      const element = el.closest('#v-polls')
      if(element) {
        // const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
        const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
        window.scrollTo({ top: y, behavior: 'smooth' });
      }
      // const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      // window.scrollTo({ top: y, behavior: 'smooth' });
    },
    mutationSendingResultsServer(el){
      this.stats.sessid=this.sessid
      this.stats.VOTE_ID=this.idTest
      this.stats.PUBLIC_VOTE_ID=this.idTest
      for(let item of this.checBox_temporary){
        this.checBox.push(item)
      }
      for(let elem of this.checBox){
        delete elem.id_question
      }
      Vue.set(this.sending_data_server,'stats',this.stats)
      Vue.set(this.sending_data_server,'checBox',this.checBox)
      el.classList.remove('active')
      el.classList.add('unactive')
      el.closest('.js--window').querySelector('.js--window-stub').classList.add('active')
      el.closest('.js--window').querySelector('.polls__btn-repeat').classList.add('active')
    },

    thanksWindow(){
      const modal_for_polls = document.querySelector('#modal-for-polls')
      if(modal_for_polls){
        const poll_window = document.querySelector('.js--modal-for-polls-main-container')
        if (poll_window){
          poll_window.classList.add('unactive')
          document.querySelector('.js--modal-closer').classList.add('unactive')
        }
        Storage.dispatch('ActionThanksWindow')
      }

    },
    postParametrApi(){
      // this.thanksWindow() //перенести в нужное место
      axios({
        method:'post',
        url:'/local/api/tests/',
        headers: {
          "Content-type": "text/html; charset=UTF-8"
        },
        data:this.sending_data_server,//превращаем собранные данные в json

      })
        // Если запрос успешен
        .then((res)=> {
          this.thanksWindow() //перенести в нужное место
        })
        // Если запрос с ошибкой
        .catch((error)=> {
          console.log(error);
        });
    },
    mutationCorrectAnswer() {
      this.massive_select_correct_answer.push('correct');
      this.stats.sum_vote = this.massive_select_correct_answer.length;
    },
    clickVariantCheckBox(param){
      if(param[1]===true){
        param[0].classList.add('status-true')
      } else {
        param[0].classList.remove('status-true')
        param[0].classList.remove('true')
        param[0].classList.remove('false')
      }
    },
    clickVariantRadio(param){
      const massive_selected = []
      if(param[1]===true){
        const array_radio_btn = param[0].closest('.js--list-answers').querySelectorAll('.js--list-radio')
        for (let item of array_radio_btn){
          item.classList.remove('status-true')
          item.classList.remove('true')
          item.classList.remove('false')
        }
        param[0].classList.add('status-true')
        if(param[0].closest('.js--polls-component-radio').classList.contains('required')){
          param[0].closest('.js--polls-component-radio').classList.add('mandatory-selected')
        }
      }
      const massive_selected_radio=[]
      const parent = param[0].closest('.polls__component-question')
      const array_checked = param[0].closest('.polls__component-question').querySelectorAll('.js--list-variant')
    },
    //Из state
    mutationSelectRadioForSend(perem){
      Vue.set(this.stats,perem[0],perem[1])
    },
    mutationCheckboxAdd(perem){
      const array_answer = {}
      Vue.set(array_answer,perem[0],perem[1])
      Vue.set(array_answer,'id_question',perem[2])
      this.checBox_temporary.push(array_answer)
      // console.log(state);
    },
    mutationCheckboxDelete(perem){
      this.checBox_temporary = this.checBox_temporary.filter(function( obj ) {
        return obj.id_question !== perem[2];
      });
    },
    mutationSelectRadioForButton(perem){
      const array_check = perem[3].closest('.js--polls-component-radio').querySelectorAll('.js--list-variant.status-true')
      const promise = new Promise((resolve)=> {
        if(array_check.length>0){
          perem[3].closest('.js--polls-component-radio').classList.add('mandatory-selected')
        }
        else {
          perem[3].closest('.js--polls-component-radio').classList.remove('mandatory-selected')
        }
        resolve()
      }).then(()=>{
        return new Promise((resolve)=> {
          const array_all_inp = perem[3].closest('.js--window').querySelectorAll('.js--polls-component-radio.mandatory-selected')
          if(array_all_inp.length==this.massive_required.length){
            perem[3].closest('.js--window').querySelector('.polls__btn-chek').classList.remove('unactive')
            perem[3].closest('.js--window').querySelector('.polls__btn-chek').classList.add('active')
          }else {
            perem[3].closest('.js--window').querySelector('.polls__btn-chek').classList.remove('active')
            perem[3].closest('.js--window').querySelector('.polls__btn-chek').classList.add('unactive')
          }
          resolve()
        })
      })

    },
    mutationSelectCheckForButton(perem){
      const array_check = perem[4].closest('.js--polls-component-radio').querySelectorAll('.js--list-variant.status-true')
      // console.log(array_check.length);
      const promise = new Promise((resolve)=> {
        if(array_check.length>0){
          perem[4].closest('.js--polls-component-radio').classList.add('mandatory-selected')
        }
        else {
          perem[4].closest('.js--polls-component-radio').classList.remove('mandatory-selected')
        }
        resolve()
      }).then(()=>{
          return new Promise((resolve)=> {
            const array_all_inp = perem[4].closest('.js--window').querySelectorAll('.js--polls-component-radio.mandatory-selected')
            // console.log(array_all_inp.length);
            if(array_all_inp.length==this.massive_required.length){
              perem[4].closest('.js--window').querySelector('.polls__btn-chek').classList.remove('unactive')
              perem[4].closest('.js--window').querySelector('.polls__btn-chek').classList.add('active')
            }else {
              perem[4].closest('.js--window').querySelector('.polls__btn-chek').classList.remove('active')
              perem[4].closest('.js--window').querySelector('.polls__btn-chek').classList.add('unactive')
            }
            resolve()
          })
        })
    },
    mutationSelectTextFieldForButton(perem){
      if(perem.closest('.js--polls-component-radio').classList.contains('required')&&perem.value.length>0){
        perem.closest('.js--polls-component-radio').classList.add('mandatory-selected')
      }
      else if(perem.closest('.js--polls-component-radio').classList.contains('required')&&perem.value.length==0){
        perem.closest('.js--polls-component-radio').classList.remove('mandatory-selected')
      }
      const array_check = perem.closest('.js--polls-component-radio').querySelectorAll('.js--list-variant.status-true')
      const promise = new Promise((resolve)=> {
        // if(array_check.length>0){
        //   perem[3].closest('.js--polls-component-radio').classList.add('mandatory-selected')
        // }
        // else {
        //   perem[3].closest('.js--polls-component-radio').classList.remove('mandatory-selected')
        // }
        resolve()
      }).then(()=>{
        return new Promise((resolve)=> {
          const array_all_inp = perem.closest('.js--window').querySelectorAll('.js--polls-component-radio.mandatory-selected')
          if(array_all_inp.length==this.massive_required.length){
            perem.closest('.js--window').querySelector('.polls__btn-chek').classList.remove('unactive')
            perem.closest('.js--window').querySelector('.polls__btn-chek').classList.add('active')
          }else {
            perem.closest('.js--window').querySelector('.polls__btn-chek').classList.remove('active')
            perem.closest('.js--window').querySelector('.polls__btn-chek').classList.add('unactive')
          }
          resolve()
        })
      })

    },
    inputAnswer(perem){
      Vue.set(this.stats,perem[1],perem[2])
      // console.log(this.stats);
    }
  },
  mounted(){

  },
  computed:{

  },
  created() {
    eventBus.$on('event_closeThanksWindow',(el)=>{
      this.selected_answers = []
      this.massive_selected_required_radio = []
      this.massive_selected_required_checkbox = []
      this.massive_total_selected_required = []
      this.massive_select_correct_answer = []
      this.checBox_temporary = []
      this.sending_data_server = {}
      this.checBox=[]
      this.stats.sum_vote=null
      const array_key = Object.keys(this.stats)
      for (let item of array_key){
        if(item!='sum_vote'&&item!='sessid'&&item!='VOTE_ID'&&item!='PUBLIC_VOTE_ID'&&item!='vote'){
          delete this.stats[item]
        }
      }

      el.closest('.js--polls').querySelector('.js--window-stub').classList.remove('active')
      const array_block_variant = el.closest('.js--polls').querySelectorAll('.js--polls-component-radio')
      for(let item of array_block_variant){
        item.classList.remove('mandatory-selected')
      }
      const array_variant = el.closest('.js--polls').querySelectorAll('.js--list-variant')
      for(let item of array_variant){
        item.classList.remove('status-true')
        item.classList.remove('true')
        item.classList.remove('false')
        item.querySelector('input').checked = false
      }
      const array_text_field = el.closest('.js--polls').querySelectorAll('.js--polls-component-text-field')
      for(let item of array_text_field){
        item.querySelector('textarea').value=''
      }
      const modal = el.closest('.modal')
      if(modal){
        modal.querySelector('.js--modal-for-polls-main-container').classList.remove('unactive')
        modal.querySelector('.js--modal-closer').classList.remove('unactive')
        modal.classList.remove('open')
        document.body.classList.remove('body-modal')
      }
      Storage.dispatch('ActionCloseThanksWindow')
    })

  },
  watch:{
  },
  components:{
    RadioBtn,
    CheckBox,
    ButtonCheck,
    WindowStub,
    TextField
  }
};
</script>
<style scoped>
</style>
