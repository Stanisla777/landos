<template lang="pug">
  .modal-for-polls__thanks-window.js--thanks-window
    .modal__thanks-window-icon
      svg(width='35', height='36', viewbox='0 0 35 36', fill='none', xmlns='http://www.w3.org/2000/svg')
        path(d='M2.58208 20.9612C2.00837 20.3636 1.05882 20.3442 0.461202 20.9179C-0.136415 21.4916 -0.155793 22.4412 0.417919 23.0388L2.58208 20.9612ZM13.02 34L11.9379 35.0388C12.2563 35.3704 12.7091 35.5377 13.1665 35.4928C13.624 35.4479 14.0356 35.1957 14.2834 34.8086L13.02 34ZM34.7634 2.80858C35.21 2.11082 35.0063 1.18316 34.3086 0.736593C33.6108 0.290026 32.6832 0.493659 32.2366 1.19142L34.7634 2.80858ZM0.417919 23.0388L11.9379 35.0388L14.1021 32.9612L2.58208 20.9612L0.417919 23.0388ZM14.2834 34.8086L34.7634 2.80858L32.2366 1.19142L11.7566 33.1914L14.2834 34.8086Z', fill='white')
    p.modal-for-polls__thanks-window-status Ваши ответы были успешно отправлены
    p.modal-for-polls__thanks-window-thanks Благодарим вас за участие в нашем опросе!
    .polls__btn-chek.polls__btn.active
      button(type='button')(
        @click="closeThanksWindow"
      ) Закрыть окно
</template>
<script>
import Storage from '../development-tools/state.vue';
import eventBus from '../development-tools/eventBus.vue';

export default {
  name: 'v-conponent-thanks-window',
  props:[],
  data(){
    return {
    }
  },
  methods:{
    closeThanksWindow(el){
      const element = el.currentTarget
      // this.$emit('event_closeThanksWindow',element)
      eventBus.$emit('event_closeThanksWindow',element)
    }

  },
  mounted(){

  },
  computed:{


  },
  created() {
  },
  watch:{
  },
  components:{
  }
};
</script>
<style scoped>
</style>
