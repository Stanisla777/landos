<template lang="pug">
  div
    .test-slide-calculator(v-if="!for_insruction")
      p.test-slide-calculator__item.
        1
      p.test-slide-calculator__item.
        {{count_slide}}

    .test-slide-calculator-insruction.js--calculator-insruction(v-if="for_insruction")
      p Вопрос <span>1</span> из {{count_slide}}

</template>
<script>
export default {
  name: 'SlideCalculator',
  props:['count_slide','current_slide','for_insruction'],
  data(){
    return {

    }
  }
};
</script>
<style scoped>
</style>
