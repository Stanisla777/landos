<template lang="pug">
  .test-cotainer-final-result.final-result
    .final-result__wrap-title
      .final-result__emoticon(v-if="smile_1")
        img(src="/local/templates/main/img/emoji-1.svg",alt="")
      .final-result__emoticon(v-if="smile_2")
        img(src="/local/templates/main/img/emoji-2.svg",alt="")
      .final-result__emoticon(v-if="smile_3")
        img(src="/local/templates/main/img/emoji-3.svg",alt="")
      .final-result__emoticon(v-if="smile_4")
        img(src="/local/templates/main/img/emoji-4.svg",alt="")
      .final-result__emoticon(v-if="smile_5")
        img(src="/local/templates/main/img/emoji-5.svg",alt="")
      .final-result__emoticon(v-if="smile")
        img(src="/local/templates/main/img/emoji-6.svg",alt="")
      .final-result__title {{title}}
      include ../../../../pug/mixins/soc-list
      //+soc-list("final-result__soc-list")
      .soc-list(class != additionalClass).final-result__soc-list
        .soc-list__item(data-val="like")(@click="dispatchSher")
          .soc-list__icon(aria-label="Лайк")
            if isBig
              svg(width='20' height='20' viewBox='0 0 20 20' fill='none' xmlns='http://www.w3.org/2000/svg' aria-hidden="true")
                path(d='M9.25432 5.86631L10 6.70081L10.7457 5.86631C11.2778 5.2708 12.0278 4.52631 12.8368 3.93919C13.6773 3.32926 14.4313 3 15 3C16.2851 3 17.2544 3.51331 17.9196 4.30973C18.5999 5.12439 19 6.28605 19 7.6C19 8.83725 18.3551 10.2679 16.7792 11.9069C15.2874 13.4584 13.0423 15.1095 10.0001 16.8508C6.96037 15.1092 4.71792 13.4424 3.22781 11.861C1.6572 10.1941 1 8.70772 1 7.3871C1 6.07597 1.39793 4.97849 2.06325 4.22332C2.71556 3.48291 3.68549 3 5 3C5.56871 3 6.32271 3.32926 7.16318 3.93919C7.97221 4.52631 8.7222 5.2708 9.25432 5.86631Z' stroke='none' stroke-width='2')
            else
              svg(width='16' height='16' viewBox='0 0 16 16' fill='none' xmlns='http://www.w3.org/2000/svg' aria-hidden="true")
                path(d='M7.6205 4.32554L8 4.76795L8.3795 4.32554C8.70208 3.94949 9.15781 3.478 9.6512 3.10502C10.1616 2.71921 10.6327 2.5 11 2.5C11.793 2.5 12.4013 2.83081 12.8222 3.35571C13.2513 3.89092 13.5 4.64955 13.5 5.5C13.5 6.32593 13.0871 7.25181 12.1326 8.28586C11.2207 9.27376 9.85055 10.3199 8.00005 11.4197C6.15082 10.3198 4.78194 9.26359 3.87081 8.25632C2.91868 7.20373 2.5 6.24325 2.5 5.36694C2.5 4.5177 2.74785 3.79785 3.16951 3.2993C3.58349 2.80984 4.19176 2.5 5 2.5C5.36728 2.5 5.83843 2.71921 6.3488 3.10502C6.84219 3.478 7.29792 3.94949 7.6205 4.32554Z' stroke='none')
          span.soc-list__counter.like-js 20
        .soc-list__item(data-val="share")(@click="dispatchSher")
          .soc-list__icon.soc-list__icon_share.ya-share2(
            aria-label="Поделиться" data-limit="0" data-services="vkontakte,odnoklassniki,telegram,twitter,viber,whatsapp"
            data-direction="vertical" data-popup-position="outer" data-curtain="" data-shape="round"
            )
            if isBig
              svg(width='20' height='20' viewBox='0 0 20 20' fill='none' xmlns='http://www.w3.org/2000/svg' aria-hidden="true")
                path(d='M11.1111 6.50391H12.1111V5.50391V2.25378L18.944 9.44389L12.1111 16.634V13.3851V12.3851H11.1111H9.79108C6.12605 12.3851 2.81279 14.3368 1 17.5061V16.4814C1 10.9684 5.42474 6.50391 10.8334 6.50391H11.1111Z' stroke='none' stroke-width='2')
            else
              svg(width='16' height='16' viewBox='0 0 16 16' fill='none' xmlns='http://www.w3.org/2000/svg' aria-hidden="true")
                path(d='M9.15644 2.501C9.15538 2.5022 9.15472 2.50266 9.15471 2.50266C9.15471 2.50266 9.15553 2.50208 9.15756 2.50131L9.15714 2.50018L9.15644 2.501ZM9.15644 2.501L9.14444 2.46923L8.98 2.0339L9.15644 2.501ZM8.66664 5.00217H9.16664V4.50217V2.5C9.16866 2.5 9.17079 2.5002 9.17297 2.50064C9.17624 2.50129 9.17806 2.50215 9.17875 2.50253L13.4777 6.69105L9.17864 10.8797C9.17796 10.8801 9.17595 10.8811 9.17231 10.8818C9.17023 10.8822 9.16833 10.8824 9.16664 10.8824V8.88061V8.38061H8.66664H7.87465C5.60676 8.38061 3.54726 9.56328 2.51682 11.4937C2.51622 11.4942 2.51534 11.4948 2.51411 11.4955C2.51167 11.497 2.50878 11.4982 2.50581 11.499C2.50351 11.4996 2.50162 11.4999 2.50026 11.5L2.5 11.4999V10.6008C2.5 7.5438 5.16166 5.00217 8.50002 5.00217H8.66664Z' stroke='none')
          span.soc-list__counter.share-js 155
        .soc-list__item(data-val="count-view")
          .soc-list__icon
            if isBig
              svg(width='20' height='20' viewBox='0 0 20 20' fill='none' xmlns='http://www.w3.org/2000/svg')
                path(d='M2.36061 9.76279L2.30258 10.0003L2.36067 10.2378C3.08821 13.2119 6.39849 15.1668 9.9987 15.1668C13.5987 15.1668 16.9099 13.212 17.6368 10.2375L17.6948 10L17.6367 9.76255C16.9092 6.7884 13.5989 4.8335 9.9987 4.8335C6.39871 4.8335 3.08747 6.78828 2.36061 9.76279Z' stroke='none' stroke-width='2')
                circle(cx='10.0013' cy='9.99984' r='2.33333' stroke='#6B7081' stroke-width='2')
            else
              svg(width='16' height='16' viewBox='0 0 16 16' fill='none' xmlns='http://www.w3.org/2000/svg')
                path(d='M2.18128 6.88115L2.15227 6.9999L2.18131 7.11864C2.71904 9.31683 5.20346 10.8332 8.00033 10.8332C10.7971 10.8332 13.2822 9.31689 13.8194 7.11853L13.8484 6.99977L13.8193 6.88103C13.2816 4.68285 10.7972 3.1665 8.00033 3.1665C5.20356 3.1665 2.71848 4.68279 2.18128 6.88115Z' stroke='none')
                circle(cx='7.99967' cy='7.00016' r='2.16667' stroke='none')
          span.soc-list__counter.viewing.js 5

    .final-result__block-result
      p.final-result__result.
        Правильных ответов: <span>{{sum_of_points}}</span>/<span>{{count_answers}}</span>
      //p.final-result__des.fs-1rem(
      //  v-html="final_text"
      //)
      p.final-result__des.fs-1rem.
        При покупке квартиры важно избежать возможных ошибок. Тогда вы сможете сэкономить на этом время и деньги.
        Подробнее изучить тему о покупке квартиры вы можете на портале спроси.дом.рф.
        Остались вопросы? Позвоните по номеру бесплатной горячей линии: 8 (800) 775-11-22.
        Подробнее изучить тему о покупке квартиры вы можете на портале спроси.дом.рф.
        Остались вопросы? Позвоните по номеру бесплатной горячей линии: 8 (800) 775-11-22.
    //.space-between.final-result__btn
    //  //a(href="/tests/").btn.btn_green-n-white(type="button") Другие тесты
    //  button.btn.polls__slider-again(type="button")(@click="pass_repeatTest") Пройти еще раз
    .final-result__empty-block
</template>

<script>

export default {
  name: "FinishWindow",
  data(){
    return {
      status_smile:this.smile,
      like:null,
      sher:null,
      title:"Тест завершен",
    }
  },
  props:["sum_of_points","count_slide","final_text","smile","smile_1","smile_2","smile_3","smile_4","smile_5","count_correct_answers","finalResult","count_answers"],

  methods:{
    pass_repeatTest(){
      this.$emit('event_repeatTest')
    },
    pressButton() {
      const current_el = document.querySelector('.test-cotainer-final-result');
      current_el.setAttribute('style', 'height:600px');
    },
    initializationServiceSher() {
      let url = document.location.href;
      let share = document.querySelector('.final-result__soc-list.ya-share2');
      if (share) {
        for (i = 0; i < share.length; i++) {
          Ya.share2(share[i], {
            content: {
              url: url
            }
          });
        }
      }
    },
    preventDefaultSher() {
      const sher = document.querySelectorAll('.final-result__soc-list');
      for (let i = 0; i < sher.length; i++) {
        // eslint-disable-next-line camelcase
        const soc_list = sher[i].querySelectorAll('.soc-list__item a');
        for (let j = 0; j < soc_list.length; j++) {
          // eslint-disable-next-line func-names
          soc_list[j].onclick = function (e) {
            e.preventDefault();
          };
        }
      }
    }, //чтгобы можно было кликать по сердечку, оно сделано как ссылка
    receiveDataFromTopSher() {
      const parent = document.querySelector('.container-test')
      if(parent){
        const parent_shareUp = parent.querySelector('.space-between .soc-list')
        if (parent_shareUp) {
          const likeUp = parent_shareUp.querySelector('.soc-list__item:first-child');
          if (likeUp) {
            const likeUp_text = likeUp.querySelector('span').textContent;
            const test = parent.querySelectorAll('.test-cotainer-final-result .final-result__soc-list .soc-list__item')
            test[test.length - 3].querySelector('span').textContent = likeUp_text;
              if (likeUp.querySelector('.soc-list__icon').classList.contains('active')) {
                test[test.length - 3].querySelector('.soc-list__icon').classList.add('active')
                test[test.length - 3].setAttribute('style','pointer-events: none')
              }
          }
          const shareUp = parent_shareUp.querySelector('.soc-list__item:nth-child(2)');
          if (shareUp) {
            const shareUp_text = shareUp.textContent;
            const test = parent.querySelectorAll('.test-cotainer-final-result .final-result__soc-list .soc-list__item');
            test[test.length - 2].querySelector('span.share-js').textContent = shareUp_text;
          }
          const viewingUp = parent_shareUp.querySelector('.soc-list__item:nth-child(3)');
          if (viewingUp) {
            const viewingUp_text = viewingUp.textContent;
            const test = parent.querySelectorAll('.test-cotainer-final-result .final-result__soc-list .soc-list__item');
            for (let j = 0; j < test.length; j++) {
              test[test.length - 1].querySelector('span').textContent = viewingUp_text;
            }
          }
          const likes = parent_shareUp.querySelectorAll('.soc-list__item')
        }
      }

    },
    changeTopLikes(){

    },
    dispatchSher(el) {
      const element = el.currentTarget;
      const parent = element.closest('.container-test')
      const up_soc_list = parent.querySelectorAll('.space-between .soc-list .soc-list__item')
      const data = element.getAttribute('data-val')
      if(data=='like'){
        up_soc_list[0].querySelector('.soc-list__icon').click()
      }
      if(data=='share'){
        up_soc_list[1].querySelector('.ya-share2__link').click()
      }
      const parent_shareUp = document.querySelector('.container-test .block-middle .space-between .soc-list')

    },
    serviceConnectionSher() {
      let recaptchaScript = document.createElement('script');
      recaptchaScript.setAttribute('src', 'https://yastatic.net/share2/share.js');
      document.head.appendChild(recaptchaScript);
    },
    finalText(){
      const popup = document.querySelector('.common-test-pop-up')
      if(popup){
        this.title= "Спасибо, что помогаете нам стать лучше!"
      }
    }
  },
  mounted(){
    this.serviceConnectionSher()
    this.preventDefaultSher()
    this.initializationServiceSher()
    this.finalText()
    this.changeTopLikes()
  },
  watch:{
    finalResult(){
      this.receiveDataFromTopSher()
    }
  },
}
</script>
<style scoped>

</style>
