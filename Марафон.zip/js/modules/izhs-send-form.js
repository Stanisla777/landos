/* eslint-disable */
import Vue from 'vue';
// import universalForm from './universal-form/universal-form';
// import { catalogModal, modals } from './modals';
import mixinLiveSearch from './mixinForVueComponent/mixinLiveSearch';
import mixinOpenListAndSelectItem from './mixinForVueComponent/mixinOpenListAndSelectItem';
import mixinformComponent from './mixinForVueComponent/vue-mixin-form/formComponent';

export default function izhsSendForm() {
  const app = new Vue({
    el: '#modal-housing-cooperative-request',
    data: {
      show_warn:true,//
      fullness_radio:0,//
      fullness_select:0,//
      fullness_input_radio:0,//
      all_checked:true,//

    },
    mixins: [mixinLiveSearch,mixinOpenListAndSelectItem,mixinformComponent],
    methods: {
      liveSearch(el) {
        const input_search = el.currentTarget;
        this.sampleliveSearch(input_search)
      },
      changeRightParticipate(el) {
        const element = el.currentTarget
        const val_attr = element.getAttribute('value')
        if(val_attr==='yes'){
          this.show_warn=false
          element.closest('.js--izhs-radio-group').classList.add('js--selected')
          this.fullness_input_radio=1
        }
        else {
          this.show_warn=true
          element.closest('.js--izhs-radio-group').classList.remove('js--selected')
          this.fullness_input_radio=0
        }
        this.fullness_input = this.fullness_input_name+this.fullness_input_tel+this.fullness_input_mail+
          this.fullness_input_radio+this.fullness_select

      },
      changeRightParticipateNo(el){
        const element = el.currentTarget
        this.show_warn=true
        element.closest('.js--izhs-radio-group').classList.remove('js--selected')
        if(this.fullness_input!==0){
          this.fullness_input-=1
        }
      },
      raidoId(){
        const array_radio = document.querySelectorAll('.js--universal-form input[type="radio"]')
        for(let i=0;i<array_radio.length;i++){
          const name = array_radio[i].getAttribute('name')
          array_radio[i].setAttribute('id',`${name}_${i}`)
          array_radio[i].nextSibling.setAttribute('for',`${name}_${i}`)
        }
      },
      // nextSlide(){
      //   this.step_1=false
      // },
      // prevSlaide(){
      //   this.step_1=true
      // },
      changePolls(el){
        const element = el.currentTarget
        const parent = element.closest('.js--step-2')
        const array = parent.querySelectorAll('.js--izhs-radio-required')
        const array_selected = parent.querySelectorAll('.js--izhs-radio-required.js--selected')
        if(element.checked){
          element.closest('.js--izhs-radio-group-step-2').classList.add('js--selected')
          element.closest('.js--izhs-radio-group-step-2').classList.remove('input_error')
          if (element.classList.contains('js--input_personal') && element.closest('.checkbox-stylized')) {
            element.closest('.checkbox-stylized').classList.remove('input_error')
          }
        }
        else {
          element.closest('.js--izhs-radio-group-step-2').classList.remove('js--selected')
        }
        if(array_selected.length+1===array.length){
          this.all_checked=true
        }
        this.buttoActivationLastStep()
      },

      buttoActivationLastStep(){
        const array = document.querySelectorAll('.js--izhs-radio-group-step-2')
        const array_length = array.length
        this.fullness_radio=0
        for(let item of array){
          if(item.classList.contains('js--selected')){
            this.fullness_radio+=1
          }
        }
        if(array_length===this.fullness_radio){
          this.error_step_2 = false
        }
        else {
          this.error_step_2 = true
        }
      },

      // buttonActivationName(element){
      //   if (element.value.length > 0&&this.fullness_input_name!==1) {
      //     this.fullness_input_name = 1;
      //   }
      //   if (element.value.length < 1) {
      //     this.fullness_input_name = 0;
      //   }
      //   this.fullness_input = this.fullness_input_name+this.fullness_input_tel+this.fullness_input_mail+
      //     this.fullness_input_radio+this.fullness_select
      // },
      // buttonActivationEmail(element){
      //   if(element.value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)&&element.value.length>0){
      //     if(this.fullness_input_mail!==1) {
      //       this.fullness_input_mail=1
      //     }
      //   }
      //   if (!element.value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)) {
      //     this.fullness_input_mail=0
      //   }
      //   if (element.value.length<1) {
      //     this.fullness_input_mail=0
      //   }
      //   this.fullness_input = this.fullness_input_name+this.fullness_input_tel+this.fullness_input_mail+
      //     this.fullness_input_radio+this.fullness_select
      // },
      // buttonActivationTel(element){
      //   if(element.value.length>=16&&this.fullness_input_tel!==1){
      //     this.fullness_input_tel=1
      //   }
      //   if (element.value.length < 16) {
      //     this.fullness_input_tel=0
      //   }
      //   this.fullness_input = this.fullness_input_name+this.fullness_input_tel+this.fullness_input_mail+
      //     this.fullness_input_radio+this.fullness_select
      // },
      // buttonActivation(element){
      //   const parent = element.closest('.js--housing-cooperative-request')
      //   if(parent){
      //     const array = parent.querySelectorAll('.js--validate-mask')
      //     const array_length = array.length
      //     for (let item of array){
      //       const inp_val = element.value.length
      //       if(item.classList.contains('js--validate-mask-name')&&item.value.length>0){
      //       }
      //       if(item.classList.contains('js--validate-mask-email')&&item.value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)&&item.value.length>0){
      //       }
      //       if(item.classList.contains('js--validate-mask-tel')&&item.value.length>=16){
      //       }
      //     }
      //   }
      // },

      sendingRequestSecondStep(el){
        const element = el.currentTarget
        const array = element.closest('.js--step-2').querySelectorAll('.js--izhs-radio-group-step-2')
        const array_selected_required = element.closest('.js--step-2').querySelectorAll('.js--izhs-radio-group-step-2.js--izhs-radio-required')
        const array_selected = element.closest('.js--step-2').querySelectorAll('.js--izhs-radio-group-step-2.js--selected')
        for (let item of array) {
          if(!item.classList.contains('js--selected')){
            item.classList.add('input_error')
            if (item.querySelector('.checkbox-stylized') && item.querySelector('.checkbox-stylized').classList.contains('required')) {
              item.querySelector('.checkbox-stylized').classList.add('input_error')
            }
          }
          else {
            item.classList.remove('input_error')
          }
        }
        if(array_selected_required.length!==array_selected.length){
          this.all_checked = false
        }
        else {
          this.all_checked = true
        }
      },

      // sendingRequestFirstStep(el){
      //   const element = el.currentTarget
      //   const parent = element.closest('.js--step-1')
      //   const array_input = parent.querySelectorAll('input[required]')
      //   for(let item of array_input){
      //     if(item.classList.contains('js--validate-mask-select')){
      //       if(item.value===''){
      //         item.closest('.js--izhs-select').classList.add('input_error')
      //       }
      //     }
      //     else if (item.classList.contains('js--validate-mask')) {
      //       if(item.value===''){
      //         item.closest('label').classList.add('input_error')
      //         const array_error = item.closest('label').querySelectorAll('.js--input__error_required')
      //         if(array_error.length===0){
      //           const element_error = document.createElement('p');
      //           element_error.classList.add('input__error','js--input__error_required');
      //           element_error.innerHTML += 'Поле обязательно для заполнения'
      //           item.closest('label').append(element_error);
      //         }
      //       }
      //     }
      //   }
      // },


      // closeItemList(el){
      //   if(el.target.classList.contains('js--select-input')!==true){
      //     const array_search = el.currentTarget.querySelectorAll('.js--container-select.open');
      //     for(let item of array_search){
      //       if (item.querySelector('.js--select-input')
      //         .hasAttribute('data-search') && item.querySelector('.js--select-input')
      //         .getAttribute('data-search').length > 0) {
      //         item.querySelector('.js--select-input').value = item.querySelector('.js--select-input')
      //           .getAttribute('data-search');
      //       }
      //       if ((!item.querySelector('.js--select-input')
      //         .hasAttribute('data-search') || item.querySelector('.js--select-input')
      //         .getAttribute('data-search').length === 0)) {
      //         item.querySelector('.js--select-input').value = '';
      //       }
      //       item.classList.remove('open')
      //     }
      //   }
      // },
      callback(){
        const beesenderchat = document.querySelector('#modal-housing-cooperative-request');
        if (beesenderchat.hasAttribute('data-formsubmit')
          && beesenderchat.getAttribute('data-formsubmit') === 'success'
          && !beesenderchat.classList.contains('open')) {
          setTimeout(()=>{
            if (beesenderchat.querySelector('#right_1')) {
              beesenderchat.querySelector('#right_1').checked = true;
            }
            this.show_warn = true;
            this.step_1=true;
            this.error_step_1=true;
            this.error_step_2=true;
            this.fullness_input=0;
            this.fullness_radio=0;
            this.hiddenInput='';
            this.all_checked=true;
            this.InputSearhPlace='';
            this.fullness_input_name=0,
            this.fullness_input_mail=0,
            this.fullness_input_tel=0,
            this.fullness_select=0,
            this.fullness_input_radio=0,
            beesenderchat.setAttribute('data-formsubmit','')
            const array_select_item = beesenderchat.querySelectorAll('.js--select-item.active-item')
            for(let item of array_select_item){
              item.classList.remove('active-item');
              item.closest('.js--izhs-select').querySelector('input.js--select-input').setAttribute('data-search','');
            }
            const array_select_radio_btn = beesenderchat.querySelectorAll('.js--izhs-radio-group-step-2.js--selected');
            for(let item of array_select_radio_btn){
              item.classList.remove('js--selected')
            }
          },1000)
        }
      },
      successfulSubmission(){
        const beesenderchat = document.querySelector('#modal-housing-cooperative-request');
        const observerOptions = {
          attributes: true,
        };
        const observer = new MutationObserver(this.callback);
        if (beesenderchat) {
          observer.observe(beesenderchat, observerOptions);
        }
      }
    },
    filters: {
    },
    updated() {
    },
    computed: {
    },
    watch: {
      // fullness_input(){
      //   const parent = document.querySelector('.js--housing-cooperative-request');
      //   if(parent){
      //     const array = parent.querySelectorAll('.js--validate-mask')
      //     const array_length = array.length
      //     if(array_length===this.fullness_input){
      //       this.error_step_1 = false
      //     }
      //     else {
      //       this.error_step_1 = true
      //     }
      //   }
      // }
    },
    mounted() {
      // modals();
      // catalogModal();
      // universalForm();
      this.raidoId();
      this.successfulSubmission()
    }
  });
}
