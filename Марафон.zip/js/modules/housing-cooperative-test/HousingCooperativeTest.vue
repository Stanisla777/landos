<template lang="pug">
  .housing-cooperative-test
    .housing-cooperative-test__wrap
      h2.housing-cooperative-test__title.housing-cooperative-test__title_bordered Тест на&nbsp;соответствие критериям ЖСК
      .housing-cooperative-test__row.housing-cooperative-test__row_select
        span.housing-cooperative-test__label.housing-cooperative-test__label_small-mb Относитесь&nbsp;ли вы&nbsp;к&nbsp;одной из&nbsp;следующих категорий граждан?
        .select(:class="{ open: isSelectOpened, select_disabled: isSelectDisabled }")
          .select__background(@click="selectHandler(true)")
          .select__choosen(@click="selectHandler()") {{ selectedValue }}
          .select__list-wrapper
            ul.select__list
              li.select__list-item(
                v-for="( item, idx ) in selectValues"
                :key="item.text"
                @click="selectItemHandler(item, idx)"
              ) {{ item.text }}
      .housing-cooperative-test__row(
        v-for="(question, idx) in currentQuestions"
        :key="question.text"
      )
        span.housing-cooperative-test__label {{ question.text }}
          span.content-note.content-note_test.js--content-note(v-if="question.note") ?
            span.content-note__text
              span.content-note__title {{ question.note.title }}
        .housing-cooperative-test__checkbox-wrap
          label.checkbox-round(
            v-for="( answer, key ) in question.answers"
            :data-name="question.radioName"
            :key="answer"
          )
            input(
              type="radio"
              :name="question.radioName"
              @click.once="checkboxHandler(key, question.radioName)"
            )
            .checkbox-round__field
            span.checkbox-round__text {{ answer }}

      p.housing-cooperative-test__no-success(v-if="isFailing && currentUnsuccessfulTest")
        span.housing-cooperative-test__subtitle {{ currentUnsuccessfulTest.title }}
        span.housing-cooperative-test__desc(v-html="currentUnsuccessfulTest.text")

      .housing-cooperative-test__success(v-if="isSuccess")
        span.housing-cooperative-test__subtitle Поздравляем!
        span.housing-cooperative-test__desc Вы&nbsp;можете создать ЖСК с&nbsp;господдержкой или вступить в&nbsp;существующий
        a.btn(href="/zhsk-support/list/") Перейти к выбору ЖСК
      //- form.housing-cooperative-test__success(v-if="isSuccess" action="")
      //-   span.housing-cooperative-test__title Поздравляем!
      //-   span.housing-cooperative-test__subtitle Вы&nbsp;можете создать ЖСК с&nbsp;господдержкой или
      //-     span.svg-anima(ref="svgUnderline")  вступить
      //-       svg.svg-anima__desktop(stroke-dasharray="350" stroke-dashoffset="350" width='117' height='46' viewBox='0 0 117 46' fill='none' xmlns='http://www.w3.org/2000/svg')
      //-         path(d='M58.3885 11.5029C58.3885 11.5029 94.401 6.29372 113.41 28.6716C130.15 48.3779 -0.610867 51.7183 1.56263 19.856C3.36724 -6.59852 83.9632 -1.0662 107.827 20.2419' stroke='#8BC540' stroke-width='3' stroke-linecap='round' stroke-linejoin='round')
      //-       svg.svg-anima__tablet(stroke-dasharray="300" stroke-dashoffset="300" width='98' height='38' viewBox='0 0 98 38' fill='none' xmlns='http://www.w3.org/2000/svg')
      //-         path(d='M49.9947 9.90047C49.9947 9.90047 80.3725 5.88098 95.3138 24.3377C108.471 40.5911 -1.1522 42.4313 2.05423 16.3522C4.71645 -5.30071 71.9539 -0.217997 91.0059 17.396' stroke='#8BC540' stroke-width='3' stroke-linecap='round' stroke-linejoin='round')
      //-       svg(stroke-dasharray="300" stroke-dashoffset="300" width='98' height='38' viewBox='0 0 98 38' fill='none' xmlns='http://www.w3.org/2000/svg')
      //-         path.svg-anima__mobile(d='M49.9947 9.90047C49.9947 9.90047 80.3725 5.88098 95.3138 24.3377C108.471 40.5911 -1.1522 42.4313 2.05423 16.3522C4.71645 -5.30071 71.9539 -0.217997 91.0059 17.396' stroke='#8BC540' stroke-width='3' stroke-linecap='round' stroke-linejoin='round')
      //-     |  в&nbsp;существующий
      //-   span.housing-cooperative-test__desc Заполните форму и&nbsp;дождитесь ответа от&nbsp;консультационного центра
      //-   label.input.input_dark-placeholder.housing-cooperative-test__form-row(:class="{ input_error: formErrors.name, disabled: isFormSended  }")
      //-       input(
      //-         v-model.trim="form.name"
      //-         type="text"
      //-         name="name"
      //-         placeholder="ФИО"
      //-         @input="isValidationActivated ? isPassedValidation() : null"
      //-       )
      //-       span.input__error Заполните поле
      //-   label.input.input_dark-placeholder.housing-cooperative-test__form-row(:class="{ input_error: formErrors.email.value, disabled: isFormSended  }")
      //-       input(
      //-         v-model="form.email"
      //-         type="email"
      //-         name="email"
      //-         placeholder="E-mail"
      //-         @input="isValidationActivated ? isPassedValidation() : null"
      //-       )
      //-       span.input__error {{ formErrors.email.text  }}
      //-   label.input.input_dark-placeholder.housing-cooperative-test__form-row(:class="{ input_error: formErrors.phone, disabled: isFormSended  }")
      //-       input(
      //-         v-model="form.phone"
      //-         type="tel"
      //-         name="phone"
      //-         placeholder="Номер телефона"
      //-         @input="isValidationActivated ? isPassedValidation() : null"
      //-       )
      //-       span.input__error Введите корректный номер телефона
      //-   label.housing-cooperative-test__form-check
      //-       .checkbox(:class="{ checkbox_error: formErrors.checkbox }")
      //-           input(
      //-             v-model="form.checkbox"
      //-             type="checkbox"
      //-             name="policy"
      //-             @change="isValidationActivated ? isPassedValidation() : null"
      //-           )
      //-           div
      //-       span.housing-cooperative-test__checkbox-text
      //-           | Я даю согласие на обработку
      //-           |
      //-           a(href="/user-agreement/") персональных данных
      //-   button.housing-cooperative-test__btn.btn.btn_dark-gray(:class="{ disabled: isFormSended }" type="submit" @click="sendButtonHandler($event)") Отправить

      //- .modal(:class="{ open: isModalOpened }")
      //-   .modal__wrapper.housing-cooperative-test__modal-wrapper
      //-     button.modal__closer.icon-round.icon-round_white.icon-round_border(@click="modalCloseHandler()")
      //-       svg(width='17' height='18' viewBox='0 0 17 18' fill='none' xmlns='http://www.w3.org/2000/svg')
      //-         path(fill-rule='evenodd' clip-rule='evenodd' d='M0.357542 15.3637C-0.0329827 15.7543 -0.0329827 16.3874 0.357542 16.778C0.748066 17.1685 1.38123 17.1685 1.77176 16.778L8.13551 10.4142L14.4995 16.7782C14.89 17.1687 15.5232 17.1687 15.9137 16.7782C16.3042 16.3876 16.3042 15.7545 15.9137 15.364L9.54972 8.99999L15.9139 2.63582C16.3044 2.24529 16.3044 1.61213 15.9139 1.2216C15.5234 0.83108 14.8902 0.83108 14.4997 1.2216L8.13551 7.58577L1.77156 1.22182C1.38104 0.8313 0.747871 0.8313 0.357346 1.22182C-0.0331781 1.61235 -0.0331778 2.24551 0.357346 2.63604L6.7213 8.99999L0.357542 15.3637Z')
      //-     .housing-cooperative-test__modal-container
      //-       .housing-cooperative-test__modal-icon
      //-         svg(width='72' height='72' viewBox='0 0 72 72' fill='none' xmlns='http://www.w3.org/2000/svg')
      //-           circle(cx='36' cy='36' r='36' fill='#8BC540')
      //-           path(d='M21.0821 38.9612C20.5084 38.3636 19.5588 38.3442 18.9612 38.9179C18.3636 39.4916 18.3442 40.4412 18.9179 41.0388L21.0821 38.9612ZM31.52 52L30.4379 53.0388C30.7563 53.3704 31.2091 53.5377 31.6665 53.4928C32.124 53.4479 32.5356 53.1957 32.7834 52.8086L31.52 52ZM53.2634 20.8086C53.71 20.1108 53.5063 19.1832 52.8086 18.7366C52.1108 18.29 51.1832 18.4937 50.7366 19.1914L53.2634 20.8086ZM18.9179 41.0388L30.4379 53.0388L32.6021 50.9612L21.0821 38.9612L18.9179 41.0388ZM32.7834 52.8086L53.2634 20.8086L50.7366 19.1914L30.2566 51.1914L32.7834 52.8086Z' fill='white')
      //-       span.housing-cooperative-test__modal-title Ваши данные сохранены
      //-       span.housing-cooperative-test__modal-text Теперь вы можете посмотреть
      //-         strong  перечень существующих ЖСК
      //-         |  и выбрать желаемый
      //-       a.btn.housing-cooperative-test__modal-submit(href="https://дом.рф/land/cooperatives/#coops-catalog") Перейти к выбору ЖСК
</template>

<script>

const ALL_QUESTIONS = [
  {
    text: 'Какой у вас стаж работы?',
    answers: {
      a: 'Более года',
      b: 'Менее года'
    },
    correctAnswer: 'a',
    radioName: 'experience',
    uncorrectText: 0
  },
  {
    text: 'В какой организации вы работаете?',
    answers: {
      a: 'Государственная',
      b: 'Частная'
    },
    correctAnswer: 'a',
    radioName: 'organization',
    uncorrectText: 1
  },
  {
    text: 'Включены ли вы в список граждан, имеющих право вступить в ЖСК с господдержкой?',
    answers: {
      a: 'Да',
      b: 'Нет'
    },
    correctAnswer: 'a',
    radioName: 'list-of-gs',
    uncorrectText: 2,
    note: {
      title: 'Узнать, состоите ли вы в списке имеющих право вступить в ЖСК с господдержкой, можно в профильном подразделении работодателя.',
    }
  },
  {
    text: 'Относитесь ли к категории граждан, которым положена субсидия на приобретение жилья в рамках государственной программы "Жилище"?',
    answers: {
      a: 'Да',
      b: 'Нет'
    },
    correctAnswer: 'a',
    radioName: 'subsidy',
    uncorrectText: 3
  },
  {
    text: 'У вас есть специальное звание органов внутренних дел Российской Федерации?',
    answers: {
      a: 'Да',
      b: 'Нет'
    },
    correctAnswer: 'a',
    radioName: 'rank',
    uncorrectText: 1
  },
  {
    text: 'Имеет ли ваша трудовая организация статус оборонно-промышленного комплекса?',
    answers: {
      a: 'Да',
      b: 'Нет'
    },
    correctAnswer: 'a',
    radioName: 'status',
    uncorrectText: 3
  },
  {
    text: 'Какой у вас срок членства в спортивной федерации?',
    answers: {
      a: 'Менее года',
      b: 'Более года'
    },
    correctAnswer: 'b',
    radioName: 'term',
    uncorrectText: 4
  },
  {
    text: 'Вы проходите военную службу по контракту?',
    answers: {
      a: 'Да',
      b: 'Нет'
    },
    correctAnswer: 'a',
    radioName: 'contract',
    uncorrectText: 1
  },
  {
    text: 'Вы являетесь участником накопительно-ипотечной системы жилищного обеспечения военнослужащих?',
    answers: {
      a: 'Да',
      b: 'Нет'
    },
    correctAnswer: 'b',
    radioName: 'soldier',
    uncorrectText: 1
  },
]

const CATEGORIES_OF_CITIZENS = [
  {
    text: 'Сотрудник ФГУП/ФГУ',
    questions: [0, 2]
  },
  {
    text: 'Молодые ученые',
    questions: [1, 3, 2]
  },
  {
    text: 'Военнослужащие',
    questions: [7, 8, 2]
  },
  {
    text: 'Сотрудники органов внутренних дел',
    questions: [4, 2]
  },
  {
    text: 'Работники оборонно-промышленного комплекса',
    questions: [5, 2]
  },
  {
    text: 'Госслужащие',
    questions: [0, 2]
  },
  {
    text: 'Члены спортивных федераций',
    questions: [6, 2]
  },
  {
    text: 'Работник госкорпорации',
    questions: [0, 2]
  },
  {
    text: 'Работник Института развития',
    questions: [0, 2]
  },
  {
    text: 'Многодетная семья',
    questions: [2]
  },
  {
    text: 'Не подхожу под категории',
    questions: false,
  },
]

const UNSUCCESSFUl_TEXTS = [
  {
    title: 'Вы не подходите для участия в ЖСК с господдержкой, так как ваш стаж не соответствует установленным требованиям.',
    text: 'Ознакомьтесь с требованиями к стажу в нашем материале о том, <a href="https://xn--h1alcedd.xn--d1aqf.xn--p1ai/instructions/chto-takoe-zhilishchno-stroitelnye-kooperativy/">как вступить в ЖСК</a>.',
  },
  {
    title: 'К сожалению, вы не можете вступить или создать ЖСК с господдержкой, так как не соответствуете условиям программы.',
    text: 'Вы можете ознакомиться с другими мерами поддержки по улучшению жилищных условий: <a href="https://xn--h1alcedd.xn--d1aqf.xn--p1ai/catalog/">Каталог жилищных программ</a>.',
  },
  {
    title: 'К сожалению, вы не включены в список, рекомендуем обратиться в профильное подразделение работодателя для включения в список граждан, имеющих право на вступление в ЖСК.',
    text: 'Вы можете ознакомиться с другими <a href="https://xn--h1alcedd.xn--d1aqf.xn--p1ai/catalog/">мерами поддержки</a> по улучшению жилищных условий.',
  },
  {
    title: 'К сожалению, вы не можете вступить или создать ЖСК с господдержкой, так как не соответствуете условиям программы.',
    text: 'Ознакомьтесь с требованиями в нашем материале о том, <a href="https://xn--h1alcedd.xn--d1aqf.xn--p1ai/instructions/chto-takoe-zhilishchno-stroitelnye-kooperativy/">как вступить в ЖСК</a>.',
  },
  {
    title: 'Вы не подходите для участия в ЖСК с господдержкой, так как ваш срок членства не соответствует установленным требованиям.',
    text: 'Ознакомьтесь, какой срок членства установлен для участия в ЖСК с господдержкой в нашем <a href="https://xn--h1alcedd.xn--d1aqf.xn--p1ai/instructions/chto-takoe-zhilishchno-stroitelnye-kooperativy/">материале</a>.',
  },
]

import contentNote from '../content-note';
import { phoneMask } from '../validations';
import Vue from 'vue';
import VueAxios from 'vue-axios';
import axios from 'axios';
Vue.use(VueAxios, axios);
const apiForm = '/local/ajax/add_form_zhsk.php';

export default {
  name: 'HousingCooperativeTest',
  data() {
    return {
      allQuestions: ALL_QUESTIONS,
      selectValues: CATEGORIES_OF_CITIZENS,
      unsuccessfulTexts: UNSUCCESSFUl_TEXTS,
      isSelectOpened: false,
      isSelectDisabled: false,
      // isModalOpened: false,
      currentCategory: undefined,
      currentCategoryIdx: undefined,
      currentQuestions: [],
      currentQuestionIdx: undefined,
      currentUnsuccessfulTest: undefined,
      isSuccess: false,
      isFailing: false,
      // isValidationActivated: false,
      // isFormSended: false,
      // form: {
      //   name: '',
      //   email: '',
      //   phone: '',
      //   checkbox: true
      // },
      // formErrors: {
      //   name: false,
      //   email: {
      //     value: false,
      //     text: '',
      //   },
      //   phone: false,
      //   checkbox: false
      // }
    }
  },
  computed: {
    selectPlaceholder() {
      return document.documentElement.clientWidth > 767 ? 'Выберите категорию, к которой вы относитесь' : 'Выберите категорию';
    },
    selectedValue() {
      return this.currentCategory ? this.currentCategory.text : this.selectPlaceholder;
    }
  },
  watch: {
    isFailing() {
      if (this.isFailing === true && this.currentQuestions.length) {
        this.currentUnsuccessfulTest = this.unsuccessfulTexts[this.currentQuestions[this.currentQuestionIdx].uncorrectText];
      }
    },
    // isSuccess() {
    //   if (this.isSuccess) this.getForm();
    // }
  },
  mounted() {
    this.currentUnsuccessfulTest = this.unsuccessfulTexts[1];
  },
  updated() {
    // если при добавлении новых элементов есть тултип - инициализируем скрипт для него
    if (this.$root.$el.querySelectorAll('.js--content-note')) contentNote();
    // if (this.isSuccess) {
    //   phoneMask(); // при открытии формы инициализируем маску на инпут телефона
    //   setTimeout(() => {
    //     this.$refs.svgUnderline.classList.add('active');
    //   }, 200);
    // }
  },
  methods: {
    selectHandler(close = false) {
      if (close) {
        this.isSelectOpened = false;
      } else {
        this.isSelectOpened = !this.isSelectOpened;
      }
    },
    addQuestionToCurrents() {
      const questionToAddOrder = this.currentCategory.questions[this.currentQuestionIdx]
      const questionToAdd = this.allQuestions[questionToAddOrder];
      this.currentQuestions.push(questionToAdd);
    },
    selectItemHandler(item, idx) {
      this.isSelectDisabled = true;
      this.currentCategory = item;
      this.currentCategoryIdx = idx;

      if (item.questions) {
        this.currentQuestionIdx = 0;
        this.addQuestionToCurrents();
      } else {
        this.isFailing = true;
      }

      this.selectHandler(true);
    },
    checkboxHandler(key, radioName) {
      // блокируем чекбокс и его соседей чтобы не было возможности перевыбрать
      const checkboxes = this.$root.$el.querySelectorAll(`[data-name='${radioName}']`);
      checkboxes .forEach((checkbox) => {
        checkbox.classList.add('disabled');
      });

      const currentQuestion = this.currentQuestions[this.currentQuestionIdx];
      const isCorrectAnswer = currentQuestion.correctAnswer === key;

      if (isCorrectAnswer) {
        this.isFailing = false;

        // если последний вопрос - выводим форму
        if (this.selectValues[this.currentCategoryIdx].questions.length - 1 === this.currentQuestionIdx) {
          this.isSuccess = true;
        } else { // иначе выводим следующий вопрос
          this.currentQuestionIdx = this.currentQuestionIdx + 1;
          this.addQuestionToCurrents();
        }
      } else {
        this.isSuccess = false;
        this.isFailing = true;
      }
    },
    // getForm() {
    //   axios.get(apiForm)
    //     .then((res) => {
    //       $(this.$refs.formPlace).html(res.data); // jquery поцдепляется глобально битриксом
    //       phoneMask();
    //     })
    //     .catch((error) => {
    //       console.error(error);
    //     });
    // }
    // isPassedValidation() {
    //   if (this.form.name.length === 0) {
    //     this.formErrors.name = true;
    //   } else {
    //     this.formErrors.name = false;
    //   }

    //   if (this.form.email.length > 0 && this.form.email.match(/^.+@.+\..+$/igm)) {
    //     this.formErrors.email.value = false;
    //   } else if (this.form.email.length === 0) {
    //     this.formErrors.email.value = true;
    //     this.formErrors.email.text = 'Это поле обязательно для заполнения';
    //   } else {
    //     this.formErrors.email.value = true;
    //     this.formErrors.email.text = 'Введите корректный email';
    //   }

    //   if (this.form.phone.length < 17) {
    //     this.formErrors.phone = true;
    //   } else {
    //     this.formErrors.phone = false;
    //   }

    //   if (this.form.checkbox) {
    //     this.formErrors.checkbox = false;
    //   } else {
    //     this.formErrors.checkbox = true;
    //   }

    //   return !(this.formErrors.name || this.formErrors.email.value || this.formErrors.phone || this.formErrors.checkbox);
    // },
    // sendButtonHandler(e) {
    //   this.isValidationActivated = true;

    //   if (this.isPassedValidation()) {
    //     e.preventDefault(); // временно для теста, чтобы тестировщик мог посмотреть модалку
    //     this.isFormSended = true;
    //     this.isModalOpened = true;
    //   } else {
    //     e.preventDefault();
    //   }
    // },
    // modalCloseHandler() {
    //   this.isModalOpened = false;
    // }
  }
}
</script>
