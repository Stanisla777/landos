/* eslint-disable */
// import ApexCharts from 'apexcharts'
// const ApexCharts = () => import ("apexcharts");
function chartLine() {
  const element_chart = document.querySelector('.js--schedule-line');

  if(element_chart){
    const chart = element_chart.querySelector('.js--schedule-line-wr')
    const legend = element_chart.querySelector('.js--schedule-legend-wr')
    let data = element_chart.getAttribute('data-line-chart')
    data = JSON.parse(data);
    for(let i=0;i<data.length;i++){
      chart.querySelector(`.js--schedule-line-item:nth-child(${i+1})`).setAttribute('style',`width:${data[i]}%`)
      legend.querySelector(`.js--schedule-legend-item:nth-child(${i+1}) .js--schedule-legend-text`).textContent = data[i]+'%'
    }
  }


}
export default function progressRs() {
  chartLine();
}
