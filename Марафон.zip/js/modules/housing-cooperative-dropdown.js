import dropDown from './dropDown';
// eslint-disable-next-line camelcase
function izsDropDownQuestions() {
  // eslint-disable-next-line camelcase
  const array_btn = document.querySelectorAll('.js--izs-dropdown-button');
  array_btn.forEach((item) => {
    // eslint-disable-next-line no-param-reassign,no-unused-vars
    item.onclick = (e) => {
      dropDown(item, 0);
    };
  });
}
function autoHeight() {
  // eslint-disable-next-line camelcase
  const body_dropdown = document.querySelectorAll('.block_faq__item-des.js-accordion-body');
  body_dropdown.forEach((item) => {
    if (item.closest('.js-accordion-parent') && item.closest('.js-accordion-parent').classList.contains('active')) {
      // eslint-disable-next-line no-param-reassign
      item.style.maxHeight = `${item.scrollHeight}px`;
    }
  });
}
// eslint-disable-next-line no-unused-vars
function loadMore() {
  // eslint-disable-next-line camelcase
  const containe_r = document.querySelectorAll('.js--faq-container');
  for (let item = 0; item < containe_r.length; item++) {
    if (containe_r[item].querySelector('.js--load-more')) {
      // eslint-disable-next-line camelcase
      const array_dropdown_list = containe_r[item].querySelectorAll('.js--block_faq-wrapper .js-accordion-parent');
      let height = 0;
      for (let i = 0; i < array_dropdown_list.length; i++) {
        height += array_dropdown_list[i].offsetHeight;
        if (i === 2) {
          break;
        }
      }
      containe_r[item].querySelector('.js--block_faq-wrapper').setAttribute('style', `max-height:${height}px;`);
    }
  }
}
function izsDropDownBlock() {
  // eslint-disable-next-line camelcase
  const array_btn = document.querySelectorAll('.js--load-more');
  array_btn.forEach((item) => {
    // eslint-disable-next-line no-param-reassign
    item.onclick = () => {
      if (item.closest('.js--faq-container') && item.closest('.js--faq-container').classList.contains('active')) {
        item.closest('.js--faq-container').classList.remove('active');
        item.closest('.js--faq-container').scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      } else {
        item.closest('.js--faq-container').classList.add('active');
      }
    };
  });
}
// eslint-disable-next-line camelcase
export default function dropDownNew() {
  window.addEventListener('resize', autoHeight);
  // window.addEventListener('resize', () => {
  //   autoHeight();
  //   loadMore();
  // });
  // loadMore();
  izsDropDownQuestions();
  izsDropDownBlock();
}
