/* eslint-disable */
export default function jsCallModal() {
  // eslint-disable-next-line camelcase
  const array_btn = document.querySelectorAll('.js--call-modal-window');
  // eslint-disable-next-line no-restricted-syntax,camelcase
  for (const item of array_btn) {
    item.addEventListener('click', () => {
      const attrib = item.getAttribute('data-modal');
      const modal = document.querySelector(`#${attrib}`);
      if (modal) {
        modal.classList.add('open');
        document.body.classList.add('body-modal');
      }
    });
  }
  const close_btn = document.querySelectorAll('.js--close--modals-window')
  for (let item of close_btn){
    item.onclick = () => {
      item.closest('.js--modal-window').classList.remove('open')
      document.body.classList.remove('body-modal')
      document.body.classList.remove('body-unactive')
    }
  }
  const area = document.querySelectorAll('.modal-for-polls');

  for(let item of area){
    item.addEventListener('click', (e) => {
      if (e.target === item && item.querySelector('.js--close--modals-window')) {
        e.target.classList.remove('open');
        document.body.classList.remove('body-unactive');
        document.body.classList.remove('body-modal');
        const scrollY = document.body.style.top;
        document.body.style.position = '';
        document.body.style.top = '';
        window.scrollTo(0, parseInt(scrollY || '0') * -1);
      }
    });
  }





}
