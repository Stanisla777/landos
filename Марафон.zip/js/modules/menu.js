function removeActiveClass(arr, className) {
    for (let i = 0; i < arr.length; i += 1) {
        arr[i].classList.remove(className);
    }
}

function setSubMenu(item, activeClass) {
    const wrapSubMenu = document.getElementById('sub-menu-wrap');
    const subMenu = item.querySelector('.js-sub-menu');
    wrapSubMenu.innerHTML = '';
    if (subMenu) {
        wrapSubMenu.classList.add(activeClass);
        wrapSubMenu.appendChild(subMenu.cloneNode(true));

        const subMenuItems = wrapSubMenu.querySelectorAll('.menu-sub-nav__item');

        setTimeout(() => {
            for (let i = 0; i < subMenuItems.length; i += 1) {
                subMenuItems[i].classList.add('active');
            }
        }, 10);
    }
}

export default function menu() {
    const links = document.getElementsByClassName('menu-nav__item');
    const wrap = document.getElementsByClassName('js-p-wrap')[0];
    const opener = document.querySelector('.js-open-menu');
    const closer = document.querySelector('.js-close-menu');
    const body = document.querySelector('body');
    const navMenu = document.getElementById('menu');
    // const intViewportWidth = window.innerWidth;
    const activeClass = 'is-active';
    const openClass = 'is-open';

  for (let i = 0; i < links.length; i += 1) {
    links[i].addEventListener('mouseover', (e) => {
      const windowWidth = window.innerWidth;
      if (windowWidth > 1243) {
        removeActiveClass(links, activeClass);
        setSubMenu(links[i], activeClass);
        links[i].classList.add(activeClass);
      } else {
        e.preventDefault();
      }
    });

    links[i].addEventListener('click', (e) => {
      const windowWidth = window.innerWidth;
      if (windowWidth <= 1243) {
        if (!e.target.classList.contains('menu-nav__link')) {
          links[i].classList.toggle(activeClass);
        }
      } else {
        e.preventDefault();
      }
    });
  }

    if (!opener || !closer) return;

    opener.addEventListener('click', (e) => {
        e.preventDefault();
        navMenu.classList.add(openClass);
        wrap.classList.add('is-hidden');
        body.classList.add('menu-opened');
        opener.classList.add(activeClass);
    });

    closer.addEventListener('click', (e) => {
        e.preventDefault();
        navMenu.classList.remove(openClass);
        wrap.classList.remove('is-hidden');
        body.classList.remove('menu-opened');
        opener.classList.remove(activeClass);
    });
}
