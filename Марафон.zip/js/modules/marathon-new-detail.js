export default function marathonNewDetail() {
  const parent = document.querySelector('.marathon-new-detail__video');
  let count = 0;
  if (parent) {
    const link = parent.querySelector('iframe').getAttribute('src');
    parent.onclick = () => {
      if (count === 0) {
        parent.querySelector('.marathon-new-detail__video-plug').classList.add('unactive');
        parent.querySelector('iframe').setAttribute('src', `${link}&autoplay=1`);
        setTimeout(() => {
          parent.querySelector('.marathon-new-detail__before-load').classList.add('unactive');
        }, 800);
        count += 1;
      }
    };
  }
}
