<template lang="pug">
  .test-cotainer-answer(
    v-bind:class="{mandatory:req}"
  )

    //  тут стоит условие заполнено ли что-нибудь в "QUESTION", это может быть и форма и простое текстовое поле
    p.test-window__question(
      v-if="question!='REZULTAT'"
      v-html="question"
    )
    .marathon-detail__wr-final-result(
      v-else
    )
      p.marathon-detail__final-result.js--inflected-block.
        Ваш результат: <span class="js--count-result">{{sum_of_points}}</span> <span class="js--inflected-word"></span> из <span>{{count_answers-1}}</span>
      p.marathon-detail__offer-fill-form.
        Заполните форму, чтобы зарегистрироваться на марафоне и принять участие в розыгрыше

    .test-item
      .test-window__item.test-window__textarea(
        v-for ="(answer,key,ind) in variants"
      )
        textarea(
          v-if="answer.FIELD_TYPE==5"
          @change="pass_inputAnswer($event,answer.NAME_INPUT)"
          @input="limitInput"

        )(name="",maxlength="1001")
        p.test-window__textarea-error.
          Превышено допустимое количество в 1000 символов

        input.js--marathon-detail-input(
          v-if="answer.FIELD_TYPE==4"
          v-bind:placeholder="answer.MESSAGE"
          v-bind:id="[`marathon-detail__${key}`]"
          v-bind:class="[`js--marathon-detail__${key}`]"
          @change="pass_inputAnswer($event,answer.NAME_INPUT)"
          @input="fieldCompletion"
        )

    .marathon-detail__wr-checkboxes
      .marathon-detail__checkbox.checkbox-stylized.js--marathon-detail-checkbox.js--marathon-detail-input
        input#marathon-detail__checkbox1(type='checkbox')(
          @change="changeChek"
        )
        label(for='marathon-detail__checkbox1') Я даю согласие на обработку <a href="/user-agreement/">персональных данных</a>
        .marathon-detail__checkbox-empty
      .marathon-detail__checkbox.checkbox-stylized.js--marathon-detail-checkbox.js--marathon-detail-input
        input#marathon-detail__checkbox2(type='checkbox')(
          @change="changeChek"
        )

        label(for='marathon-detail__checkbox2') Я соглашаюсь на получение информационных рассылок <a href="/user-personalized-communications/">спроси.дом.рф</a>
        .marathon-detail__checkbox-empty
    button.test-window__btn.btn.btn-slide-sub.marathon-detail__btn-sub(type="button")(
      v-bind:class="{unact:req}"
      v-if="btn_answer"
      @click="pass_clickButtonAnswer"
    ) Отправить
</template>

<script>
import IMask from 'imask';
export default {
  name: "QuestionTextField",
  props:['question','variants','item_key','btn_answer','circle_number','count_answers','required','current_answer','button_text','sum_of_points'],
  data(){
    return{
      input:"",
      req:null,
      count:0,
      count_name:0,
      count_tel:0,
      count_mail:0,
      showChec:false
    }
  },

  methods:{
    pass_inputAnswer(elem,param_1){
      const element = elem.currentTarget
      const val_input = element.value
      this.$emit('event_inputAnswer',[element,elem,param_1,val_input,this.input])
    },
    pass_clickButtonAnswer(elem){
      const element = elem.currentTarget
      const mandatory_choice = document.querySelectorAll('.js--marathon-detail-input').length
      const mail_input = element.closest('.test-cotainer-answer').querySelector('.js--marathon-detail__2')

      if (mandatory_choice>0&&this.count===mandatory_choice){
        this.$emit('event_clickButtonAnswer',element)
      }
      this.count=0
      this.count_mail=0
      this.count_name=0
      this.count_tel=0
    },
    inputCost(){
      const input_tel = document.querySelectorAll('#marathon-detail__1');
      const maskOptions = {
        mask: '+{7} (000) 000 00 00'
      };
      for (const item of input_tel) {
        new IMask(item, maskOptions);
      }

    },
    fieldCompletion(el){
      const element = el.currentTarget
      let count_tel = 0
      const input_name_val = element.value.length
      const mail_input = element.closest('.test-cotainer-answer').querySelector('.js--marathon-detail__2')
      if(element.classList.contains('js--marathon-detail__0')&&input_name_val>0&&this.count_name===0){
        this.count+=1
        this.count_name+=1
      }
      else if(element.classList.contains('js--marathon-detail__0')&&input_name_val===0&&this.count_name>0){
        this.count-=1
        if(this.count_name!==0){
          this.count_name-=1
        }
      }

      if(element.classList.contains('js--marathon-detail__1')&&input_name_val===18){
        this.count+=1
        this.count_tel+=1
      }
      else if(element.classList.contains('js--marathon-detail__1')&&input_name_val<18&&this.count!==0&&this.count_tel>0){
        this.count-=1
        if(this.count_tel!==0){
          this.count_tel-=1
        }
      }
      if(element.classList.contains('js--marathon-detail__2')&&input_name_val>4&&this.count_mail===0&&mail_input&&mail_input.value.match(/^.+@.+\..+$/igm)){
        this.count+=1
        this.count_mail+=1
      }
      else if(element.classList.contains('js--marathon-detail__2')&&input_name_val<5&&this.count_mail>0&&!mail_input.value.match(/^.+@.+\..+$/igm)){
        this.count-=1
        if(this.count_mail!==0){
          this.count_mail-=1
        }
      }
      console.log(this.count);

    },
    changeChek(el){
      const element = el.currentTarget
      if(element.checked){
        this.count+=1
      }
      else {
        this.count-=1
      }
    },
    inactiveButton(){
      const array__inp = document.querySelectorAll('.js--marathon-detail-input')
      const btn = document.querySelector('.marathon-detail__btn-sub')
      if(array__inp.length>0){
        this.showChec=true
      }
      if(btn&&array__inp.length>0){
        btn.setAttribute('data-active','unactive_btn')
      }
    },
    requiredButton(){
    },
    requiredButton_2(){
    },
    limitInput(el) {
      const max = 10
      const field=el.currentTarget
      // field.value = field.value.substring(0, max);
      const parent = field.closest('.test-window__item')
      const item = parent.querySelectorAll('.test-window__textarea-error')
      if (field.value.length === max) {
        item.forEach(function (item){
          item.setAttribute('style','display:block')
        })
      }
      else
      {
        item.forEach(function (item){
          item.setAttribute('style','display:none')
        })
      }
    },
    declensionOfNumber(number, txt) {
      const massive_variant = ['правильных ответов','правильный ответ','правильных ответа']
      const cases = [2, 0, 1, 1, 1, 2];
      return txt[(number % 100 > 4 && number % 100 < 20) ? 2 : cases[(number % 10 < 5) ? number % 10 : 5]];
    }
  },
  watch: {
    input(){
      this.requiredButton_2()
    },
    count(){
      const mandatory_choice = document.querySelectorAll('.js--marathon-detail-input').length
      const btn = document.querySelector('.marathon-detail__modal .marathon-detail__btn-sub')
      if (mandatory_choice>0&&btn&&this.count===mandatory_choice){
        btn.setAttribute('data-active','active_btn')
      }
      else if(mandatory_choice>0&&btn&&this.count!==mandatory_choice){
        btn.setAttribute('data-active','unactive_btn')
      }
    }
  },
  mounted() {
    this.requiredButton();
    const inflected_block = document.querySelector('.js--inflected-block');
    if(inflected_block){
      let received_figure = inflected_block.querySelector('.js--count-result').textContent
      inflected_block.querySelector('.js--inflected-word').textContent = this.declensionOfNumber(received_figure, ['правильный ответ', 'правильных ответа','правильных ответов']);
    }
    this.inputCost();
    this.inactiveButton();
  },
}
</script>

<style scoped>

</style>
