<template lang="pug">
  .test-slide-calculator
    p.test-slide-calculator__item.
      Шаг <span>1</span> из {{count_slide}}
</template>
<script>
export default {
  name: 'SlideCalculator',
  props:['count_slide','current_slide'],
  data(){
    return {

    }
  }
};
</script>
<style scoped>
</style>
