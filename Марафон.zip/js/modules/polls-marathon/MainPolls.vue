<template lang="pug">
  .polls.js--polls
    p.polls__call-action {{title_text}}
    template
      step-polls(
        v-show="main_window"
        v-if="viewsTest==='Test2'"
        :idTest ="idTest"
        :VOTE_ID="VOTE_ID"
        :QUESTIONS="QUESTIONS"
        :id_correct_answers="id_correct_answers"
        :massive_required="massive_required"
        :sessid="sessid"
        :button_text="button"
        :title_text="title_text"
        :views_test="viewsTest"
      )
    template
      slider-test(
        v-if="viewsTest==='Test1'"
        :idTest ="idTest"
        :VOTE_ID="VOTE_ID"
        :button_text="button"
        :title_text="title_text"
      )
    template
      thanks-window(
        v-show="thanks_window"
      )
</template>
<script>
import Vue from 'vue';
import StepPolls from './components/v-component-step-polls.vue';
import SliderTest from './components/v-component-slider-polls.vue';
import ThanksWindow from './components/v-component-thanks-window.vue';
import Storage from './development-tools/state.vue';
import eventBus from './development-tools/eventBus.vue';
import axios from 'axios';
import anchors from '../anchors';

export default {
  name:'PollsMarathon',
  data(){
    return {
      // // QUESTIONS:'', //Раскоментировать


      viewsTest:'2',
      idTest:null,
      VOTE_ID:null,
      button:'Проверить ответы',
      title_text:'Проверьте себя',
      id_correct_answers:[],//Расскоментировать
      massive_required:[],//Расскоментировать
      // id_correct_answers:[12,13,18,21,31,32,33],//Убрать
      // massive_required:['Y'],//Убрать
      sessid:null,
    }
  },

  methods:{
    getParameterApi(param){
      const config_header = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        }
      }

      //расскоментировать

      axios.get(`/local/api/tests/?id_tests=${param}`, this.config_header)
        .then((res)=>{
          this.QUESTIONS = res.data.QUESTIONS
          // for (let item of res.data.QUESTIONS){
          //   for (let elem of item.CORRECT_ANSWERS){
          //     this.id_correct_answers.push(elem)
          //   }
          //   if(item.REQUIRED=='Y'){
          //     this.massive_required.push(item.REQUIRED)
          //   }
          // }
          let sessid=res.data.SESSID.split('=').pop();
          sessid = sessid.replace(/[^a-zа-яё0-9\s]/gi, '');
          sessid = sessid.trim()
          this.sessid = sessid

        }).catch((error) => {
          console.log(error);
        });
    },
    accordion() {
      const courses = document.querySelectorAll('.js--courses-accord');
      for (let i = 0; i < courses.length; i++) {
        const content = courses[i].querySelector('.js--courses-accord-content');
        const opener = courses[i].querySelector('.js--courses-accord-btn');
        opener.onclick = () => {
          if (courses[i].classList.contains('active')) {
            opener.classList.remove('active');
            courses[i].classList.remove('active');
            content.classList.remove('show');
            content.setAttribute('style', `height:0`);
          } else {
            courses[i].classList.add('active');
            opener.classList.add('active');
            content.classList.add('show');
            const rte = content.querySelector('#RTE');
            const contentHeight = rte.offsetHeight;
            content.style.height = `${contentHeight}px`;
          }
        };
      }
    }
  },
  mounted() {
    this.viewsTest = this.$attrs.views
    this.idTest = this.$attrs.id
    this.VOTE_ID = this.$attrs.id
    console.log(this.$attrs.title_text);
    if(this.$attrs.button){
      this.button=this.$attrs.button
    }
    if(this.$attrs.button==='null') {
      this.button='Проверить ответы'
    }

    if(this.$attrs.title_text){
      this.title_text=this.$attrs.title_text
    }
    if(this.$attrs.title_text==='null') {
      this.title_text='Проверьте себя'
    }

    // this.getParameterApi(this.idTest)//расскоментировать
    anchors()
    this.accordion()
  },
  computed:{
    thanks_window(){
      return Storage.getters.THANKSWINDOW
    },
    main_window(){
      return Storage.getters.MAINWINDOW
    },
  },
  components:{
    StepPolls,
    SliderTest,
    ThanksWindow
  },
}
</script>
