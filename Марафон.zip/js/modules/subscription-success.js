export default function subscriptionSuccess() {
    const successWindow = document.querySelector('.js--subscription-success');
    const observerOptions = {
        attributes: true
    };
    function callback() {
        if (successWindow.classList.contains('show')) {
            setTimeout(() => {
                successWindow.classList.remove('show');
            }, 5000);
        }
    }
    const observer = new MutationObserver(callback);

    if (successWindow) {
        observer.observe(successWindow, observerOptions);
    }
}
