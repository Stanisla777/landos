<template lang="pug">
  .minsport__area-application.minsport__area-check-yourself
    p.minsport__block-title Проверьте список спортивных организаций самостоятельно
    .minsport__wr-check-yourself
      p.minsport__plain-text Получить перечень организаций для налогового вычета
      .minsport__wr-icon-check-yourself
        svg(width='18', height='16', viewbox='0 0 18 16', fill='none', xmlns='http://www.w3.org/2000/svg')
          path(d='M8 0L14 7H0V9H14L8 16H11L17.8531 8L11 0H8Z', fill='black')
    a.minsport__area-check-yourself-link(href="/upload/minsport.zip" download)
</template>
<script>

export default {
  name: 'v-component-check-yourself',
};
</script>
<style scoped>
</style>
