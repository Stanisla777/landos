/* eslint-disable */
import Vue from 'vue';
import VueSlider from 'vue-slider-component';
import IMask from 'imask';
import Cookies from 'js-cookie'

export default function formRating() {
  const formRate=document.querySelectorAll('.js--form-rating');
  const cookie_key = `was_useful_rating_${window.location.pathname}`;
  for(let item=0;item<formRate.length;item++){
    formRate[item].id = `js--form-rating${item}`;
    const app = new Vue({
      el: `#js--form-rating${item}`,
      data: {
        variant_placeholder:['Что разочаровало?','Какие изменения вы бы предложили?','Чем стоит дополнить?','Что показалось сложным?','Поделитесь своими эмоциями!'],
        place_holder:'',
        array_star:[`form-rating-input-${item}-1`,`form-rating-input-${item}-2`,`form-rating-input-${item}-3`,`form-rating-input-${item}-4`,`form-rating-input-${item}-5`],
        rate:0,
        textValue:'',
        show_error:false,
        length_error:false,
        max_length:300,
        btn_active:false,
        form_show:true
      },
      methods: {
        changeGrade(el,index){
          const element = el.currentTarget
          const parent = this.$refs.formRating;
          this.rate = this.array_star.length - index
          //действие над звёздочками оценки
          const array_star = parent.querySelectorAll('.js--grade-item')
          for(let i=0;i<array_star.length-this.rate;i++){
            array_star[i].checked=false
          }
          for(let i=0;i<this.rate;i++){
            array_star[(array_star.length-1)-i].checked=true
          }
          //  формирование плэйсхолдер
          1 === this.rate ? this.place_holder = this.variant_placeholder[0] : 2 === this.rate ? this.place_holder = this.variant_placeholder[1] : 3 === this.rate ? this.place_holder = this.variant_placeholder[2] : 4 === this.rate ? this.place_holder = this.variant_placeholder[3] : 5 === this.rate && (this.place_holder = this.variant_placeholder[4]);
          this.$refs.hiddenInput.value= this.rate;
        },
        clearField(el){
          this.textValue=''
          this.show_error=false
        },
        showError(){
          this.show_error=true
        },
        endFocus(){
          this.show_error=false
          this.length_error = false;
        },
        beginFocus(){
          this.show_error=false
          this.length_error = false;
        },
        textKeyDown(el){
          this.show_error=false
          const element = el.currentTarget
          if(element.value.length===this.max_length){
            this.length_error=true
          }
        },
        inputIMask(){
          const input_status = document.querySelectorAll('.js--text_area');
          const maskOptions = {
            // mask: /^(?=.{1,300}$)[^\s]((?!\s{2}).)*$/i,
            mask: /\S\s?$/
          };
          IMask(this.$refs.textArea, maskOptions);

        },
        textInput(el) {
          const element = el.currentTarget
          if(element.value.trim().length>0){
            this.btn_active=true
          }
          else {
            this.btn_active=false
          }
          if (element.value.length<= this.max_length) {
            this.length_error = false;
          }
        },

        // ----------- функции куки
        localStorageLoading() {
          let local_stage = Cookies.get(cookie_key);
          if ((local_stage !== undefined) && (parseInt(local_stage) !== 0)) {
            const parent = this.$refs.formRating;
            const array_star = parent.querySelectorAll('.js--grade-item')
            for(let i=0;i<parseInt(local_stage);i++){
              array_star[(array_star.length-1)-i].checked=true
            }
            this.form_show=false
          }
        },

        localStorageClick(){
          Cookies.set(cookie_key,this.rate)
        },

        submitForm(el){
          el.preventDefault()
          el.stopPropagation()
          // const form = this.$refs.webform
          const form = el.currentTarget.closest('form')
          if (!form){
            console.error('Форма не найдена')
            return;
          }
          // console.log('submitForm',form)
          let formData = new URLSearchParams(Array.from(new FormData(form))).toString()
          const _success = form.querySelector('.js--webform-success')
          BX.ajax({
            url: '/local/ajax/form.result.new.php',
            data: formData,
            method: 'POST',
            dataType: 'json',
            timeout: 30,
            async: true,
            processData: true,
            scriptsRunFirst: true,
            emulateOnload: true,
            start: true,
            cache: false,
            onsuccess: (result)=>{
              if (!!result) {
                if (result['debug'])
                  console.log(result);
                if (result['result']) {
                  if (typeof window.dmpkitdl !== "undefined" && window.dmpkitdl !== null) {
                    window.dmpkitdl.push({event: 'evaluation-fos-send'});
                  }
                  if (_success) {
                    this.localStorageClick()
                    this.form_show=false
                    _success.classList.add('show');
                    document.body.classList.add('modal-opened');
                    document.body.classList.add('body-modal');
                    document.body.classList.add('body-modal-modals');
                    setTimeout(() => {
                      _success.classList.remove('show');
                      document.body.classList.remove('modal-opened');
                      document.body.classList.remove('body-modal');
                      document.body.classList.remove('body-modal-modals');
                    }, 10000);
                    _success.addEventListener('click', function (e) {
                      _success.classList.remove('show');
                      document.body.classList.remove('modal-opened');
                      document.body.classList.remove('body-modal-modals');
                      setTimeout(() => {
                        document.body.classList.remove('body-modal');
                      }, 500);
                    })
                  }
                  // return;
                } else {
                  if (result['errors']) {
                    console.warn(result['errors']);
                    return;
                  }
                }
              }
            },
            onfailure: function(error){
              console.warn(error);
            }
          });
        }
      },
      computed: {
      },
      watch: {
      },
      mounted() {
        this.inputIMask()
        this.localStorageLoading()

      },
      components: {

      },
    })
  }

}
