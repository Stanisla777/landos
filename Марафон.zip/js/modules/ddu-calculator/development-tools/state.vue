<script>
import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);


export default new Vuex.Store({
  state: {

    holidays_count:0,
    //массиве праздников
    holidays: [
      {
        2013: [['01.01.2013', '02.01.2013', '03.01.2013', '04.01.2013', '07.01.2013', '08.01.2013'], '08.03.2013', ['01.05.2013', '02.05.2013', '03.05.2013'], ['09.05.2013', '10.05.2013'], '12.06.2013', '04.11.2013']
      },
      {
        2014: [['01.01.2014', '02.01.2014', '03.01.2014', '06.01.2014', '07.01.2014', '08.01.2014'], '10.03.2014', ['01.05.2014', '02.05.2014'], '09.05.2014', ['12.06.2014', '13.06.2014'], ['03.11.2014', '04.11.2014']]
      },
      {
        2015: [['01.01.2015', '02.01.2015', '05.01.2015', '06.01.2015', '07.01.2015', '08.01.2015', '09.01.2015'], '23.02.2015', '09.03.2015', ['01.05.2015', '04.05.2015'], '11.05.2015', '12.06.2015', '04.11.2015']
      },
      {
        2016: [['01.01.2016', '04.01.2016', '05.01.2016', '06.01.2016', '07.01.2016', '08.01.2016'], ['22.02.2016', '23.02.2016'], ['07.03.2016', '08.03.2016'], ['02.05.2016', '03.05.2016'], '09.05.2016', '13.06.2016', '04.11.2016']
      },
      {
        2017: [['02.01.2017', '03.01.2017', '04.01.2017', '05.01.2017', '06.01.2017'], ['23.02.2017', '24.02.2017'], '08.03.2017', '01.05.2017', ['08.05.2017', '09.05.2017'], '12.06.2017', '06.11.2017']
      },
      {
        2018: [['01.01.2018', '02.01.2018', '03.01.2018', '04.01.2018', '05.01.2018'],['08.01.2018'], '23.02.2018', ['08.03.2018', '09.03.2018'], ['01.05.2018', '02.05.2018'], '09.05.2018', ['11.06.2018', '12.06.2018'], '05.11.2018']
      },
      {
        2019: [['01.01.2019', '02.01.2019', '03.01.2019', '04.01.2019', '07.01.2019', '08.01.2019'], '08.03.2019', ['01.05.2019', '02.05.2019', '03.05.2019'], ['09.05.2019', '10.05.2019'], '12.06.2019', '04.11.2019']
      },
      {
        2020: [['01.01.2020', '02.01.2020', '03.01.2020', '06.01.2020', '07.01.2020', '08.01.2020'], '24.02.2020', '09.03.2020', ['01.05.2020', '04.05.2020', '05.05.2020'], '11.05.2020', '12.06.2020', '04.11.2020']
      },
      {
        2021: [['01.01.2021', '04.01.2021', '05.01.2021', '06.01.2021', '07.01.2021', '08.01.2021'], ['22.02.2021','23.02.2021'], '08.03.2021', ['03.05.2021','04.05.2021','05.05.2021','06.05.2021','07.05.2021'],['10.05.2021'], '14.06.2021', ['01.11.2021','02.11.2021','03.11.2021','04.11.2021', '05.11.2021'], '31.12.2021']
      },
      {
        2022: [['03.01.2022', '04.01.2022', '05.01.2022', '06.01.2022', '07.01.2022'], '23.02.2022', '08.03.2022', ['02.05.2022', '03.05.2022'], ['09.05.2022', '10.05.2022'], '13.06.2022', '04.11.2022']
      },
      {
        2023: [['02.01.2023', '03.01.2023', '04.01.2023', '05.01.2023', '06.01.2023'], ['23.02.2023', '24.02.2023'], '08.03.2023', '01.05.2023', ['08.05.2023', '09.05.2023'], '12.06.2023', '06.11.2023']
      }
    ],


    //массив из ключевых ставок
    array_key_rate: null,
    //дата и ставка последнего изменения ключевой ставки ЦБ
    last_change_key:{},

    //дата первого периода со ставкой переведённая в new Date
    first_period_data:null,

    usual_first_period_data:null,



    //ключевая ставка на сегодняшний день
    key_rate:0,

    //ставка, кторая участвует в расчётах
    applicable_rate:0,

    //ключевая ставка на день сдачи объекта
    rate_day_delivery:0,
    //ключевая ставка на день начала просрочки
    rate_day_delay:0,
    //ключевая ставка на день сдачи объекта
    rate_day_fact_delivery:0,


    apartment_price:0,
    apartment_price_show:0,

    date_transfer:null,
    date_transfer_actual:null,


    //нужен, чтобы выводить ошибку "Дата начала периода не может быть позднее, чем дата окончания"
    difference_days:false,

    //нужен, чтобы выводить ошибку "Дата начала периода не может быть позднее, чем дата окончания"
    delivery_date:false,

    //нужен, чтобы выводить ошибку "Дата начала периода не может быть позднее, чем дата окончания"
    delivery_date_fact:false,

    //чекбокс юридическое лицо
    check_entity:false,
    //чекбокс физическое лицо
    checbox_individual:true,
    checbox_individual_show:true,

    state_approval:[
      {
        name:'apartment_price',
        state:false
      },
      {
        name:'input_date_transfer',
        state:false
      },
      {
        name:'input_date_transfer_actual',
        state:false
      },
      {
        name:'difference_days',
        state:false
      },

      {
        name:'check_person',
        state:true
      },
      {
        name:'delivery_date',
        state:false
      },
      {
        name:'delivery_date_fact',
        state:false
      },






    ],

    // moratorium_dates:null,

    moratorium_dates:[
      //должно быть MM-DD-YEAR
      {
        begin:'29.03.2022',
        end:'30.06.2023',
        amount_days:0
      }
    ],

    lower_rate:[
      {
      begin:'25.02.2022',
      end:'31.12.2022'
    }
    ],
    // lower_rate:null,

    //разница дней сдачи объекта по договору и фактической сдачи
    days_of_delay:0,
    //сколько вычесть дней моратория
    array_minus_moratorium_days:[],
    minus_moratorium_days:0,

    day_show:0,

    calculate_result:0,

    rate_periods:[

    ],
    rate_periods_for_calc:[

    ],

    formula_for_show:[],
    show_final_block:false,






  },
  getters:{


    //*******
    STATE_APPROVAL_CHECK_NOT_WORK(state){ //*
      return state.state_approval[0].state
    },
    STATE_APPROVAL_INPUT_PER_YEAR(state){
      return state.state_approval[1].state
    },
    STATE_APPROVAL_INPUT_MONTHLY(state){
      return state.state_approval[2].state
    },
    STATE_APPROVAL_INPUT_DATE(state){
      return state.state_approval[3].state
    },

    //******

    //массив ключевых ставок
    ARRAY_KEY_RATE(state){
      return state.array_key_rate
    },
    // дата последнаго изменения ставки
    LAST_CHANGE_KEY(state){
      return state.last_change_key
    },



    STATE_DIFFERENCE_DAYS(state){
      return state.difference_days
    },
    DELIVERY_DATE(state){
      return state.delivery_date
    },
    DELIVERY_DATE_FACT(state){
      return state.delivery_date_fact
    },

    STATE_BUTTON_STATE(state){
      return state.state_approval
    },

    CALCULATE_RESULT(state){
      return state.calculate_result
    },

    APARTMENT_PRICE(state){
      return state.apartment_price
    },
    APARTMENT_PRICE_SHOW(state){
      return state.apartment_price_show
    },


    DAYS_OF_DELAY(state){
      return state.days_of_delay
    },

    MINUS_MORATORIUM_DAYS(state){
      return state.minus_moratorium_days
    },

    DAY_SHOW(state){
      return state.day_show
    },

    CHECBOX_INDIVIDUAL(state){
      return state.checbox_individual
    },
    CHECBOX_INDIVIDUAL_SHOW(state){
      return state.checbox_individual_show
    },


    CHECK_ENTITY(state){
      return state.check_entity
    },
    APPLICABLE_RATE(state){
      return state.applicable_rate
    },

    FIRST_PERIOD_DATA(state){
      return state.first_period_data
    },

    USUAL_FIRST_PERIOD_DATA(state){
      return state.usual_first_period_data
    },


    FORMULA_FOR_SHOW(state){
      return state.formula_for_show
    },
    SHOW_FINAL_BLOCK(state){
      return state.show_final_block
    },

    RATE_PERIOD(state){
      return state.rate_periods
    }






  },
  mutations:{

    //Праздики

    mutationHoliday(state,received_perem){
      state.holidays=received_perem
    },

    //подсчёт дней маратория нужно будет доработать, так как подсчёты только с одним отрезком маратория возможно удалить
    mutationMoratorium(state,received_perem){
      const oneDay = 1000 * 60 * 60 * 24;
      state.moratorium_dates=received_perem
      for(let i=0;i<state.moratorium_dates.length;i++){
        Vue.set(state.moratorium_dates[i],'begin',state.moratorium_dates[i].begin.substr(6, 4)+'-'+state.moratorium_dates[i].begin.substr(3, 2)+"-"+state.moratorium_dates[i].begin.substr(0, 2))
        Vue.set(state.moratorium_dates[i],'end',state.moratorium_dates[i].end.substr(6, 4)+'-'+state.moratorium_dates[i].end.substr(3, 2)+"-"+state.moratorium_dates[i].end.substr(0, 2))

        const date1 = new Date(state.moratorium_dates[i].begin);
        const date2 = new Date(state.moratorium_dates[i].end);

        //чтобы вбиваемая дата сдачи жилья по договору не была больше сегодняшней даты, тогда просрочки нет
        const present_dayTime = date2.getTime() - date1.getTime();
        let diffpresent_dayTime = Math.round(present_dayTime / oneDay);
        diffpresent_dayTime+=1
        Vue.set(state.moratorium_dates[i],'amount_days',diffpresent_dayTime)

      }

    },
    mutationLowerRate(state,received_perem){
      state.lower_rate=received_perem
      for(let i=0;i<state.lower_rate.length;i++){
        Vue.set(state.lower_rate[i],'begin',state.lower_rate[i].begin.substr(6, 4)+'-'+state.lower_rate[i].begin.substr(3, 2)+"-"+state.lower_rate[i].begin.substr(0, 2))
        Vue.set(state.lower_rate[i],'end',state.lower_rate[i].end.substr(6, 4)+'-'+state.lower_rate[i].end.substr(3, 2)+"-"+state.lower_rate[i].end.substr(0, 2))
      }

    },

    //Ключевая ставка + записываю дату начала последней ключевой ставки и саму последнюю ставку
    mutationKeyRates(state,received_perem){
      state.array_key_rate=received_perem
      Vue.set(state.last_change_key,'key',Object.values(received_perem[received_perem.length-1])[0])
      Vue.set(state.last_change_key,'date',Object.keys(received_perem[received_perem.length-1])[0])

      state.first_period_data = new Date(String(Object.keys(received_perem[0])[0]).substr(6, 4)+", "+String(Object.keys(received_perem[0])[0]).substr(3, 2)+", "+String(Object.keys(received_perem[0])[0]).substr(0, 2))

      state.usual_first_period_data = Object.keys(received_perem[0])[0];


    },
    //Ключевая ставка получается это нужно юудет убрать
    mutationKeyRate(state,received_perem){
      state.key_rate=(parseFloat(received_perem))/100
    },



    //Стоимость квартиры
    mutationApartmentPrice(state,received_perem){

      state.state_approval[0].state=received_perem[1]
      state.apartment_price=received_perem[0]
    },


    mutationChecboxEntity(state,received_perem){
      state.check_entity=received_perem
      state.checbox_individual=false


      if(state.checbox_individual==true || state.check_entity==true){
        state.state_approval[4].state=true
      }
      else {
        state.state_approval[4].state=false
      }

    },
    mutationChecboxIndividual(state,received_perem){
      state.checbox_individual=received_perem
      state.check_entity=false
      if(state.checbox_individual==true || state.check_entity==true){
        state.state_approval[4].state=true
      }
      else {
        state.state_approval[4].state=false
      }
    },


    mutationInputDateTransfer(state,received_perem){

      state.rate_periods=[]
      state.state_approval[1].state=received_perem[1]
      state.date_transfer=received_perem[0]
      let array_holiday=[]
      //подсчёт разницы дней
      if (state.date_transfer != null && state.date_transfer_actual != null) {
        const oneDay = 1000 * 60 * 60 * 24;
        let date1 = new Date(state.date_transfer);
        const date2 = new Date(state.date_transfer_actual);
        const date3 = new Date();

        const key_last_period = parseInt(Object.keys(state.holidays[state.holidays.length - 1])[0])
        let year = parseInt(state.date_transfer.substr(0, 4));


        if (year > key_last_period) {
          let period=[]
          period = state.holidays[state.holidays.length - 1][key_last_period]

          for(let i = 0; i < period.length; i++) {
            if(Array.isArray(period[i])===false) {
              period[i] = period[i].replace(`${key_last_period}`, `${year}`);
            }
            else if(Array.isArray(period[i])===true) {
              for(let k=0;k<period[i].length;k++){
                period[i][k] = period[i][k].replace(`${key_last_period}`, `${year}`);
              }

            }
          }
          const obj_new_year = {}
          Vue.set(obj_new_year,year,period)
          state.holidays.push(obj_new_year)

        }

        const date4 = new Date('2021-12-31');
        const new_year = date1.getTime() - date4.getTime();
        const diffnew_year = Math.round(new_year / oneDay);

        if(diffnew_year===0){
          date1 = new Date('2022-01-01');
          for (let i = 0;i<state.holidays.length;i++){
            if(state.holidays[i][parseInt(year+1)]!==undefined){
              // array_holiday = state.holidays[i][parseInt(year+1)]
              array_holiday = JSON.parse(JSON.stringify(state.holidays[i][parseInt(year+1)]));
            }
          }
        }
        else {
          for (let i = 0;i<state.holidays.length;i++){
            if(state.holidays[i][parseInt(year)]!==undefined){
              // array_holiday = state.holidays[i][parseInt(year)]
              array_holiday = JSON.parse(JSON.stringify(state.holidays[i][parseInt(year)]));
            }
          }
        }


        if(date1.getDay()==6){
          date1.setDate(date1.getDate()+2);
          // // date1 = new Date((date1.getMonth()+1)+','+date1.getDate()+','+date1.getFullYear()+',00:00:00');
          // console.log(date1)
        }
        else if(date1.getDay()==0){
          date1.setDate(date1.getDate()+1);
          // // date1 = new Date((date1.getMonth()+1)+','+date1.getDate()+','+date1.getFullYear()+',00:00:00');
        }


        if(array_holiday[0]!==undefined){
          for (let i = 0;i<array_holiday.length;i++){
            if(Array.isArray(array_holiday[i])===false) {
              array_holiday[i] = array_holiday[i].substr(6, 4) + '-' + array_holiday[i].substr(3, 2) + '-' + array_holiday[i].substr(0, 2)
            }
            else if(Array.isArray(array_holiday[i])===true){

              for (let j = 0;j<array_holiday[i].length;j++){
                array_holiday[i][j] = array_holiday[i][j].substr(6, 4) + '-' + array_holiday[i][j].substr(3, 2) + '-' + array_holiday[i][j].substr(0, 2)
              }
            }

          }

          for (let i = 0;i<array_holiday.length;i++){
            if(Array.isArray(array_holiday[i])===false) {
              let date_holiday = new Date(array_holiday[i]);
              const present_holiday = date_holiday.getTime() - date1.getTime();
              const diffpresent_holiday = Math.round(present_holiday / oneDay);
              if(diffpresent_holiday===0){
                date1.setDate(date1.getDate()+1);
                // console.log(date1);
                // // date1 = new Date((date1.getMonth()+1)+','+date1.getDate()+','+date1.getFullYear()+',00:00:00');
                // console.log(date1);
              }
            }
            if(Array.isArray(array_holiday[i])===true) {
              for (let j = 0;j<array_holiday[i].length;j++){
                let date_holiday = new Date(array_holiday[i][j]);
                const present_holiday = date_holiday.getTime() - date1.getTime();
                const diffpresent_holiday = Math.round(present_holiday / oneDay);

                if(diffpresent_holiday===0){
                  if(Array.isArray(array_holiday[i+1])===true&&array_holiday[i+1].length===1){
                    date1.setDate(date1.getDate()+((array_holiday[i].length-j))+2);
                    // // date1 = new Date((date1.getMonth()+1)+','+date1.getDate()+','+date1.getFullYear()+',00:00:00');
                  }
                  else {
                    date1.setDate(date1.getDate()+(array_holiday[i].length-j));
                    // // date1 = new Date((date1.getMonth()+1)+','+date1.getDate()+','+date1.getFullYear()+',00:00:00');
                  }
                }
              }
            }
          }
        }

        if(date1.getDay()==6){
          date1.setDate(date1.getDate()+2);
          // // date1 = new Date((date1.getMonth()+1)+','+date1.getDate()+','+date1.getFullYear()+',00:00:00');
        }
        else if(date1.getDay()==0){
          date1.setDate(date1.getDate()+1);
          // // date1 = new Date((date1.getMonth()+1)+','+date1.getDate()+','+date1.getFullYear()+',00:00:00');
        }
        // ----------------- МОРАТОРИЙ---------------------------------------------------

        //от фактической сдачи объекта
        const present_moratorium_end_3 = date2.getTime() - date1.getTime();
        const diffpresent_moratorium__end_3 = Math.round(present_moratorium_end_3 / oneDay);

        state.array_minus_moratorium_days = [];
        for (let i = 0; i < state.moratorium_dates.length; i++) {
          //день начала маратория нужно будет доработать, так отрезков мораториев может быть несколько, а я пока беру 1
          const date_mor_begin = new Date(state.moratorium_dates[i].begin);
          const date_mor_end = new Date(state.moratorium_dates[i].end);
          //от даты сдачи по ДДУ

          const present_moratorium_begin = date1.getTime() - date_mor_begin.getTime();
          const diffpresent_moratorium__begin = Math.round(present_moratorium_begin / oneDay);

          //от фактической сдачи объекта
          const present_moratorium_end = date2.getTime() - date_mor_end.getTime();
          const diffpresent_moratorium__end = Math.round(present_moratorium_end / oneDay);

          //от фактической сдачи объекта
          const present_moratorium_end_2 = date2.getTime() - date_mor_begin.getTime();
          const diffpresent_moratorium__end_2 = Math.round(present_moratorium_end_2 / oneDay);

          //от фактической сдачи объекта
          // const present_moratorium_end_3 = date1.getTime() - date_mor_end.getTime();
          // const diffpresent_moratorium__end_3 = Math.round(present_moratorium_end_3 / oneDay);





          if (diffpresent_moratorium__end_2 < 0) {
            state.array_minus_moratorium_days.push(0);
          }
          if (diffpresent_moratorium__begin === 0 && diffpresent_moratorium__end === 0) {
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days - 1);
          }
          if (diffpresent_moratorium__begin < 0 && diffpresent_moratorium__end > 0) {
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days);
          }
          if (diffpresent_moratorium__begin === 0 && diffpresent_moratorium__end > 0) {
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days - 1);
          }
          if (diffpresent_moratorium__begin < 0 && diffpresent_moratorium__end === 0) {
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days);
          }
          if (diffpresent_moratorium__begin > 0 && diffpresent_moratorium__end > 0) {
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days - (diffpresent_moratorium__begin + 1));
          }
          if (diffpresent_moratorium__begin > 0 && diffpresent_moratorium__end === 0) {
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days - diffpresent_moratorium__begin - 2);
          }
          if (diffpresent_moratorium__begin > 0 && diffpresent_moratorium__end < 0) {

            state.array_minus_moratorium_days.push(diffpresent_moratorium__end_3);
          }
          //Посмотреть
          if (diffpresent_moratorium__begin < 0 && diffpresent_moratorium__end < 0 && diffpresent_moratorium__end_2 > 0) {
            state.array_minus_moratorium_days.push(diffpresent_moratorium__end_2+1);
          }
          if (diffpresent_moratorium__begin === 0 && diffpresent_moratorium__end < 0 && diffpresent_moratorium__end_2 > 0) {
            state.array_minus_moratorium_days.push(diffpresent_moratorium__end_2);
          }
        }
        //считаю просрочку дата по договору сдачи - дата фактической сдачи, только наоборот

        const diffInTime = date2.getTime() - date1.getTime();
        const diffInDays = Math.round(diffInTime / oneDay);
        // state.days_of_delay = parseInt(diffInDays) - 1;
        state.days_of_delay = parseInt(diffInDays);

        if (diffInDays == 0) {
          state.days_of_delay = 0;
        } else if (diffInDays <= -1) {
          state.state_approval[3].state = false;
          state.difference_days = true;
          state.days_of_delay = 0;
        } else {
          state.state_approval[3].state = true;
          state.difference_days = false;
        }

        state.array_minus_moratorium_days = state.array_minus_moratorium_days.filter(function (item) {
          return item > 0;
        });

        state.minus_moratorium_days = state.array_minus_moratorium_days.reduce(function (acc, val) {
          return acc + val;
        }, 0);

        if (state.days_of_delay - state.minus_moratorium_days < 0) {
          // state.minus_moratorium_days=0
        }

        //----подсчитываю дни пониженной ставки в зависимости от вбиваемых дат

        const date_lower_begin = new Date(state.lower_rate[0].begin);
        const date_lower_end = new Date(state.lower_rate[0].end);

        const present_lower_contract_begin = date1.getTime() - date_lower_begin.getTime();
        const diffpresent_lower_contract_begin = Math.round(present_lower_contract_begin / oneDay);

        const present_lower_contract_end = date1.getTime() - date_lower_end.getTime();
        const diffpresent_lower_contract_end = Math.round(present_lower_contract_end / oneDay);

        const present_lower_fact_begin = date2.getTime() - date_lower_begin.getTime();
        const diffpresent_lower_fact_begin = Math.round(present_lower_fact_begin / oneDay);

        const present_lower_fact_end = date2.getTime() - date_lower_end.getTime();
        const diffpresent_lower_fact_end = Math.round(present_lower_fact_end / oneDay);

        //-------Подсчитываю, какую ставку использовать в зависимости от от дат

        let rate_entered_date = 1;
        let rate_period_date = null;

        let rate_entered_date_2 = 1;
        let rate_period_date_2 = null;

        //ДЛЯ ПОНИЖЕННОЙ СТАВКИ

        for (let t = 0; t < state.lower_rate.length; t++) {
          const present_day_key_fact_begin_lower_rate = date1.getTime() - new Date(state.lower_rate[t].begin).getTime();
          const diffpresent_day_key_fact_begin = Math.round(present_day_key_fact_begin_lower_rate / oneDay);

          const present_day_key_fact_end_lower_rate = date1.getTime() - new Date(state.lower_rate[t].end).getTime();
          const diffpresent_day_key_fact_end = Math.round(present_day_key_fact_end_lower_rate / oneDay);

          const present_day_key_fact_begin_lower_rate_2 = date2.getTime() - new Date(state.lower_rate[t].begin).getTime();
          const diffpresent_day_key_fact_begin_2 = Math.round(present_day_key_fact_begin_lower_rate_2 / oneDay);

          const present_day_key_fact_end_lower_rate_2 = date2.getTime() - new Date(state.lower_rate[t].end).getTime();
          const diffpresent_day_key_fact_end_2 = Math.round(present_day_key_fact_end_lower_rate_2 / oneDay);

          if (diffpresent_day_key_fact_begin >= 0 && diffpresent_day_key_fact_end < 0) {
            rate_period_date = state.lower_rate[t].rate;
          }

          if (diffpresent_day_key_fact_begin_2 >= 0 && diffpresent_day_key_fact_end_2 < 0) {
            rate_period_date_2 = state.lower_rate[t].rate;
          }
        }

        //ставка на день сдачи объекта
        for (let i = 0; i < state.array_key_rate.length; i++) {
          if (i === state.array_key_rate.length - 1) {

          }
          let data_begin = String(Object.keys(state.array_key_rate[i]))
            .substr(6, 4) + '-' + String(Object.keys(state.array_key_rate[i]))
            .substr(3, 2) + '-' + String(Object.keys(state.array_key_rate[i]))
            .substr(0, 2);
          const present_day_key_fact_begin = date1.getTime() - new Date(data_begin).getTime();
          const diffpresent_day_key_fact_begin = Math.round(present_day_key_fact_begin / oneDay);

          const present_day_key_fact_begin_2 = date2.getTime() - new Date(data_begin).getTime();
          const diffpresent_day_key_fact_begin_2 = Math.round(present_day_key_fact_begin_2 / oneDay);

          let data_end = null;
          let present_day_key_fact_end = null;
          let diffpresent_day_key_fact_end = null;

          let present_day_key_fact_end_2 = null;
          let diffpresent_day_key_fact_end_2 = null;

          if (i !== state.array_key_rate.length - 1) {
            data_end = String(Object.keys(state.array_key_rate[i + 1]))
              .substr(6, 4) + '-' + String(Object.keys(state.array_key_rate[i + 1]))
              .substr(3, 2) + '-' + String(Object.keys(state.array_key_rate[i + 1]))
              .substr(0, 2);

            present_day_key_fact_end = date1.getTime() - new Date(data_end).getTime();
            diffpresent_day_key_fact_end = Math.round(present_day_key_fact_end / oneDay);

            present_day_key_fact_end_2 = date2.getTime() - new Date(data_end).getTime();
            diffpresent_day_key_fact_end_2 = Math.round(present_day_key_fact_end / oneDay);
          }

          if (i === state.array_key_rate.length - 1) {
            const present_day_key_fact_end_5 = date2.getTime() - new Date(data_end).getTime();
            const diffpresent_day_key_fact_end_5 = Math.round(present_day_key_fact_end_5 / oneDay);
            if (diffpresent_day_key_fact_end_5 > 0) {
              data_end = state.date_transfer_actual;
            }
          }

          //ДЛЯ ПОНИЖЕННОЙ СТАВКИ
          if (present_day_key_fact_begin >= 0 && diffpresent_day_key_fact_end < 0) {

            rate_entered_date = parseFloat(Object.values(state.array_key_rate[i])[0]);
          }

          if (diffpresent_day_key_fact_begin_2 >= 0 && diffpresent_day_key_fact_end_2 < 0) {

            rate_entered_date_2 = parseFloat(Object.values(state.array_key_rate[i])[0]);
          }

          if (i === state.array_key_rate.length - 1 && present_day_key_fact_begin >= 0) {

            rate_entered_date = parseFloat(Object.values(state.array_key_rate[i])[0]);
          }

          if (i === state.array_key_rate.length - 1 && diffpresent_day_key_fact_begin_2 >= 0) {

            rate_entered_date_2 = parseFloat(Object.values(state.array_key_rate[i])[0]);
          }

        }



        //ДЛЯ ПОНИЖЕННОЙ СТАВКИ

        if (rate_period_date !== null && parseFloat(rate_entered_date) > parseFloat(rate_period_date)) {
          state.rate_day_delay = rate_period_date;
        } else if (rate_period_date !== null && parseFloat(rate_entered_date) < parseFloat(rate_period_date)) {
          state.rate_day_delay = parseFloat(rate_entered_date);
        }
        if (rate_period_date === null) {
          state.rate_day_delay = parseFloat(rate_entered_date);
        }

        if (rate_period_date_2 !== null && parseFloat(rate_entered_date_2) > parseFloat(rate_period_date_2)) {
          state.rate_day_fact_delivery = parseFloat(rate_period_date_2);
        } else if (rate_period_date_2 !== null && parseFloat(rate_entered_date_2) < parseFloat(rate_period_date_2)) {
          state.rate_day_fact_delivery = parseFloat(rate_entered_date_2);
        }
        if (rate_period_date_2 === null) {
          state.rate_day_fact_delivery = parseFloat(rate_entered_date_2);
        }

        //----------------------------------------------------------------------------------------

        //чтобы вбиваемая дата сдачи жилья по договору не была больше сегодняшней даты, тогда просрочки нет
        const present_dayTime = date3.getTime() - date1.getTime();
        const diffpresent_dayTime = Math.round(present_dayTime / oneDay);
        if (diffpresent_dayTime < 0) {
          state.delivery_date = true;
          state.state_approval[5].state = false;
        } else {
          state.delivery_date = false;
          state.state_approval[5].state = true;
        }

        //чтобы вбиваемая дата фактической сдачи жилья  не была больше сегодняшней даты
        const present_dayTimeFact = date3.getTime() - date2.getTime();
        const diffpresent_dayTimeFact = Math.round(present_dayTimeFact / oneDay);
        if (diffpresent_dayTimeFact < 0) {
          state.delivery_date_fact = true;
          state.state_approval[6].state = false;
        } else {
          state.delivery_date_fact = false;
          state.state_approval[6].state = true;
        }

      }
    },

    mutationInputDateActual(state, received_perem) {

      state.rate_periods = [];
      state.state_approval[2].state = received_perem[1];
      state.date_transfer_actual = received_perem[0];
      let array_holiday=[]

      // debugger
      //подсчёт разницы дней
      if (state.date_transfer != null && state.date_transfer_actual != null) {
        const oneDay = 1000 * 60 * 60 * 24;
        let date1 = new Date(state.date_transfer);
        const date2 = new Date(state.date_transfer_actual);
        const date3 = new Date();


        const key_last_period = parseInt(Object.keys(state.holidays[state.holidays.length - 1])[0])
        let year = parseInt(state.date_transfer.substr(0, 4));

        if (year > key_last_period) {
          let period=[]
          period = state.holidays[state.holidays.length - 1][key_last_period]

          for(let i = 0; i < period.length; i++) {
            if(Array.isArray(period[i])===false) {
              period[i] = period[i].replace(`${key_last_period}`, `${year}`);
            }
            else if(Array.isArray(period[i])===true) {
              for(let k=0;k<period[i].length;k++){
                period[i][k] = period[i][k].replace(`${key_last_period}`, `${year}`);
              }

            }
          }
          const obj_new_year = {}
          Vue.set(obj_new_year,year,period)
          state.holidays.push(obj_new_year)

        }


        const date4 = new Date('2021-12-31');
        const new_year = date1.getTime() - date4.getTime();
        const diffnew_year = Math.round(new_year / oneDay);

        if(diffnew_year===0){
          date1 = new Date('2022-01-01');
          for (let i = 0;i<state.holidays.length;i++){
            if(state.holidays[i][parseInt(year+1)]!==undefined){
              // array_holiday = state.holidays[i][parseInt(year+1)]
              array_holiday = JSON.parse(JSON.stringify(state.holidays[i][parseInt(year+1)]));
            }
          }
        }
        else {
          for (let i = 0;i<state.holidays.length;i++){
            if(state.holidays[i][parseInt(year)]!==undefined){
              // array_holiday = state.holidays[i][parseInt(year)]
              array_holiday = JSON.parse(JSON.stringify(state.holidays[i][parseInt(year)]));
            }
          }
        }


        if(date1.getDay()==6){
          date1.setDate(date1.getDate()+2);
          // date1 = new Date((date1.getMonth()+1)+','+date1.getDate()+','+date1.getFullYear()+',00:00:00');
        }
        else if(date1.getDay()==0){
          date1.setDate(date1.getDate()+1);
          // date1 = new Date((date1.getMonth()+1)+','+date1.getDate()+','+date1.getFullYear()+',00:00:00');
        }

        if(array_holiday[0]!==undefined){
            for (let i = 0;i<array_holiday.length;i++){
              if(Array.isArray(array_holiday[i])===false) {
                array_holiday[i] = array_holiday[i].substr(6, 4) + '-' + array_holiday[i].substr(3, 2) + '-' + array_holiday[i].substr(0, 2)
              }
              else if(Array.isArray(array_holiday[i])===true){

                for (let j = 0;j<array_holiday[i].length;j++){
                  array_holiday[i][j] = array_holiday[i][j].substr(6, 4) + '-' + array_holiday[i][j].substr(3, 2) + '-' + array_holiday[i][j].substr(0, 2)
                }
              }

            }

          for (let i = 0;i<array_holiday.length;i++){
            if(Array.isArray(array_holiday[i])===false) {
              let date_holiday = new Date(array_holiday[i]);
              const present_holiday = date_holiday.getTime() - date1.getTime();
              const diffpresent_holiday = Math.round(present_holiday / oneDay);
              if(diffpresent_holiday===0){
                date1.setDate(date1.getDate()+1);
                // date1 = new Date((date1.getMonth()+1)+','+date1.getDate()+','+date1.getFullYear()+',00:00:00');
              }
            }
            if(Array.isArray(array_holiday[i])===true) {

              for (let j = 0;j<array_holiday[i].length;j++){
                let date_holiday = new Date(array_holiday[i][j]);
                const present_holiday = date_holiday.getTime() - date1.getTime();
                const diffpresent_holiday = Math.round(present_holiday / oneDay);

                if(diffpresent_holiday===0){
                  if(Array.isArray(array_holiday[i+1])===true&&array_holiday[i+1].length===1){
                    date1.setDate(date1.getDate()+((array_holiday[i].length-j))+2);
                    // date1 = new Date((date1.getMonth()+1)+','+date1.getDate()+','+date1.getFullYear()+',00:00:00');
                  }
                  else {
                    date1.setDate(date1.getDate()+(array_holiday[i].length-j));
                    // date1 = new Date((date1.getMonth()+1)+','+date1.getDate()+','+date1.getFullYear()+',00:00:00');
                  }
                }
              }
            }
          }
        }


        if(date1.getDay()==6){
          date1.setDate(date1.getDate()+2);
          // date1 = new Date((date1.getMonth()+1)+','+date1.getDate()+','+date1.getFullYear()+',00:00:00');
        }
        else if(date1.getDay()==0){
          date1.setDate(date1.getDate()+1);
          // date1 = new Date((date1.getMonth()+1)+','+date1.getDate()+','+date1.getFullYear()+',00:00:00');
        }
        // ----------------- МОРАТОРИЙ---------------------------------------------------

        //от фактической сдачи объекта
        const present_moratorium_end_3 = date2.getTime() - date1.getTime();
        const diffpresent_moratorium__end_3 = Math.round(present_moratorium_end_3 / oneDay);

        state.array_minus_moratorium_days = [];
        for (let i = 0; i < state.moratorium_dates.length; i++) {
          //день начала маратория нужно будет доработать, так отрезков мораториев может быть несколько, а я пока беру 1
          const date_mor_begin = new Date(state.moratorium_dates[i].begin);
          const date_mor_end = new Date(state.moratorium_dates[i].end);
          //от даты сдачи по ДДУ

          const present_moratorium_begin = date1.getTime() - date_mor_begin.getTime();
          const diffpresent_moratorium__begin = Math.round(present_moratorium_begin / oneDay);

          //от фактической сдачи объекта
          const present_moratorium_end = date2.getTime() - date_mor_end.getTime();
          const diffpresent_moratorium__end = Math.round(present_moratorium_end / oneDay);

          //от фактической сдачи объекта
          const present_moratorium_end_2 = date2.getTime() - date_mor_begin.getTime();
          const diffpresent_moratorium__end_2 = Math.round(present_moratorium_end_2 / oneDay);

          //от фактической сдачи объекта
          // const present_moratorium_end_3 = date1.getTime() - date_mor_end.getTime();
          // const diffpresent_moratorium__end_3 = Math.round(present_moratorium_end_3 / oneDay);





          if (diffpresent_moratorium__end_2 < 0) {
            state.array_minus_moratorium_days.push(0);
          }
          if (diffpresent_moratorium__begin === 0 && diffpresent_moratorium__end === 0) {
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days - 1);
          }
          if (diffpresent_moratorium__begin < 0 && diffpresent_moratorium__end > 0) {
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days);
          }
          if (diffpresent_moratorium__begin === 0 && diffpresent_moratorium__end > 0) {
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days - 1);
          }
          if (diffpresent_moratorium__begin < 0 && diffpresent_moratorium__end === 0) {
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days);
          }
          if (diffpresent_moratorium__begin > 0 && diffpresent_moratorium__end > 0) {
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days - (diffpresent_moratorium__begin + 1));
          }
          if (diffpresent_moratorium__begin > 0 && diffpresent_moratorium__end === 0) {
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days - diffpresent_moratorium__begin - 2);
          }
          if (diffpresent_moratorium__begin > 0 && diffpresent_moratorium__end < 0) {

            state.array_minus_moratorium_days.push(diffpresent_moratorium__end_3);
          }
          //Посмотреть
          if (diffpresent_moratorium__begin < 0 && diffpresent_moratorium__end < 0 && diffpresent_moratorium__end_2 > 0) {
            state.array_minus_moratorium_days.push(diffpresent_moratorium__end_2+1);
          }
          if (diffpresent_moratorium__begin === 0 && diffpresent_moratorium__end < 0 && diffpresent_moratorium__end_2 > 0) {
            state.array_minus_moratorium_days.push(diffpresent_moratorium__end_2);
          }
        }
        //считаю просрочку дата по договору сдачи - дата фактической сдачи, только наоборот

        const diffInTime = date2.getTime() - date1.getTime();
        const diffInDays = Math.round(diffInTime / oneDay);
        // state.days_of_delay = parseInt(diffInDays) - 1;
        state.days_of_delay = parseInt(diffInDays);

        if (diffInDays == 0) {
          state.days_of_delay = 0;
        } else if (diffInDays <= -1) {
          state.state_approval[3].state = false;
          state.difference_days = true;
          state.days_of_delay = 0;
        } else {
          state.state_approval[3].state = true;
          state.difference_days = false;
        }

        state.array_minus_moratorium_days = state.array_minus_moratorium_days.filter(function (item) {
          return item > 0;
        });

        state.minus_moratorium_days = state.array_minus_moratorium_days.reduce(function (acc, val) {
          return acc + val;
        }, 0);

        if (state.days_of_delay - state.minus_moratorium_days < 0) {
          // state.minus_moratorium_days=0
        }

        //----подсчитываю дни пониженной ставки в зависимости от вбиваемых дат

        const date_lower_begin = new Date(state.lower_rate[0].begin);
        const date_lower_end = new Date(state.lower_rate[0].end);

        const present_lower_contract_begin = date1.getTime() - date_lower_begin.getTime();
        const diffpresent_lower_contract_begin = Math.round(present_lower_contract_begin / oneDay);

        const present_lower_contract_end = date1.getTime() - date_lower_end.getTime();
        const diffpresent_lower_contract_end = Math.round(present_lower_contract_end / oneDay);

        const present_lower_fact_begin = date2.getTime() - date_lower_begin.getTime();
        const diffpresent_lower_fact_begin = Math.round(present_lower_fact_begin / oneDay);

        const present_lower_fact_end = date2.getTime() - date_lower_end.getTime();
        const diffpresent_lower_fact_end = Math.round(present_lower_fact_end / oneDay);

        //-------Подсчитываю, какую ставку использовать в зависимости от от дат

        let rate_entered_date = 1;
        let rate_period_date = null;

        let rate_entered_date_2 = 1;
        let rate_period_date_2 = null;

        //ДЛЯ ПОНИЖЕННОЙ СТАВКИ

        for (let t = 0; t < state.lower_rate.length; t++) {
          const present_day_key_fact_begin_lower_rate = date1.getTime() - new Date(state.lower_rate[t].begin).getTime();
          const diffpresent_day_key_fact_begin = Math.round(present_day_key_fact_begin_lower_rate / oneDay);

          const present_day_key_fact_end_lower_rate = date1.getTime() - new Date(state.lower_rate[t].end).getTime();
          const diffpresent_day_key_fact_end = Math.round(present_day_key_fact_end_lower_rate / oneDay);

          const present_day_key_fact_begin_lower_rate_2 = date2.getTime() - new Date(state.lower_rate[t].begin).getTime();
          const diffpresent_day_key_fact_begin_2 = Math.round(present_day_key_fact_begin_lower_rate_2 / oneDay);

          const present_day_key_fact_end_lower_rate_2 = date2.getTime() - new Date(state.lower_rate[t].end).getTime();
          const diffpresent_day_key_fact_end_2 = Math.round(present_day_key_fact_end_lower_rate_2 / oneDay);

          if (diffpresent_day_key_fact_begin >= 0 && diffpresent_day_key_fact_end < 0) {
            rate_period_date = state.lower_rate[t].rate;
          }

          if (diffpresent_day_key_fact_begin_2 >= 0 && diffpresent_day_key_fact_end_2 < 0) {
            rate_period_date_2 = state.lower_rate[t].rate;
          }
        }

        //ставка на день сдачи объекта
        for (let i = 0; i < state.array_key_rate.length; i++) {
          if (i === state.array_key_rate.length - 1) {

          }
          let data_begin = String(Object.keys(state.array_key_rate[i]))
            .substr(6, 4) + '-' + String(Object.keys(state.array_key_rate[i]))
            .substr(3, 2) + '-' + String(Object.keys(state.array_key_rate[i]))
            .substr(0, 2);
          const present_day_key_fact_begin = date1.getTime() - new Date(data_begin).getTime();
          const diffpresent_day_key_fact_begin = Math.round(present_day_key_fact_begin / oneDay);

          const present_day_key_fact_begin_2 = date2.getTime() - new Date(data_begin).getTime();
          const diffpresent_day_key_fact_begin_2 = Math.round(present_day_key_fact_begin_2 / oneDay);

          let data_end = null;
          let present_day_key_fact_end = null;
          let diffpresent_day_key_fact_end = null;

          let present_day_key_fact_end_2 = null;
          let diffpresent_day_key_fact_end_2 = null;

          if (i !== state.array_key_rate.length - 1) {
            data_end = String(Object.keys(state.array_key_rate[i + 1]))
              .substr(6, 4) + '-' + String(Object.keys(state.array_key_rate[i + 1]))
              .substr(3, 2) + '-' + String(Object.keys(state.array_key_rate[i + 1]))
              .substr(0, 2);

            present_day_key_fact_end = date1.getTime() - new Date(data_end).getTime();
            diffpresent_day_key_fact_end = Math.round(present_day_key_fact_end / oneDay);

            present_day_key_fact_end_2 = date2.getTime() - new Date(data_end).getTime();
            diffpresent_day_key_fact_end_2 = Math.round(present_day_key_fact_end / oneDay);
          }

          if (i === state.array_key_rate.length - 1) {
            const present_day_key_fact_end_5 = date2.getTime() - new Date(data_end).getTime();
            const diffpresent_day_key_fact_end_5 = Math.round(present_day_key_fact_end_5 / oneDay);
            if (diffpresent_day_key_fact_end_5 > 0) {
              data_end = state.date_transfer_actual;
            }
          }

          //ДЛЯ ПОНИЖЕННОЙ СТАВКИ
          if (present_day_key_fact_begin >= 0 && diffpresent_day_key_fact_end < 0) {

            rate_entered_date = parseFloat(Object.values(state.array_key_rate[i])[0]);
          }

          if (diffpresent_day_key_fact_begin_2 >= 0 && diffpresent_day_key_fact_end_2 < 0) {

            rate_entered_date_2 = parseFloat(Object.values(state.array_key_rate[i])[0]);
          }

          if (i === state.array_key_rate.length - 1 && present_day_key_fact_begin >= 0) {

            rate_entered_date = parseFloat(Object.values(state.array_key_rate[i])[0]);
          }

          if (i === state.array_key_rate.length - 1 && diffpresent_day_key_fact_begin_2 >= 0) {

            rate_entered_date_2 = parseFloat(Object.values(state.array_key_rate[i])[0]);
          }

        }



        //ДЛЯ ПОНИЖЕННОЙ СТАВКИ

        if (rate_period_date !== null && parseFloat(rate_entered_date) > parseFloat(rate_period_date)) {
          state.rate_day_delay = rate_period_date;
        } else if (rate_period_date !== null && parseFloat(rate_entered_date) < parseFloat(rate_period_date)) {
          state.rate_day_delay = parseFloat(rate_entered_date);
        }
        if (rate_period_date === null) {
          state.rate_day_delay = parseFloat(rate_entered_date);
        }

        if (rate_period_date_2 !== null && parseFloat(rate_entered_date_2) > parseFloat(rate_period_date_2)) {
          state.rate_day_fact_delivery = parseFloat(rate_period_date_2);
        } else if (rate_period_date_2 !== null && parseFloat(rate_entered_date_2) < parseFloat(rate_period_date_2)) {
          state.rate_day_fact_delivery = parseFloat(rate_entered_date_2);
        }
        if (rate_period_date_2 === null) {
          state.rate_day_fact_delivery = parseFloat(rate_entered_date_2);
        }

        //----------------------------------------------------------------------------------------

        //чтобы вбиваемая дата сдачи жилья по договору не была больше сегодняшней даты, тогда просрочки нет
        const present_dayTime = date3.getTime() - date1.getTime();
        const diffpresent_dayTime = Math.round(present_dayTime / oneDay);
        if (diffpresent_dayTime < 0) {
          state.delivery_date = true;
          state.state_approval[5].state = false;
        } else {
          state.delivery_date = false;
          state.state_approval[5].state = true;
        }

        //чтобы вбиваемая дата фактической сдачи жилья  не была больше сегодняшней даты
        const present_dayTimeFact = date3.getTime() - date2.getTime();
        const diffpresent_dayTimeFact = Math.round(present_dayTimeFact / oneDay);
        if (diffpresent_dayTimeFact < 0) {
          state.delivery_date_fact = true;
          state.state_approval[6].state = false;
        } else {
          state.delivery_date_fact = false;
          state.state_approval[6].state = true;
        }

      }

    },

    //Итоговый результат тут будет переделка, так как в расчётах участвует не просто ставка на сегодняшний день, а конкретная ставка
    mutationCalculate(state){
      // console.log(state.minus_moratorium_days);
      if (state.checbox_individual === true) {
        state.calculate_result = (((state.apartment_price * (state.rate_day_fact_delivery / 100)) / 150) * (state.days_of_delay - state.minus_moratorium_days)).toFixed(2);
        state.applicable_rate = state.rate_day_fact_delivery;
        state.apartment_price_show = state.apartment_price;
        state.checbox_individual_show = state.checbox_individual;
        state.day_show = state.days_of_delay - state.minus_moratorium_days;
      }

      if (state.check_entity === true) {
        state.calculate_result = (((state.apartment_price * (state.rate_day_fact_delivery / 100)) / 300) * (state.days_of_delay - state.minus_moratorium_days)).toFixed(2);
        state.applicable_rate = state.rate_day_fact_delivery;
        state.apartment_price_show = state.apartment_price;
        state.checbox_individual_show = state.checbox_individual;
        state.day_show = state.days_of_delay - state.minus_moratorium_days;
      }


    },


    //*******
    mutationChecboxNotWork(state,received_perem){
      state.state_approval[3].state=received_perem

    },

  },
  actions:{
    //Получаю праздники
    //Получаю ключевые ставкм
    ActionHolidays({commit},param){

      // commit('mutationHoliday',param)
    },


    //Получаю ключевые ставкм
    ActionKeyRates({commit},param){
      commit('mutationKeyRates',param)
    },

    //  моратории

    ActionMoratorium({commit},param){
      commit('mutationMoratorium',param)
    },
    ActionLowerRate({commit},param){
      commit('mutationLowerRate',param)
    },


    // ActionKeyRate({commit},param){
    //   commit('mutationKeyRate',param)
    // },
    ActionApartmentPrice({commit},param){
      commit('mutationApartmentPrice',param)
      commit('mutationCalculate')
    },


    //*********************
    //Проверка на заполенность и корректность всех необъодимых полей
    ActionChecboxNotWork({commit},param){
      commit('mutationChecboxNotWork',param)
    },



    ActionInputDateTransfer({commit},param){
      commit('mutationInputDateTransfer',param)
      commit('mutationCalculate')
    },
    ActionInputDateActual({commit},param){
      commit('mutationInputDateActual',param)
      commit('mutationCalculate')
    },

    ActionChecboxEntity({commit},param){
      commit('mutationChecboxEntity',param)
      commit('mutationCalculate')
    },
    ActionChecboxIndividual({commit},param){
      commit('mutationChecboxIndividual',param)
      commit('mutationCalculate')
    },
    ActionCalculate({commit}){
      commit('mutationCalculate')
    },













  },
})
</script>
