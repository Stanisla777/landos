<template lang="pug">
  .property-calculator__row
    p.property-calculator__sub-title Кем вы являетесь?
    .ddu__swiper-type-person
      .swiper-container.swiper-container.js--type-person
        .swiper-wrapper
          .swiper-slide
            template
              component-check-box-individual
          .swiper-slide
            template
              component-check-box-entity


</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import ToolTip from '../components/v-component-tooltip.vue';
import Storage from '../development-tools/state.vue';
import ComponentCheckBoxIndividual from './v-component-checkbox-individual.vue';
import ComponentCheckBoxEntity from './v-component-checkbox-entity.vue';
import Swiper, { Navigation, Pagination } from 'swiper';
Swiper.use([Navigation, Pagination]);
let mySwiper;

export default {
  name: 'v-checkbox',
  data(){
    return {

    }

  },
  methods:{
    initSliderStoriesButton() {
      mySwiper = new Swiper('.js--type-person', {
        loop: false,
        simulateTouch: true,
        allowTouchMove: false,
        centeredSlides: false,
        slidesPerView:2,
        slidesPerGroup:1,
        spaceBetween: 12,


        navigation: false,
        pagination: false,
        breakpoints: {
          0: {
            slidesPerView:2,
            allowTouchMove: true,
            centeredSlides: true,
          },
          620: {
            slidesPerView:2,
            allowTouchMove: false,
            centeredSlides: false,
          }
        },
      });
      mySwiper.on('slideChange', () => {


      });
    },



  },
  mounted(){
    this.initSliderStoriesButton()

  },
  computed:{},
  watch:{
  },
  components:{
    ToolTip,
    ComponentCheckBoxIndividual,
    ComponentCheckBoxEntity,
  }
};
</script>
<style scoped>
</style>
