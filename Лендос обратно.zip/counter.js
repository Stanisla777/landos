/* eslint-disable */


/*// Проверка видимости блока
function isBlockVisible(block, offset = 60) {
  const rect = block.getBoundingClientRect();
  const viewportHeight = window.innerHeight || document.documentElement.clientHeight;
  return (
    rect.top >= 0 &&
    // rect.bottom <= viewportHeight - offset
    rect.bottom <= viewportHeight + offset
  );
}

//когда меняется окно
function initResize() {
  const countBlocks = document.querySelectorAll('.js--count-people');
  // init(countBlocks);
}

// Обработчик скролла
function handleScroll() {
  let isTrigger = false
  const countBlocks = document.querySelectorAll('.js--count-people');
  countBlocks.forEach(block => {
    if (isBlockVisible(block) && !isTrigger) {
      init(countBlocks);
      isTrigger=true
      window.removeEventListener('scroll',handleScroll)
    }
  });
}


// Функция для создания HTML-структуры цифрового колеса
function createDigitWheel(digit) {
  const container = document.createElement('div');
  container.className = 'digit-container';

  const strip = document.createElement('div');
  strip.className = 'digit-strip';

  // Создаем 20 цифр (два полных набора)
  for (let i = 0; i < 20; i++) {
    const span = document.createElement('div');
    span.textContent = i % 10;
    strip.appendChild(span);
  }

  container.appendChild(strip);
  return {
    container,
    strip,
    digit
  };
}

// Функция для замены цифр на анимированные колеса
function replaceDigitsWithWheels(p, dataCount) {
  console.log('p');
  p.classList.remove('opacity-0')
  const originalContent = p.textContent;
  const cleanData = dataCount.replace(/\s/g, '');
  let digitIndex = 0;

  p.innerHTML = '';

  for (let i = 0; i < originalContent.length; i++) {
    if (originalContent[i] === ' ') {
      const space = document.createElement('div');
      space.className = 'space';
      p.appendChild(space);
    } else {
      const digitValue = parseInt(cleanData[digitIndex]);
      const wheel = createDigitWheel(digitValue);
      p.appendChild(wheel.container);
      digitIndex++;
    }
  }

  return p.querySelectorAll('.digit-strip');
}

// Функция для запуска анимации
function animateDigitWheel(strip, digit) {

  console.log('strip');
  console.log(strip);

  console.log('digit');
  console.log(digit);

  const steps = 10 + digit;
  const height = strip.firstElementChild.offsetHeight;
  const randomOffset = Math.random() * 0.3 + 0.9; // Случайная скорость

  // Сбрасываем трансформацию
  strip.style.transition = 'none';
  strip.style.transform = 'translateY(0)';

  // Запускаем анимацию в следующем фрейме
  requestAnimationFrame(() => {
    strip.style.transition = `transform ${2 * randomOffset}s cubic-bezier(0.34, 1.56, 0.64, 1)`;
    strip.style.transform = `translateY(-${steps * height}px)`;
  });
}

// Основная функция инициализации
function init(countBlocks) {
  // const countBlocks = document.querySelectorAll('.js--count-people');
  countBlocks.forEach(block => {
    const dataCount = block.dataset.count;
    const p = block.querySelector('.js--at-count-people-text');

    // Заменяем цифры на анимированные элементы
    const digitStrips = replaceDigitsWithWheels(p, dataCount);

    // Запускаем анимацию с небольшой задержкой
    setTimeout(() => {
      const cleanData = dataCount.replace(/\s/g, '');
      digitStrips.forEach((strip, index) => {
        const digit = parseInt(cleanData[index]);
        animateDigitWheel(strip, digit);
      });
    }, 300);
  });
}

// Инициализируем анимацию


export default function counterThing(el) {


  window.addEventListener('scroll', handleScroll);
  window.addEventListener('resize', initResize);
  handleScroll(); // Проверить при загрузке






}*/

/* eslint-disable */

function isBlockVisible(block, offset = 60) {
    const rect = block.getBoundingClientRect();
    const viewportHeight = window.innerHeight || document.documentElement.clientHeight;
    return rect.bottom <= viewportHeight + offset;
}

function initResize() {
    const countBlocks = document.querySelectorAll('.js--count-people');
}

function handleScroll() {
    let isTrigger = false;
    const countBlocks = document.querySelectorAll('.js--count-people');
    countBlocks.forEach(block => {
        if (isBlockVisible(block) && !isTrigger) {
            init(countBlocks);
            isTrigger = true;
            window.removeEventListener('scroll', handleScroll);
        }
    });
}

function createDigitWheel(digit) {
    const container = document.createElement('div');
    container.className = 'digit-container';

    const strip = document.createElement('div');
    strip.className = 'digit-strip';

    for (let i = 0; i < 20; i++) {
        const span = document.createElement('div');
        span.textContent = i % 10;
        strip.appendChild(span);
    }

    container.appendChild(strip);
    return {
        container,
        strip,
        digit
    };
}

function replaceDigitsWithWheels(p, dataCount) {
    p.classList.remove('opacity-0');
    const originalContent = p.textContent;
    const cleanData = dataCount.replace(/\s/g, '');
    let digitIndex = 0;

    p.innerHTML = '';

    for (let i = 0; i < originalContent.length; i++) {
        if (originalContent[i] === ' ') {
            const space = document.createElement('div');
            space.className = 'space';
            p.appendChild(space);
        } else {
            const digitValue = parseInt(cleanData[digitIndex]);
            const wheel = createDigitWheel(digitValue);
            p.appendChild(wheel.container);
            digitIndex++;
        }
    }

    return p.querySelectorAll('.digit-strip');
}

function animateDigitWheel(strip, digit) {
    return new Promise(resolve => {
        const steps = 10 + digit;
        const height = strip.firstElementChild.offsetHeight;
        const randomOffset = Math.random() * 0.3 + 0.9;

        strip.style.transition = 'none';
        strip.style.transform = 'translateY(0)';

        requestAnimationFrame(() => {
            strip.style.transition = `transform ${2 * randomOffset}s cubic-bezier(0.34, 1.56, 0.64, 1)`;
            strip.style.transform = `translateY(-${steps * height}px)`;

            const onTransitionEnd = (e) => {
                if (e.propertyName === 'transform') {
                    strip.removeEventListener('transitionend', onTransitionEnd);
                    resolve();
                }
            };

            strip.addEventListener('transitionend', onTransitionEnd);
        });
    });
}

function showFinalDigits(p, dataCount) {
    const finalDigits = document.createElement('div');
    finalDigits.className = 'final-digit';
    finalDigits.textContent = dataCount;
    p.appendChild(finalDigits);

    requestAnimationFrame(() => {
        setTimeout(()=>{
          finalDigits.style.opacity = '1';
        })
        //finalDigits.style.opacity = '1';
        
        const oldChildren = Array.from(p.children).filter(child => 
            !child.classList.contains('final-digit')
        );
        
        oldChildren.forEach(child => {
            child.style.transition = 'opacity 0.2s ease';
            child.style.opacity = '0';
        });

        setTimeout(() => {
            oldChildren.forEach(child => p.removeChild(child));
        }, 500);
    });
}

function init(countBlocks) {
    countBlocks.forEach(block => {
        const dataCount = block.dataset.count;
        const p = block.querySelector('.js--at-count-people-text');

        const digitStrips = replaceDigitsWithWheels(p, dataCount);

        setTimeout(() => {
            const cleanData = dataCount.replace(/\s/g, '');
            const promises = [];

            digitStrips.forEach((strip, index) => {
                const digit = parseInt(cleanData[index]);
                promises.push(animateDigitWheel(strip, digit));
            });

            Promise.all(promises).then(() => {
                showFinalDigits(p, dataCount);
            });
        }, 300);
    });
}

export default function counterThing(el) {
    window.addEventListener('scroll', handleScroll);
    window.addEventListener('resize', initResize);
    handleScroll();
}