<template lang="pug">
  .calc-tax-deduc-new__block.mobile-padding.mor-rep-calculators__block-schedule.mobile.grey.js--container-block(
          v-show="shedule.length>0"
        )
      h3.calc-tax-deduc-new__block-title.big График платежей

      .mor-rep-calculators__shedule-calendar
        component-calendar-mobile-shedule(
          @sendDateMobile="receivedDateMobile"
        )

      .mor-rep-calculators__cal-mobile-item-container
        .calc-tax-deduc-new__area.mor-rep-calculators__shedule-calendar-mobile-container(ref="mobileShedule")
          .mor-rep-calculators__shedule-calendar-mobile-item.calc-tax-deduc-new__area.js-accordion-parent-calc(
            v-for='(item,index) in shedule' :key="index"
            :data-date="`${item.year}-${item.month}`"
            :ref="`scheduleItem-${item.year}-${item.month}`"
          )
            .mor-rep-calculators__shedule-calendar-mobile-wr-row(@click="dropdownAreaMobileShedule")
              .mor-rep-calculators__shedule-calendar-mobile-row
                .mor-rep-calculators__calendar-mobile-item-col
                  .mor-rep-calculators__shedule-calendar-mobile-month {{item.nameMonth}}, {{item.year}}
                .mor-rep-calculators__calendar-mobile-item-col.row
                  .mor-rep-calculators__shedule-calendar-mobile-value {{item.payment | format_decimal}}  ₽
                  .mor-rep-calculators__shedule-calendar-mobile-icon

            .calc-tax-deduc-new__wr-function-block.active(@transitionend="handleTransitionEnd")
              .calc-tax-deduc-new__acc-wr
                .mor-rep-calculators__shedule-calendar-mobile
                  .mor-rep-calculators__shedule-calendar-mobile-row
                    .mor-rep-calculators__calendar-mobile-item-col
                      p.mor-rep-calculators__shedule-calendar-mobile-key Задолженность
                      .mor-rep-calculators__shedule-calendar-mobile-value {{item.remainingBalance | format_decimal}} ₽
                    .mor-rep-calculators__calendar-mobile-item-col
                      p.mor-rep-calculators__shedule-calendar-mobile-key Сумма платежа
                      .mor-rep-calculators__shedule-calendar-mobile-value {{item.payment | format_decimal}}  ₽

                  .mor-rep-calculators__shedule-calendar-mobile-row.margin
                    .mor-rep-calculators__calendar-mobile-item-col
                      p.mor-rep-calculators__shedule-calendar-mobile-key.col-1 Погашение процентов
                      .mor-rep-calculators__shedule-calendar-mobile-value {{item.interest | format_decimal}} ₽
                    .mor-rep-calculators__calendar-mobile-item-col
                      p.mor-rep-calculators__shedule-calendar-mobile-key.col-2 Погашение основного долга
                      .mor-rep-calculators__shedule-calendar-mobile-value {{item.principal | format_decimal}} ₽

      .mor-rep-calculators__shedule-footer-share
        .mor-rep-calculators__shedule-footer-share-item.mor-rep-calculators__parent-tooltip-mobile.js--tooltip-parent(v-if="can_share===1&&answerLink!==null")
          .btn_s.transparent_black_border.hover-green.btn-icon-share(@click="openTooltipMobile") Отправить расчёт
          div
            .select__background.modal-special-background(@click="closeTooltipMobile")
            .select-list__selection-window.mor-rep-calculators__selection-window-share.modal-special-styles.js--openlist-body
              .select-list__head
                p Отправить расчёт
                .select-list__head-close(@click="closeTooltipMobile")
                  svg(width='10', height='10', viewbox='0 0 10 10', fill='none', xmlns='http://www.w3.org/2000/svg')
                    path(fill-rule='evenodd', clip-rule='evenodd', d='M0.209209 0.209209C0.488155 -0.0697365 0.940416 -0.0697365 1.21936 0.209209L5 3.98985L8.78064 0.209209C9.05958 -0.0697365 9.51184 -0.0697365 9.79079 0.209209C10.0697 0.488155 10.0697 0.940416 9.79079 1.21936L6.01015 5L9.79079 8.78064C10.0697 9.05958 10.0697 9.51184 9.79079 9.79079C9.51184 10.0697 9.05958 10.0697 8.78064 9.79079L5 6.01015L1.21936 9.79079C0.940416 10.0697 0.488155 10.0697 0.209209 9.79079C-0.0697365 9.51184 -0.0697365 9.05958 0.209209 8.78064L3.98985 5L0.209209 1.21936C-0.0697365 0.940416 -0.0697365 0.488155 0.209209 0.209209Z', fill='#252628')

              template
                component-payment-list-soc
      .mor-rep-calculators__input-error.mor-rep-calculators__after-sand-error(v-show="description_after_sand!==null") {{description_after_sand}}
</template>

<script>
import Vue from 'vue';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import numberFormatting from '../mixin/numberFormatting.js';
import ComponentCalendarMobileShedule from '../components/v-2-component-calendar-mobile-shedule.vue';
import ComponentPaymentListSoc from '../components/v-component-payment-list-soc.vue';

export default {
  name: 'v-component-payment-list-mobile',
  mixins: [numberFormatting],
  props:[],
  data(){
    return {
      description_after_sand: null,
      description_after_sand_mail: null,
      isAnimatingMobile: false,
    }
  },
  methods:{
    async receivedDateMobile([year, month]) {
      const dateString = `${year}-${month}`;
      // Добавляем небольшую задержку для гарантированного обновления DOM
      await this.$nextTick();
      
      try {
        const container = this.$refs.mobileShedule;
        const element = container.querySelector(`[data-date="${dateString}"]`);
        
        if (!element || !container) return;

        // Добавляем дополнительную задержку для iOS
        if (/iPad|iPhone|iPod/.test(navigator.userAgent)) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
        
        this.scrollToElementSmart(container, element);
      } catch (e) {
        console.error('Error in scroll:', e);
      }
    },

    async scrollToElementSmart(container, targetElement) {
      try {
        // Добавляем задержку для гарантированного обновления layout
        await new Promise(resolve => requestAnimationFrame(resolve));
        
        const containerRect = container.getBoundingClientRect();
        const targetRect = targetElement.getBoundingClientRect();
        const pageScrollTop = window.scrollY || window.pageYOffset;

        // Проверяем, что измерения прошли корректно
        if (!containerRect || !targetRect) {
          console.warn('Could not measure element positions');
          return;
        }

        const targetTopInContainer = targetRect.top - containerRect.top + container.scrollTop;
        const maxContainerScroll = container.scrollHeight - container.clientHeight;

        // Желаемая позиция скролла контейнера, чтобы элемент был вверху
        const desiredContainerScroll = Math.max(0, Math.min(targetTopInContainer, maxContainerScroll));

        // Проверка: может ли контейнер проскроллиться?
        const canScrollContainer = container.scrollHeight > container.clientHeight;

        if (canScrollContainer) {
          // Скроллим контейнер с проверкой успешности
          await this.smoothScrollTo(container, 'scrollTop', desiredContainerScroll, 300, (val) => {
            container.scrollTop = val;
          });

          // После анимации проверяем, попал ли элемент в нужную позицию на экране
          await new Promise(resolve => setTimeout(resolve, 100));
          
          const finalTargetRect = targetElement.getBoundingClientRect();
          
          // Если элемент выходит за пределы экрана — подкручиваем страницу
          if (finalTargetRect.top < 0 || finalTargetRect.bottom > window.innerHeight) {
            const newPageScrollTop = pageScrollTop + finalTargetRect.top - 10; // 10 — небольшой отступ сверху
            await this.smoothScrollTo(window, 'scrollY', newPageScrollTop, 300, (val) => {
              window.scrollTo(0, val);
            });
          }
        } else {
          // Контейнер не скроллится — скроллим страницу к самому элементу (вверх экрана)
          const targetPageScrollTop = pageScrollTop + targetRect.top - 10; // 10 — небольшой отступ сверху
          await this.smoothScrollTo(window, 'scrollY', targetPageScrollTop, 300, (val) => {
            window.scrollTo(0, val);
          });
        }
      } catch (e) {
        console.error('Error in smart scroll:', e);
      }
    },

    smoothScrollTo(element, property, target, duration, setValue) {
      return new Promise((resolve) => {
        const start = element === window ? (window.scrollY || window.pageYOffset) : element[property];
        const change = target - start;
        let startTime = null;

        const animateScroll = (currentTime) => {
          if (startTime === null) startTime = currentTime;
          const timeElapsed = currentTime - startTime;
          const progress = Math.min(timeElapsed / duration, 1);

          // easeInOutCubic
          const ease = progress < 0.5
            ? 4 * progress * progress * progress
            : (progress - 1) * (2 * progress - 2) * (2 * progress - 2) + 1;

          const val = start + change * ease;
          setValue(val);

          if (timeElapsed < duration) {
            requestAnimationFrame(animateScroll);
          } else {
            resolve();
          }
        };

        requestAnimationFrame(animateScroll);
      });
    },

    dropdownAreaMobileShedule(e){
      const target = e.target;
      const element = e.currentTarget;
      const parent = element.closest('.js-accordion-parent-calc');
      
      if (parent) {
        if (this.isAnimatingMobile) return;
        this.isAnimatingMobile = true;

        if(parent.classList.contains('active')){
          parent.classList.remove('active-overflow');
          setTimeout(() => {
            parent.classList.remove('active');
          }, 300);
        } else {
          parent.classList.add('active');
          setTimeout(() => {
            parent.classList.add('active-overflow');
          }, 500);
        }
      }
    },
    
    handleTransitionEnd(event){
      if (event.propertyName === 'grid-template-rows') {
        this.isAnimatingMobile = false;
      }
    },
  },
  mounted() {
    // Инициализация при монтировании
  },
  filters: {
  },
  computed: {
    shedule() {
      return Storage.getters.SHEDULE;
    },
    can_share() {
      return Storage.getters.CAN_SHARE;
    },
    answerLink() {
      return Storage.getters.ANSWER_LINK;
    }
  },
  watch: {
  },
  created() {
  },
  components: {
    ComponentCalendarMobileShedule,
    ComponentPaymentListSoc
  }
};
</script>

<style scoped>
</style>
