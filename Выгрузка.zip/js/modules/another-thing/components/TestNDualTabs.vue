<template lang="pug">
  .test-a__container(ref='mainContainer')
    .test-a__dual-wr-btn(
      ref="btnDualTabs"
      v-if="status==1"
      )
      .test-a__btn.white.js--dual-btn(
        v-for="(answer, index) in param_component.options" :key="answer.id"
        @click="changeVarint($event,param_component.id,answer.id)"
      ) {{ answer.name }}

    .test-a__dual-wr-btn.unactive(
      v-if="status==3"
    )
      .test-a__btn.white(
        v-for="(answer, index) in param_component.options" :key="answer.id"
        v-bind:class="(status===3&&completedTask.tab==answer.id)?'active':''"
      ) {{ answer.name }}


    .test-a__dual-wr-selected-option(v-if="this.status_tab&&status===1")
      .test-a__dual-selected-option(
        v-for="(item, index) in param_component.description" :key="index"
        v-if="item.id==data_tab"
      )
        p.test-a__dual-selected-option-title {{item.name}}
        .test-a__dual-selected-option-body
          .test-a__list(v-html="item.description")

      .test-a__entry-field.test-a__entry-field-fin.js--number-cost(
        v-bind:class="sent?'unactive':''"
      )
        input(inputmode="numeric" type="text" placeholder="Введите сумму")(
          ref="InputField"
          @keyup="inputChange"
          @keydown="inputChangeDown"
          @input="inputField"
          @paste="pasteNumber"
        )
        //  появится, когда нажмётся отправить
        .test-a__entry-field-icon(
          v-if="sent"
        )
          svg(width='16', height='12', viewbox='0 0 16 12', fill='none', xmlns='http://www.w3.org/2000/svg')
            path(d='M14.6673 1L5.50065 10.1667L1.33398 6', stroke='white', stroke-width='2', stroke-linecap='round', stroke-linejoin='round')

          svg(width='18', height='18', viewbox='0 0 18 18', fill='none', xmlns='http://www.w3.org/2000/svg')
            path(d='M14.7137 4.57227L6.85658 12.4294L3.28516 8.85798', stroke='white', stroke-width='2', stroke-linecap='round', stroke-linejoin='round')

        .test-a__entry-field-currency
          span
          b ₽

      .test-a__wr-btn.test-a__dual-selected-btn

        .test-a__add-zone-btn.green.test-a__btn(
          v-if="!sent&&active_btn&&status_internet"
          @click="sendPost"
        ) Отправить


        .test-a__add-zone-btn.unactive.test-a__btn(
          v-if="sent||!active_btn||status_internet===false"
        ) Отправить
        p.test-a__error-hint(v-if="!status_internet&&!sent") Нет интернета
        p.test-a__error-hint(v-if="hint!=''&&!sent") {{hint}}
        //  появится, когда нажмётся отправить
        p.test-a__add-zone-final-des(
          v-if="sent"
        ) Сумма учтена и будет видна в личном кабинете

    .test-a__dual-wr-selected-option(v-if="status===3")
      .test-a__dual-selected-option(
        v-for="(item, index) in param_component.description" :key="index"
        v-if="item.id==completedTask.tab"
      )
        p.test-a__dual-selected-option-title {{item.name}}
        .test-a__dual-selected-option-body
          .test-a__list(v-html="item.description")

      .test-a__entry-field.test-a__entry-field-fin.js--number-cost
        input(inputmode="numeric" readonly type="text")(
          v-bind:value="completedTask.value"
        )
        //  появится, когда нажмётся отправить
        .test-a__entry-field-icon
          svg(width='16', height='12', viewbox='0 0 16 12', fill='none', xmlns='http://www.w3.org/2000/svg')
            path(d='M14.6673 1L5.50065 10.1667L1.33398 6', stroke='white', stroke-width='2', stroke-linecap='round', stroke-linejoin='round')
          svg(width='18', height='18', viewbox='0 0 18 18', fill='none', xmlns='http://www.w3.org/2000/svg')
            path(d='M14.7137 4.57227L6.85658 12.4294L3.28516 8.85798', stroke='white', stroke-width='2', stroke-linecap='round', stroke-linejoin='round')

        .test-a__entry-field-currency
          span {{completedTask.value.toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')}}
          b.active ₽
      .test-a__wr-btn.test-a__dual-selected-btn
        .test-a__add-zone-btn.unactive.test-a__btn Отправить
        p.test-a__add-zone-final-des Сумма учтена и будет видна в личном кабинете

    .test-a__thanks-passing(
      v-if="sent&status===1"
    )
      p.test-a__thanks-passing-title Благодарим за прохождение теста

      .test-a__final-result-label
        p.test-a__thanks-passing-title-count Вы заработали:
        .test-a__final-result-unit
          p.test-a__thanks-passing-count +{{post_answer!=undefined?post_answer.score:0}}
          .test-a__final-result-unit-icon
            img(src="/dist/img/scored-icon1.png")
          p баллов

        .test-a__final-result-unit
          p.test-a__thanks-passing-count +{{post_answer!=undefined?post_answer.points:0}}
          .test-a__final-result-unit-icon
            img(src="/dist/img/scored-icon2.png")
          p очков


      //      Благодарность после перезагрузки

    .test-a__thanks-passing(
      v-if="!sent&&status===3"
    )
      p.test-a__thanks-passing-title Благодарим за прохождение теста

      .test-a__final-result-label
        p.test-a__thanks-passing-title-count Вы заработали:
        .test-a__final-result-unit
          p.test-a__thanks-passing-count +{{completedTask.score}}
          .test-a__final-result-unit-icon
            img(src="/dist/img/scored-icon1.png")
          p баллов

        .test-a__final-result-unit
          p.test-a__thanks-passing-count +{{completedTask.points}}
          .test-a__final-result-unit-icon
            img(src="/dist/img/scored-icon2.png")
          p очков

</template>

<script>
import IMask from 'imask';
import onlyNumbers from '../custom-scripts/only-numbers.js'
import Storage from '../development-tools/state.vue';
import axios from 'axios';
import inputField from '../mixin/inputField'
let maskName;

export default {
  name: 'TextNDualTabs',
  // mixins: [inputField],
  props: {
    param_component:Object,
    id:Number,
    userId:Number,
    status:Number,
    completedTask:Object
  },
  data() {
    return {
      answerValue: null,
      sent:false,
      stgMax:99999999,
      status_tab:false,
      data_tab:null,
      post_answer:null,
      // post_answer:{
      //   id:0,
      //   score:0,
      //   points:0,
      //   rightAnswers:0,
      //   wrongAnswers:0,
      //   showFinancialLevel: 0,
      //   financialLevel: 0,
      // },
      active_btn:false,
      hint:'',
      count:0
    }
  },
  methods: {
    changeVarint(elem,id_question,id_answer){
      const element = elem.currentTarget
      const array_btn = this.$refs.btnDualTabs.querySelectorAll('.js--dual-btn');
      array_btn.forEach((item)=>{
        item.classList.remove('active')
      })
      element.classList.add('active')
      if(this.status_tab!==true){
        this.status_tab=true
      }
      this.data_tab = id_answer;
    },

    pasteNumber(el){
      const element = el.currentTarget
      let char = (el.clipboardData || window.clipboardData).getData('text');
      if ( !char.match(/\d+/g)) {
        el.preventDefault();
      }
      if(char.match(/^0|\D/g)){
        el.preventDefault();
      }
    },
    inputField(el) {
      const element = el.currentTarget;
      const val = element.value
      if(val.length===0 && val=='0'){
        el.preventDefault()
      }
      let char = el.data
      if (element.value.length > 0 && (Number.isInteger(parseInt(element.value))&&element.value.replace(/\s/g, '')>0)) {
        // eslint-disable-next-line no-undef
        this.active_btn = true;
      } else {
        this.active_btn = false;
      }

      if(element.value.length > 0&&parseInt(element.value.replace(/\s/g, ''))===0){
        maskName.value=''
        element.closest('.js--number-cost').querySelector('b').classList.remove('active')
        element.setAttribute('placeholder','Введите сумму')
      }

      if(val.length>0&&(val.length===1&&val!=0)){
        element.closest('.js--number-cost').querySelector('b').classList.add('active')
        element.setAttribute('placeholder','')
      }

      if(val.length===0){
        element.closest('.js--number-cost').querySelector('b').classList.remove('active')
        element.setAttribute('placeholder','Введите сумму')
      }
      element.closest('.js--number-cost').querySelector('span').textContent=val

    },
    inputChangeDown(event) {
      const element = event.currentTarget
      const val = element.value
      // console.log(event.which);

      // Разрешаем: backspace, delete, tab и escape
      if ( event.which == 46 || event.which == 8 || event.which == 9 || event.which == 27 ||
        // Разрешаем: Ctrl+A
        (event.which == 65 && event.ctrlKey === true) ||
        // Разрешаем: home, end, влево, вправо
        (event.which >= 35 && event.which <= 39)||event.which==86) {
        // Ничего не делаем
        return;
      }
      else {
        // Обеждаемся, что это цифра, и останавливаем событие keypress
        if ((event.which < 48 || event.which > 57) && (event.which < 96 || event.which > 105 )) {
          event.preventDefault();
        }
        if(event.which == 229){
          event.preventDefault();
        }

      }
      if(element.selectionStart===0&&(event.which == 96||event.which == 48||event.which == 229)){
        event.preventDefault();
      }
      if(val.length===10){
        event.preventDefault()
      }
    },
    inputChange(el){
      const element = el.currentTarget
      const val = element.value
      element.closest('.js--number-cost').querySelector('span').textContent=val

    },

    //Отправка на сервер
    sendPost(){
      this.$refs.InputField.closest('.js--number-cost').querySelector('.test-a__entry-field-currency span').textContent=(parseInt(this.$refs.InputField.value.replace(/\s/g, ''))).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
      if(this.count===0){
        this.count=1
        axios({
          method:'post',
          // url:'https://httpbin.org/post', //для раЗРАБОТКИ
          url:'/api/local/gamedd/task/',

          timeout: 10000,
          headers: {
            "Content-type": "application/json; charset=UTF-8",
            'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
          },
          data:{
            userId:this.userId,
            id: this.id,
            itemId:this.param_component.id,
            itemSelectedOption:this.data_tab,
            itemValue:parseInt(this.$refs.InputField.value.replace(/\s/g, ''))
          },
        })
          // Если запрос успешен
          .then((res) => {
            this.post_answer = res.data.result


            // this.post_answer = {
            //   "id":1,
            //   "score":123, // баллы ДД
            //   "points":100, // наши очки
            //   "rightAnswers":9,
            //   "wrongAnswers":14,
            //   "showFinancialLevel": false, // выводить ли уровень фин.грамотности ТОЛЬКО для теста "фин.грамотности"
            //   "financialLevel": 1, // null | 1 | 2 | 3 - уровень фин.грамотности ТОЛЬКО для теста "фин.грамотности"
            // }

            this.sent = true
            this.hint=''

          })
          // Если запрос с ошибкой
          .catch((error)=> {
            if (error.response) {
              console.log(error.response);
              if (error.response.status == 401 || error.response.status == 403) {
                this.hint = `Время сессии истекло, перезагрузите страницу`
              } else {
                if (error.response && error.response.data.error != undefined && error.response.data.error.code) {
                  this.hint = `Ошибка ${error.response.data.error.code}. Обратитесь в колл-центр`
                } else {
                  this.hint = `Ошибка. Обратитесь в колл-центр`
                }
              }

              // if(error.response.status==404||error.response.status==522||error.response.status==524||error.response.status==523||error.response.status==503){
              //   this.hint=`Нет связи с сервером`
              // }
            } else if (error.request) {
              console.log(error.request);
              this.hint = `Нет связи с сервером`

            }
            this.count=0
          });

      }

    },



    inputCost(){
      const input_status = document.querySelectorAll('.js--number-cost input');
      const maskOptions = {
        mask: Number,
        thousandsSeparator: ' ',
        padFractionalZeros: false,
        normalizeZeros: false,
        signed: false,
        // max:this.stgMax,
        scale: 0,

      };
      for (const item of input_status) {
        maskName = IMask(item, maskOptions);
      }
    },
  },
  computed: {
    status_internet() {
      return Storage.getters.STATUSINTERNET;
    },
  },
  watch: {
    post_answer() {
      const btn = this.$refs.mainContainer.closest('.js-p-wrap')
        .querySelector('.js--call-game-task');
      const arrow = this.$refs.mainContainer.closest('.js-p-wrap')
        .querySelector('.js--gamedd-next-task-control');
      const coundown = this.$refs.mainContainer.closest('.js-p-wrap')
        .querySelector('.gamedd-detailed__body-col-link');
      if (btn) {
        btn.removeAttribute('data-modal');
        btn.classList.add('unactive');
        btn.classList.remove('green');
      }
      if(arrow){
        if(this.post_answer!==undefined&&this.post_answer.nextUrl!==''&&this.post_answer.nextUrl!==null&&this.post_answer.nextUrl!==undefined){
          arrow.querySelector('a').setAttribute('href',`${this.post_answer.nextUrl}`)
          arrow.classList.remove('unactive')
        }
      }
      if(coundown){
        coundown.classList.add('unactive')
      }


    }
  },
  mounted() {
    this.inputCost()
  },
  updated() {
    this.inputCost()
  }
}
</script>
