<template lang="pug">
  .test-cont.js--test-cont
    //h3.test-n__title {{ title }}
    //.test-a__question(v-if="isShowDescription" v-html="description")
    .test-a__question(v-if="param.name!==''" v-html="param.name")
    component(
      :is="param.type"
      :is-answered="isAnswered"
      :options="options"
      :description="description"
      :pollId="pollId"
      :param_component="param"
      :modal="modal"
      :requireModeration="requireModeration"
      :id="id"
      :status="status"
      :completedTask="completedTask"
      :userId="userId"
      @valuesIsChosen="setValues(true)"
      @valuesIsUnchosen="setValues(false)"
      @answerIsSetted="setAnswered()"
      @readyForDataSending="sendData"

    )

</template>

<script>
import Vue from 'vue';
import VueAxios from 'vue-axios';
import axios from 'axios';
import TestNSlider from './components/TestNSlider.vue';
import TestNImages from './components/TestNImages.vue';
import TestNMultipleChoice from './components/TestNMultipleChoice.vue';
import TestNPercent from './components/TestNPercent.vue';
import TestNDualTabs from './components/TestNDualTabs.vue';
import TestRadioBtn from './components/TestNRadioBtn.vue';
import CheckBox from './components/TestNCheckbox.vue';
import TestNDual from './components/TestNDual.vue';
import TestNNumberEntry from './components/TestNNumberEntry.vue';
import TestNFinansialAdd from './components/TestNFinansialAdd.vue';

import TestNAddFile from './components/TestNAddFile.vue';


//это тут не нужно, будет отдельное окно
Vue.use(VueAxios, axios);
const apiForGet = '/local/ajax/tests.php';
const apiForSend = '/local/ajax/add_tests.php';

export default {
  name: 'TestN',
  components: {
    'test_radiogroup':TestRadioBtn,
    'test_checkboxes':CheckBox,
    'test_multiimages': TestNImages,
    'test_slider': TestNSlider,
    'test_multiradiogroups': TestNMultipleChoice,
    'test_dualbuttons': TestNDual,

    //фрейм
    'input_number':TestNNumberEntry,
    'financial_add':TestNFinansialAdd,
    'financial_start': TestNDualTabs,
    'input_file':TestNAddFile,

    // Финальные окна
    'percent': TestNPercent,
  },
  props: {
    // id: { // нужен для запрашивания данных по api
    //   type: Number,
    //   required: true
    // },
    param:Object,
    modal:Boolean,
    requireModeration:Boolean,
    id:Number,
    status:Number,
    userId:Number,
    completedTask:Object
  },
  data() {
    return {
      typeOfTest: null, // тип теста, определяет какой компонент будет использоваться, может принимать значения: 'slider', 'images', 'multiple-choice', 'percent' или 'dual'
      colorTheme: 'black', // тип цветовой темы, может принимать значения: 'white', 'gray или 'black'
      title: null, // заголовок
      description: null, // описание/подзаголовок
      answerText: null, // текст ответа
      answerTitle: null, // заголовок ответа
      options: null, // настройки для дочернего компонента
      isAnswered: false, // был ли дан ответ (нажата кнопка проверки)
      isValuesChosen: false, // были ли выбраны ответы в тесте,
      buttonText: 'Проверить ответ', // текст кнопки проверки ответа,
      pollId:null,// id вопроса


    }
  },
  computed: {

  },
  mounted() {
    //Расскоментировать - это для боя
    // this.getData();
  //Закоментировать - это для разработки
  //   this.getLocalData();
  },
  methods: {
    getLocalData(){
      // console.log(this.param);
      const { typeOfTest, options, title, description, end_text, end_title, btn, colorTheme, pollId} = this.param;
      this.typeOfTest = typeOfTest;
      this.options = options;
      this.title = title;
      this.description = description;
      this.answerText = end_text;
      this.answerTitle = end_title;
      if (btn) this.buttonText = btn; // если условие не выполнено, то останется дефолтный текст
      if (colorTheme) this.colorTheme = colorTheme; // если условие не выполнено, то останется дефолтная тема
      this.pollId = pollId

    },


    /**
     * Запрашивает данные по api, заносит их в data
     */
    getData() {
      axios.get(apiForGet, {
        params:{
          id: this.id
        }
      })
        .then((res) => {
          const { typeOfTest, options, title, description, end_text, end_title, btn, colorTheme } = res.data;
          this.typeOfTest = typeOfTest;
          this.options = options;
          this.title = title;
          this.description = description;
          this.answerText = end_text;
          this.answerTitle = end_title;
          if (btn) this.buttonText = btn; // если условие не выполнено, то останется дефолтный текст
          if (colorTheme) this.colorTheme = colorTheme; // если условие не выполнено, то останется дефолтная тема
        })
        .catch((err) => {
          console.error(err);
        });
    },
    /**
     * Отправляет данные
     * @param {Object} - объект с данными
     */
    sendData(data) {
      data.id = this.id; // добавляем id теста
      data.typeOfTest = this.typeOfTest; // добавляем тип теста
      data.URL = document.URL; // добавляем url страницы

      axios.post(apiForSend, data)
        .catch((err) => {
          console.error(err);
        });
    },

  }
}
</script>
