<template lang="pug">
  .key-indicators__panel(:class="{active: tab.isActive}")
    .key-indicators__circle(:class="`key-indicators__circle_${tab.color}`")
    .key-indicators__img
      picture
        source(:srcset="`${imgPath}/${tab.picture}_mobile.png 1x, ${imgPath}/${tab.picture}-2x_mobile.png 2x`" media='(max-width: 767px)')
        source(:srcset="`${imgPath}/${tab.picture}_tablet.png 1x, ${imgPath}/${tab.picture}-2x_tablet.png 2x`" media='(max-width: 1243px)')
        source(:srcset="`${imgPath}/${tab.picture}.png 1x, ${imgPath}/${tab.picture}-2x.png 2x`")
        img(:src="`${imgPath}/${tab.picture}.png`" alt='')
    .key-indicators__wrapper
      span.key-indicators__title {{ tab.name }}
      .key-indicators__list
        .key-indicators__calculations
          template(v-if="tab.key === 'all'")
            .key-indicators__list-item
              span.key-indicators__list-value {{ tab.creditorCnt }}
              span.key-indicators__list-title {{ pluralize(tab.creditorCnt, ['кредитор', 'кредитора', 'кредиторов']) }}
            .key-indicators__list-item
              span.key-indicators__list-value {{ tab.loanCnt | format }}
                span  {{ tab.loanCntOrder | formatUnit }}
              span.key-indicators__list-title {{ pluralize(Math.floor(tab.loanCntFull), ['участник', 'участника', 'участников']) }}
          template(v-else)
            .key-indicators__list-item
              span.key-indicators__list-value {{ tab.loanCnt | format }}
                span  {{ tab.loanCntOrder | formatUnit }}
              span.key-indicators__list-title {{ pluralize(Math.floor(tab.loanCntFull), ['участник', 'участника', 'участников']) }}
            .key-indicators__list-item(v-if="tab.creditorCnt")
              span.key-indicators__list-value {{ tab.creditorCnt }}
              span.key-indicators__list-title {{ pluralize(tab.creditorCnt, ['кредитор', 'кредитора', 'кредиторов']) }}

          .key-indicators__list-item
            span.key-indicators__list-value {{ tab.loanAmt | format }}
              span {{ tab.loanOrder | formatUnit }}
              | &#8381;
            template(v-if="tab.key !== 'slf'")
              span.key-indicators__list-title сумма выданных кредитов
                span(v-show="tab.key === 'all'")
                  | &nbsp;и&nbsp;выплат
            template(v-else)
              span.key-indicators__list-title сумма выплат
        a(:href="`${tab.link_btn}`").key-indicators__link-program
          .key-indicators__link-program-btn
            p Подробнее о программе
</template>

<script>
export default {
  name: 'KeyTab',
  props: {
    tab: {
      type: Object,
      required: true
    },
    imgPath: {
      type: String,
      default: ''
    }
  },
  filters: {
    format: (val) => `${val}`.replace('.', ','),
    formatUnit: (val) => {
      if (!val.length  || val === ' ') { return val }
      const trimStr = `${val}`.replace(/ /g, '');
      if (trimStr.indexOf('.') === -1) {
        return ` ${trimStr}. `
      } else {
        return ` ${trimStr} `;
      }
    }
  },
  methods: {
    /**
     * склонение для периода
     * @param  {Number} count quantity for word
     * @param  {Array} words Array of words. Example:
     * ['депутат', 'депутата', 'депутатов'], ['коментарий', 'коментария', 'комментариев']
     * @return {String} Count + plural form for word
     */
    pluralize(count, words) {
      const cases = [2, 0, 1, 1, 1, 2];
      return words[(count % 100 > 4 && count % 100 < 20)
          ? 2
          : cases[Math.min(count % 10, 5)]];
    },
  }
};
</script>
