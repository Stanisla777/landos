<template lang="pug">
  .calculator_s__checkbox.calculator_s__calculator-row.js--tax_checkbox
    .calculator_s__checkbox-item.checkbox-stylized
      input#checkbox_not_work(type='checkbox' checked)(@change="checkboxChanged")
      label(for='checkbox_not_work') На момент обращения в банк не действуют ипотечные каникулы
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import ToolTip from '../components/v-component-tooltip.vue';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-checkbox-not-work',
  data(){
    return {
      hint_text_1:"Вы получали ранее налоговый вычет за&#160;имущество, либо другие социальные налоговые вычеты",
      modal_text:'Вы не можете подать заявку на кредитные каникулы, если они уже действуют',
      paramName:null,
    }

  },
  methods:{
    checkboxChanged(el){
      const element = el.currentTarget
      if(!element.checked){
        const obj={
          state:false,
          text:this.modal_text
        }
        this.$emit('eventcheckboxChanged',obj)
        Storage.dispatch('ActionChecboxNotWork',obj.state)
      }
      else{
        const obj={
          state:true,
          text:''
        }
        this.$emit('eventcheckboxChanged',obj)
        Storage.dispatch('ActionChecboxNotWork',obj.state)
      }
    }


  },
  mounted(){

  },
  computed:{},
  watch:{
  },
  components:{
    ToolTip
  }
};
</script>
<style scoped>
</style>
