/* eslint-disable */
import Vue from 'vue';
// import universalForm from './universal-form/universal-form';
// import { catalogModal, modals } from './modals';
import mixinLiveSearch from './mixinForVueComponent/mixinLiveSearch';
import mixinOpenListAndSelectItem from './mixinForVueComponent/mixinOpenListAndSelectItem';
import mixinformComponent from './mixinForVueComponent/vue-mixin-form/formComponent';

export default function CatalogNewSendForm() {
  const app = new Vue({
    el: '#modal-catalog-new-request',
    data: {
      show_warn:true,
      fullness_radio:0,
      fullness_select:0,
      fullness_input_radio:0,
      all_checked:true,
    },
    mixins: [mixinLiveSearch,mixinOpenListAndSelectItem,mixinformComponent],
    methods: {

      buttonActivitySecondStep(el){
        const element = el.currentTarget

        if (element.getAttribute('type')==='checkbox') {
          if (element.checked) {
            element.classList.add('js-filled')
          }
          else {
            element.classList.remove('js-filled')
          }
        }
        else {
          if(element.value.length>0) {
            element.classList.add('js-filled')
          }
          else {
            element.classList.remove('js-filled')
          }
        }



        const parent = element.closest('.js--step-2')
        const array = parent.querySelectorAll('.js--validate-mask')
        const array_input_filled = parent.querySelectorAll('.js--validate-mask.js-filled');
        if(array_input_filled.length===array.length){
          this.error_step_2 = false
        }
        else {
          this.error_step_2 = true
        }
      },
      callback(){
        const beesenderchat = document.querySelector('#modal-catalog-new-request');
        if (beesenderchat && beesenderchat.hasAttribute('data-formsubmit')
          && beesenderchat.getAttribute('data-formsubmit') === 'success'
          && !beesenderchat.classList.contains('open')) {
          setTimeout(()=>{
            if (beesenderchat.querySelector('#right_1')) {
              beesenderchat.querySelector('#right_1').checked = true;
            }
            this.show_warn = true;
            this.step_1=true;
            this.error_step_1=true;
            this.error_step_2=true;
            this.fullness_input=0;
            this.fullness_radio=0;
            this.hiddenInput='';
            this.all_checked=true;
            this.InputSearhPlace='';
            this.fullness_input_name=0;
            this.fullness_input_mail=0;
            this.fullness_input_tel=0;
            this.fullness_select=0;
            this.fullness_input_radio=0;
            this.show_warn=true;
            this.fullness_radio=0;
            this.fullness_select=0;
            this.fullness_input_radio=0;
            this.all_checked=true
            beesenderchat.setAttribute('data-formsubmit','')
          },1000)
        }
      },
      successfulSubmission(){
        const beesenderchat = document.querySelector('#modal-catalog-new-request');
        const observerOptions = {
          attributes: true,
        };
        const observer = new MutationObserver(this.callback);
        if (beesenderchat) {
          observer.observe(beesenderchat, observerOptions);
        }
      },
    },
    filters: {
    },
    updated() {
    },
    computed: {
    },
    watch: {

    },
    mounted() {
      // modals();
      // catalogModal();
      // universalForm();
      this.successfulSubmission()
    }
  });
}
