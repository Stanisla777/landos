/* eslint-disable */
export default function commentsTexarea() {
  const array_textarea = document.querySelectorAll('.js--form-comments-text, .js--form-comments-text-modal');
  for (let item of array_textarea) {
    if (item.closest('.js--wr-form-comments-text')) {
      item.value = item.value.trim()
    }
    item.onfocus = () => {
      if (item.closest('.js--wr-form-comments-text')) {
        item.closest('.js--wr-form-comments-text').classList.add('border-color')
      }
    }
    item.onblur = () => {
      if (item.closest('.js--wr-form-comments-text')) {
        item.closest('.js--wr-form-comments-text').classList.remove('border-color')
      }
    }
  }
}
