/* eslint-disable */
import Swiper, {
  Navigation, Pagination, Autoplay, Thumbs, EffectFade
} from 'swiper';
import RemoveClassBody from '../redesign-site/allow-body-scrolling';
import AddClassBody from '../redesign-site/disallow-body-scrolling';

// import paginationSlider_s from './redesign-site/paginationSlider';
// import arrowSlider from './redesign-site/arrowSlider';
// // eslint-disable-next-line no-unused-vars
// import setEqualHeight from './TemplateScript/updateBlockHeights';
// import RemoveClassBody from './redesign-site/allow-body-scrolling';

Swiper.use([Navigation, Pagination, Autoplay, Thumbs, EffectFade]);




let swiper=null

function closeModal() {
  const array_close = document.querySelectorAll('.js--modal-reviews-closer')
  const modal = document.querySelector('.js--modal-reviews')
  for (let item of array_close) {
    item.onclick = ()=>{
      if (modal) {
        item.disabled=true
        modal.classList.remove('open')
        RemoveClassBody()
        setTimeout(() => {
          item.disabled=false
        },1000)
      }
    }
  }
}

function closeModalBody(){
  const modal = document.querySelector('.js--modal-reviews')

  if(modal){
    modal.onclick = (e)=>{
      if (e.target===modal) {
        modal.classList.remove('open')
        if (document.body.classList.contains('body-modal')) {
          RemoveClassBody()
        }
      }
    }
  }
}


export default function swiperReviews() {

  const array_btn = document.querySelectorAll('.js--at-reviews-item')
  const modal = document.querySelector('.js--modal-reviews')
  for (let item of array_btn) {
    item.onclick = ()=>{
      const data = parseInt(item.getAttribute('data-count'))
      swiper.slideTo(data,0)
      if (modal) {
        modal.classList.add('open')
        AddClassBody();
      }
    }
  }

  swiper = new Swiper('.js--slider-at-2025-reviews', {
    init: true,
    loop: false,
    slidesPerView: 1,
    spaceBetween: 16,
    simulateTouch: false,
    allowTouchMove: false,
    autoHeight: false,
    resizeObserver: true,
    observeParents: true,
    observer: true,
    observeSlideChildren: true,

    pagination: {
      // el: '.js--swiper-pagination-question',
      // clickable: true,
    },
    navigation: {
      nextEl: '.js--swiper-modal-reviews-right',
      prevEl: '.js--swiper-modal-reviews-left',
    },
    breakpoints: {

    },
    on: {
      beforeInit:()=>{

      },
      afterInit: function (el) {

      },
      resize:function (el){

      },

    }
  });

  closeModal();
  closeModalBody();




}
