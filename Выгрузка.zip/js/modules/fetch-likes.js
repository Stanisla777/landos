import axios from 'axios-jsonp-pro';

function* generateLikes() {
  const wrappers = document.querySelectorAll('.js-likes-wrapper');

  for (let i = 0; i < wrappers.length; i++) {
    const likes = wrappers[i].querySelectorAll('.js-likes-list');
    if (likes) {
      for (let j = 0; j < likes.length; j++) {
        yield likes[j];
      }
    }
  }
}

function setInnerHtml(data) {
  const numberFormat = new Intl.NumberFormat('en', { notation: 'compact' });
  const generator = generateLikes();

  // eslint-disable-next-line no-restricted-syntax
  for (const like of generator) {
    const elem = like.querySelector('[data-el-id]');
    const id = elem.dataset.elId;
    const type = elem.dataset.elType || '1';
    const index = `${id}_${type}`;
    if (data[index]) {
      like.querySelector('.js-likes-count').innerHTML = data[index].count;
      like.querySelector('.js-likes-share').innerHTML = data[index].share;
      like.querySelector('.js-likes-views').innerHTML = numberFormat.format(data[index].views);
    }
  }
}

function collectIds() {
  const generator = generateLikes();
  const ids = [];

  // eslint-disable-next-line no-restricted-syntax
  for (const like of generator) {
    const id = like.querySelector('[data-el-id]').dataset.elId;
    ids.push(id);
  }

  return ids;
}

export default async function () {
  const ids = collectIds();

  if (!ids || !ids.length) {
    return;
  }

  const response = await axios.post(
    // '/bitrix/services/main/ajax.php?mode=ajax&c=dev:likes&action=likes',
    '/api/local/likes/',
    { ids },
    {
      headers: {
        'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        'Content-Type': 'application/json',
        Accept: 'application/json',
      }
    }
  );
  if (response.data.result) {
    setInnerHtml(response.data.result);
  }
}
