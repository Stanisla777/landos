<template lang="pug">
  .personal-office__notifications-list(ref="notifications")
    .personal-office__notifications-list-non(
      v-if="Notifications.length===0"
    )
      p Уведомлений нет
    template(
      v-if="Notifications.length>0"
    )
      gamedd-notifications-item(
        :notifications="Notifications"
      )
</template>
<script>
import Vue from 'vue';
import eventBus from './development-tools/eventBus.vue';
import Storage from './development-tools/state.vue';
import GameddNotificationsItem from './components/GameddNotificationsItem.vue';
import axios from 'axios';

export default {
  name: 'GameddNotifications',
  data(){
    return {
      Notifications:[]

      // Notifications:[
      //   {
      //     "ID": 33729,
      //     "TYPE": "1", // Тип уведомления [1 - Открыт новый блок заданий, 2 - Новость в разделе "Прочее/FAQ" 3 - Задание №Х на модерации 4 - Ваше задание №Х проверено]
      //     "TITLE": "Открыт новый блок заданий", // текст васмого уведомления
      //     "URL": "https://yandex.ru/", // url куда должно вести задание
      //     "ACTIVE": "Y",
      //     "USER_ID": 98,
      //     "IS_READ": false, // прочитано или нет уведомление
      //     "DATE_START": "01.03.2023 12:30:00" // дата задания
      //   },
      //   {
      //     "ID": 33731,
      //     "TYPE": "2",
      //     "TITLE": "Новость в разделе \"Прочее/FAQ\"",
      //     "URL": "https://yandex.ru/",
      //     "ACTIVE": "Y",
      //     "DATE_START": "",
      //     "USER_ID": 98,
      //     "IS_READ": false
      //   },
      //   {
      //     "ID": 33733,
      //     "TYPE": "3",
      //     "TITLE": "Задание №Х на модерации",
      //     "URL": "https://yandex.ru/",
      //     "ACTIVE": "Y",
      //     "USER_ID": 98,
      //     "IS_READ": true,
      //     "DATE_START": "25.02.2023 12:30:00"
      //   },
      //   {
      //     "ID": 33733,
      //     "TYPE": "4",
      //     "TITLE": "Ваше задание №Х проверено",
      //     "URL": "https://yandex.ru/",
      //     "ACTIVE": "Y",
      //     "USER_ID": 98,
      //     "IS_READ": true,
      //     "DATE_START": "25.02.2023 12:30:00"
      //   },
      // ]
    }
  },
  methods:{
    bellState(){
      const array = this.$refs.notifications.querySelectorAll('.js--notif-item[data-read="false"]')
      if(array.length>0){
        this.$refs.notifications.closest('.at-header__container-icon').querySelector('.js--private-bell .personal-office__alarm').classList.add('active')
      }
    },
    dataGetParam(){
      axios.get(`/api/local/gamedd/notification/`,{
        headers: {
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        }
      })
        .then((res) => {
          console.log(res);
          this.Notifications=res.data.result.notifications //бой
        })
        .then((res)=>{
          this.bellState()

        })
        .catch((err) => {
          console.error(err);
        });

    }

  },
  mounted(){
    this.dataGetParam()
    // this.bellState() //для разработки

  },
  computed:{
    step(){
      // return Storage.getters.STEP
    },
  },
  watch:{
  },
  components:{
    GameddNotificationsItem
  }
};
</script>
<style scoped>
</style>
