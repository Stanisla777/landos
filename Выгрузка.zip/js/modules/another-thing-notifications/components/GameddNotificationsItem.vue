<template lang="pug">
  .personal-office__notifications-list-wr
    .personal-office__notifications-list-item.js--notif-item(
      v-for="(item,key,ind) in notifications"
      :key="item.ID"
      v-bind:class="item.TYPE=='1'?'status-new':item.TYPE=='4'?'status-checked':item.TYPE=='3'?'status-examination':item.TYPE=='2'?'status-in-chapter':item.TYPE=='5'?'code-for-invitation':item.TYPE=='6'?'reward-for-invitation':''"
      v-bind:data-read="item.IS_READ===true?'true':'false'"
      v-bind:data-link="item.URL.length!==0?'true':'false'"
      @click="sendPost(item.ID,item.IS_READ)"
    )
      a.personal-office__notifications-list-wr-link(
        v-if="item.URL.length!==0&&item.URL.includes('https')"
        :href="item.URL"
        target="_blank"
      )
      a.personal-office__notifications-list-wr-link(
        v-if="item.URL.length!==0&&!item.URL.includes('https')"
        :href="item.URL"
      )
      .personal-office__notifications-info
        .personal-office__notifications-icon
        .personal-office__notifications-wr-not
          p.personal-office__notifications-title {{item.TITLE}}
          p.personal-office__notifications-data(
            v-if=" typeof item.DATE_START === 'string'"
          ) {{item.DATE_START.split(' ')[0]}}
          p.personal-office__notifications-data(
            v-if="item.DATE_START===null"
          )

</template>

<script>
import Storage from '../development-tools/state.vue'
import axios from 'axios';

let mask;

export default {
  name: 'GameddNotificationsItem',

  props: ['notifications'],
  data() {
    return {

    }
  },

  methods: {
    sendPost(param_1,param_2){
      const obj={}
      if(param_2===false){

        obj.NOTIFICATION_ID=param_1

        axios({
          method:'post',
          // url:'https://httpbin.org/post', //для раЗРАБОТКИ
          url:'/api/local/gamedd/notification/',

          headers: {
            "Content-type": "application/json; charset=UTF-8",
            'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
          },
          data:obj
        })
          // Если запрос успешен
          .then((res) => {

          })
          // Если запрос с ошибкой
          .catch(function (error) {
            console.log(error);
          });
      }

    },

  },

  computed: {

  },
  watch: {

  },
  mounted() {

  },
  updated() {

  },
  components:{

  }

}
</script>
