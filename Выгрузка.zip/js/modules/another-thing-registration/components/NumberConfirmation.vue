<template lang="pug">
  .gameddreg__wrapper
    .gameddreg__come-back(@click="comeBack")
      svg(width='24', height='24', viewbox='0 0 24 24', fill='none', xmlns='http://www.w3.org/2000/svg')
        path(d='M19 12H5', stroke='white', stroke-width='2', stroke-linecap='round', stroke-linejoin='round')
        path(d='M12 19L5 12L12 5', stroke='white', stroke-width='2', stroke-linecap='round', stroke-linejoin='round')

    p.gameddreg__title.margin  Подтвердите номер телефона
    p.gameddreg__sub-title.
      Введите 4 цифры кода из смс
    .gameddreg__confirmation
      .gameddreg__confirmation-wr-number
        p.gameddreg__confirmation-number {{user_data.PHONE.replace(/(\+7|8)[\s(]?(\d{3})[\s)]?(\d{3})[\s-]?(\d{2})[\s-]?(\d{2})/g, '+7 $2 $3 $4 $5')}}
        p.gameddreg__confirmation-not(
          @click="changeNumber"
        ) Это не мой номер
      .gameddreg__verification-code(
        ref="verificationCode"
        v-bind:class="(code_status==='check_phone_code_error'||code_status==='check_code_time_error')?'error':''"
        )
        input(inputmode="numeric").gameddreg__verification-code-item(
          ref="firstInput"
          @keydown="inputField"
          @keyup="jumpingField"
          @paste="pastOnlyNumber"

          @input="CountSymbol"
        )
        input(inputmode="numeric").gameddreg__verification-code-item(
          @keydown="inputField"
          @keyup="jumpingField"
          @paste="pastOnlyNumber"

          @input="CountSymbol"
        )
        input(inputmode="numeric").gameddreg__verification-code-item(
          @keydown="inputField"
          @keyup="jumpingField"
          @paste="pastOnlyNumber"

          @input="CountSymbol"
        )
        input(inputmode="numeric").gameddreg__verification-code-item(
          @keydown="inputField"
          @keyup="jumpingField"
          @paste="pastOnlyNumber"

          @input="CountSymbol"
        )


      .gameddreg__repeated-countdown-wr
        p.gameddreg__repeated-countdown.common.js--coundown(
          ref="countDown"
          ) Получить повторно код можно через <span> <i class="js--minutes">0</i>:<i class="js--seconds">{{countdown}}</i></span>
        p.gameddreg__repeated-countdown.error(
          v-if="code_status==='check_phone_code_error'"
        ) Неверный код
        p.gameddreg__repeated-countdown.error(
          v-if="code_status==='check_code_time_error'"
        ) Время истекло


      .gameddreg__wr-verification-btn.gameddreg__button
        .gameddreg__btn-request(
          @click="requestAgain"
          v-if="active_btn_request"
        ) Запросить код повторно

        .gameddreg__btn-request.unactive(
          v-if="!active_btn_request"
        ) Запросить код повторно


        .test-a__add-zone-btn.green.test-a__btn(
          v-if="active_btn_confirm"
          @click="sendPostCode"
        ) Подтвердить
        .test-a__add-zone-btn.unactive.test-a__btn(
          v-if="!active_btn_confirm"
        ) Подтвердить
        p.gameddreg__input-error.gameddreg__input-error-hint(ref="hintText")

</template>

<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import onlyNumbers from '../custom-scripts/only-numbers.js';
import axios from 'axios';
import Cookies from 'js-cookie'
let timeId;
let obratniyOtschet;

export default {
  name: 'NumberConfirmation',
  data() {
    return {
      time:41/60,//0.2 41/60,
      active_btn_confirm:false,
      active_btn_request:false,

      status_window:true,
      code_status:'common' //common time_over wrong
    }
  },
  methods: {

    countDown(){
      const coundown = document.querySelector('.js--coundown')
      if(coundown){
        this.active_btn_request=false
        var kolichestvoMinut = (parseInt(this.countdown)+1)/60;  // желаемое время таймера в минутах (5 минут)
        var tekuscheyeVremya = new Date(); // получаем сегодняшнюю дату и время
        // var deadlineTime = tekuscheyeVremya.setMinutes(tekuscheyeVremya.getMinutes() + 5); // устанавливаем таймер на 5 минут
        var deadlineTime = new Date( new Date().getTime() + (kolichestvoMinut * 60 * 1000) ); // можно и так установить таймер на 5 минут
        // обновляем скрипт каждую секунду - так мы получаем обратный отсчет
        obratniyOtschet = setInterval(()=> {
          var seychas = new Date().getTime(); // текущее время
          var ostatokVremeni = deadlineTime - seychas; // находим различие между текущим моментом и временем дедлайна
          // преобразовываем значение миллисекунд в минуты и секунды
          var minuti = Math.floor( (ostatokVremeni % (1000 * 60 * 60)) / (1000 * 60) );
          var secundi = Math.floor( (ostatokVremeni % (1000 * 60)) / 1000 );
          // если значение текущей минуты или секунды меньше 10, добавляем вначале ведущий ноль
          minuti = minuti < 10 ? minuti : minuti;
          secundi = secundi < 10 ? "0" + secundi : secundi;
          // отображаем результат таймера в элементе с id="deadline-timer"
          coundown.querySelector('.js--minutes').textContent = minuti;
          coundown.querySelector('.js--seconds').textContent = secundi;
          // если в таймере остались только секунды, меняем слово "минуты" на "секунды"

          // когда обратный отсчет закончился, отображаем соответствующее уведомление
          if (ostatokVremeni <= 0) {
            clearInterval(obratniyOtschet);
            coundown.querySelector('.js--minutes').textContent = '0';
            coundown.querySelector('.js--seconds').textContent = '00';
            this.active_btn_request=true
          }
        }, 1000);
      }

    },
    inputField(el){
      onlyNumbers(el)
      const element = el.currentTarget
      if(Number.isInteger(parseInt(el.key))){
        element.value=el.key
      }
      if(el.ctrlKey === true){
        element.value=''
      }

    },
    CountSymbol(el){
      const element = el.currentTarget
      element.value = element.value.substr(0, 1)
      let count_filled_inp=0
      const array = this.$refs.verificationCode.querySelectorAll('input')
      for (let i=0;i<array.length;i++){
        if(array[i].value.length>0){
          count_filled_inp+=1
        }
      }
      if(count_filled_inp===array.length){
        this.active_btn_confirm=true
      }
      else {
        this.active_btn_confirm=false
      }

    },
    jumpingField(el) {
      const element = el.currentTarget;
      const val = element.value;
      const array = this.$refs.verificationCode.querySelectorAll('input');
      if (Number.isInteger(parseInt(val)) && element.nextSibling != null) {
        element.nextSibling.focus();
      }
      if (el.ctrlKey === true && Number.isInteger(parseInt(val)) && element.nextSibling != null) {
        element.nextSibling.focus();
      }
      if (el.key === 'Backspace' && element.previousSibling != null) {
        element.previousSibling.focus();
      }
      // if (el.key === 'ArrowLeft' && element.previousSibling != null) {
      //   element.selectionStart = element.selectionEnd = element.value.length;
      //   element.previousSibling.focus();
      //   return true
      // }
      // if (el.key === 'ArrowLeft' && element.previousSibling === null) {
      //   el.preventDefault()
      // }
      // if (el.key === 'ArrowRight' && element.nextSibling != null) {
      //   element.selectionStart = element.selectionEnd = element.value.length;
      //   element.nextSibling.focus();
      //   return true
      // }
      // if (el.key === 'ArrowRight' && element.nextSibling === null) {
      //   element.selectionStart = element.selectionEnd = element.value.length;
      //   el.preventDefault()
      // }




    },
    pastOnlyNumber(el){
      // alert(1)
      const element = el.currentTarget
      let element_val = (el.clipboardData || window.clipboardData).getData('text');
      if ( element_val.search(/[^0-9]/g) != -1 ) {
        this.state=false
        el.preventDefault();
      }
      const array_el = this.$refs.verificationCode.querySelectorAll('input')
      const array = String(element_val).split("");
      let count= array.length-1
      if(array.length===4){
        for(let i=0;i<array.length;i++){
          if(Number.isInteger(parseInt(array[i]))){
            array_el[i].value=array[i]
          }
          else {
            count = i
          }

        }

        array_el[count].focus()
      }

    },


    //Отправка на сервер
    sendPostCode(){
      const obj={}
      let code = []
      let str='';
      const array = this.$refs.verificationCode.querySelectorAll('input')
      for (let i=0;i<array.length;i++){
        code.push(array[i].value)
      }
      str = code.join('');
      str = parseInt(str)
      obj.CODE=str

      axios({
        method:'post',
        // url:'https://httpbin.org/post', //для раЗРАБОТКИ
        url:'/api/local/gamedd/profile/phone/',

        headers: {
          "Content-type": "application/json; charset=UTF-8",
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        },
        data:obj
      })
        // Если запрос успешен
        .then((res) => {
          // Storage.dispatch('ActionStep','finish') //убрать
          if(res.data.result.success===true){
            Storage.dispatch('ActionStep','finish')
            this.$refs.hintText.textContent=''
          }

        })
        // Если запрос с ошибкой
        //вот тут в переменную  буду записывать ошибки, которые будет возвращать бэк
        // и в зависимости от неё выводить ошибку(неправильный код и так далее)
        .catch((error)=> {

          //расскоментировать
          if(error.response){
            console.log(error.response);
            if(error.response.data.error!=undefined&&error.response.data.error.code!=undefined){
              if(error.response.data.error.code=='check_code_time_error'){ //
                this.code_status = 'check_code_time_error'
                clearInterval(obratniyOtschet)
                const coundown = document.querySelector('.js--coundown')
                if(coundown){
                  coundown.querySelector('.js--minutes').textContent = '0';
                  coundown.querySelector('.js--seconds').textContent = '00';
                  this.active_btn_request=true
                }
              }

              if(error.response.data.error.code=='check_phone_code_error'){
                this.code_status = 'check_phone_code_error'
              }

              if(error.response.data.error.code!='check_code_time_error'&&error.response.data.error.code!='check_phone_code_error'){
                this.$refs.hintText.textContent = error.response.data.error.description
              }
            }
          }




        //  error.response.data.error.description

        });

    },



    //нажатие на кнопку Запросить код повторно отправляю post запрос передавая номер телефона
    // и в случае успешной отправки запускаю счётчик
    requestAgain(){
      const tel = this.user_data.PHONE
      const obj={}
      obj.PHONE=tel
      axios({
        method:'post',
        // url:'https://httpbin.org/post', //для раЗРАБОТКИ
        url:'/api/local/gamedd/profile/user/',

        headers: {
          "Content-type": "application/json; charset=UTF-8",
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        },
        data:obj
      })
        // Если запрос успешен
        .then((res) => {
          Storage.dispatch('ActionCountDownAgain')
          this.countDown()
          this.code_status='common'
          const array = this.$refs.verificationCode.querySelectorAll('input')
          for (let i=0;i<array.length;i++){
            array[i].value=''
            array[0].focus()
          }
          this.active_btn_confirm=false
        })
        // Если запрос с ошибкой
        //вот тут в переменную  буду записывать ошибки, которые будет возвращать бэк
        // и в зависимости от неё выводить ошибку(неправильный код и так далее)
        .catch((error)=> {
          if(error.response){
            console.log(error.response);
            if(error.response.data.error!=undefined&&error.response.data.error.code!=undefined){
              if(error.response.data.error.code!='check_code_time_error'&&error.response.data.error.code!='check_phone_code_error'){
                this.$refs.hintText.textContent = error.response.data.error.description
              }
            }
          }

        });

    },


    comeBack(){
      if(this.transition_step>0){
        let time = this.$refs.countDown.querySelector('.js--seconds').textContent
        if(time=='00'){
          time=0
        }
        Storage.dispatch('ActionCountDown',time)
        Cookies.set('gamedd_time_begin', 'yourCookieName' + '=' + new Date());
      }
      clearInterval(obratniyOtschet)
      Storage.dispatch('ActionStep','completion')

      // else if(this.transition_step===0){
      //   Storage.dispatch('ActionTransitionStep',1)
      // }

    },
  //  изменить номер
    changeNumber(el){
      const element = el.currentTarget
      let time = this.$refs.countDown.querySelector('.js--seconds').textContent
      if(time=='00'){
        time=0
      }
      Storage.dispatch('ActionCountDown',time)
      // console.log(time);
      Cookies.set('gamedd_time_begin', 'yourCookieName' + '=' + new Date());
      clearInterval(obratniyOtschet)
      Storage.dispatch('ActionStep','change_number')
    },
  },
  mounted() {
    this.$refs.firstInput.focus()
    Storage.dispatch('ActionTransitionStep',1)
    this.countDown()

  },
  computed:{
    user_data(){
      return Storage.getters.USERDATA
    },
    countdown(){
      return Storage.getters.COUNTDOWN
    },
    transition_step(){
      return parseInt(Storage.getters.TRANSITIONSTEP)
    },

  },
  created(){


  },
  updated() {

  }

}
</script>
