<template lang="pug">
  div
    template
      another-thing-registration(
        :vk_address="vk_address"
        :vk_app_id="vk_app_id"
        )

</template>
<script>
import Storage from './development-tools/state.vue';
const AnotherThingRegistration = () => import ("./AnotherThingRegistration.vue");


export default {
  name: 'AnotherThingRegistrationPointEntry',
  data(){
    return {
      vk_address:null,
      vk_app_id:null,
    }
  },
  methods:{
    receivingData(){
      if(this.$attrs.step!==undefined){
        Storage.dispatch('ActionStep',this.$attrs.step)
      }
      if(this.$attrs.vk_address!==undefined){
        this.vk_address = this.$attrs.vk_address
      }
      if(this.$attrs.vk_app_id!==undefined){
        this.vk_app_id = parseInt(this.$attrs.vk_app_id)
      }
      if(this.$attrs.countdown!==undefined){
        Storage.dispatch('ActionCountDown',this.$attrs.countdown)
      }
      if(this.$attrs.user_data!==undefined){
        this.user_data = JSON.parse(this.$attrs.user_data)
        Storage.dispatch('ActionUserData',JSON.parse(this.$attrs.user_data))
      }


    },
  },
  mounted(){
    this.receivingData()
  },
  computed:{
  },
  watch:{
  },
  components:{
    AnotherThingRegistration
  }
};
</script>
<style scoped>
</style>
