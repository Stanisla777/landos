<script>
import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios';

Vue.use(Vuex);

export default new Vuex.Store({
  state:{
    number_tel_show:'',
    user_data:null,
    step:null,
    back_error:null,
    countdown:null,
    constant_countdown:40,
    check_agreement:false,
    transition_step:0
  },
  getters:{

    NUMBERTELSHOW(state){
      return state.number_tel_show
    },
    USERDATA(state){
      return state.user_data
    },
    STEP(state){
      return state.step
    },

    COUNTDOWN(state){
      return state.countdown
    },
    CHECKAGREEMENT(state){
      return state.check_agreement
    },
    TRANSITIONSTEP(state){
      return state.transition_step
    },
    CONSTANTCOUNTDOWN(state){
      return state.constant_countdown
    },





  },
  mutations:{

    mutationUserData(state,received_perem){
      state.user_data = received_perem
    },

    mutationInfoUser(state,received_perem){
      state.user_data = received_perem
      // console.log(state);
    },
    mutationChangeTel(state,received_perem){
      Vue.set(state.user_data,'PHONE',received_perem.PHONE)
    },
    mutationChangeMail(state,received_perem){
      Vue.set(state.user_data,'EMAIL',received_perem.EMAIL)
    },




    mutationStep(state,received_perem){
      state.step = received_perem
    },
    mutationCountDown(state,received_perem){
      state.countdown = received_perem
    },
    mutationCountDownConstant(state,received_perem){
      state.constant_countdown = received_perem
    },
    mutationCountDownAgain(state){
      state.countdown = state.constant_countdown
    },
    mutationCheckAgreement(state,received_perem){
      state.check_agreement = received_perem
    },
    mutationTransitionStep(state,received_perem){
      state.transition_step = received_perem
    },











  },
  actions:{


  //данные пользователя
    ActionUserData({commit,state},param){
      commit('mutationUserData',param)
    },

    //При нажатии на кнопку продолжить завершение регистрации

    ActionInfoUser({commit,state},param){
      commit('mutationInfoUser',param)
    },
    ActionStep({commit,state},param){
      commit('mutationStep',param)
    },

  //  Замена номера телефона
    ActionChangeTel({commit,state},param){
      commit('mutationChangeTel',param)
    },

    //  Замена номера мэйл
    ActionChangeMail({commit,state},param){
      commit('mutationChangeMail',param)
    },

  //  передаю данные из куки, когда человек нажал продолжить в окне Завершение регистрации

    ActionCountDown({commit,state},param){
      commit('mutationCountDown',param)
    },

  //  когда в подтверждении нажали запросить снова
    ActionCountDownConstant({commit,state},param){
      commit('mutationCountDownConstant',param)
    },

    ActionCountDownAgain({commit,state}){
      commit('mutationCountDownAgain')
    },

    //выбор чекбокса согласие на подписку
    ActionCheckAgreement({commit,state},param){
      commit('mutationCheckAgreement',param)
    },

    ActionTransitionStep({commit,state},param){
      commit('mutationTransitionStep',param)
    },














  },
})
</script>
