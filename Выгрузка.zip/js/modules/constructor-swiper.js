/* eslint-disable */
import Swiper, {
  Navigation, Pagination, Autoplay, Thumbs, EffectFade
} from 'swiper';
import paginationSlider_s from './redesign-site/paginationSlider';
// eslint-disable-next-line no-unused-vars
import setEqualHeight from './TemplateScript/updateBlockHeights';
import RemoveClassBody from './redesign-site/allow-body-scrolling';

Swiper.use([Navigation, Pagination, Autoplay, Thumbs, EffectFade]);

/**
 * Выравнивает высоту блоков с классом .js--blocks-in-slide-one-height
 * внутри видимых слайдов Swiper-слайдеров.
 *
 * Если у .js--slider-construtor есть класс .js--not-one-height-mobile,
 * то на экранах < 590px выравнивание НЕ применяется.
 */
function equalizeBlocksInSlideHeight() {
  const sliders = document.querySelectorAll('.js--slider-construtor');

  sliders.forEach(sliderEl => {
    const swiper = sliderEl.swiper;
    if (!swiper) return;

    const disableOnMobile = sliderEl.classList.contains('js--not-one-height-mobile');
    const isMobile = window.innerWidth < 590;

    if (disableOnMobile && isMobile) {
      const blocks = sliderEl.querySelectorAll('.js--blocks-in-slide-one-height');
      blocks.forEach(block => block.style.minHeight = '');
      return;
    }

    // Берём ВСЕ настоящие слайды (не дубликаты, не заглушки)
    const realSlides = Array.from(sliderEl.querySelectorAll('.swiper-slide'))
      .filter(slide =>
        !slide.classList.contains('swiper-slide-duplicate') &&
        !slide.classList.contains('swiper-slide-invisible-blank')
      );

    if (realSlides.length <= 1) {
      const blocks = sliderEl.querySelectorAll('.js--blocks-in-slide-one-height');
      blocks.forEach(block => block.style.minHeight = '');
      return;
    }

    const targetBlocks = realSlides
      .map(slide => slide.querySelector('.js--blocks-in-slide-one-height'))
      .filter(Boolean);

    if (targetBlocks.length <= 1) {
      targetBlocks.forEach(block => block.style.minHeight = '');
      return;
    }

    // Сброс
    targetBlocks.forEach(block => block.style.minHeight = '');

    let maxHeight = 0;
    targetBlocks.forEach(block => {
      maxHeight = Math.max(maxHeight, block.offsetHeight);
    });

    targetBlocks.forEach(block => {
      block.style.minHeight = `${maxHeight}px`;
    });
  });
}

// === УЛУЧШЕННАЯ ФУНКЦИЯ: ожидание загрузки ВСЕХ изображений, включая внутри <picture> ===
function waitForImages(container) {
  const images = [];

  // Находим все <img>, включая вложенные в <picture>
  container.querySelectorAll('img').forEach(img => {
    // Если изображение уже загружено и имеет высоту — пропускаем
    if (img.complete && img.naturalHeight > 0) {
      return;
    }

    // Создаём промис для загрузки
    const promise = new Promise((resolve) => {
      const onLoad = () => {
        img.removeEventListener('load', onLoad);
        img.removeEventListener('error', onError);
        resolve();
      };
      const onError = () => {
        img.removeEventListener('load', onLoad);
        img.removeEventListener('error', onError);
        resolve(); // даже при ошибке — продолжаем
      };

      img.addEventListener('load', onLoad, { once: true });
      img.addEventListener('error', onError, { once: true });

      // Принудительно запускаем декодирование, если lazy
      if (img.loading === 'lazy') {
        // Попытка "разленивить" — но это не всегда работает
        img.setAttribute('loading', 'eager');
        // Или просто ждём, когда браузер сам загрузит
      }
    });

    images.push(promise);
  });

  return images.length ? Promise.all(images) : Promise.resolve();
}

// === ОСНОВНАЯ ФУНКЦИЯ ИНИЦИАЛИЗАЦИИ СЛАЙДЕРОВ ===
function appraisalSlider() {
  const array_slider = document.querySelectorAll('.js--slider-construtor');

  for (const item of array_slider) {
    // Параметры по умолчанию
    let data_space_between = { desctop: '16', tablet: '14', mobile: '0' };
    let data_count_slide = { large_desctop: '4', desctop: '4', small_desctop: '3', tablet: '2', mobile: '1' };
    let data_loop = { desctop: 'false', small_desctop: 'false', tablet: 'false', mobile: 'false' };
    let data_simulation_touch = { desctop: 'false', tablet: 'false', mobile: 'true' };
    let data_arrows = { arrow_left: '', arrow_right: '' };
    let data_pagination = { pagination: '' };
    let auto_height = false;

    // Чтение атрибутов
    if (item.hasAttribute('data-space-between')) {
      data_space_between = JSON.parse(item.getAttribute('data-space-between'));
    }
    if (item.hasAttribute('data-count-slide')) {
      data_count_slide = JSON.parse(item.getAttribute('data-count-slide'));
    }
    if (item.hasAttribute('data-loop')) {
      data_loop = JSON.parse(item.getAttribute('data-loop'));
    }
    if (item.hasAttribute('data-simulation-touch')) {
      data_simulation_touch = JSON.parse(item.getAttribute('data-simulation-touch'));
    }
    if (item.hasAttribute('data-arrows')) {
      data_arrows = JSON.parse(item.getAttribute('data-arrows'));
    }
    if (item.hasAttribute('data-pagination')) {
      data_pagination = JSON.parse(item.getAttribute('data-pagination'));
    }
    if (item.hasAttribute('auto-height')) {
      auto_height = item.getAttribute('auto-height') === 'true';
    }

    // Создаём Swiper
    const swiper = new Swiper(item, {
      init: false, // ⚠️ НЕ инициализируем сразу!
      observer: true,
      observeParents: true,
      observeSlideChildren: true,

      slidesPerView: parseInt(data_count_slide.desctop, 10),
      spaceBetween: parseInt(data_space_between.desctop, 10),
      loop: false,
      autoHeight: auto_height,
      simulateTouch: true,
      allowTouchMove: true,

      pagination: data_pagination.pagination
        ? {
          el: data_pagination.pagination,
          clickable: true,
        }
        : false,

      navigation: data_arrows.arrow_left && data_arrows.arrow_right
        ? {
          prevEl: data_arrows.arrow_left,
          nextEl: data_arrows.arrow_right,
        }
        : false,

      breakpoints: {
        0: {
          slidesPerView: parseInt(data_count_slide.mobile, 10),
          spaceBetween: parseInt(data_space_between.mobile, 10),
          loop: JSON.parse(data_loop.mobile),
          simulateTouch: JSON.parse(data_simulation_touch.mobile),
          allowTouchMove: JSON.parse(data_simulation_touch.mobile),
        },
        590: {
          slidesPerView: parseInt(data_count_slide.tablet, 10),
          spaceBetween: parseInt(data_space_between.tablet, 10),
          loop: JSON.parse(data_loop.tablet),
          simulateTouch: JSON.parse(data_simulation_touch.tablet),
          allowTouchMove: JSON.parse(data_simulation_touch.tablet),
        },
        768: {
          slidesPerView: parseInt(data_count_slide.small_desctop, 10),
          spaceBetween: parseInt(data_space_between.desctop, 10),
          loop: JSON.parse(data_loop.small_desctop),
          simulateTouch: JSON.parse(data_simulation_touch.desctop),
          allowTouchMove: JSON.parse(data_simulation_touch.desctop),
        },
        1100: {
          slidesPerView: parseInt(data_count_slide.desctop, 10),
          spaceBetween: parseInt(data_space_between.desctop, 10),
          loop: JSON.parse(data_loop.desctop),
          simulateTouch: JSON.parse(data_simulation_touch.desctop),
          allowTouchMove: JSON.parse(data_simulation_touch.desctop),
        },
        1360: {
          slidesPerView: parseInt(data_count_slide.large_desctop, 10),
          spaceBetween: parseInt(data_space_between.desctop, 10),
          loop: JSON.parse(data_loop.desctop),
          simulateTouch: JSON.parse(data_simulation_touch.desctop),
          allowTouchMove: JSON.parse(data_simulation_touch.desctop),
        },
      },

      on: {
        afterInit: (el) => {
          const wrapper = el.el.closest('.js--general-style-slider.before-init');
          if (wrapper) {
            wrapper.classList.remove('before-init');
          }
          paginationSlider_s(el);
        },

        resize: (el) => {
          setTimeout(() => {
            el.update();
            if (auto_height) el.updateAutoHeight();
            equalizeBlocksInSlideHeight();
          }, 100);
          paginationSlider_s(el);
        },
      },
    });

    // === КЛЮЧЕВОЙ МОМЕНТ: ждём загрузки изображений → инициализируем Swiper ===
    waitForImages(item).then(() => {
      swiper.init(); // Теперь инициализируем
      equalizeBlocksInSlideHeight();

      // После инициализации — обновляем высоту, если нужно
      if (auto_height) {
        // Swiper сам обновит высоту, но иногда нужно подождать рендер
        setTimeout(() => {
          swiper.updateAutoHeight(300);
        }, 50);
      }

      // Отключаем свайп, если слайдов мало
      if (swiper.slides && swiper.slides.length <= swiper.params.slidesPerView) {
        swiper.allowTouchMove = false;
      }

      // Обновляем пагинацию
      paginationSlider_s(swiper);
    });
  }
}

export default function slideConstructor() {
  appraisalSlider();
}
