<template lang="pug">
  .modal(
    @click="closeModalBody" ref="dataModal"
    :class="modal_tooltip_status?'open':''"
  )
    .modal__wrapper.new.bg-grey.mor-rep-calculators__modal.js--modal
        button.modal__closer.outside(@click="closeModal")
            svg(width='17' height='18' viewBox='0 0 17 18' fill='none' xmlns='http://www.w3.org/2000/svg')
                path(fill-rule='evenodd' clip-rule='evenodd' d='M0.357542 15.3637C-0.0329827 15.7543 -0.0329827 16.3874 0.357542 16.778C0.748066 17.1685 1.38123 17.1685 1.77176 16.778L8.13551 10.4142L14.4995 16.7782C14.89 17.1687 15.5232 17.1687 15.9137 16.7782C16.3042 16.3876 16.3042 15.7545 15.9137 15.364L9.54972 8.99999L15.9139 2.63582C16.3044 2.24529 16.3044 1.61213 15.9139 1.2216C15.5234 0.83108 14.8902 0.83108 14.4997 1.2216L8.13551 7.58577L1.77156 1.22182C1.38104 0.8313 0.747871 0.8313 0.357346 1.22182C-0.0331781 1.61235 -0.0331778 2.24551 0.357346 2.63604L6.7213 8.99999L0.357542 15.3637Z')
        //временно
        .modal__main-content.js--modal-main-content
          .feed_back.feedback.modal-new-container.modal-new-container__content(
            v-if="modal_tooltip_attribute!==null"
            v-html="transfer_tooltip[modal_tooltip_attribute]['info']"
          )


</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import numberFormatting from '../mixin/numberFormatting.js';

export default {
  name: 'v-modal-tooltip',
  mixins: [numberFormatting],
  props:[],
  data(){
    return {

    }
  },
  methods:{
    closeModal(){
      // this.$refs.dataModal.classList.remove('open')
      Storage.dispatch('ActionOpenModalStatus',false)
      this.RemoveClassBody()
    },
    closeModalBody(e){
      if(e.target===this.$refs.dataModa){
        // this.$refs.dataModal.classList.remove('open')
        Storage.dispatch('ActionOpenModalStatus',false)
        this.RemoveClassBody()
      }
    },
  },
  mounted(){

  },
  computed:{
    modal_tooltip_status(){
      return Storage.getters.MODALTOOLTIPSTATUS
    },
    modal_tooltip_attribute(){
      return Storage.getters.MODALTOOLTIPATTRIBUTEDATA
    },

    transfer_tooltip(){
      return Storage.getters.TRANSFERTOOLTIP
    },

  },
  watch:{

  },
  components:{}
};
</script>
<style scoped>
</style>
