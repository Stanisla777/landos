<template lang="pug">
  .property-calculator__final-calc
    .property-calculator__final-item-block
      p.refinancing-calc__final-item-value {{parseFloat(calculate_result).toLocaleString('ru')}} ₽
      p.property-calculator__final-item-key Сумма неустойки
    .property-calculator__final-item-block.not-border
      p.refinancing-calc__final-item-value {{parseFloat(apartment_price_show).toLocaleString('ru')}} × {{day_show}} × 1/{{checbox_individual_show === true ? '150' : checbox_individual_show === null ? '...' : '300'}} × {{applicable_rate}}%
      p.property-calculator__final-item-key Формула расчета



</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import ToolTip from '../components/v-component-tooltip.vue';
export default {
  name: 'v-component-final-block-confirmed',
  props:['html_list'],
  data(){
    return {

    }
  },
  methods:{


  },
  mounted(){

  },
  updated() {

  },
  computed:{
    calculate_result(){
      return Storage.getters.CALCULATE_RESULT
    },
    apartment_price(){
      return Storage.getters.APARTMENT_PRICE
    },
    apartment_price_show(){
      return Storage.getters.APARTMENT_PRICE_SHOW
    },

    days_of_delay(){
      return Storage.getters.DAYS_OF_DELAY
    },
    minus_moratorium_days(){
      return Storage.getters.MINUS_MORATORIUM_DAYS
    },
    day_show(){
      return Storage.getters.DAY_SHOW
    },


    checbox_individual(){
      return Storage.getters.CHECBOX_INDIVIDUAL
    },
    checbox_individual_show(){
      return Storage.getters.CHECBOX_INDIVIDUAL_SHOW
    },

    check_entity(){
      return Storage.getters.CHECK_ENTITY
    },
    applicable_rate(){
      return Storage.getters.APPLICABLE_RATE
    },


    formula_for_show(){
      return Storage.getters.FORMULA_FOR_SHOW
    },
    rate_period(){
      return Storage.getters.RATE_PERIOD
    },

  },

  watch:{

  },
  components:{
    ToolTip,
  },
  created(){
  //  Тут помещаюстя Шина событий
  }
};
</script>
<style scoped>
</style>
