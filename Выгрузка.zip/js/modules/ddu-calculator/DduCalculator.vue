<template lang="pug">
  div.property-calculator__body.ddu__calculator-body.white
    .property-calculator__body-row.ddu__body-row
      div.property-calculator__calculations.js--tax-deduction_calculations
        template(v-if="!pop_up")
          pop-up(
            :paramText="text_pop_up"
            v-on:eventClosePopUp="closePopUp($event)"
          )

        template
          component-key-rate
        .ddu__bg-margin
          template
            component-apartment-price
        .property-calculator__several-columns.two-columns.grow
          template
            component-date-transfer(
              :first_period_date ="first_period_date"
            )
          template
            component-date-actual-transfer

        .property-calculator__block

          template
            component-checkbox



          //template
          //  component-button(
          //    v-on:eventCalculate="showCalculation"
          //  )

      div.property-calculator__container-result.refinancing-calc__container-result.first-show
        .property-calculator__wrapper-detailed-result.black.js-scroll
          template
            component-final-block-confirmed(
            :html_list="html_list"
          )
        p.refinancing-calc__footnote.
          Результат расчета предварительный, сформирован в ознакомительных целях на основе предоставленных сведений и
          не является официальным заключением, офертой, индивидуальной оценкой. Для получения подробной информации и
          индивидуальной оценки рекомендуем обратиться в кредитную организацию
</template>
<script>
import Vue from 'vue';
import eventBus from './development-tools/eventBus.vue';
import Storage from './development-tools/state.vue';
import ComponentKeyRate from './components/v-component-key-rate.vue';
import ComponentApartmentPrice from './components/v-component-apartment-price.vue';
import ComponentDateTransfer from './components/v-component-date-transfer.vue';
import ComponentDateActualTransfer from './components/v-component-date-actual-transfer.vue';
import ComponentCheckbox from './components/v-component-checkbox.vue';

import ComponentButton from './components/v-component-button.vue';
import ComponentFinalBlockConfirmed from './components/v-component-final-block-confirmed.vue';
import PopUp from './components/v-component-pop-up.vue';

import ToolTip from './components/v-component-tooltip.vue';

export default {
  name: 'DduCalculator',
  data(){
    return {
      key_rates:null,
      first_period_date:null,

      pop_up:true,
      text_pop_up:null,
      hint_text:'Если дохода не было, укажите 0',


      final_state_confirmed:null,
      final_result:false,
      state_for_button:null,

      html_list:null,
      // final_result=false
    }
  },
  methods:{
    contentPopUp(ev){
      this.pop_up=ev.condition
      this.text_pop_up=ev.text
    },
    closePopUp(ev){
      this.pop_up=ev
    },
    callModal(ev){
      this.pop_up=ev.state
      this.text_pop_up=ev.text
      if(ev.state===false){
        this.state_for_button=false
      }
    },

    receivedData(){
      //получаю ключевые ставки
      let key_rates = this.$attrs.key_rates
      key_rates = JSON.parse(key_rates);
      this.first_period_date = new Date(String(Object.keys(key_rates[0])[0]).substr(6, 4)+"-"+String(Object.keys(key_rates[0])[0]).substr(3, 2)+"-"+String(Object.keys(key_rates[0])[0]).substr(0, 2))
      Storage.dispatch('ActionKeyRates',key_rates)

      let moratorium_dates = this.$attrs.moratorium_dates
      moratorium_dates = JSON.parse(moratorium_dates);
      Storage.dispatch('ActionMoratorium',moratorium_dates)

      let lower_rate = this.$attrs.lower_rate
      lower_rate = JSON.parse(lower_rate);
      Storage.dispatch('ActionLowerRate',lower_rate)

      // let holidays = this.$attrs.holidays
      // holidays = JSON.parse(holidays);
      // Storage.dispatch('ActionHolidays',holidays)
    },
    receivedHtml(){

      this.html_list = this.$attrs.html_list

    },

    startMoratoriumMethod(){
      // Storage.dispatch('ActionMoratorium')
    },

    showCalculation(){
      this.final_result=false
      setTimeout(()=>{
        this.final_result=true
      },100)
    },



  },
  mounted(){
    this.receivedData()
    this.receivedHtml()
    this.startMoratoriumMethod()

  },
  computed:{
    appearance_error(){
      return Storage.getters.STATE_DIFFERENCE_DAYS
    },
    show_final_block(){
      return Storage.getters.SHOW_FINAL_BLOCK
    },


  },
  watch:{
  },
  components:{
    ComponentFinalBlockConfirmed,
    ComponentDateTransfer,
    ComponentDateActualTransfer,
    ComponentCheckbox,
    PopUp,
    ComponentKeyRate,
    ComponentApartmentPrice,
    ToolTip,
    ComponentButton,
  }
};
</script>
<style scoped>
</style>
