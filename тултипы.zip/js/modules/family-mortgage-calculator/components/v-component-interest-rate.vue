<template lang="pug">
.calc-tax-deduc-new__container-block.mor-rep-calculators__parent-tooltip-mobile.js--tooltip-parent
  .calc-tax-deduc-new__row-title-main-container(
    v-if="(transfer_tooltip!==null&&transfer_tooltip['interest-rate']&&transfer_tooltip['interest-rate']['info']!=='')&&(transfer_tooltip['interest-rate']['size']===''||transfer_tooltip['interest-rate']['size']==='small'||transfer_tooltip['interest-rate']['size']===undefined)"
  )
    .calc-tax-deduc-new__row-title-container
      p.calc-tax-deduc-new__row-title Процентная ставка, %
      span.content-note.desctop.content-note__center.js--content-note
        span.content-note__text {{transfer_tooltip["interest-rate"]["info"]}}
      span.content-note.mobile(
        v-if="transfer_tooltip['interest-rate']['info']!==''"
        @click="openTooltipMobile"
      )
    div(v-if="transfer_tooltip['interest-rate']['info']!==''")
      .select__background.modal-special-background(@click="closeTooltipMobile")
      .select-list__selection-window.modal-special-styles.js--openlist-body
        .select-list__head
          p Процентная ставка, %
          .select-list__head-close(@click="closeTooltipMobile")
            svg(width='10', height='10', viewbox='0 0 10 10', fill='none', xmlns='http://www.w3.org/2000/svg')
              path(fill-rule='evenodd', clip-rule='evenodd', d='M0.209209 0.209209C0.488155 -0.0697365 0.940416 -0.0697365 1.21936 0.209209L5 3.98985L8.78064 0.209209C9.05958 -0.0697365 9.51184 -0.0697365 9.79079 0.209209C10.0697 0.488155 10.0697 0.940416 9.79079 1.21936L6.01015 5L9.79079 8.78064C10.0697 9.05958 10.0697 9.51184 9.79079 9.79079C9.51184 10.0697 9.05958 10.0697 8.78064 9.79079L5 6.01015L1.21936 9.79079C0.940416 10.0697 0.488155 10.0697 0.209209 9.79079C-0.0697365 9.51184 -0.0697365 9.05958 0.209209 8.78064L3.98985 5L0.209209 1.21936C-0.0697365 0.940416 -0.0697365 0.488155 0.209209 0.209209Z', fill='#252628')
        .select-list__wr-search.mor-rep-calculators__wr-search
          p {{transfer_tooltip["interest-rate"]["info"]}}

  .calc-tax-deduc-new__row-title-main-container(
    v-if="transfer_tooltip!==null&&transfer_tooltip['interest-rate']&&transfer_tooltip['interest-rate']['info']!==''&&transfer_tooltip['interest-rate']['size']!==''&&transfer_tooltip['interest-rate']['size']==='big'&&transfer_tooltip['interest-rate']['size']!==undefined"
  )
    .calc-tax-deduc-new__row-title-container
      p.calc-tax-deduc-new__row-title Процентная ставка, %
      .content-note(
        @click="openModal"
        :data-tooltip="transfer_tooltip['interest-rate']['name']?transfer_tooltip['interest-rate']['name']:''"
      )

  .calc-tax-deduc-new__row-title-main-container(v-if="transfer_tooltip===null||transfer_tooltip['interest-rate']['info']===''")
    .calc-tax-deduc-new__row-title-container
      p.calc-tax-deduc-new__row-title Процентная ставка, %

  .calc-tax-deduc-new__col-input.js--number-old-rate.js--tex-deduc-input(@click="inputFocus")
    input(
      inputmode="decimal"
      type="text"
      ref="realtyInput"
      @focus="inpFocus"
      @blur="inputBlur"
      @click="inpRemoveMark"
      @keyup="keyUp"
    )
    .range-input__slider(ref="mortgagePrice")
  .calc-tax-deduc-new__wr-range
    p {{String(stgMin).replace('.', ',')}}
    p {{stgMiddle}}
    p {{stgMax}}
</template>

<script>
import eventBus from '../development-tools/eventBus.vue';
import noUiSlider from 'nouislider';
import Storage from '../development-tools/state.vue';
import IMask from 'imask';
import numberFormatting from '../mixin/numberFormatting.js';
import onlyNumbers from '../custom-scripts/only-numbers.js'

export default {
  name: 'v-interest-rate',
  mixins: [numberFormatting],
  data() {
    return {
      realtySlider: null,
      dataField: '6,0',
      dataFieldForCalculation: 6.0,
      stepApartment: 0.1,
      stgMin: 0.1,
      stgMiddle: 50,
      stgMax: 100,
      start: 6.0,
      input_salary: false,
      slider: false,
      mask_interest: null,
      isUpdating: false,
      isSliderDragging: false, // Добавить
      fractionalPart: 0.00, // Сохраняем сотые при движении ползунком
      wasManualInput: false // Флаг: был ли ввод с клавиатуры
    }
  },
  methods: {
    formatValue(value) {
      return parseFloat(value).toFixed(1).toString().replace('.', ',')
    },

    initRealtySlider() {
      this.realtySlider = noUiSlider.create(this.$refs.mortgagePrice, {
        start: [this.start],
        connect: 'lower',
        step: 0.01,
        range: {
          min: this.stgMin,
          max: this.stgMax
        },
      })

      this.realtySlider.on('start', () => {
        this.input_salary = false
      });

      this.realtySlider.on('slide', (values, handle) => {
        if (this.isUpdating) return
        this.isUpdating = true
        this.isSliderDragging = true

        const rawValue = parseFloat(values[handle])
        let newValue

        // Если значение близко к 0.1 — фиксируем как 0.1
        if (rawValue <= 0.1) {
          newValue = 0.1
        } else {
          // Иначе — двигаем целую часть, сохраняя дробную часть
          const integerPart = Math.floor(rawValue)
          newValue = integerPart + this.fractionalPart

          // Если значение не менялось вручную, и было целым — сохраняем .00
          if (!this.wasManualInput && this.fractionalPart === 0) {
            newValue = integerPart
          }

          // Ограничиваем максимум
          if (newValue > this.stgMax) newValue = this.stgMax
          if (newValue < 0.1) newValue = 0.1
        }

        this.updateInputValue(newValue)
        this.isSliderDragging = false
        this.isUpdating = false
      });

      this.realtySlider.on('set', (values, handle) => {
        if (this.isUpdating) return
        this.isUpdating = true
        this.isSliderDragging = true

        const rawValue = parseFloat(values[handle])
        let newValue

        if (rawValue <= 0.1) {
          newValue = 0.1
        } else {
          const integerPart = Math.floor(rawValue)
          newValue = integerPart + this.fractionalPart

          if (!this.wasManualInput && this.fractionalPart === 0) {
            newValue = integerPart
          }

          if (newValue > this.stgMax) newValue = this.stgMax
          if (newValue < 0.1) newValue = 0.1
        }

        this.updateInputValue(newValue)
        this.updateStoreValue(newValue)
        this.isSliderDragging = false
        this.isUpdating = false
      });
    },

    initInputMask() {
      const maskOptions = {
        mask: Number,
        scale: 2,
        thousandsSeparator: '',
        padFractionalZeros: true,
        normalizeZeros: true,
        radix: ',',
        mapToRadix: ['.', ','],
        min: this.stgMin,
        max: this.stgMax,
        autofix: true,
        prepare: (value) => value.replace(/[бю\/]/gi, ',')
      };

      this.mask_interest = new IMask(this.$refs.realtyInput, maskOptions)
      this.mask_interest.value = this.formatValue(this.start)

      this.mask_interest.on('accept', () => {
        if (this.isUpdating || !this.mask_interest.typedValue) return
        this.isUpdating = true

        let value = parseFloat(this.mask_interest.unmaskedValue.replace(',', '.'))
        if (isNaN(value)) value = this.stgMin

        // Корректируем на минимум
        if (value < this.stgMin) value = this.stgMin
        if (value > this.stgMax) value = this.stgMax

        // Сохраняем дробную часть
        this.fractionalPart = value - Math.floor(value)
        this.wasManualInput = true // Флаг: пользователь вводил вручную

        this.updateSliderValue(value)
        this.updateInputValue(value)
        this.updateStoreValue(value)

        this.isUpdating = false
      });
    },

    updateInputValue(value) {
      // Округляем до сотых
      const roundedValue = Math.round(value * 100) / 100
      const formattedValue = roundedValue.toString().replace('.', ',')

      this.dataField = formattedValue
      this.dataFieldForCalculation = roundedValue

      // Сохраняем дробную часть для будущего использования ползунком
      if (!this.isSliderDragging) {
        this.fractionalPart = roundedValue - Math.floor(roundedValue)
      }

      if (this.mask_interest) {
        this.mask_interest.unmaskedValue = roundedValue.toString()
      } else {
        this.$refs.realtyInput.value = formattedValue
      }
    },

    updateSliderValue(value) {
      if (this.realtySlider) {
        const roundedValue = Math.round(value * 100) / 100
        this.realtySlider.set(roundedValue)
      }
    },

    updateStoreValue(value) {
      const roundedValue = Math.round(value * 100) / 100
      Storage.dispatch('ActionInterestRate', roundedValue)
    },

    inputFocus(el) {
      const element = el.currentTarget
      element.querySelector('input').focus()
    },

    keyUp(e) {
      if (e.key === 'Enter') {
        this.$refs.realtyInput.blur()
      }
    },

    inpRemoveMark(el) {
      const element = el.currentTarget;
      if (element.value === '0' || element.value === '0 %') {
        element.value = ''
      }
    },

    inputBlur(el) {
      const element = el.currentTarget
      element.closest('.js--tex-deduc-input').classList.remove('input-focus')

      if (!element.value || element.value === '') {
        this.wasManualInput = false // Сброс флага
        this.fractionalPart = 0.1 - 0 // = 0.1
        this.updateSliderValue(0.1)
        this.updateInputValue(0.1)
        this.updateStoreValue(0.1)
      }
    }
  },

  beforeDestroy() {
    if (this.mask_interest) {
      this.mask_interest.destroy()
    }
    if (this.realtySlider) {
      this.realtySlider.destroy()
    }
  },

  mounted() {
    this.initRealtySlider()
    this.initInputMask()
    this.updateStoreValue(this.start)

    // Инициализация дробной части
    this.fractionalPart = this.start - Math.floor(this.start)
    if (this.fractionalPart === 0) this.wasManualInput = false
    else this.wasManualInput = true

    if (this.answers && this.answers.bet) {
      const initialValue = parseFloat(this.answers.bet)
      const clampedValue = Math.max(this.stgMin, Math.min(this.stgMax, initialValue))

      this.fractionalPart = clampedValue - Math.floor(clampedValue)
      this.wasManualInput = true

      this.updateSliderValue(clampedValue)
      this.updateInputValue(clampedValue)
      this.updateStoreValue(clampedValue)
    }
  },

  computed: {
    transfer_tooltip() {
      return Storage.getters.TRANSFERTOOLTIP
    },
    answers() {
      return Storage.getters.ANSWERS
    },
  }
};
</script>

<style scoped>
</style>
