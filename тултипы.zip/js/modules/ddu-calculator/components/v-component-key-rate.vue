<template lang="pug">
  .property-calculator__row

    .property-calculator__block-area.ddu__key-rate
      .ddu__key-rate-block
        svg(width='24', height='24', viewbox='0 0 24 24', fill='none', xmlns='http://www.w3.org/2000/svg')
          circle(cx='12', cy='12', r='11', stroke='#EEA20F', stroke-width='2')
          path(d='M12 6V14', stroke='#EEA20F', stroke-width='2', stroke-linecap='round')
          circle(cx='12', cy='18', r='1', fill='#EEA20F')
        p С {{array_key_rate.date}} ключевая ставка ЦБ – {{array_key_rate.key}}%
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import PopUp from '../components/v-component-pop-up.vue';
export default {
  name: 'v-component-key-rate',
  data(){
    return {
      select_region:null
    }
  },
  methods:{


    sendKeyRate(){
      let value = '9.5'
      if(value.includes(',')){
        value = value.replace(',','.')
      }
      // Storage.dispatch('ActionKeyRate',value)
    },
  },
  mounted(){
    this.sendKeyRate()


  },
  computed:{
    array_key_rate(){
      return Storage.getters.LAST_CHANGE_KEY
    },
  },
  watch:{
  },
  components:{
    PopUp
  }
};
</script>
<style scoped>
</style>
