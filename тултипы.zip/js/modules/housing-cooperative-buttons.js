/* eslint-disable */
import { housingCooperativeChoosenAccordion } from './accordions';

const COOKIE_KEY = 'BITRIX_SM_housing_cooperative_chosen';
const BUTTON_SELECTED_CLASS = 'btn_selected';

function findCounterEl() {
  return document.querySelector('.js--housing-cooperative-choosen-results-counter');
}

function findChoseButton() {
  return document.querySelector('.js--housing-cooperative-filter-chose-btn');
}

function findAddedNotification() {
  return document.querySelector('.js--housing-cooperative-notification');
}

// возвращает куки с указанным name,
// или undefined, если ничего не найдено
function getCookie(name) {
  const matches = document.cookie.match(new RegExp(
      // eslint-disable-next-line no-useless-escape
      `(?:^|; )${name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1')}=([^;]*)`
  ));
  return matches ? decodeURIComponent(matches[1]) : undefined;
}

function writeCookie(array) {
  const cookieValue = array.join('|');
  document.cookie = `${COOKIE_KEY}=${cookieValue}; path=/`;
}

// eslint-disable-next-line camelcase,no-unused-vars
function normalizeCountForm(number, words_arr) {
  // eslint-disable-next-line no-param-reassign
  number = Math.abs(number);
  if (Number.isInteger(number)) {
    const options = [2, 0, 1, 1, 1, 2];
    // eslint-disable-next-line max-len
    return words_arr[(number % 100 > 4 && number % 100 < 20) ? 2 : options[(number % 10 < 5) ? number % 10 : 5]];
  }
  return words_arr[1];
}

function setStateToChoseButton(array) {
  const declination = normalizeCountForm(array.length, ['выбранному', 'выбранным', 'выбранным']);
  const choseButton = findChoseButton();
  choseButton.querySelector('.js--declination-word').innerText = declination;
  choseButton.querySelector('.housing-cooperative-filter__chose-btn-counter').innerText = array.length;
  if (array.length > 0) {
    choseButton.removeAttribute('disabled');
  } else {
    choseButton.setAttribute('disabled', '');
  }
}

function setCookie(code) {
  let currentValues = getCookie(COOKIE_KEY);
  if (!currentValues) {
    currentValues = [];
  } else {
    currentValues = currentValues.split('|');
  }
  if (!currentValues.includes(code)) currentValues.push(code);
  writeCookie(currentValues);
  if (findChoseButton()) setStateToChoseButton(currentValues);
}

function showNotification() {
  const addedNotification = findAddedNotification();
  if (addedNotification) {
    addedNotification.classList.add('show');
    addedNotification.querySelector('.js--housing-cooperative-notification-close').onclick = () => {
      addedNotification.classList.remove('show');
    };
  }
}

function deleteCookie(code) {
  const currentValues = getCookie(COOKIE_KEY);
  if (!currentValues) return;
  const currentValuesArray = currentValues.split('|');
  const indexOfCode = currentValuesArray.indexOf(code);
  currentValuesArray.splice(indexOfCode, 1);
  if (currentValuesArray.length === 0) {
    document.cookie = `${COOKIE_KEY}=false; path=/; max-age=-1`;
  } else {
    writeCookie(currentValuesArray);
  }
  if (findChoseButton()) setStateToChoseButton(currentValuesArray);
}

function setButtonToSelected(button) {
  button.classList.add(BUTTON_SELECTED_CLASS);
}

function setButtonToUnselected(button) {
  button.classList.remove(BUTTON_SELECTED_CLASS);
}

function deleteCard(button) {
  button.closest('.card-housing-cooperative').remove();
  const cardInList = document.querySelector(`.housing-cooperative-choosen__results-list-item[data-code="${button.dataset.code}"]`);
  if (cardInList) cardInList.remove();
  housingCooperativeChoosenAccordion();
}

function setEmptyState() {
  document.querySelector('.js--housing-cooperative-choosen-empty').classList.remove('d-none');
  document.querySelector('.js--housing-cooperative-choosen').classList.add('d-none');
  document.querySelector('.page-title-block').classList.add('d-none');
}

function decreaseCounter() {
  // eslint-disable-next-line no-param-reassign
  const counterEl = findCounterEl();
  if (counterEl) {
    counterEl.innerText -= 1;
    if (+counterEl.innerText === 0) setEmptyState();
  }
}

function addButtonHandler(button) {
  // console.log(button);
  const btns = document.querySelectorAll(`[data-code='${button.dataset.code}']`);
  if (!button.classList.contains(BUTTON_SELECTED_CLASS)) {
    setCookie(button.dataset.code);
    btns.forEach((btn) => {
      setButtonToSelected(btn);
    });
    showNotification();
  } else {
    deleteCookie(button.dataset.code);
    btns.forEach((btn) => {
      setButtonToUnselected(btn);
    });
  }
}

function removeButtonHandler(button) {
  deleteCookie(button.dataset.code);
  deleteCard(button);
  decreaseCounter();
}

function activeButtonsLoading() {
  const elementButton = document.querySelectorAll('.js--housing-cooperative-add-buttons .card-housing-cooperative__adder');
  const container = document.querySelector('.js--housing-cooperative-add-buttons');
  if(container){
    for (let item of elementButton) {
      if (item.classList.contains('btn_selected')) {
        item.classList.remove('btn_selected');
      }
    }
    const codeButtons = getCookie('BITRIX_SM_housing_cooperative_chosen');
    if (codeButtons) {
      const massiveCodeButtons = codeButtons.split('|');
      for (let item of elementButton) {
        const dataCode = item.getAttribute('data-code');
        if (massiveCodeButtons.includes(dataCode) && !item.classList.contains('btn_selected') && !item.disabled) {
          item.classList.add('btn_selected');
        }
      }
    }
  }
}

function changingScreensFilter (){
  const beesenderchat = document.querySelector('.js--housing-cooperative-add-buttons');
  const observerOptions = {
    subtree: true,
    childList: true
  };
  const observer = new MutationObserver(onUrlChange);
  if (beesenderchat) {
    observer.observe(beesenderchat, observerOptions);
  }
}

function reloadingCards (){
    const beesenderchat = document.querySelector('.js--housing-cooperative-add-buttons');
    const observerOptions = {
      subtree: true,
      childList: true
    };
    const observer = new MutationObserver(onUrlChange);
    if (beesenderchat) {
      observer.observe(beesenderchat, observerOptions);
    }

  let lastUrl = location.href;
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      onUrlChange();
    }
  }).observe(document, {subtree: true, childList: true});
}

function onUrlChange() {
  setTimeout(()=>{
    activeButtonsLoading();
  },100)
}

export default function housingCooperativeButtons() {
  const removeButtons = document.querySelectorAll('.js--housing-cooperative-remover');
  const addButtonsWrap = document.querySelector('.js--housing-cooperative-add-buttons');
  if (addButtonsWrap) {
    addButtonsWrap.addEventListener('click', (e) => {
      const button = e.target.closest('.js--housing-cooperative-adder');
      if (button) addButtonHandler(button);
    });
  }

  removeButtons.forEach((removeButton) => {
    removeButton.addEventListener('click', () => {
      removeButtonHandler(removeButton);
    }, { once: true });
  });
  activeButtonsLoading();
  // reloadingCards();
  changingScreensFilter();
}
