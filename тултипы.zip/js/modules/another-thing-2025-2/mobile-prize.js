/* eslint-disable */
import AddClassBody from '../redesign-site/disallow-body-scrolling';
import RemoveClassBody from '../redesign-site/allow-body-scrolling';
export default function mobilePrize(el) {
  const btn = document.querySelector('.js--pagination-btn-mobile');
  const background = document.querySelector('.js--another-thing-background');

  if (btn) {
    btn.onclick = (el) =>{
      const element = el.currentTarget;
      if (element.closest('.js--pagination-parent-mobile')) {
        if (element.closest('.js--pagination-parent-mobile').classList.contains('active')) {
          element.closest('.js--pagination-parent-mobile').classList.remove('active')
          RemoveClassBody();
        }
        else {
          element.closest('.js--pagination-parent-mobile').classList.add('active')
          AddClassBody();
        }
      }

    }
  }
  if (background) {
    background.onclick = (el) =>{
      const element = el.currentTarget;
      if (element.closest('.js--pagination-parent-mobile')) {
        element.closest('.js--pagination-parent-mobile').classList.remove('active')
        RemoveClassBody();
      }

    }
  }




}
