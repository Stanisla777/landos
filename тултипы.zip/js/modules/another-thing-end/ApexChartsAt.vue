<template lang="pug">
  .personal-office__end-container-chart
    template
      apex-chart-at-ring
    template
      apex-chart-at-radar



</template>

<script>
// const ApexChartAtRing = () => import ('./component/ApexChartAtRing.vue');
import ApexChartAtRing from './component/ApexChartAtRing.vue';
import ApexChartAtRadar from './component/ApexChartAtRadar.vue';


export default {
  name: 'ApexChartAt',
  data() {
    return {

    }
  },
  mounted() {

  },
  components: {
    ApexChartAtRing,
    ApexChartAtRadar
  }
}
</script>
