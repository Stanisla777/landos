<template lang="pug">
  .test-a__container-bonus-task(
    ref="gamedd_wrapper"
  )
    .test-a__close-window.js--close--modals-window(
      @click="closeModal"
    )
      svg(width='24', height='24', viewbox='0 0 24 24', fill='none', xmlns='http://www.w3.org/2000/svg')
        circle(cx='12', cy='12', r='11', fill='#F1F2F4', stroke='#F1F2F4', stroke-width='2')
        path(d='M8.11137 15.8887C7.9161 15.6934 7.9161 15.3769 8.11137 15.1816L15.1824 8.11054C15.3777 7.91527 15.6943 7.91527 15.8895 8.11053V8.11053C16.0848 8.3058 16.0848 8.62238 15.8895 8.81764L8.81847 15.8887C8.62321 16.084 8.30663 16.084 8.11137 15.8887V15.8887Z', fill='#1C1B28')
        path(d='M15.8887 15.8896C15.6934 16.0849 15.3769 16.0849 15.1816 15.8896L8.11054 8.81855C7.91527 8.62328 7.91527 8.3067 8.11054 8.11144V8.11144C8.3058 7.91618 8.62238 7.91618 8.81764 8.11144L15.8887 15.1825C16.084 15.3778 16.084 15.6943 15.8887 15.8896V15.8896Z', fill='#1C1B28')

    p.test-a__question.
      Бонусное задание
    .test-a__list.test-a__bonus-list(v-html="param.description")

    .test-a__final-wr-btn
      a(
        v-if="active_btn&&status_internet"
        target="_blank"
        v-bind:href="param.url"
        @click.once="sendPost"
      ).test-a__btn.test-a__btn-bonus.green Перейти
      .test-a__btn.test-a__btn-bonus.unactive(v-if="!active_btn||status_internet===false") Перейти

      .test-a__final-result-container-prise
        p.test-a__final-result-prise-label Чтобы получить
        .test-a__final-result-wr-prise
          .test-a__final-result-prise-item
            p +{{param.canBeEarned.score}}
            .test-a__final-result-prise-item-img
              img(src="/dist/img/scored-icon1.png")
          .test-a__final-result-prise-item
            p +{{param.canBeEarned.points}}
            .test-a__final-result-prise-item-img
              img(src="/dist/img/scored-icon2.png")
    p.test-a__error-hint(v-if="status_internet===false") Нет интернета
</template>
<script>
import Storage from '../development-tools/state.vue';

export default {
  name: 'bonus-task',
  props:['param'],
  data(){
    return {
      active_btn:true

    }
  },
  methods: {
    sendPost(el){
      const element = el.currentTarget
      const val = true
      Storage.dispatch('ActionBonus',[this.param.id,val])
      this.active_btn=false
    },
    closeModal(el){
      const element = el.currentTarget
      element.closest('.modal-for-polls').classList.remove('open')
      document.body.classList.remove('body-unactive')
      document.body.classList.remove('body-modal')

      const scrollY = document.body.style.top;
      document.body.style.position = '';
      document.body.style.top = '';
      window.scrollTo(0, parseInt(scrollY || '0') * -1);

      document.ontouchmove =  (e)=> {
        return true;
      }
    },
  },
  computed: {
    status_internet() {
      return Storage.getters.STATUSINTERNET;
    },
    status_btn() {
      return Storage.getters.STATUSBTN;
    },

  },
  mounted() {
  },
};
</script>
<style scoped>
</style>
