export default {
  methods: {
    autoHeight() {
      if (document.documentElement.clientWidth < 470) {
        const parent = this.$refs.test_container.closest('.js--test-a-slider');
        // eslint-disable-next-line camelcase
        const parent_height = parent.offsetHeight;
        // eslint-disable-next-line camelcase
        const title_height = parent.querySelector('.test-a__question').offsetHeight + 32;
        // eslint-disable-next-line camelcase
        parent.querySelector('.test-a__container').setAttribute('style', `height:${(parent_height - title_height) - 4}px`);
      }
    },
  }
};
