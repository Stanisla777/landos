<template lang="pug">
  .gameddreg__container(
    ref="gamedd_wrapper"
  )
    template(
      v-if="step==='enterVK'"
    )
      registration-login-via-v-k(
        :vk_address="vk_address"
        :vk_app_id="vk_app_id"
      )
    template(
      v-if="step==='completion'"
    )
      registration-completion(
        :user_data="user_data"
      )
    template(
      v-if="step==='confirmation'"
    )
      number-confirmation
    template(
      v-if="step==='finish'"
    )
      registration-finish
    template(
      v-if="step==='change_number'"
    )
      registration-change-number
    template(
      v-if="step==='change_mail'"
    )
      registration-change-mail

    template(
      v-if="step==='change_number_account'"
    )
      change-number-account

    template(
      v-if="step==='confirmation_account'"
    )
      number-confirmation-account

    template(
      v-if="step==='change_mail_account'"
    )
      change-mail-account


    template(
      v-if="step==='finish_change_tel_account'"
    )
      finish-number-changed

    template(
      v-if="step==='finish_change_mail_account'"
    )
      finish-mail-changed

    template(
      v-if="step==='mail_notification'"
    )
      registration-mail-notification
    template(
      v-if="step==='change_mail_notification'"
    )
      registration-change-mail-notification
    template(
      v-if="step==='end_registration'"
    )
      registration-end-registration



</template>
<script>
import Vue from 'vue';
import eventBus from './development-tools/eventBus.vue';
import Storage from './development-tools/state.vue';
import RegistrationLoginViaVK from './components/RegistrationLoginViaVK.vue';
import RegistrationCompletion from './components/RegistrationCompletion.vue';
import NumberConfirmation from './components/NumberConfirmation.vue';
import RegistrationFinish from './components/RegistrationFinish.vue';
import RegistrationChangeNumber from './components/RegistrationChangeNumber.vue';
import FinishNumberChanged from './components/FinishNumberChanged.vue';
import RegistrationChangeMail from './components/RegistrationChangeMail.vue';
import FinishMailChanged from './components/FinishMailChanged.vue';
import ChangeNumberAccount from './components/ChangeNumberAccount.vue';
import NumberConfirmationAccount from './components/NumberConfirmationAccount.vue';
import ChangeMailAccount from './components/ChangeMailAccount.vue';
import RegistrationMailNotification from './components/RegistrationMailNotification.vue';
import RegistrationChangeMailNotification from './components/RegistrationChangeMailNotification.vue';
import RegistrationEndRegistration from './components/RegistrationEndRegistration.vue';

export default {
  name: 'GameddRegistration',
  data(){
    return {
      // step:'',
      // vk_address:null,
      user_data:null,
      // vk_app_id:null,
    }
  },
  props:['vk_address','vk_app_id'],
  methods:{
    startMoratoriumMethod(){
      Storage.dispatch('ActionMoratorium')
    },
  },
  mounted(){
    //это если бэк ничего не передаёт в step и происходит нажатие кнопки Изменить телефон в личном кабинете
    const btn_change_number = document.querySelector('.js--call-game-task[data-step="change_number_account"]')
    const btn_change_mail = document.querySelector('.js--call-game-task[data-step="change_mail_account"]')
    if(btn_change_number){
      btn_change_number.onclick=()=>{
        const data = btn_change_number.getAttribute('data-step')
        Storage.dispatch('ActionStep',data)
      }
    }
    if(btn_change_mail){
      btn_change_mail.onclick=()=>{
        const data = btn_change_mail.getAttribute('data-step')
        Storage.dispatch('ActionStep',data)
      }
    }
    const modal = this.$refs.gamedd_wrapper.closest('#modal-at-registration')
    if(modal&&modal.classList.contains('open')){
      document.body.setAttribute('style',`top:-${window.scrollY}px;position: fixed;`);
    }
  },
  computed:{
    step(){
      return Storage.getters.STEP
    },
  },
  watch:{
  },
  components:{
    RegistrationLoginViaVK,
    RegistrationCompletion,
    NumberConfirmation,
    RegistrationFinish,
    RegistrationChangeNumber,
    FinishNumberChanged,
    RegistrationChangeMail,
    FinishMailChanged,
    ChangeNumberAccount,
    NumberConfirmationAccount,
    ChangeMailAccount,
    RegistrationMailNotification,
    RegistrationChangeMailNotification,
    RegistrationEndRegistration

  }
};
</script>
<style scoped>
</style>
