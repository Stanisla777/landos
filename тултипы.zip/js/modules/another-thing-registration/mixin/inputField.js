/* eslint-disable */
import IMask from 'imask';
let mask;
export default {
  methods: {
    inputChangeMail(el){
      const element = el.currentTarget
      const val = element.value.length
      if(val>0&&!element.value.match(/^.+@.+\..+$/igm)){
        this.error=true
        element.closest('.js--reg-input-mail').classList.add('error')
      }
      else if(val>0&&element.value.match(/^.+@.+\..+$/igm)){
        this.error=false
        element.closest('.js--reg-input-mail').classList.remove('error')
      }
    },
    inputChangeTel(el){
      const element = el.currentTarget
      const val = element.value.length
      if(val>=16){
        this.error_tel=false
        element.closest('.js--reg-tel-mask').classList.remove('error')
      }
      else {
        this.error_tel=true
        element.closest('.js--reg-tel-mask').classList.add('error')
      }
    },
    focusInput(el){
      const element = el.currentTarget
      element.closest('.js--reg-input').classList.add('active')
    },
    bindInput(el){
      const element = el.currentTarget
      const val = element.value.length
      if(val===0){
        element.closest('.js--reg-input').classList.remove('active')
      }
      // if((element.closest('.js--reg-input').classList.contains('js--reg-input-mail')&&val>0&&!element.value.match(/^.+@.+\..+$/igm))){
      //   this.error=true
      //   element.closest('.js--reg-input').classList.add('error')
      // }
      // else if((element.closest('.js--reg-input').classList.contains('js--reg-input-mail')&&val>0&&element.value.match(/^.+@.+\..+$/igm))){
      //   this.error=false
      //   element.closest('.js--reg-input').classList.remove('error')
      // }

    },
    hoverBtnOver(el){
      const element = el.currentTarget
      if(!element.closest('.js--reg-input').classList.contains('error')){
        this.$refs.parentInput.querySelector('.gameddreg__input-error').style.opacity=0
        if(element.closest('.js--reg-input').querySelector('input').value.length>0){
          element.closest('.js--reg-input').style.borderColor='#82BF00'
        }

      }

    },
    hoverBtnOut(el){
      const element = el.currentTarget
      this.$refs.parentInput.querySelector('.gameddreg__input-error').style.opacity=1
    },
    // clearField(el){
    //   const element = el.currentTarget
    //   if(element.closest('.js--reg-input').classList.contains('js--reg-tel-mask')){
    //     this.InputTel=''
    //     mask.value=''
    //   }
    //   if(element.closest('.js--reg-input').classList.contains('js--reg-input-name')){
    //     this.InputName=''
    //   }
    //   if(!element.closest('.js--reg-input').classList.contains('js--reg-tel-mask')){
    //     element.closest('.js--reg-input').querySelector('input').value=''
    //   }
    //   element.closest('.js--reg-input').classList.remove('error')
    //   element.closest('.js--reg-input').classList.remove('active')
    //   if(element.closest('.js--reg-input').classList.contains('js--reg-input-mail')){
    //     this.error=false
    //   }
    //   if(element.closest('.js--reg-input').classList.contains('js--reg-tel-mask')){
    //     this.error=false
    //   }
    //   this.active_btn=false
    //   element.classList.remove('active')
    //
    // },

    fullnessCheck(){
      const array = document.querySelectorAll('.js--gameddreg-wrapper .js--reg-input')
      const array_length = array.length
      let fullness_input=0
      for (let item of array){
        const inp_val = item.querySelector('input').value.length

        if(item.classList.contains('js--reg-input-mail')&&item.querySelector('input').value.match(/^.+@.+\..+$/igm)&&item.querySelector('input').value.length>0){
          fullness_input+=1
          item.classList.remove('error')
          this.error=false
        }
        if(item.classList.contains('js--reg-tel-mask')&&item.querySelector('input').value.length>=16){
          fullness_input+=1
          item.classList.remove('error')
          this.error_tel=false
        }


        if(!item.classList.contains('js--reg-input-mail')&&!item.classList.contains('js--reg-tel-mask')&&item.querySelector('input').value.length>0){
          fullness_input+=1
        }

        if(inp_val>0){
          item.querySelector('.test-a__entry-field-add-icon').classList.add('active')
          item.classList.add('active')
        }
        else {
          item.querySelector('.test-a__entry-field-add-icon').classList.remove('active')
          item.classList.remove('active')
        }

      }
      if(array_length===fullness_input){
        this.active_btn=true
      }
      else {
        this.active_btn=false
      }
    },


  }
};
