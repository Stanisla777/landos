<template lang="pug">
  .gameddreg__wrapper(
    ref="gamedd_wrapper"
  )
    .gameddreg__come-back.gameddreg__come-back-change-mail(@click="comeBack")
      svg(width='24', height='24', viewbox='0 0 24 24', fill='none', xmlns='http://www.w3.org/2000/svg')
        path(d='M19 12H5', stroke='white', stroke-width='2', stroke-linecap='round', stroke-linejoin='round')
        path(d='M12 19L5 12L12 5', stroke='white', stroke-width='2', stroke-linecap='round', stroke-linejoin='round')
    template
      registration-close
    p.gameddreg__title  Введите номер телефона
    p.gameddreg__sub-title.
      Введите другой номер телефона, который будет привязан к вашему аккаунту

    .gameddreg__container-input
      .gameddreg__wr-input
        p.test-a__entry-field-fin-add-des Номер телефона
        .test-a__entry-field-fin-add.gameddreg__input.js--reg-input.js--reg-tel-mask
          input(type="text" inputmode="numeric" placeholder="+7 ххх ххх хх хх")(
            ref="inputTelefon"
            @focus="focusInput"
            @blur="lossFocus"
            @keyup="inputVal"
            @paste="pasteTel"
          )
          .test-a__entry-field-add-icon(
            @click="clearFieldState"
            @mouseover="elemMouseOver"
            @mouseout="elemMouseOut"
          )
            svg(width='14', height='14', viewbox='0 0 14 14', fill='none', xmlns='http://www.w3.org/2000/svg')
              path(fill-rule='evenodd', clip-rule='evenodd', d='M5.58544 6.99975L0.635742 11.9495L2.04996 13.3637L6.99966 8.41396L11.9495 13.3638L13.3637 11.9495L8.41387 6.99975L13.3637 2.04996L11.9495 0.635742L6.99966 5.58553L2.04996 0.635835L0.635746 2.05005L5.58544 6.99975Z', fill='white')
          p.gameddreg__input-error Некорректное значение в поле
    .gameddreg__wr-btn-input.gameddreg__button
      .test-a__add-zone-btn.green.test-a__btn(
        v-if="active_btn"
        @click="sendPost"
      ) Продолжить
      .test-a__add-zone-btn.unactive.test-a__btn(
        v-if="!active_btn"
      ) Продолжить
</template>

<script>
import IMask from 'imask';
import Storage from '../development-tools/state.vue';
import RegistrationClose from './RegistrationClose.vue';
import inputField from '../mixin/inputField';
import axios from 'axios';
import Cookies from 'js-cookie'
let mask;

export default {
  name: 'RegistrationChangeNumber',
  // mixins: [inputField],
  props: {},
  data() {
    return {
      active_btn:false,
      InputName:'',
      InputSurName:'',
      InputMail:'',
      error:false,
      error_tel:false,
    }
  },

  methods: {
    comeBack(){
      this.countdownBack()
      Storage.dispatch('ActionStep','confirmation')

    },
    elemMouseOver(el){
      const element = el.currentTarget
      element.closest('.js--reg-input').classList.add('not_error')
    },
    elemMouseOut(el){
      const element = el.currentTarget
      element.closest('.js--reg-input').classList.remove('not_error')

    },
    focusInput(el){
      const element = el.currentTarget
      element.closest('.js--reg-input').classList.add('active')
    },
    lossFocus(el){
      const element = el.currentTarget
      const val = element.value.length
      if(val===0){
        element.closest('.js--reg-input').classList.remove('active')
        element.closest('.js--reg-input').querySelector('.test-a__entry-field-add-icon').classList.remove('active')
      }

      if (element.closest('.js--reg-input')
        .classList.contains('js--reg-tel-mask') && !element.closest('.js--reg-input').classList.contains('not_error')) {
        if (val<16&&val>2) {
          element.closest('.js--reg-tel-mask').classList.add('error');
        }
      }
    },
    pasteTel(el){
      const element = el.currentTarget
      let char = (el.clipboardData || window.clipboardData).getData('text');
      char = char.replace(/\D/g, '')
      if (char.substring(0, 1)=='8'||char.substring(0, 1)=='+'||char.substring(0, 1)=='7') {
        if(char.length>=11){
          element.closest('.js--reg-tel-mask').classList.remove('error');
          this.active_btn=true
        }
        else{
          element.closest('.js--reg-tel-mask').classList.add('error');
          this.active_btn=false
        }

      }
      else if(char.substring(0, 1)!='8'||char.substring(0, 1)!='+'||char.substring(0, 1)!='9'||char.substring(0, 1)!='7'){
        if(char.length>=10){
          element.closest('.js--reg-tel-mask').classList.remove('error');
          this.active_btn=true
        }
        else{
          element.closest('.js--reg-tel-mask').classList.add('error');
          this.active_btn=false
        }

      }


      element.closest('.js--reg-input').querySelector('.test-a__entry-field-add-icon').classList.add('active')

    },
    inputVal(el){
      const element = el.currentTarget
      if(element.value.length>0){
        element.closest('.js--reg-input').querySelector('.test-a__entry-field-add-icon').classList.add('active')
      }
      if (element.value.length>=16) {
        element.closest('.js--reg-tel-mask').classList.remove('error');
        this.active_btn=true
      }
      if (element.value.length<16) {
        this.active_btn=false
      }

      if(element.value.length===0){
        element.closest('.js--reg-input').querySelector('.test-a__entry-field-add-icon').classList.remove('active')
        element.closest('.js--reg-input').classList.remove('error')
      }


    },
    clearFieldState(el){
      const element = el.currentTarget
      element.closest('.js--reg-input').classList.remove('active')
      element.classList.remove('active')
      if(element.closest('.js--reg-input').classList.contains('js--reg-tel-mask')){
        element.closest('.js--reg-input').querySelector('input').value=''
        element.closest('.js--reg-input').classList.remove('error')
        mask.value=''
      }
      else {
        element.closest('.js--reg-input').querySelector('input').value=''
        element.closest('.js--reg-input').classList.remove('error')
      }
      this.active_btn=false

      // Storage.dispatch('ActionClearField',)
    },
    inputCost(){
      const input_status = document.querySelectorAll('.js--reg-tel-mask input');
      const maskOptions = {
        mask: '+{7} 000 000 00 00',
        prepare: (appended, masked) => {
          if (appended === '8' && masked.value === '') {
            return '';
          }

          return appended;
        },

      };
      for (const item of input_status) {
        mask = IMask(item, maskOptions);
      }
    },

    countdownBack() {
      if(this.transition_step>0){
        let now_time = new Date();
        let time_previous_window = Cookies.get('gamedd_time_begin');
        let data_time_previous_window = new Date(time_previous_window.replace(/(?:(?:^|.*;\s*)yourCookieName\s*\=\s*([^;]*).*$)|^.*$/, "$1"))

        let  difference_time = (now_time.getTime() - data_time_previous_window.getTime()) / 1000;
        difference_time = Math.round(difference_time)

        let counter_time_difference = this.countdown - difference_time
        if(counter_time_difference<0){
          counter_time_difference=0
        }
        if(counter_time_difference<10){
          counter_time_difference='0'+counter_time_difference
        }
        Storage.dispatch('ActionCountDown',counter_time_difference)
      }
      else if(this.transition_step===0){
        Storage.dispatch('ActionCountDown',this.countdown)
      }
    },

    sendPost(){
      //как и везде передаю объект
      const obj={}
      const val_tel = this.$refs.inputTelefon.value.replace(/\s/g, '')
      obj.PHONE=val_tel

      //считаем время для обратного отсчёта
      this.countdownBack()


      Storage.dispatch('ActionStep','confirmation')
      Storage.dispatch('ActionChangeTel',obj)

      //сказали пока убрать

      // axios({
      //   method:'post',
      //   // url:'https://httpbin.org/post', //для раЗРАБОТКИ
      //   url:'/api/local/gamedd/profile/user/',
      //
      //   headers: {
      //     "Content-type": "application/json; charset=UTF-8"
      //   },
      //   data:obj
      // })
      //   // Если запрос успешен
      //   .then((res) => {
      //     Storage.dispatch('ActionStep','confirmation')
      //     Storage.dispatch('ActionChangeTel',obj)
      //   })
      //   // Если запрос с ошибкой
      //   //вот тут в переменную  буду записывать ошибки, которые будет возвращать бэк
      //   // и в зависимости от неё выводить ошибку(неправильный код и так далее)
      //   .catch((error)=> {
      //     console.log(error.response.status);
      //   });

    },
  },

  computed: {
    countdown(){
      return Storage.getters.COUNTDOWN
    },
    user_data_state(){
      return Storage.getters.USERDATA.PHONE.replace(/(\+7|8)[\s(]?(\d{3})[\s)]?(\d{3})[\s-]?(\d{2})[\s-]?(\d{2})/g, '+7 $2 $3 $4 $5')
    },
    transition_step(){
      return parseInt(Storage.getters.TRANSITIONSTEP)
    },

  },
  watch: {

  },
  mounted() {
    this.inputCost()
    // this.fullnessCheck()
  },
  updated() {

  },
  components:{
    RegistrationClose
  }

}
</script>
