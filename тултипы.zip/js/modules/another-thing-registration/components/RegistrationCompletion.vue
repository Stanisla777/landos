<template lang="pug">
  .gameddreg__wrapper.js--gameddreg-wrapper(
    ref="gamedd_wrapper"
  )
    template
      registration-close
    p.gameddreg__title  Завершение регистрации
    p.gameddreg__sub-title.
      Заполните недостающие поля

    .gameddreg__container-input
      .gameddreg__wr-input
        p.test-a__entry-field-fin-add-des Имя
        .test-a__entry-field-fin-add.gameddreg__input.js--reg-input.js--reg-input-name-pr
          input(type="text")(
            ref="inputName"
            v-bind:value="user_data_state.NAME"
            @focus="focusInput"
            @blur="lossFocus"
            @input="InputNameChange"
            @keyup="commonInput"
            @paste="keyPaste"


          )
          .test-a__entry-field-add-icon(
            @click="clearFieldState"
          )
            svg(width='14', height='14', viewbox='0 0 14 14', fill='none', xmlns='http://www.w3.org/2000/svg')
              path(fill-rule='evenodd', clip-rule='evenodd', d='M5.58544 6.99975L0.635742 11.9495L2.04996 13.3637L6.99966 8.41396L11.9495 13.3638L13.3637 11.9495L8.41387 6.99975L13.3637 2.04996L11.9495 0.635742L6.99966 5.58553L2.04996 0.635835L0.635746 2.05005L5.58544 6.99975Z', fill='white')
          p.gameddreg__input-error Поле должно содержать кириллицу
      .gameddreg__wr-input
        p.test-a__entry-field-fin-add-des Фамилия
        .test-a__entry-field-fin-add.gameddreg__input.js--reg-input.js--reg-input-surname-pr
          input(type="text")(
            ref="inputSurname"
            v-bind:value="user_data_state.LAST_NAME"
            @focus="focusInput"
            @blur="lossFocus"
            @keyup="commonInput"
            @paste="keyPaste"
            @input="InputNameChange"

          )
          .test-a__entry-field-add-icon(
            @click="clearFieldState"
          )
            svg(width='14', height='14', viewbox='0 0 14 14', fill='none', xmlns='http://www.w3.org/2000/svg')
              path(fill-rule='evenodd', clip-rule='evenodd', d='M5.58544 6.99975L0.635742 11.9495L2.04996 13.3637L6.99966 8.41396L11.9495 13.3638L13.3637 11.9495L8.41387 6.99975L13.3637 2.04996L11.9495 0.635742L6.99966 5.58553L2.04996 0.635835L0.635746 2.05005L5.58544 6.99975Z', fill='white')
          p.gameddreg__input-error Поле должно содержать кириллицу
      .gameddreg__wr-input(
        ref="parentInput"
      )
        p.test-a__entry-field-fin-add-des Email
        .test-a__entry-field-fin-add.gameddreg__input.js--reg-input.js--reg-input-mail
          input(type="text")(
            v-bind:value="user_data_state.EMAIL"
            ref="inputMail"
            @focus="focusInput"
            @blur="lossFocus"
            @keyup="commonInput"
            @paste="pasteMail"
            @input="InputMailChange"

          )
          .test-a__entry-field-add-icon(
            @click="clearFieldState"
            @mouseover="elemMouseOver"
            @mouseout="elemMouseOut"
          )
            svg(width='14', height='14', viewbox='0 0 14 14', fill='none', xmlns='http://www.w3.org/2000/svg')
              path(fill-rule='evenodd', clip-rule='evenodd', d='M5.58544 6.99975L0.635742 11.9495L2.04996 13.3637L6.99966 8.41396L11.9495 13.3638L13.3637 11.9495L8.41387 6.99975L13.3637 2.04996L11.9495 0.635742L6.99966 5.58553L2.04996 0.635835L0.635746 2.05005L5.58544 6.99975Z', fill='white')
          p.gameddreg__input-error Некорректное значение в поле
          p.gameddreg__attempt-input-error-con Попытка ввести недопустимый символ
      .gameddreg__wr-input
        p.test-a__entry-field-fin-add-des Номер телефона
        .test-a__entry-field-fin-add.gameddreg__input.js--reg-input.js--reg-tel-mask
          input(type="text" placeholder="+7" inputmode="numeric")(
            v-bind:value="user_data_state.PHONE"
            ref="inputTelefon"
            @focus="focusInput"
            @blur="lossFocus"
            @keyup="commonInput"
            @paste="pasteTel"
          )
          .test-a__entry-field-add-icon(
            @click="clearFieldState"
            @mouseover="elemMouseOver"
            @mouseout="elemMouseOut"
          )
            svg(width='14', height='14', viewbox='0 0 14 14', fill='none', xmlns='http://www.w3.org/2000/svg')
              path(fill-rule='evenodd', clip-rule='evenodd', d='M5.58544 6.99975L0.635742 11.9495L2.04996 13.3637L6.99966 8.41396L11.9495 13.3638L13.3637 11.9495L8.41387 6.99975L13.3637 2.04996L11.9495 0.635742L6.99966 5.58553L2.04996 0.635835L0.635746 2.05005L5.58544 6.99975Z', fill='white')
          p.gameddreg__input-error Некорректное значение в поле
    .gameddreg__wr-checkbox
      .checkbox-stylized.personal-office__user-form-subscription.js--user-checkbox
        .personal-office__user-form-subscription-em
        .personal-office__user-form-block
          input(type="checkbox")#subscription(
            ref="checkBox"
            @change="changeChek"

          )
          label.gameddreg__chek-label(for="subscription")
            p Я соглашаюсь на
            <a href="/user-agreement/#soglasie-na-poluchenie-informatsionnykh-rassylok-v-ramkakh-onlayn-igry-po-finansovoy-gramotnosti-mys" target="_blank">получение информационных рассылок спроси.дом.рф</a>
    .gameddreg__wr-btn-input-compl.gameddreg__button
      .green.test-a__btn.unactive(
        ref="btnActive"
        @click="sendPost"
      ) Продолжить
      p.gameddreg__input-error.gameddreg__input-error-hint(ref="hintText")


</template>

<script>
import IMask from 'imask';
import Storage from '../development-tools/state.vue';
import RegistrationClose from './RegistrationClose.vue';
// import inputField from '../mixin/inputField';
import axios from 'axios';
import Cookies from 'js-cookie'
let mask;
let maskName;
let maskSurName;
let maskMail;

export default {
  name: 'RegistrationCompletion',
  props: {
    user_data:Object
  },
  data() {
    return {
      input_not_empty:true,
      fullness_input:0,
      len:25,
      error_text:'',
      inputError:false,



      active_btn:false,
      InputName:'',
      InputSurName:'',
      InputMail:'',
      InputTel:'',
      error:false,
      error_tel:false,
    }
  },

  methods: {

    //Имя фамилия

    keyPaste(el){
      const element = el.currentTarget
      let char = (el.clipboardData || window.clipboardData).getData('text');
      if ( char.search(/^[а-яё\-\s]*$/i) == -1 ) {
        element.closest('.js--reg-input').querySelector('.gameddreg__input-error').style.display='block'
        el.preventDefault();
      }
      if (char.search(/^[а-яё\-\s]*$/i) != -1 ) {
        element.closest('.js--reg-input').classList.add('true');
      }
      this.pasteActiveBtn()
      element.closest('.js--reg-input').querySelector('.test-a__entry-field-add-icon').classList.add('active');

    },
    pasteActiveBtn(){
      const array_el = document.querySelectorAll('.js--gameddreg-wrapper .js--reg-input');
      const array_true = document.querySelectorAll('.js--gameddreg-wrapper .js--reg-input.true');
      if (array_el.length == array_true.length) {
        this.$refs.btnActive.classList.remove('unactive');
      }
      else {
        this.$refs.btnActive.classList.add('unactive')
      }
    },

    pasteMail(el){
      const element = el.currentTarget
      maskMail.value=''
      let char = (el.clipboardData || window.clipboardData).getData('text');
      if ( char.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)) {
        element.closest('.js--reg-input').classList.remove('error')
        element.closest('.js--reg-input').classList.add('true')
      }
      else{
        element.closest('.js--reg-input').classList.add('error')
        element.closest('.js--reg-input').classList.remove('true')
      }
      this.pasteActiveBtn()
      element.closest('.js--reg-input').querySelector('.test-a__entry-field-add-icon').classList.add('active')
    },
    InputMailChange(e){
      const element = e.currentTarget
      let char = e.data
      if (/^[a-z0-9a-z0-9@!#$%&'.+-=?^_"`{|}~\s]*$/i.test(char)) {
        // element.closest('.js--reg-input').querySelector('.gameddreg__input-error').style.display="none"
        element.closest('.js--reg-input').classList.add('error-input')
        // this.inputError=true
      }
      if(e.inputType==='historyUndo'||e.inputType==='deleteContentBackward'||e.inputType!=='deleteContentForward'||e.inputType!=='insertFromPaste'){
        // element.closest('.js--reg-input').querySelector('.gameddreg__input-error').style.display="none"
        element.closest('.js--reg-input').classList.remove('error-input')
        // this.inputError=false
      }
      if (!/^[a-z0-9a-z0-9@!#$%&'.+-=?^_"`{|}~\s]*$/i.test(char)&&e.inputType!=='deleteContentBackward'&&e.inputType!=='deleteContentForward'&&e.inputType!=='insertFromPaste'&&e.inputType!=='historyUndo') {
        element.closest('.js--reg-input').classList.add('error-input')
        // this.inputError=true
      }
    },
    pasteTel(el){
      const element = el.currentTarget
      let char = (el.clipboardData || window.clipboardData).getData('text');
      char = char.replace(/\D/g, '')
      if (char.substring(0, 1)=='8'||char.substring(0, 1)=='+'||char.substring(0, 1)=='7') {
        if(char.length>=11){
          element.closest('.js--reg-input').classList.remove('error');
          element.closest('.js--reg-input').classList.add('true')
        }
        else{
          element.closest('.js--reg-input').classList.add('error');
          element.closest('.js--reg-input').classList.remove('true')
        }

      }
      else if(char.substring(0, 1)!='8'||char.substring(0, 1)!='+'||char.substring(0, 1)!='9'||char.substring(0, 1)!='7'){
        if(char.length>=10){
          element.closest('.js--reg-input').classList.remove('error');
        }
        else{
          element.closest('.js--reg-input').classList.add('error');
        }

      }
      element.closest('.js--reg-input').querySelector('.test-a__entry-field-add-icon').classList.add('active')
      this.pasteActiveBtn()

    },

    commonInput(el) {
      this.inputVal(el);
      this.buttonActivation();
    },
    InputNameChange(e){
      const element = e.currentTarget
      if (element.value.length > this.len) {
        element.value = element.value.substring(0, this.len);
      }
      let char = e.data
      if (/^[а-яё\-\s]*$/i.test(char)) {
        element.closest('.js--reg-input').querySelector('.gameddreg__input-error').style.display="none"
      }
      if(e.inputType==='historyUndo'||e.inputType==='deleteContentBackward'||e.inputType!=='deleteContentForward'||e.inputType!=='insertFromPaste'){
        element.closest('.js--reg-input').querySelector('.gameddreg__input-error').style.display="none"
      }
      if (!/^[а-яё\-\s]*$/i.test(char)&&e.inputType!=='deleteContentBackward'&&e.inputType!=='deleteContentForward'&&e.inputType!=='insertFromPaste'&&e.inputType!=='historyUndo') {
        element.closest('.js--reg-input').querySelector('.gameddreg__input-error').style.display="block"
      }

    },

    inputVal(el){
      const element = el.currentTarget
      if(element.value.length===0&&!element.closest('.js--reg-input').classList.contains('js--reg-tel-mask')){
        element.closest('.js--reg-input').querySelector('.test-a__entry-field-add-icon').classList.remove('active')
        element.closest('.js--reg-input').classList.remove('error')
      }
      if(element.value.length>0&&!element.closest('.js--reg-input').classList.contains('js--reg-tel-mask')) {
        element.closest('.js--reg-input').querySelector('.test-a__entry-field-add-icon').classList.add('active')
      }
      if(element.closest('.js--reg-input').classList.contains('js--reg-input-mail')){
        if(element.value.length>0&&element.value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)){
          element.closest('.js--reg-input-mail').classList.remove('error')
        }

      }

      if(element.closest('.js--reg-input').classList.contains('js--reg-tel-mask')){
        if (element.value.length>=16) {
          element.closest('.js--reg-tel-mask').classList.remove('error');
        }
        if(element.value.length===0){ //это похоже должно быть у телефона
          element.closest('.js--reg-input').querySelector('.test-a__entry-field-add-icon').classList.remove('active')
          element.closest('.js--reg-input').classList.remove('error')
        }
      }

      // if(!element.closest('.js--reg-input').classList.contains('js--reg-input-mail')
      //   &&!element.closest('.js--reg-input').classList.contains('js--reg-tel-mask')&&element.value.length>0){
      //   element.closest('.js--reg-input').classList.add('true')
      // }
      // else if(!element.closest('.js--reg-input').classList.contains('js--reg-input-mail')
      //   &&!element.closest('.js--reg-input').classList.contains('js--reg-tel-mask')&&element.value.length===0){
      //   element.closest('.js--reg-input').classList.remove('true')
      // }
      // if(element.closest('.js--reg-input').classList.contains('js--reg-input-mail')){
      //   if(element.value.length>0&&element.value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)){
      //     element.closest('.js--reg-input').classList.add('true')
      //   }
      //   if(element.value.length===0||!element.value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)){
      //     element.closest('.js--reg-input').classList.remove('true')
      //   }
      // }

    },
    buttonActivation(){
      const array = document.querySelectorAll('.js--gameddreg-wrapper .js--reg-input')
      const array_length = array.length
      this.fullness_input=0
      for (let item of array){
        const inp_val = item.querySelector('input').value.length

        if(item.classList.contains('js--reg-input-mail')&&item.querySelector('input').value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)&&item.querySelector('input').value.length>0){
          this.fullness_input+=1
        }
        if(item.classList.contains('js--reg-tel-mask')&&item.querySelector('input').value.length>=16){
          this.fullness_input+=1
        }



        if((!item.classList.contains('js--reg-input-mail')&&!item.classList.contains('js--reg-tel-mask'))&&item.querySelector('input').value.length>0){
          this.fullness_input+=1
        }

        if(inp_val>0){
          item.querySelector('.test-a__entry-field-add-icon').classList.add('active')
          item.classList.add('active')
          item.classList.add('true')
        }
        else {
          item.querySelector('.test-a__entry-field-add-icon').classList.remove('active')
          // item.classList.remove('active')
        }

      }
      if(array_length===this.fullness_input){
        this.$refs.btnActive.classList.remove('unactive')
      }
      else {
        this.$refs.btnActive.classList.add('unactive')
      }
    },

    //вывод ошибок в полях телефон и мэйл при загрузке страницы если вбито не правильно
    buttonActivationMounted(){
      const array = document.querySelectorAll('.js--gameddreg-wrapper .js--reg-input')
      const array_length = array.length
      for (let item of array){
        const inp_val = item.querySelector('input').value.length

        if(item.classList.contains('js--reg-input-mail')&&!item.querySelector('input').value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)&&item.querySelector('input').value.length>0){
          item.classList.add('error')
          item.classList.remove('true')
        }
        if(item.classList.contains('js--reg-tel-mask')&&item.querySelector('input').value.length<16&&item.querySelector('input').value.length>0){
          item.classList.add('error')
          item.classList.remove('true')
        }
      }

    },

    elemMouseOver(el){
      const element = el.currentTarget
      element.closest('.js--reg-input').classList.add('not_error')
    },
    elemMouseOut(el){
      const element = el.currentTarget
      element.closest('.js--reg-input').classList.remove('not_error')

    },

    //фокус в инпуте
    focusInput(el){
      const element = el.currentTarget
      element.closest('.js--reg-input').classList.add('active')
    },
    //потеря фокуса
    lossFocus(el){
      const element = el.currentTarget
      const val = element.value.length
      element.closest('.js--reg-input').classList.remove('error-input')
      if(val===0){
        element.closest('.js--reg-input').classList.remove('active')
        element.closest('.js--reg-input').classList.remove('true')
        element.closest('.js--reg-input').querySelector('.test-a__entry-field-add-icon').classList.remove('active')
      }
      if(element.closest('.js--reg-input').classList.contains('js--reg-input-mail')){
        if(element.value.length>0&&!element.value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)){
          element.closest('.js--reg-input').classList.remove('true')
        }

      }
      if (element.closest('.js--reg-input').classList.contains('js--reg-tel-mask')) {
        if (val<16&&val>2) {
          element.closest('.js--reg-input').classList.remove('true')
        }
      }

      if (element.closest('.js--reg-input')
        .classList.contains('js--reg-input-mail') && !element.closest('.js--reg-input').classList.contains('not_error')) {
        if (val > 0 && !element.value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)) {
          element.closest('.js--reg-input-mail').classList.add('error');
        }
      }
      if (element.closest('.js--reg-input')
        .classList.contains('js--reg-tel-mask') && !element.closest('.js--reg-input').classList.contains('not_error')) {
        // console.log(element.value);
        if (val<16&&val>2) {
          element.closest('.js--reg-tel-mask').classList.add('error');
        }
      }
      if (!element.closest('.js--reg-input').classList.contains('js--reg-input-mail') && !element.closest('.js--reg-input').classList.contains('js--reg-tel-mask')){
        element.closest('.js--reg-input').querySelector('.gameddreg__input-error').style.display="none"
      }
    },

    clearFieldState(el){
      const element = el.currentTarget

      element.closest('.js--reg-input').classList.remove('active')
      element.closest('.js--reg-input').classList.remove('true')
      element.classList.remove('active')
      if(element.closest('.js--reg-input').classList.contains('js--reg-tel-mask')){
        element.closest('.js--reg-input').querySelector('input').value=''
        element.closest('.js--reg-input').classList.remove('error')
        mask.value=''
      }
      else if(element.closest('.js--reg-input').classList.contains('js--reg-input-name-pr')){
        element.closest('.js--reg-input').querySelector('input').value=''
        element.closest('.js--reg-input').classList.remove('error')
        element.closest('.js--reg-input').querySelector('.gameddreg__input-error').style.display="none"
        maskName.value=''
      }
      else if(element.closest('.js--reg-input').classList.contains('js--reg-input-surname-pr')){
        element.closest('.js--reg-input').querySelector('input').value=''
        element.closest('.js--reg-input').classList.remove('error')
        maskSurName.value=''
      }
      else if(element.closest('.js--reg-input').classList.contains('js--reg-input-mail')){
        element.closest('.js--reg-input').querySelector('input').value=''
        element.closest('.js--reg-input').classList.remove('error')
        maskMail.value=''
        element.closest('.js--reg-input').classList.remove('error-input')
      }
      else {
        element.closest('.js--reg-input').querySelector('input').value=''
        element.closest('.js--reg-input').classList.remove('error')
      }
      this.buttonActivation()

    },

    //Для телефона
    inputCost(){
      const input_status = document.querySelectorAll('.js--reg-tel-mask input');
      const maskOptions = {
        mask: '+{7} 000 000 00 00',
        prepare: (appended, masked) => {
          if (appended === '8' && masked.value === '') {
            return '';
          }

          return appended;
        },

        // lazy: false,  // make placeholder always visible
        // placeholderChar: ''

      };
      for (const item of input_status) {
        mask = IMask(item, maskOptions);
      }
    },

    //для почты
    inputMail(){
      const input_status = document.querySelectorAll('.js--reg-input-mail input');
      const maskOptions = {
        mask: /^[a-z0-9a-z0-9@!#$%&'.+-=?^_"`{|}~\s]*$/i,
        // lazy: false,  // make placeholder always visible
        // placeholderChar: ''

      };
      for (const item of input_status) {
        maskMail = IMask(item, maskOptions);
      }
    },

    //для имени
    inputName(){
      const input_status = document.querySelectorAll('.js--reg-input-name-pr input');
      const maskOptions = {
        mask: /^[а-яё]+(?:[ -]{1}[а-яё]*)?$/i
        // lazy: false,  // make placeholder always visible
        // placeholderChar: ''

      };
      for (const item of input_status) {
        maskName = IMask(item, maskOptions);
      }
    },

    //для фамилии
    inputSurName(){
      const input_status = document.querySelectorAll('.js--reg-input-surname-pr input');
      const maskOptions = {
        mask: /^[а-яё]+(?:[ -]{1}[а-яё]*)?$/i
        // lazy: false,  // make placeholder always visible
        // placeholderChar: ''

      };
      for (const item of input_status) {
        maskSurName = IMask(item, maskOptions);
      }
    },


    changeChek(el){
      const element = el.currentTarget
      if(element.checked){
        Storage.dispatch('ActionCheckAgreement',true)
      }
      else {
        Storage.dispatch('ActionCheckAgreement',false)
      }

    },


    sendPost(){

      const array = document.querySelectorAll('.js--gameddreg-wrapper .js--reg-input')
      const array_length = array.length
      this.fullness_input=0
      const obj={}
      for (let item of array){
        const inp_val = item.querySelector('input').value.length

        if(item.classList.contains('js--reg-input-mail')&&item.querySelector('input').value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)&&item.querySelector('input').value.length>0){
          this.fullness_input+=1
        }
        if(item.classList.contains('js--reg-tel-mask')&&item.querySelector('input').value.length>=16){
          this.fullness_input+=1
        }

        if((!item.classList.contains('js--reg-input-mail')&&!item.classList.contains('js--reg-tel-mask'))&&item.querySelector('input').value.length>0){
          this.fullness_input+=1
        }

      }
      if (this.$refs.checkBox.checked){
        obj.AGREEMENT=true
      }
      else {
        obj.AGREEMENT=false
      }

      if(array_length===this.fullness_input){
        // console.log(this.$refs.inputTelefon.value.replace(/\s+/g, ''));

        const val_name = this.$refs.inputName.value
        const val_surname = this.$refs.inputSurname.value
        const val_mail = this.$refs.inputMail.value
        const val_tel_show = this.$refs.inputTelefon.value
        const val_tel = this.$refs.inputTelefon.value.replace(/\s+/g, '')
        obj.NAME=val_name
        obj.LAST_NAME=val_surname
        obj.EMAIL=val_mail
        obj.PHONE=val_tel


        //считаем время для обратного отсчёта
        //получается это не нужно

        // if(this.transition_step>0){
        //   let now_time = new Date();
        //   let time_previous_window = Cookies.get('gamedd_time_begin');
        //   let data_time_previous_window = new Date(time_previous_window.replace(/(?:(?:^|.*;\s*)yourCookieName\s*\=\s*([^;]*).*$)|^.*$/, "$1"))
        //
        //   let  difference_time = (now_time.getTime() - data_time_previous_window.getTime()) / 1000;
        //   difference_time = Math.round(difference_time)
        //
        //   let counter_time_difference = this.countdown - difference_time
        //   if(counter_time_difference<0){
        //     counter_time_difference=0
        //   }
        //   if(counter_time_difference<10){
        //     counter_time_difference='0'+counter_time_difference
        //   }
        //   Storage.dispatch('ActionCountDown',counter_time_difference)
        // }
        // else if(this.transition_step===0){
        //   Storage.dispatch('ActionCountDown',this.countdown)
        // }





        axios({
          method:'post',
          // url:'https://httpbin.org/post', //для раЗРАБОТКИ
          url:'/api/local/gamedd/profile/user/',

          headers: {
            "Content-type": "application/json; charset=UTF-8",
            'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
          },
          data:obj
        })
          // Если запрос успешен
          .then((res) => {
            Storage.dispatch('ActionCountDownAgain')
            Storage.dispatch('ActionStep','confirmation')
            Storage.dispatch('ActionInfoUser',obj)
            this.$refs.hintText.textContent=''

          })
          // Если запрос с ошибкой
          //вот тут в переменную  буду записывать ошибки, которые будет возвращать бэк
          // и в зависимости от неё выводить ошибку(неправильный код и так далее)
          .catch((error)=> {
            if(error.response){
              console.log(error.response);
              if(error.response.data.error!=undefined&&error.response.data.error.description!=undefined){
                this.$refs.hintText.textContent = error.response.data.error.description
              }

            }

          });
      }

    },

  },



  computed: {
    user_data_state(){
      return Storage.getters.USERDATA
    },
    countdown(){
      return Storage.getters.COUNTDOWN
    },
    check_agreement(){
      return Storage.getters.CHECKAGREEMENT
    },
    transition_step(){
      return parseInt(Storage.getters.TRANSITIONSTEP)
    },
    constant_countdown(){
      return parseInt(Storage.getters.CONSTANTCOUNTDOWN)
    },




  },
  watch: {

  },
  mounted() {
    this.inputCost()
    this.inputName()
    this.inputSurName()
    this.inputMail()
    this.buttonActivation();
    this.buttonActivationMounted()
    if(this.check_agreement===true){
      this.$refs.checkBox.setAttribute('checked',true)
    }

  },
  updated() {
    // this.inputCost()
    // this.fullnessCheck()


  },
  renderTriggered(key, target, type){
  },
  components:{
    RegistrationClose
  }

}
</script>
