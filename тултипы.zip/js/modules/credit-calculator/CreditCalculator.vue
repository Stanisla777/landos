<template lang="pug">
  div
    .property-calculator__body-row.refinancing-calc__body-row
      div.property-calculator__calculations
        .property-calculator__block
          template
            component-start-payments

          template
            component-credit-amount
          template
            component-interest-rate

          template
            component-credit-time


      div.property-calculator__container-result.refinancing-calc__container-result.first-show
        template
          component-final-result
        p.refinancing-calc__footnote.
          Результат расчета предварительный, сформирован в ознакомительных целях на основе предоставленных сведений и
          не является официальным заключением, офертой, индивидуальной оценкой. Для получения подробной информации и
          индивидуальной оценки рекомендуем обратиться в кредитную организацию
    template
      pop-up(
        v-show="modal_state"
      )

</template>
<script>
import Vue from 'vue';
import eventBus from './development-tools/eventBus.vue';
import Storage from './development-tools/state.vue';
import ComponentCreditAmount from './components/v-component-credit-amount.vue';
import ComponentInterestRate from './components/v-component-interest-rate.vue';
import ComponentCreditTime from './components/v-component-credit-time.vue';
import ComponentStartPayments from './components/v-component-start-payments.vue';

import ComponentFinalBlockConfirmed from './components/v-component-block-final-result.vue';
import ToolTip from './components/v-component-tooltip.vue';
import ComponentFinalResult from './components/v-component-block-final-result.vue';
import PopUp from './components/v-component-pop-up.vue';


export default {
  name: 'CreditCalculator',
  data(){
    return {
      other_means:false,
      final_result:true,
      final_state_confirmed:false,
      pop_up:false,
      text_pop_up:''
    }
  },
  methods:{

  },
  mounted(){


  },
  computed:{
    button_state(){
      return  Storage.getters.BUTTON_STATE
    },
    modal_state(){
      return  Storage.getters.MODAL_STATE
    },

  },
  created(){
    eventBus.$on('eventcheckboxChanged',(param)=>{
      this.other_means=param
    })
  },
  watch:{
  },
  components:{
    ComponentCreditAmount,
    ComponentInterestRate,
    ComponentCreditTime,
    ComponentStartPayments,

    ComponentFinalBlockConfirmed,
    ToolTip,
    ComponentFinalResult,
    PopUp
  }
};
</script>
<style scoped>
</style>
