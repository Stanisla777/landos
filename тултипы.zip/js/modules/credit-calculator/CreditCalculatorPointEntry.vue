<template lang="pug">
  div.property-calculator__body.refinancing-calc__body.property-calculator__style-nouislider.white
    template
      credit-calculator

</template>
<script>
// import DduCalculator from './DduCalculator.vue';
import Storage from './development-tools/state.vue';
const CreditCalculator = () => import ("./CreditCalculator.vue");


export default {
  name: 'CreditCalculatorPointEntry',
  data(){
    return {

    }
  },
  methods:{
  },
  mounted(){
  },
  computed:{
  },
  watch:{
  },
  components:{
    CreditCalculator
  }
};
</script>
<style scoped>
</style>
