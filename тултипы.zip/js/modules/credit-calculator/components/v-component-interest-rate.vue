<template lang="pug">
  .property-calculator__row.margin

    p.property-calculator__row-label Процентная ставка, %
    .property-calculator__input-field.js--number-old-rate(@click="inputFocus")
      input.property-calculator__value(
        inputmode="decimal"
        type="text"
        ref="realtyInput"
        @keyup="keyUp"
        @blur="inputBlur"
        @click="inpRemoveMark"
      )
      .range-input__slider(ref="mortgagePrice")
    .calculator_s__cost-flat
      p.property-calculator__range {{stgMin}}
      p.property-calculator__range {{stgMax}}
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import noUiSlider from 'nouislider';
import Storage from '../development-tools/state.vue';
import IMask from 'imask';
import onlyNumbers from '../custom-scripts/only-numbers.js'
export default {
  name: 'v-interest-rate',
  data(){
    return {
      realtySlider: '', // Слайдер "Стоимость недвижимости"
      dataField: 0, // Стоимость недвижимости
      dataFieldForCalculation: 0,
      subsidies: 0,
      stepApartment: 0.1, // Шаг для range инпутов
      stgMin: 0.1, // Минимальное значение поля стоимости
      stgMax: 100, // Максимальное значение поля стоимости
      start:9.2, // с какого значения при загрузке должен стоять ползунок
      input_salary:false,
      slider:false,
      mask_interest:null,
    }
  },
  methods:{


    initRealtySlider() {
      this.realtySlider = noUiSlider.create(this.$refs.mortgagePrice, {
        start: [this.start],
        connect: 'lower',
        initial: this.stgMin,
        step:0.1,


        range: {
          min: this.stgMin,
          max: this.stgMax
        },
      })
      this.realtySlider.on('start', (val,handle) => {

        if (this.mask_interest!==null){
          this.mask_interest.destroy()
          this.mask_interest = null
        }
      });
      this.realtySlider.on('update', (val,handle) => {

        this.input_salary = false
        this.$refs.realtyInput.value = parseFloat(val[handle]).toFixed(1).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        this.dataField = parseFloat(val[handle]).toFixed(1).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')

      });

      this.realtySlider.on('set', (val,handle) => {

        this.input_salary = false
        this.$refs.realtyInput.value = parseFloat(val[handle]).toFixed(1).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        this.dataField = parseFloat(val[handle]).toFixed(1).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        this.dataFieldForCalculation = parseFloat(val[handle]).toFixed(1)
        this.inputCost()
        this.mask_interest.value = parseFloat(val[handle]).toFixed(1).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        Storage.dispatch('ActionRateOldCredit',parseFloat(val[handle]).toFixed(1))
      });

      this.realtySlider.on('end', (val,handle) => {
        // this.dataFieldForCalculation = parseFloat(val[handle]).toFixed(1)
        // // if (this.mask_interest!==null){
        //   this.inputCost()
        //   this.mask_interest.value = parseFloat(val[handle]).toFixed(1).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        // // }
        // Storage.dispatch('ActionRateOldCredit',parseFloat(val[handle]).toFixed(1))
      });
    },
    inputCost(){
      const input_status = document.querySelector('.js--number-old-rate input')
      if (!this.$refs.realtyInput) return
      const maskOptions = {
        mask: Number,
        scale: 2,
        thousandsSeparator: '',
        padFractionalZeros:false,
        normalizeZeros:'trim',
        // padFractionalZeros: true,
        radix: '.',
        mapToRadix: ['.',','],
        min: 0.1,
        // max: 100,
        autofix:true,
        prepare:(value) => {
          return value.replace(/[бю\/]/gi, '.')
        }
      };

      this.mask_interest = new IMask(this.$refs.realtyInput, maskOptions)
      this.mask_interest.value = String(this.start)

      this.mask_interest.on('accept',()=>{
        if (this.mask_interest.typedValue === null) return

        if (this.mask_interest.typedValue > 100) {
          this.mask_interest.typedValue = 100
        }
        this.dataField=this.mask_interest.value
      })
      this.mask_interest.on('complete', () => {

      })

    },

    //Ввод значения пользователем
    inputFocus(el){
      const element = el.currentTarget
      element.querySelector('input').focus()
    },

    keyUp(e) {
      const element = e.currentTarget


      if(element.value!==''&&(parseFloat(element.value)>=this.stgMin)&&parseFloat(element.value)<=this.stgMax){
        Storage.dispatch('ActionRateOldCredit',parseFloat(element.value).toFixed(1))
      }

      else if(element.value!==''&&parseFloat(element.value)>this.stgMax)  {
        Storage.dispatch('ActionRateOldCredit',parseFloat(this.stgMax).toFixed(1))
      }
      else if(element.value!==''&&parseFloat(element.value)<this.stgMin)  {
        Storage.dispatch('ActionRateOldCredit',parseFloat(this.stgMin).toFixed(1))
      }
    },

    inpRemoveMark(el) {
      const element = el.currentTarget;
      if(element.value==0||element.value=='0 %'){
        element.value=''
      }

    },
    inputBlur(el) {
      const element = el.currentTarget;
      this.realtySlider.set(element.value)
      if (element.value==='') {
        this.realtySlider.set(0.1);
        Storage.dispatch('ActionRateOldCredit',0.1)
      }
      setTimeout(()=>{
        Storage.dispatch('ActionFinalWindow',false)
      },400)



      // const element = el.currentTarget;
      // if (!element.value.includes('%')) {
      //   // element.value = this.dataField;
      //   element.value = this.mask_interest.value;
      // }
      // if (element.value==='') {
      //   element.value = 1;
      //   // this.realtySlider.set(1);
      //   Storage.dispatch('ActionRateOldCredit',1)
      //
      // }
    },

  },
  beforeDestroy() {
    if (this.mask_interest){
      this.mask_interest.destroy()
    }
  },
  mounted(){
    // this.$nextTick(()=>{
      this.initRealtySlider()
      this.inputCost()
      Storage.dispatch('ActionRateOldCredit',parseFloat(this.mask_interest.value))
    // })

    // this.mask_interest.value = this.start


    // Storage.dispatch('ActionRateOldCredit',parseFloat(this.dataField))

  },
  computed:{
  },
  watch:{
    //как только стоимость квартиры изменилась, вызываю функцию
    dataField(){
      // const elem = document.querySelector('.property-calculator__final-preload')
      // if (elem){
      //   elem.setAttribute('style','display:block;')
      // }
      Storage.dispatch('ActionFinalWindow',true)


    },
    dataFieldForCalculation(){
      if(this.dataFieldForCalculation==100.0){
        // this.dataField = '100'
        this.mask_interest.value = '100'
      }
      if(this.dataFieldForCalculation==0.0){
        // this.dataField = '0 %'
      }
    }
  },
  created(){
  },
  components:{}
};
</script>
<style scoped>
</style>
