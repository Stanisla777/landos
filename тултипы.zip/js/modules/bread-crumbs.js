/* eslint-disable */
function breadWidth (){
  const bread_crumbs = document.querySelector('.js--bread-crumbs')
  const page_wrap = document.querySelector('.js-p-wrap')
  if(bread_crumbs&&page_wrap){
    let elementWidth = bread_crumbs.clientWidth;
    let pageWidth = page_wrap.clientWidth;
    if (elementWidth > pageWidth){
      bread_crumbs.closest('.js--bread-crumbs-container').classList.add('active')
    }
    else if(elementWidth < pageWidth) {
      bread_crumbs.closest('.js--bread-crumbs-container').classList.remove('active')
    }
  }
}
export default function breadCrumbs() {
  breadWidth ();
  window.addEventListener('resize', breadWidth);

}
