<template lang="pug">
  .calculator_s__checkbox.calculator_s__calculator-row.js--tax_checkbox.calculator_s__co-borrower-wr
    .calculator_s__checkbox-item.checkbox-stylized
      input#checkbox_2(type='checkbox' checked)(
        v-bind:id="param_id"
        @change="checkboxChanged"
      )
      label(
        v-bind:for="param_id"
      ) {{param_label}}
    .calculator_s__co-borrower-del(
      v-bind:class="param_id"
      @click="deleteCoBorrower"
    )
      svg#Capa_1(version='1.1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' width='15px' height='15px' viewBox='0 0 348.333 348.334' style='enable-background:new 0 0 348.333 348.334;' xml:space='preserve')
        path(fill='red' d='M336.559,68.611L231.016,174.165l105.543,105.549c15.699,15.705,15.699,41.145,0,56.85\
        c-7.844,7.844-18.128,11.769-28.407,11.769c-10.296,0-20.581-3.919-28.419-11.769L174.167,231.003L68.609,336.563\
        c-7.843,7.844-18.128,11.769-28.416,11.769c-10.285,0-20.563-3.919-28.413-11.769c-15.699-15.698-15.699-41.139,0-56.85\
        l105.54-105.549L11.774,68.611c-15.699-15.699-15.699-41.145,0-56.844c15.696-15.687,41.127-15.687,56.829,0l105.563,105.554\
        L279.721,11.767c15.705-15.687,41.139-15.687,56.832,0C352.258,27.466,352.258,52.912,336.559,68.611z')

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import ToolTip from '../components/v-component-tooltip.vue';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-checkbox-same-salary',
  props:['param_label','param_id'],
  data(){
    return {

    }

  },
  methods:{

    checkboxChanged(el){
      const element = el.currentTarget
      if(!element.checked){
        this.$emit('eventcheckboxChanged',[element,false])
        eventBus.$emit('eventcheckboxChanged',[element,false])
      }
      else{
        this.$emit('eventcheckboxChanged',[element,true])
        eventBus.$emit('eventcheckboxChanged',[element,true])
      }
    },
    deleteCoBorrower(el){
      const element = el.currentTarget
      element.closest('.calculator_s__wrap-borrower').remove()
    }

  },
  mounted(){

  },
  computed:{},
  watch:{
  },
  components:{
    ToolTip
  }
};
</script>
<style scoped>
</style>
