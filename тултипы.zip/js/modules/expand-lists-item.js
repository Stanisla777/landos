const ELEMENTS = {
  btnExpand: '.js--expand-list-btn',
  list: '.js--expand-list',
  listItem: '.js--expand-list-item',
  txtBtnExpand: 'Показать все',
  txtBtnCollapse: 'Скрыть',
};

function hideItems(nodes, showCount = 6) {
  nodes.forEach((node, index) => {
    if (index >= showCount) {
      // eslint-disable-next-line no-param-reassign
      node.style.display = 'none';
    }
  });
}
function showItems(nodes) {
  nodes.forEach((node) => {
    // eslint-disable-next-line no-param-reassign
    node.style.display = 'block';
  });
}

export default function expandListsItem() {
  const btnExpands = document.querySelectorAll(ELEMENTS.btnExpand);
  if (!btnExpands.length) { return; }
  btnExpands.forEach((btn) => {
    const btnItems = btn.parentNode.querySelectorAll(`${ELEMENTS.list} ${ELEMENTS.listItem}`);
    if (!btnItems.length) { return; }

    hideItems(btnItems);
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      if (btn.textContent === ELEMENTS.txtBtnExpand) {
        showItems(btnItems);
        // eslint-disable-next-line no-param-reassign
        btn.innerText = ELEMENTS.txtBtnCollapse;
      } else {
        hideItems(btnItems);
        // eslint-disable-next-line no-param-reassign
        btn.innerText = ELEMENTS.txtBtnExpand;
      }
    });
  });
}
