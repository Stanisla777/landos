export default function activeSlideTest() {
  let but = document.querySelectorAll('.btn-slide-sub');
  but = Array.prototype.slice.call(but);
  // eslint-disable-next-line func-names
  but.forEach((item) => {
    // eslint-disable-next-line no-param-reassign
    item.onclick = function () {
      // eslint-disable-next-line no-use-before-define
      activeButton(item);
      // eslint-disable-next-line no-use-before-define
      activeBullet(item);
      // eslint-disable-next-line no-use-before-define
      activeResult(item);
    };
  });
  const activeButton = function (item) {
    for (let i = 0; i <= but.length - 1; i++) {
      but[i].classList.add('unactive');
    }
    item.classList.add('unactive');
    const butParent = item.closest('.test-window');
    butParent.querySelector('.test-window__slider-btn').classList.remove('unactive');
  };
  // eslint-disable-next-line no-unused-vars
  const activeBullet = function (item) {
    const butParent = item.closest('.test-window');
    // eslint-disable-next-line no-shadow
    const activeBullet = butParent.querySelector('.test-pagination .swiper-pagination-bullet-active');
    activeBullet.classList.add('active');
  };
  const activeResult = function (item) {
    const btnParent = item.closest('.test-item');
    if (btnParent.classList.contains('test-answer')) {
      btnParent.querySelector('.test-window__answer').setAttribute('style', 'display:none');
      btnParent.querySelector('.test-window__result-answer').setAttribute('style', 'display:block');
    }
  };
}
