<template lang="pug">
  .calc-tax-deduc-new__container-block.mor-rep-calculators__parent-tooltip-mobile.js--tooltip-parent
    .calc-tax-deduc-new__row-title-main-container(
        v-if="(transfer_tooltip!==null&&transfer_tooltip['credit-time']&&transfer_tooltip['credit-time']['info']!=='')&&(transfer_tooltip['credit-time']['size']===''||transfer_tooltip['credit-time']['size']==='small'||transfer_tooltip['credit-time']['size']===undefined)"
      )
      .calc-tax-deduc-new__row-title-container
        p.calc-tax-deduc-new__row-title Срок кредита, мес.
        span.content-note.desctop.content-note__center.js--content-note
          span.content-note__text {{transfer_tooltip["credit-time"]["info"]}}
        span.content-note.mobile(
          v-if="transfer_tooltip['credit-time']['info']!==''"
          @click="openTooltipMobile"
        )
      div(v-if="transfer_tooltip['credit-time']['info']!==''")
        .select__background.modal-special-background(@click="closeTooltipMobile")
        .select-list__selection-window.modal-special-styles.js--openlist-body
          .select-list__head
            p Срок кредита, мес.
            .select-list__head-close(@click="closeTooltipMobile")
              svg(width='10', height='10', viewbox='0 0 10 10', fill='none', xmlns='http://www.w3.org/2000/svg')
                path(fill-rule='evenodd', clip-rule='evenodd', d='M0.209209 0.209209C0.488155 -0.0697365 0.940416 -0.0697365 1.21936 0.209209L5 3.98985L8.78064 0.209209C9.05958 -0.0697365 9.51184 -0.0697365 9.79079 0.209209C10.0697 0.488155 10.0697 0.940416 9.79079 1.21936L6.01015 5L9.79079 8.78064C10.0697 9.05958 10.0697 9.51184 9.79079 9.79079C9.51184 10.0697 9.05958 10.0697 8.78064 9.79079L5 6.01015L1.21936 9.79079C0.940416 10.0697 0.488155 10.0697 0.209209 9.79079C-0.0697365 9.51184 -0.0697365 9.05958 0.209209 8.78064L3.98985 5L0.209209 1.21936C-0.0697365 0.940416 -0.0697365 0.488155 0.209209 0.209209Z', fill='#252628')
          .select-list__wr-search.mor-rep-calculators__wr-search
            p {{transfer_tooltip["credit-time"]["info"]}}

    .calc-tax-deduc-new__row-title-main-container(
      v-if="transfer_tooltip!==null&&transfer_tooltip['credit-time']&&transfer_tooltip['credit-time']['info']!==''&&transfer_tooltip['credit-time']['size']!==''&&transfer_tooltip['credit-time']['size']==='big'&&transfer_tooltip['credit-time']['size']!==undefined"
    )
      .calc-tax-deduc-new__row-title-container
        p.calc-tax-deduc-new__row-title Срок кредита, мес.
        .content-note(
          @click="openModal"
          :data-tooltip="transfer_tooltip['credit-time']['name']?transfer_tooltip['credit-time']['name']:''"
        )

    .calc-tax-deduc-new__row-title-main-container(v-if="transfer_tooltip===null||transfer_tooltip['credit-time']['info']===''")
      .calc-tax-deduc-new__row-title-container
        p.calc-tax-deduc-new__row-title Срок кредита, мес.

    .calc-tax-deduc-new__col-input.js--number-cost-pr.js--tex-deduc-input
      input(
        inputmode="numeric"
        v-model="dataField"
        type="text"
        ref="realtyInput"
        @keyup="keyUp"
        @change ="inputValue"
        @input ="simplyNumber(360,$event)"
        @paste="inputPast"
        @blur="moveAnotherElement"
        @focus="inpFocus"
      )



      .range-input__slider(ref="mortgagePrice")
    .calc-tax-deduc-new__wr-range
      p {{stgMin}}
      p {{Math.floor((stgMin + stgMax) / 2)}}
      p {{stgMax}}
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import noUiSlider from 'nouislider';
import Storage from '../development-tools/state.vue';
import numberFormatting from '../mixin/numberFormatting.js';
import IMask from 'imask';
import onlyNumbers from '../custom-scripts/only-numbers.js'
export default {
  name: 'v-credit-time',
  mixins: [numberFormatting],
  data(){
    return {
      realtySlider: '', // Слайдер "Стоимость недвижимости"
      dataField: '', // Стоимость недвижимости
      dataFieldForCalculation: 0,
      stepInput: 1, // Шаг для range инпутов
      stgMin: 3, // Минимальное значение поля стоимости
      // stgMin: 36, // Минимальное значение поля стоимости
      stgMiddle: 120, // Значение по середине (стоимость)
      stgMax: 360, // Максимальное значение поля стоимости
      input_salary:false,
      start:1,

    }
  },
  methods:{
    initRealtySlider() {
      this.realtySlider = noUiSlider.create(this.$refs.mortgagePrice, {
        start: [this.start],
        connect: 'lower',
        step: this.stepInput,
        initial: this.stgMin,
        range: {
          min: this.stgMin,
          max: this.stgMax
        },
      });
      this.realtySlider.on('start', (val,handle) => {

      });
      this.realtySlider.on('update', (val,handle) => {
        this.input_salary = false
        this.dataField = parseInt(val[handle])
      });

      this.realtySlider.on('set', (val,handle) => {
        this.input_salary = false
        this.dataField = parseInt(val[handle])
        this.dataFieldForCalculation = parseInt(val[handle])

        this.$nextTick(() => {
          setTimeout(()=>{
            //новое
            Storage.dispatch('ActionTimeCredit',parseInt(val[handle]))

          },300)
        })

      });
      this.realtySlider.on('end', (val,handle) => {

      });
    },
    keyUp(e){
      const element = e.currentTarget
      if(element.value!==''&&(parseInt(element.value.replace(/\s/g, ''))>=this.stgMin)&&parseInt(element.value.replace(/\s/g, ''))<=this.stgMax){
        this.realtySlider.set(parseInt(element.value.replace(/\s/g, '')));
      }
      else if(parseInt(element.value.replace(/\s/g, ''))>this.stgMax)  {
        this.realtySlider.set(this.stgMax);
      }
      if(parseInt(element.value.replace(/\s/g, ''))>=this.stgMax){
        this.dataField = this.stgMax.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
      }
    },
    inputValue(el){
      const element = el.currentTarget;
      let value = element.value
      value = parseInt(value.replace(/\s/g, ''));
      if(value>this.stgMax)  {
        this.dataFieldForCalculation = this.stgMax

      }
      if(value<this.stgMin)  {
        this.dataFieldForCalculation = this.stgMin
        this.realtySlider.set(this.stgMin);
      }
    },
    inputPast(el){
      const element = el.currentTarget;
      let element_val = (el.clipboardData || window.clipboardData).getData('text');
      if ( element_val.search(/[^0-9]/g) != -1 ) {
        el.preventDefault();
      }
    },
    moveAnotherElement(el) {
      const element = el.currentTarget;
      element.closest('.js--tex-deduc-input').classList.remove('input-focus')
      if (element.value==='') {
        element.value = this.stgMin;
        this.realtySlider.set(this.stgMin);
      }
    },
  },
  mounted(){
    this.initRealtySlider()
    if (this.answers===null) {
      Storage.dispatch('ActionTimeCredit',parseInt(this.dataField))
    }
    else {
      this.realtySlider.set(parseInt(this.answers.loanTerm));
      Storage.dispatch('ActionTimeCredit',parseInt(this.answers.loanTerm))
    }

  },
  computed:{
    transfer_tooltip(){
      return Storage.getters.TRANSFERTOOLTIP
    },
    answers(){
      return Storage.getters.ANSWERS
    },
  },
  watch:{
    dataField(){

    },
  },
  created(){
  },
  components:{}
};
</script>
<style scoped>
</style>
