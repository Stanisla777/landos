/* eslint-disable */
// Обработчик скролла
function handleScroll() {
  // let isTrigger = false
  const parentBlock = document.querySelectorAll('.js--another-thing-paralax');
  parentBlock.forEach(block => {
      const position = block.getBoundingClientRect();

      if (position.top < window.innerHeight * 0.9) {
        block.classList.add('show')
      }

      // isTrigger=true
      // window.removeEventListener('scroll',handleScroll)
  });
}

export default function parallaxThing(el) {

  // const parentBlock = document.querySelector('.another-thing-2025__speaker');
  //
  //
  // // Создаем IntersectionObserver
  // const observer = new IntersectionObserver((entries) => {
  //   entries.forEach(entry => {
  //     // Добавляем класс при появлении блока в зоне видимости
  //     if (entry.isIntersecting) {
  //       console.log('Ура!!!');
  //       parentBlock.classList.add('show');
  //       // Отключаем наблюдение после срабатывания (опционально)
  //       observer.unobserve(parentBlock);
  //     }
  //   });
  // }, {
  //   threshold: 0.1 // Срабатывает при 10% видимости элемента
  // });
  //
  // // Начинаем наблюдение
  // observer.observe(parentBlock);

  window.addEventListener('scroll', handleScroll);
  handleScroll();
}
