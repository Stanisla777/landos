/* eslint-disable */



// Функция проверки видимости элемента
function isElementVisible(el) {
  const rect = el.getBoundingClientRect();
  const windowHeight = window.innerHeight || document.documentElement.clientHeight;
  return (
    rect.top <= windowHeight * 0.9 && // Когда 90% элемента появилось
    rect.bottom >= 0
  );
}

// Функция запуска анимации
function animateChildren(children) {
  children.forEach((child, index) => {
    setTimeout(() => {
      child.classList.add('show');
    }, index * 150); // Задержка 150мс между элементами
  });
}





export default function parallaxSeveral() {

  const parent = document.querySelectorAll('.js--another-thing-paralax-several-parent');
  for (let i=0;i<parent.length;i++) {
    const children = parent[i].querySelectorAll('.js--another-thing-paralax-several-child');
    let animated = false;



    // Проверка при загрузке
    if (isElementVisible(parent[i]) && !animated) {
      animated = true;
      animateChildren(children);
    }

    // Обработчик скролла с троттлингом
    let isScrolling = false;
    window.addEventListener('scroll', () => {
      if (isScrolling) return;
      isScrolling = true;

      setTimeout(() => {
        if (!animated && isElementVisible(parent[i])) {
          animated = true;
          animateChildren(children);
        }
        isScrolling = false;
      }, 600);
    });
  }






}
