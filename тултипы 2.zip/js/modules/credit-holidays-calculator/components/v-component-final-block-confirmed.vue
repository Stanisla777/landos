<template lang="pug">
  .calculator_s__wrapper-detailed-result
    p.credit-holiday__final-result.confirmed Снижение дохода более чем на 30% <span>подтверждено</span>
    p.credit-holiday__final-result-sub-title Вы можете воспользоваться кредитными каникулами.
    p.footnote-calculators.
      Результат расчета предварительный, сформирован в ознакомительных целях на основе предоставленных сведений и не
      является официальным заключением, офертой, индивидуальной оценкой. Для получения подробной информации и
      индивидуальной оценки рекомендуем обратиться в кредитную организацию.


</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import ToolTip from '../components/v-component-tooltip.vue';
export default {
  name: 'v-component-final-block-confirmed',
  data(){
    return {

    }
  },
  methods:{
    dropDownList(el){
      const btn = el.currentTarget
      const parent = btn.closest('.js-accordion-parent');
      const container = parent.querySelector('.js-accordion-body ');
      if (parent.classList.contains('active')) {
        parent.classList.remove('active');
        // eslint-disable-next-line camelcase
        container.style.maxHeight = 0;
      } else {
        // eslint-disable-next-line no-restricted-syntax,camelcase
        parent.classList.add('active');
        container.style.maxHeight = `${container.scrollHeight}px`;
      }
    },

  },
  mounted(){
  },
  computed:{
  //  Сюда помещаются в том числе GETTTERS

  },

  watch:{

  },
  components:{
    ToolTip,
  },
  created(){
  //  Тут помещаюстя Шина событий
  }
};
</script>
<style scoped>
</style>
