<template lang="pug">
  .credit-holiday__row-btn
    button.credit-holiday__btn(
      :class="[(check_not_work===true&&input_salary_per_year===true&&input_salary_monthly===true&&input_date===true)?'active':'unactive']"
      @click="calculateData"
    ) Рассчитать
    .credit-holiday__add-co-borrower(@click="addCoBorrower")
      .credit-holiday__add-co-borrower-icon
        svg(width='14' height='14' viewbox='0 0 14 14' fill='none' xmlns='http://www.w3.org/2000/svg')
          path(fill-rule='evenodd' clip-rule='evenodd' d='M6.99961 0.599976C7.39961 0.599976 7.79953 0.898452 7.79953 1.26664L7.79961 6.19998L12.7329 6.19999C13.1011 6.19999 13.3996 6.59998 13.3996 6.99998C13.3996 7.39998 13.1011 7.79999 12.7329 7.79999L7.79961 7.79998L7.79952 12.7333C7.79953 13.1015 7.39961 13.4 6.99961 13.4C6.59961 13.4 6.19952 13.1015 6.19953 12.7333V7.79998L1.26619 7.79998C0.898002 7.79999 0.599609 7.39998 0.599609 6.99998C0.599609 6.59998 0.898002 6.19999 1.26619 6.19999L6.19953 6.19998V1.26664C6.19953 0.898453 6.59961 0.599976 6.99961 0.599976Z' fill='#686D82')
      p добавить созаемщика



</template>
<script>
import Vue from 'vue';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-component-button',
  props:[],
  data(){
    return {
      co_borrower:0,
      btn_active:[],
      button_active:true,
      button_status:[
        {
          name:'check_not_work',
          state:true
        },
        {
          name:'input_salary_per_year',
          state:true
        },
        {
          name:'input_date',
          state:false
        },
      ]
    }
  },
  methods:{
    addCoBorrower(){
      if(this.co_borrower<6){
        this.$emit('eventAddCoBorrower',this.co_borrower)
      }
      this.co_borrower+=1
    },
    calculateData(){
      this.$emit('eventCalculateSalary')
    }
  },
  mounted(){

  },
  computed:{

    check_not_work(){
     return Storage.getters.STATE_APPROVAL_CHECK_NOT_WORK
    },
    input_salary_per_year(){
      return Storage.getters.STATE_APPROVAL_INPUT_PER_YEAR
    },
    input_salary_monthly(){
      return Storage.getters.STATE_APPROVAL_INPUT_MONTHLY
    },
    input_date(){
      return Storage.getters.STATE_APPROVAL_INPUT_DATE
    },





  },
  watch:{
  },
  created(){
    eventBus.$on('eventRight',(param)=>{
      if(param===true&&this.btn_active.length===0){
        this.btn_active.push(true)
      }
      else{
        this.btn_active.splice(0);
      }

    })
  },

  components:{}
};
</script>
<style scoped>
</style>
