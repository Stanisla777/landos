<template lang="pug">
  .calculator_s__calculator-row.credit-holiday__wrap-before-bank
    .calculator_s__period-input-wrapper
      p.calculator_s__calculator-label Доход за полный месяц, предшествующий дате обращения в банк
      .calculator_s__period-input-wrap-icon
        svg(width='6' height='9' viewbox='0 0 6 9' fill='none' xmlns='http://www.w3.org/2000/svg')
          path(d='M2.29615 5.82809V5.87809H2.34615H3.38128H3.43128V5.82809C3.43128 5.17718 3.88001 4.74316 4.37092 4.26834C4.3939 4.24612 4.41697 4.2238 4.44009 4.20137C4.95161 3.70514 5.47928 3.15761 5.47928 2.27748C5.47928 1.56616 5.1798 1.02591 4.72144 0.664646C4.26438 0.304406 3.65179 0.123828 3.0251 0.123828C1.94115 0.123828 0.916704 0.644209 0.518245 1.74851L0.503822 1.78848L0.540948 1.80916L1.42025 2.2989L1.47368 2.32866L1.49223 2.27038C1.60592 1.91305 1.80522 1.65293 2.06481 1.48165C2.32489 1.31005 2.64868 1.22557 3.01397 1.22557C3.39653 1.22557 3.72964 1.31585 3.96588 1.49634C4.20027 1.67543 4.34415 1.94688 4.34415 2.322C4.34415 2.63879 4.22214 2.90106 4.03445 3.14622C3.87409 3.35566 3.66836 3.5496 3.45209 3.75346C3.41356 3.78978 3.37469 3.82642 3.33569 3.86351C2.82303 4.3511 2.29615 4.90943 2.29615 5.82809ZM2.85815 8.28226C3.29809 8.28226 3.63162 7.93659 3.63162 7.50879C3.63162 7.08098 3.29809 6.73531 2.85815 6.73531C2.42984 6.73531 2.08467 7.08048 2.08467 7.50879C2.08467 7.9371 2.42984 8.28226 2.85815 8.28226Z' fill='#1C1B28' stroke='#1C1B28' stroke-width='0.1')
      template
        tool-tip(
          :hint_text="hint_text"
        )
    .calculator_s__calculator-input.calculator_s__placeholder-numeric-set.js--salary-before-going(
      @click="inputFocus"
    )
      input(type="text" inputmode="numeric" placeholder="Введите сумму")(
        @input="inputValue"
        @keyup="inp_sum"
        @keydown="inp_sum"
        @paste="inp_sum"
        @focus="inp_sum"
      )
      p(v-if="currency") ₽

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import numberFormatting from '../custom-scripts/number-formatting.js'
import IMask from 'imask';
import Storage from '../development-tools/state.vue';
import ToolTip from '../components/v-component-tooltip.vue';
export default {
  name: 'v-component-salary-before-going-bank',
  data(){
    return {
      stgMax:900000,
      currency:false,
      hint_text:'Например, если вы подаёте заявление 14 марта 2022, то вам необходимо указать доход за февраль.'
    }
  },
  methods:{
    inp_sum(e){
      const e_field = e.currentTarget
      numberFormatting(e_field)
    },
    inputCost(){
      const input_status = document.querySelectorAll('.js--salary-before-going input');
      const maskOptions = {
        mask: Number,
        thousandsSeparator: ' ',
        max:this.stgMax

      };
      for (const item of input_status) {
        new IMask(item, maskOptions);
      }
    },
    inputValue(el){
      const element = el.currentTarget;
      element.style.width = 0+'px';
      if(element.value.length>0){
        this.currency=true
        element.setAttribute('placeholder',0)
        Storage.dispatch('ActionInputMonthly',true)
      }
      else {
        this.currency=false
        element.setAttribute('placeholder','Введите сумму')
        element.style.width=100+"%"
        Storage.dispatch('ActionInputMonthly',false)
      }
      if(element.value.length==0){
        element.style.width = element.scrollWidth + 15 + 'px';
      }
      else if(element.value.length==4){
        element.style.width = element.scrollWidth + 8 + 'px';
      }
      else if(element.value.length==8){
        element.style.width = element.scrollWidth + 4 + 'px';
        let val = element.value.replace(/\s/g, '')
        // return false
      }

      else {
        element.style.width = element.scrollWidth + 4 + 'px';
      }
      let val = element.value.replace(/\s/g, '')
    },

    sendInputChange(param){

    },
    inputFocus(el){
      const element = el.currentTarget
      element.querySelector('input').focus()
    },
  },
  mounted(){
    // this.inputCost()
  },
  computed:{},
  watch:{
  },
  created(){


  },
  components:{
    ToolTip
  }
};
</script>
<style scoped>
</style>
