<template lang="pug">
  .calculator_s__calculator-row.calculator_s__per-year-salary.js--per-year-salary
    .calculator_s__period-input-wrapper
      p.calculator_s__calculator-label Ежемесячная заработная плата в 2021
    .calculator_s__calculator-input.calculator_s__placeholder-numeric-set.js--salary-per-year(
      @click="inputFocus"
    )
      input(type="text" inputmode="numeric" placeholder="Введите сумму")(
        @input="inputValue"
        @keyup="inp_sum"
        @keydown="inp_sum"
        @paste="inp_sum"
        @focus="inp_sum"
      )
      p(v-if="currency") ₽

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import numberFormatting from '../custom-scripts/number-formatting.js'
import IMask from 'imask';
import Storage from '../development-tools/state.vue';
export default {
  name: 'v-component-salary-per-year',
  props:[],
  data(){
    return {
      // stgMax:900000,
      currency:false
    }
  },
  methods:{
    inp_sum(e){
      const e_field = e.currentTarget
      numberFormatting(e_field)
    },
    inputCost(){
      const input_status = document.querySelectorAll('.js--salary-per-year input');
      const maskOptions = {
        mask: Number,
        thousandsSeparator: ' ',
        // max:this.stgMax

      };
      for (const item of input_status) {
        new IMask(item, maskOptions);
      }
    },
    inputValue(el){
      const element = el.currentTarget;
      element.style.width = 0+'px';
      if(element.value.length>0){
        element.setAttribute('placeholder',0)
        this.currency=true
        Storage.dispatch('ActionInputPerYear',true)
      }
      else {
        element.setAttribute('placeholder','Введите сумму')
        this.currency=false
        element.style.width=100+"%"
        Storage.dispatch('ActionInputPerYear',false)
      }
      if(element.value.length==0){
        element.style.width = element.scrollWidth + 15 + 'px';
      }
      else if(element.value.length==4){
        element.style.width = element.scrollWidth + 8 + 'px';
      }
      else if(element.value.length==8){
        element.style.width = element.scrollWidth + 4 + 'px';
        let val = element.value.replace(/\s/g, '')
        // return false
      }

      else {
        element.style.width = element.scrollWidth + 4 + 'px';
      }
      let val = element.value.replace(/\s/g, '')

    },
    // sendInputChange(param){
    // },
    inputFocus(el){
      const element = el.currentTarget
      element.querySelector('input').focus()
    },
  },
  mounted(){
    // this.inputCost()
  },
  computed:{},
  watch:{
  },
  created(){
    eventBus.$on('eventcheckboxChanged',(el)=>{

      if(el[1]==false){
        this.currency=false
      }
    })
  },
  components:{}
};
</script>
<style scoped>
</style>
