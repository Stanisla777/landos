<script>
import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

export default new Vuex.Store({
  state:{
    type_credit:[
      {
        output_name:'Ипотечный кредит',
        type:'mortgage'
      },
      {
        output_name:'Автокредит',
        type:'other'
      },
      {
        output_name:'Потребительский (физлицо)',
        type:'other'
      },
      {
        output_name:'Потребительский (ИП)',
        type:'other'
      },
      {
        output_name:'Кредитная карта',
        type:'other'
      },


    ],
    regional_restrictions:[
      {
        mortgage:[
          {
            name:'Москва',
            restrictions:6000000
          },
          {
            name:'Московская область',
            restrictions:4000000
          },
          {
            name:'Санкт-Петербург',
            restrictions:4000000
          },
          {
            name:'Регионы, входящие в Дальневосточный федеральный округ',
            restrictions:4000000
          },
          {
            name:'Другой регион',
            restrictions:3000000
          },
        ],
      },
      {
        other:[
          {
            name:'Автокредит',
            restrictions:700000
          },
          {
            name:'Потребительский (физлицо)',
            restrictions:300000
          },
          {
            name:'Потребительский (ИП)',
            restrictions:350000
          },
          {
            name:'Кредитная карта',
            restrictions:100000
          },


        ],
      },
    ],
    calculation_credid_amount:'',
    calculation_region:'',
    calculation_type_credit: {},
    computed_solution_by_region:null,//решение по итогам регионов

    salary:0,
    salary_before_going_bank:0,
    final_state:null,

    state_approval:[
      {
        name:'check_not_work',
        state:true
      },
      {
        name:'input_per_year',
        state:false
      },
      {
        name:'input_monthly',
        state:false
      },
      {
        name:'input_date',
        state:false
      },




    ],
    max_sum:null




  },
  getters:{
    REGIONAL_RESTRICTIONS(state){
      return state.regional_restrictions
    },
    TYPE_CREDIT(state){
      return state.type_credit
    },
    SOLUTION_REGION(state){
      return state.computed_solution_by_region
    },

    FINAL_STATE(state){
      return state.final_state
    },
    STATE_APPROVAL_CHECK_NOT_WORK(state){
      return state.state_approval[0].state
    },
    STATE_APPROVAL_INPUT_PER_YEAR(state){
      return state.state_approval[1].state
    },
    STATE_APPROVAL_INPUT_MONTHLY(state){
      return state.state_approval[2].state
    },
    STATE_APPROVAL_INPUT_DATE(state){
      return state.state_approval[3].state
    },

    MAX_SUMM(state){
      return state.max_sum
    }







  },
  mutations:{
    mutationAmountCredit(state,received_perem){
      state.calculation_credid_amount = received_perem
      // console.log(state);
    },
    mutationRegion(state,received_perem){
      state.calculation_region = received_perem

    },
    mutationTypeCredit(state,received_perem){
      // Vue.set(state.calculation_type_credit,'name',received_perem.name)
      // Vue.set(state.calculation_type_credit,'symbolic_name',received_perem.symbolic_name)
      state.calculation_type_credit = received_perem
    },
    //проверка на ограничение суммы кредита по регионам
    mutationcomputedSolutionByRegion(state){
      if(state.calculation_type_credit.symbolic_name=='mortgage'){

        const array_region = state.regional_restrictions[0].mortgage;
        for (let item of array_region){
          if(item.name==state.calculation_region){
            state.max_sum = item.restrictions
            if(item.restrictions>=state.calculation_credid_amount){
              state.computed_solution_by_region=true
            }
            else {
              state.computed_solution_by_region=false
            }
          }
        }
      }
      else{
        const array_region = state.regional_restrictions[1].other;
        for(let item of array_region){
          if(item.name==state.calculation_type_credit.name){
            state.max_sum = item.restrictions
            if(item.restrictions>=state.calculation_credid_amount){
              state.computed_solution_by_region=true
            }
            else {
              state.computed_solution_by_region=false
            }
          }
        }
      }
    },

    mutationChecboxNotWork(state,received_perem){
      state.state_approval[0].state=received_perem
      // console.log(state);
    },
    mutationInputPerYear(state,received_perem){
      state.state_approval[1].state=received_perem
      // console.log(state);
    },
    mutationInputMonthly(state,received_perem){
      state.state_approval[2].state=received_perem
      // console.log(state);
    },
    mutationInputDate(state,received_perem){
      state.state_approval[3].state=received_perem
      // console.log(state);
    },








  },
  actions:{
    //Расчёт по ограничению
    ActionCreditAmount({commit},param){
      commit('mutationAmountCredit',param)
      commit('mutationcomputedSolutionByRegion',param)

    },
    //Получаю регион
    ActionRegion({commit},param){
      commit('mutationRegion',param)
      commit('mutationcomputedSolutionByRegion',param)
    },
    ActionTypeCredit({commit},param){
      commit('mutationTypeCredit',param)
      commit('mutationcomputedSolutionByRegion',param)
    },

    //Проверка на заполенность и корректность всех необъодимых полей
    ActionChecboxNotWork({commit},param){
      commit('mutationChecboxNotWork',param)
    },

    ActionInputPerYear({commit},param){
      commit('mutationInputPerYear',param)
    },
    ActionInputMonthly({commit},param){
      commit('mutationInputMonthly',param)
    },
    ActionInputDate({commit},param){
      commit('mutationInputDate',param)
    },








  },
})
</script>
