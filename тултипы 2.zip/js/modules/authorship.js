/* eslint-disable */
import Vue from 'vue';
import Swiper, { Navigation, Pagination } from 'swiper';
// const gf = this.paginationSlider_s
import paginationSlider_s from './redesign-site/paginationSlider';

Swiper.use([Navigation, Pagination]);
export default function authorship() {
  const app = new Vue({
    el: '#authorship',
    data: {
      title:'Привет',
      swiper_desctop:null
    },
    methods: {

      sliderResize(){
        let win_width
        win_width= window.screen.width
        if(win_width>670){
          this.swiper_desctop=true
        }
        else {
          this.swiper_desctop=false
        }
      },

      authorsDetailedSliderDes() {
        const swiper = new Swiper('.js--authorship-detailed-des', {
          init: true,
          loop: false,
          slidesPerView: 1,
          spaceBetween: 10,
          simulateTouch: true,
          autoHeight: true,
          pagination: {
            el: '.js--pag-detail-author-des',
            clickable: true,
          },
          navigation: false,
          breakpoints: {
          },
          on: {
            beforeInit:()=>{

            },
            afterInit: function (el) {
              // paginationSlider_s(el)
            },
            resize:function (el){
              // paginationSlider_s(el)
            }
          }
        });
      },
      authorsDetailedSliderMob() {
        const swiper_mob = new Swiper('.js--authorship-detailed-mob', {
          init: true,
          loop: false,
          slidesPerView: 1,
          spaceBetween: 10,
          simulateTouch: true,
          autoHeight: true,
          pagination: {
            el: '.js--pag-detail-author-mob',
            clickable: true,
          },
          navigation: false,
          breakpoints: {
          },
          on: {
            beforeInit:()=>{

            },
            afterInit: function (el) {
              // paginationSlider_s(el)
            },
            resize:function (el){
              // paginationSlider_s(el)
            }
          }
        });

      }
    },
    mounted() {
      // this.authorsDetailedSliderMob()
      // this.authorsDetailedSliderDes()
      let win_width
      win_width= window.screen.width

      if(win_width>670){
        this.swiper_desctop=true
        setTimeout(()=>{
          this.authorsDetailedSliderDes()
        },100)

      }
      else {
        this.swiper_desctop=false
        setTimeout(()=>{
          this.authorsDetailedSliderMob()
        },100)

      }
      window.addEventListener('resize', ()=>{
        this.sliderResize()
      });
    }
  })
}
