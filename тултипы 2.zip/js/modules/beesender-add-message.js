/* eslint-disable */
function beesenderBlockWindow() {
  const btn = document.querySelector('#beesenderchat-widget-startbutton');
  const close = document.querySelector('#beesenderchat-closebutton');

  if (btn) {
    btn.addEventListener('click', () => {
      if(document.documentElement.clientWidth < 470&&getComputedStyle(document.body).position != 'fixed'){
        document.body.classList.add('body-modal-beesenderchat');
        document.body.setAttribute('style', `top:-${window.scrollY}px;position: fixed;`);
      }
    });
  }
  if (close) {
    close.addEventListener('click', () => {
      if(document.body.classList.contains('body-modal-beesenderchat')){
        // eslint-disable-next-line no-unused-vars
        document.body.classList.remove('body-modal-beesenderchat');
        const scrollY = document.body.style.top;
        document.body.style.position = '';
        document.body.style.top = '';
        window.scrollTo(0, parseInt(scrollY || '0') * -1);
      }
    });
  }


}
export default function beesenderAddMessage() {
  // eslint-disable-next-line no-unused-vars
  const i = setInterval(() => {
    if (document.querySelector('#beesenderchat')) {

      // если нашли останавливаем таймер и вызываем алерт
      clearInterval(i);

      // window.addEventListener('resize', function(event){
      //   beesenderBlockWindow()
      // });
      beesenderBlockWindow()



      const beesenderchat = document.querySelector('#beesenderchat-container-body');
      // eslint-disable-next-line no-unused-vars
      // eslint-disable-next-line no-unused-vars
      const parts = beesenderchat.querySelector('.beesenderchat-conversation-parts>span>div[data-v-32a953be]');
      if (parts) {
        // eslint-disable-next-line camelcase,no-unused-vars
        const new_div = parts.querySelector('.beesenderchat-additional-message');
        // eslint-disable-next-line camelcase
        // eslint-disable-next-line no-unused-vars
        const divelem = document.createElement('div');
        divelem.setAttribute('style', 'margin-top: 50px;');
        divelem.className = 'beesenderchat-additional-message';
        // eslint-disable-next-line max-len
        let html = '<p style="font-size: 12px;line-height: 14px;font-family: Gilroy-SemiBold,sans-serif;color: #2A2936;">В нашем чате мы не&nbsp;обрабатываем сообщения, которые содержат ваши персональные данные. ';
        if (typeof conf !== 'undefined' && conf !== null && conf.hasOwnProperty('UF_PHONE') && conf.hasOwnProperty('UF_EMAIL')) {
          // eslint-disable-next-line max-len
          html += '<span style="margin-top: 7px;display: block;">Позвонить <a style="font-size: 13px;color: #8BC540;white-space: nowrap;" href="tel:' + conf.UF_PHONE + '">' + conf.UF_PHONE_formatted + '</a>';
          // eslint-disable-next-line max-len
          html += '<br/> Написать письмо на&nbsp;<a style="font-size: 13px;color: #8BC540;white-space: nowrap;" href="mailto:' + conf.UF_EMAIL + '">' + conf.UF_EMAIL + '</a></span>';
        }
        html +='</p>';
        divelem.innerHTML = html;
        // element.after(divelem);
        parts.append(divelem);
      }
    }
  }, 1000);
}
