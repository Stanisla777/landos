/* eslint-disable */
// Обработчик скролла
function handleScroll() {
  // let isTrigger = false
  const parentBlock = document.querySelectorAll('.js--another-thing-animation-show');
  parentBlock.forEach(block => {
      const position = block.getBoundingClientRect();

      // if (position.top < window.innerHeight * 0.9) {
      if (position.top < window.innerHeight - 30) {
        setTimeout(()=>{
          block.classList.add('show')
        },1000)

      }

      // isTrigger=true
      // window.removeEventListener('scroll',handleScroll)
  });
}

export default function animationShow() {
  window.addEventListener('scroll', handleScroll);
  handleScroll();
}
