/* eslint-disable */


// Проверка видимости блока
function isBlockVisible(block, offset = 60) {
  const rect = block.getBoundingClientRect();
  const viewportHeight = window.innerHeight || document.documentElement.clientHeight;
  return (
    rect.top >= 0 &&
    // rect.bottom <= viewportHeight - offset
    rect.bottom <= viewportHeight + offset
  );
}

//когда меняется окно
function initResize() {
  const countBlocks = document.querySelectorAll('.js--count-people');
  // init(countBlocks);
}

// Обработчик скролла
function handleScroll() {
  let isTrigger = false
  const countBlocks = document.querySelectorAll('.js--count-people');
  countBlocks.forEach(block => {
    if (isBlockVisible(block) && !isTrigger) {
      init(countBlocks);
      isTrigger=true
      window.removeEventListener('scroll',handleScroll)
    }
  });
}


// Функция для создания HTML-структуры цифрового колеса
function createDigitWheel(digit) {
  const container = document.createElement('div');
  container.className = 'digit-container';

  const strip = document.createElement('div');
  strip.className = 'digit-strip';

  // Создаем 20 цифр (два полных набора)
  for (let i = 0; i < 20; i++) {
    const span = document.createElement('div');
    span.textContent = i % 10;
    strip.appendChild(span);
  }

  container.appendChild(strip);
  return {
    container,
    strip,
    digit
  };
}

// Функция для замены цифр на анимированные колеса
function replaceDigitsWithWheels(p, dataCount) {
  console.log('p');
  p.classList.remove('opacity-0')
  const originalContent = p.textContent;
  const cleanData = dataCount.replace(/\s/g, '');
  let digitIndex = 0;

  p.innerHTML = '';

  for (let i = 0; i < originalContent.length; i++) {
    if (originalContent[i] === ' ') {
      const space = document.createElement('div');
      space.className = 'space';
      p.appendChild(space);
    } else {
      const digitValue = parseInt(cleanData[digitIndex]);
      const wheel = createDigitWheel(digitValue);
      p.appendChild(wheel.container);
      digitIndex++;
    }
  }

  return p.querySelectorAll('.digit-strip');
}

// Функция для запуска анимации
/*function animateDigitWheel(strip, digit) {


  const steps = 10 + digit;
  const height = strip.firstElementChild.offsetHeight;
  const randomOffset = Math.random() * 0.3 + 0.9; // Случайная скорость

  // Сбрасываем трансформацию
  strip.style.transition = 'none';
  strip.style.transform = 'translateY(0)';

  // Запускаем анимацию в следующем фрейме
  requestAnimationFrame(() => {
    strip.style.transition = `transform ${2 * randomOffset}s cubic-bezier(0.34, 1.56, 0.64, 1)`;
    strip.style.transform = `translateY(-${steps * height}px)`;
  });
}*/

// Очистка лишних цифр в полосе
function cleanupDigitStrip(strip, digit) {
  // Вычисляем индекс оставляемой цифры (10 + digit)
  const keepIndex = 10 + digit;
  const children = strip.children;

  // Находим нужный элемент
  const keepElement = children[keepIndex];

  // Удаляем все элементы кроме нужного
  while (strip.firstChild) {
    strip.removeChild(strip.firstChild);
  }

  // Возвращаем оставшуюся цифру
  strip.appendChild(keepElement);

  // Сбрасываем трансформацию
  strip.style.transition = 'none';
  strip.style.transform = 'translateY(0)';
}

function animateDigitWheel(strip, digit) {
  return new Promise((resolve) => {
    const steps = 10 + digit;
    const height = strip.firstElementChild.offsetHeight;
    const randomOffset = Math.random() * 0.3 + 0.9;

    strip.style.transition = 'none';
    strip.style.transform = 'translateY(0)';

    requestAnimationFrame(() => {
      // Обработчик окончания анимации
      const onAnimationEnd = () => {
        strip.removeEventListener('transitionend', onAnimationEnd);
        resolve(); // Разрешаем промис после анимации
      };

      strip.addEventListener('transitionend', onAnimationEnd);

      strip.style.transition = `transform ${2 * randomOffset}s cubic-bezier(0.34, 1.56, 0.64, 1)`;
      strip.style.transform = `translateY(-${steps * height}px)`;
    });
  });
}

// Основная функция инициализации
/*function init(countBlocks) {
  // const countBlocks = document.querySelectorAll('.js--count-people');
  countBlocks.forEach(block => {
    const dataCount = block.dataset.count;
    const p = block.querySelector('.js--at-count-people-text');

    // Заменяем цифры на анимированные элементы
    const digitStrips = replaceDigitsWithWheels(p, dataCount);

    // Запускаем анимацию с небольшой задержкой
    setTimeout(() => {
      const cleanData = dataCount.replace(/\s/g, '');
      digitStrips.forEach((strip, index) => {
        const digit = parseInt(cleanData[index]);
        animateDigitWheel(strip, digit);
      });
    }, 300);
  });
}*/

// Основная функция инициализации
function init(countBlocks) {
  countBlocks.forEach(block => {
    const dataCount = block.dataset.count;
    const p = block.querySelector('.js--at-count-people-text');
    const digitStrips = replaceDigitsWithWheels(p, dataCount);
    const cleanData = dataCount.replace(/\s/g, '');

    setTimeout(() => {
      // Собираем промисы для всех анимаций
      const animationPromises = [];

      digitStrips.forEach((strip, index) => {
        const digit = parseInt(cleanData[index]);
        animationPromises.push(animateDigitWheel(strip, digit));
      });

      // После завершения всех анимаций
      Promise.all(animationPromises).then(() => {
        digitStrips.forEach((strip, index) => {
          const digit = parseInt(cleanData[index]);
          cleanupDigitStrip(strip, digit);
        });
      });
    }, 300);
  });
}

// Инициализируем анимацию


export default function counterThing(el) {

  window.addEventListener('scroll', handleScroll);
  window.addEventListener('resize', initResize);
  handleScroll(); // Проверить при загрузке

}
