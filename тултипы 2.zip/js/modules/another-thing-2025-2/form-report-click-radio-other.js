/* eslint-disable */

export default function formReportRadioOther(el) {
  // для группы чекбоксов
  const checkbox_other_items = document.querySelectorAll('.js--feedback-check[data-show-other-option-block]')
  for (let checkbox_other_item of checkbox_other_items) {
    checkbox_other_item.addEventListener('change', function () {
      const field_code = this.getAttribute('data-show-other-option-block')
      if (field_code) {
        const other_option_block = document.querySelector(`.feed_back__block[data-field-code="${field_code}"]`)
        if (other_option_block) {
          if (this.checked) {
            other_option_block.classList.remove('hide')
          } else {
            other_option_block.classList.add('hide')
          }
        }
      }
    })
  }
  // для группы радиокнопок
  const radiogroup_with_other_option_items = document.querySelectorAll('.js--feedback-check[data-hide-other-option-block]')
  for (let radiogroup_with_other_option_item of radiogroup_with_other_option_items) {
    radiogroup_with_other_option_item.addEventListener('change', function () {
      const field_code = this.getAttribute('data-hide-other-option-block')
      if (field_code) {
        const other_option_block = document.querySelector(`.feed_back__block[data-field-code="${field_code}"]`)
        if (other_option_block) {
          if (this.checked) {
            other_option_block.classList.add('hide')
          }
        }
      }
    })
  }
}
