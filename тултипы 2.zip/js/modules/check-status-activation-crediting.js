// eslint-disable-next-line no-unused-vars
import IMask from 'imask';
import dropDown from './dropDown';
import tabChange from './tabs-change-m';

// eslint-disable-next-line no-unused-vars
export function checkStatusPinInput(param) {
  // eslint-disable-next-line camelcase,no-unused-vars
  const input_status = document.querySelectorAll(`${param} .js---status-input`); // относится к моему
  const inputs = document.querySelectorAll(`${param} .js---pin-input`);// не относится к моему
  const inputsArray = [...inputs];// не относится к моему
  const hiddenInput = document.querySelector(`${param} .js---pin-input-hidden`);
  const buttonStepTwo = document.querySelector(`${param} .js---check-status-button-step-2`);
  input_status.forEach((item) => {
    const input = item;
    // eslint-disable-next-line no-unused-vars
    input.addEventListener('input', (event) => {
      const targetVal = event.target;
      const position = targetVal.selectionStart; // Capture initial position
      // console.log(position);
      targetVal.selectionEnd = position;
    });
  });
  inputsArray.forEach((item) => {
    const input = item;
    input.addEventListener('keydown', (e) => {
      if (e.keyCode !== 13) {
        input.value = '';
      }
    });

    input.addEventListener('keyup', (e) => {
      const { value } = e.target;
      const nextInput = inputsArray[inputsArray.indexOf(input) + 1];
      const prevInput = inputsArray[inputsArray.indexOf(input) - 1];
      const lastInput = inputsArray.indexOf(input) === 3;
      const enterOnLastInput = e.keyCode === 13 && lastInput;
      if (e.keyCode === 8) {
        input.value = '';
        if (prevInput) {
          prevInput.focus();
        }
      }
      if (enterOnLastInput) {
        e.target.blur();
        buttonStepTwo.click();
      }
      if (value === value.replace(/[0-9]/, '')) {
        input.value = '';
        return false;
      }
      if (nextInput) {
        nextInput.focus();
      }

      let fullval = '';
      inputsArray.forEach((i) => {
        fullval += (parseInt(i.value, 10) || '0');
      });
      hiddenInput.value = fullval;
    });
  });
}
// Серия
// eslint-disable-next-line no-unused-vars
function checkStatusValidationSeries(param) {
  // eslint-disable-next-line camelcase
  const input_status = document.querySelectorAll(`${param} .js---status-input-series`);
  const maskOptions = {
    mask: 'aaa-0000000',
    max: 11,
    // lazy: true
  };
  // eslint-disable-next-line no-restricted-syntax,camelcase,no-undef
  for (const item of input_status) {
    // eslint-disable-next-line no-new
    new IMask(item, maskOptions);
  }
}
// Номер
function checkStatusValidatioNumber(param) {
  // eslint-disable-next-line camelcase
  const input_status = document.querySelectorAll(`${param} .js---status-input-number`);
  const maskOptions = {
    mask: '00-00-0000000000',
    max: 16,
    // lazy: true
  };
  // eslint-disable-next-line no-restricted-syntax,camelcase,no-undef
  for (const item of input_status) {
    // eslint-disable-next-line no-new
    new IMask(item, maskOptions);
  }
}
function checkStatusTimer(param) {
    const timeout = 60;
    const timerPane = document.querySelectorAll(`${param} .js---timer`);
    const additionalBlocks = document.querySelectorAll(`${param} .js---timer-additional`);
    const additionalBlocksArray = [...additionalBlocks];
    if (!timerPane) return false;
  // eslint-disable-next-line no-restricted-syntax
    for (const el of timerPane) {
      let timeLeft = parseInt(el.innerHTML, 10);
      if (timeLeft === 1) {
        el.innerHTML = timeout;

        el.style.display = 'inline';
        additionalBlocksArray.forEach((item) => {
          const block = item;
          block.style.display = 'inline';
        });
        checkStatusTimer();
      } else if (timeLeft === timeout) {
        const timer = setInterval(() => {
          if (--timeLeft > 0) {
            el.innerHTML = timeLeft;
          } else {
            el.style.display = 'none';
            additionalBlocksArray.forEach((item) => {
              const block = item;
              block.style.display = 'none';
            });
            clearInterval(timer);
          }
        }, 1000);
      }
    }
}

// eslint-disable-next-line no-unused-vars
function UserChange() {
  // eslint-disable-next-line camelcase
  const users_block = document.querySelectorAll('.js-tabs');
  // eslint-disable-next-line camelcase,no-restricted-syntax
  for (const elem of users_block) {
    // eslint-disable-next-line no-unused-vars
    const users = elem.querySelectorAll('.js-tabs-item');
    // eslint-disable-next-line no-restricted-syntax,no-shadow
    for (const item of users) {
      item.onclick = () => {
        // eslint-disable-next-line no-unused-vars,no-use-before-define
        tabChange(item);
      };
    }
  }
}

function UserChangeMobile() {
  const accordion = document.querySelector('.js--select-choise');
  // eslint-disable-next-line no-unused-vars
  if (accordion) {
    const btn = accordion.querySelector('.js-accordion-btn');
    btn.onclick = (ev) => {
      const element = ev.currentTarget;
      dropDown(element, 0);
    };
    const list = accordion.querySelectorAll('.js-tabs-item');
    // eslint-disable-next-line no-restricted-syntax
    for (const item of list) {
      item.onclick = () => {
        // eslint-disable-next-line no-use-before-define
        tabChange(item);
        const text = item.textContent;
        const parent = item.closest('.js--select-choise');
        parent.querySelector('.js-accordion-btn p').textContent = text;
        dropDown(btn, 0);
      };
    }
  }
}
export default function inputFieldStatus() {
  checkStatusPinInput('.activation-certificates-crediting');
  checkStatusValidationSeries('.activation-certificates-crediting');
  checkStatusValidatioNumber('.activation-certificates-crediting');
  checkStatusTimer('.activation-certificates-crediting');
  UserChange();
  UserChangeMobile();
}
