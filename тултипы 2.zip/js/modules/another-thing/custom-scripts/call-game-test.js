export default function callGameTest() {
  // eslint-disable-next-line camelcase
  const array_btn = document.querySelectorAll('.js--call-game-task');
  // eslint-disable-next-line no-restricted-syntax,camelcase
  for (const item of array_btn) {
    item.addEventListener('click', () => {
      const attrib = item.getAttribute('data-modal');
      const modal = document.querySelector(`#${attrib}`);
      if (modal) {
        modal.classList.add('open');
        if (document.documentElement.scrollHeight !== document.documentElement.offsetHeight) {
          document.body.classList.add('body-modal');
          document.body.setAttribute('style', `top:-${window.scrollY}px;position: fixed;`);
          document.ontouchmove = (e) => {
            e.preventDefault();
          };
        }
      }
    });
  }
}
