export default function numberFormatting(e) {
  // eslint-disable-next-line camelcase
  const e_field = e;
  // eslint-disable-next-line camelcase
  let c_p;
  let ie;
  // eslint-disable-next-line camelcase
  let e_range;
  let txt;
  let txt1;
  let brd;
  // eslint-disable-next-line camelcase,no-unused-vars
  let p_let;
  // eslint-disable-next-line camelcase
  let i_dig;
  let ii;
  // eslint-disable-next-line camelcase
  let is_digit;
  if ('createRange' in document) {
    // eslint-disable-next-line camelcase
    c_p = e_field.selectionEnd;
    ie = false;
} else {
    ie = true;
}
  if (ie) {
    // eslint-disable-next-line camelcase
    e_range = e_field.createTextRange();
    e_range.expand('character', e_field.value.length);
    // eslint-disable-next-line no-undef
    r = document.selection.createRange();
    // eslint-disable-next-line no-undef
    r.setEndPoint('StartToStart', e_range);
    // eslint-disable-next-line no-undef,camelcase
    c_p = r.text.length;
  }
  // eslint-disable-next-line prefer-const
  txt = e_field.value;
  txt1 = '';
  brd = txt.match(/[.,]/);
  if (brd == null) { brd = txt.length; } else { brd = brd.index; }
  // eslint-disable-next-line camelcase,prefer-const
  p_let = '';
  // eslint-disable-next-line camelcase
  i_dig = 0;
  for (let i = 0; i < txt.length; i++) {
    ii = txt.length - 1 - i;
    const lets = txt.charAt(ii);
    if ('0123456789'.indexOf(lets) >= 0) {
      // eslint-disable-next-line camelcase
      is_digit = true;
} else {
      // eslint-disable-next-line camelcase
      is_digit = false;
}
    // eslint-disable-next-line camelcase
    if (is_digit)i_dig++;
    // eslint-disable-next-line eqeqeq,camelcase
    if (ii == brd)i_dig = 0;
    // eslint-disable-next-line camelcase,eqeqeq
    if (ii >= brd) { if (is_digit || (ii == brd && (lets == '.' || lets == ','))) { txt1 = lets + txt1; } else if (c_p > ii)c_p--; }
    if (ii < brd) {
      // eslint-disable-next-line camelcase
 if (is_digit) { txt1 = lets + txt1; } else if (c_p > ii)c_p--;
      // eslint-disable-next-line camelcase,eqeqeq
      if (is_digit && i_dig % 3 == 0 && i_dig !== 0 && ii !== 0) { txt1 = ` ${txt1}`; if (c_p >= ii)c_p++; }
    }
  }
/// //////////сохранение готовой строки и восстановление позиции курсора
  e_field.value = txt1;
  if (ie) {
// eslint-disable-next-line no-undef
r.move('character', c_p);
    // eslint-disable-next-line no-undef
    r.select();
  } else { e_field.setSelectionRange(c_p, c_p); }
}
