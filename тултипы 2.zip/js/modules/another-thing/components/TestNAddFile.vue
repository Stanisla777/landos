<template lang="pug">
  .test-a__container(ref='mainContainer')
    .test-a__list(v-html="param_component.description")
    .test-a__add-zone-container(
      v-if="status===1||status===undefined"
    )
      .test-a__add-zone(
        ref="addZone"
      )
        vue-dropzone(
          ref="myVueDropzone"
          id="dropzone"
          :options="dropzoneOptions"
          @vdropzone-file-added="afterAdditionsFile"
          @vdropzone-max-files-exceeded="maxFiles"
          @vdropzone-removed-file="deleteFiles"
          @vdropzone-complete="sentFile"
          @vdropzone-error = "errorFile"
          v-bind:class="!first_window?'active':''"

          v-on:vdropzone-sending="sendingEvent"
          v-on:vdropzone-success="uploadSuccess"
        )
        .test-a__add-zone-first-state(
          v-if='first_window'
        )
          .test-a__add-zone-icon
            svg(width='34', height='32', viewbox='0 0 34 32', fill='none', xmlns='http://www.w3.org/2000/svg')
              path(fill-rule='evenodd', clip-rule='evenodd', d='M4.71056 3.70938C4.3031 3.70938 3.91233 3.87125 3.62421 4.15937C3.33609 4.44748 3.17423 4.83826 3.17423 5.24572V26.7544C3.17423 27.1618 3.33609 27.5526 3.62421 27.8407C3.91233 28.1288 4.3031 28.2907 4.71056 28.2907H29.2919C29.6994 28.2907 30.0901 28.1288 30.3782 27.8407C30.6664 27.5526 30.8282 27.1618 30.8282 26.7544V9.85472C30.8282 9.44726 30.6664 9.05648 30.3782 8.76836C30.0901 8.48025 29.6994 8.31838 29.2919 8.31838H15.4649C14.9512 8.31838 14.4715 8.06166 14.1866 7.63425L11.57 3.70938H4.71056ZM1.45151 1.98666C2.31586 1.12231 3.48818 0.636719 4.71056 0.636719H12.3922C12.9059 0.636719 13.3856 0.893442 13.6705 1.32085L16.2871 5.24572H29.2919C30.5143 5.24572 31.6866 5.73131 32.5509 6.59566C33.4153 7.46002 33.9009 8.63233 33.9009 9.85472V26.7544C33.9009 27.9768 33.4153 29.1491 32.5509 30.0134C31.6866 30.8778 30.5143 31.3634 29.2919 31.3634H4.71056C3.48818 31.3634 2.31586 30.8778 1.45151 30.0134C0.587152 29.1491 0.101562 27.9768 0.101562 26.7544V5.24572C0.101562 4.02334 0.587152 2.85102 1.45151 1.98666Z', fill='#97CB53')

          p.test-a__add-zone-title Перетащите сюда файл или нажмите, чтобы загрузить
          p.test-a__add-zone-sub Формат файла: pdf, изображение, таблица, документ

        .test-a__add-zone-wr-btn(
          v-if="!first_window"
        )
          .test-a__add-zone-btn.test-a__btn.test-a__button-add-file.unactive(
            v-if="status_sent||!active_btn||!status_internet"
          ) Отправить
          .test-a__add-zone-btn.test-a__btn.test-a__button-add-file.green(
            v-if="!status_sent&&active_btn&&status_internet"
            @click="postFile"
          ) Отправить
          p.test-a__error-hint(v-if="!status_internet&&!status_sent") Нет интернета
          p.test-a__add-zone-status(
            v-if="status_sent&&!requireModeration"
          ) Файл отправлен
          p.test-a__add-zone-status(
            v-if="status_sent&&requireModeration"
          ) Файл отправлен на модерацию

    //  на модерации после перезагрузки
    .test-a__add-zone-container(
      v-if="status===2"
    )
      .test-a__add-zone-added-file-wr
        .test-a__add-zone-added-file-icon
          svg(width='18', height='22', viewbox='0 0 18 22', fill='none', xmlns='http://www.w3.org/2000/svg')
            path(fill-rule='evenodd', clip-rule='evenodd', d='M0.87868 0.87868C1.44129 0.31607 2.20435 0 3 0H11C11.2652 0 11.5196 0.105357 11.7071 0.292893L17.7071 6.29289C17.8946 6.48043 18 6.73478 18 7V19C18 19.7957 17.6839 20.5587 17.1213 21.1213C16.5587 21.6839 15.7957 22 15 22H3C2.20435 22 1.44129 21.6839 0.87868 21.1213C0.31607 20.5587 0 19.7957 0 19V3C0 2.20435 0.31607 1.44129 0.87868 0.87868ZM3 2C2.73478 2 2.48043 2.10536 2.29289 2.29289C2.10536 2.48043 2 2.73478 2 3V19C2 19.2652 2.10536 19.5196 2.29289 19.7071C2.48043 19.8946 2.73478 20 3 20H15C15.2652 20 15.5196 19.8946 15.7071 19.7071C15.8946 19.5196 16 19.2652 16 19V8H11C10.4477 8 10 7.55228 10 7V2H3ZM12 3.41421L14.5858 6H12V3.41421ZM4 8C4 7.44772 4.44772 7 5 7H7C7.55228 7 8 7.44772 8 8C8 8.55228 7.55228 9 7 9H5C4.44772 9 4 8.55228 4 8ZM4 12C4 11.4477 4.44772 11 5 11H13C13.5523 11 14 11.4477 14 12C14 12.5523 13.5523 13 13 13H5C4.44772 13 4 12.5523 4 12ZM4 16C4 15.4477 4.44772 15 5 15H13C13.5523 15 14 15.4477 14 16C14 16.5523 13.5523 17 13 17H5C4.44772 17 4 16.5523 4 16Z', fill='white')
        .test-a__add-zone-added-file-name {{completedTask.value}}

      .test-a__add-zone-added-file-wr-btn
        .test-a__add-zone-btn.test-a__btn.test-a__button-add-file.unactive Отправить
        p.test-a__add-zone-status Файл отправлен на модерацию

      //  модерация завершена после перезагрузки
    .test-a__add-zone-container(
      v-if="status===3&&requireModeration"
    )
      .test-a__add-zone-added-file-wr
        .test-a__add-zone-added-file-icon
          svg(width='18', height='22', viewbox='0 0 18 22', fill='none', xmlns='http://www.w3.org/2000/svg')
            path(fill-rule='evenodd', clip-rule='evenodd', d='M0.87868 0.87868C1.44129 0.31607 2.20435 0 3 0H11C11.2652 0 11.5196 0.105357 11.7071 0.292893L17.7071 6.29289C17.8946 6.48043 18 6.73478 18 7V19C18 19.7957 17.6839 20.5587 17.1213 21.1213C16.5587 21.6839 15.7957 22 15 22H3C2.20435 22 1.44129 21.6839 0.87868 21.1213C0.31607 20.5587 0 19.7957 0 19V3C0 2.20435 0.31607 1.44129 0.87868 0.87868ZM3 2C2.73478 2 2.48043 2.10536 2.29289 2.29289C2.10536 2.48043 2 2.73478 2 3V19C2 19.2652 2.10536 19.5196 2.29289 19.7071C2.48043 19.8946 2.73478 20 3 20H15C15.2652 20 15.5196 19.8946 15.7071 19.7071C15.8946 19.5196 16 19.2652 16 19V8H11C10.4477 8 10 7.55228 10 7V2H3ZM12 3.41421L14.5858 6H12V3.41421ZM4 8C4 7.44772 4.44772 7 5 7H7C7.55228 7 8 7.44772 8 8C8 8.55228 7.55228 9 7 9H5C4.44772 9 4 8.55228 4 8ZM4 12C4 11.4477 4.44772 11 5 11H13C13.5523 11 14 11.4477 14 12C14 12.5523 13.5523 13 13 13H5C4.44772 13 4 12.5523 4 12ZM4 16C4 15.4477 4.44772 15 5 15H13C13.5523 15 14 15.4477 14 16C14 16.5523 13.5523 17 13 17H5C4.44772 17 4 16.5523 4 16Z', fill='white')
        .test-a__add-zone-added-file-name {{completedTask.value}}

      .test-a__add-zone-added-file-wr-btn
        .test-a__add-zone-btn.test-a__btn.test-a__button-add-file.unactive Отправить
        p.test-a__add-zone-status Файл прошел модерацию
        //  модерация и не было после перезагрузки
    .test-a__add-zone-container(
      v-if="status===3&&!requireModeration"
    )
      .test-a__add-zone-added-file-wr
        .test-a__add-zone-added-file-icon
          svg(width='18', height='22', viewbox='0 0 18 22', fill='none', xmlns='http://www.w3.org/2000/svg')
            path(fill-rule='evenodd', clip-rule='evenodd', d='M0.87868 0.87868C1.44129 0.31607 2.20435 0 3 0H11C11.2652 0 11.5196 0.105357 11.7071 0.292893L17.7071 6.29289C17.8946 6.48043 18 6.73478 18 7V19C18 19.7957 17.6839 20.5587 17.1213 21.1213C16.5587 21.6839 15.7957 22 15 22H3C2.20435 22 1.44129 21.6839 0.87868 21.1213C0.31607 20.5587 0 19.7957 0 19V3C0 2.20435 0.31607 1.44129 0.87868 0.87868ZM3 2C2.73478 2 2.48043 2.10536 2.29289 2.29289C2.10536 2.48043 2 2.73478 2 3V19C2 19.2652 2.10536 19.5196 2.29289 19.7071C2.48043 19.8946 2.73478 20 3 20H15C15.2652 20 15.5196 19.8946 15.7071 19.7071C15.8946 19.5196 16 19.2652 16 19V8H11C10.4477 8 10 7.55228 10 7V2H3ZM12 3.41421L14.5858 6H12V3.41421ZM4 8C4 7.44772 4.44772 7 5 7H7C7.55228 7 8 7.44772 8 8C8 8.55228 7.55228 9 7 9H5C4.44772 9 4 8.55228 4 8ZM4 12C4 11.4477 4.44772 11 5 11H13C13.5523 11 14 11.4477 14 12C14 12.5523 13.5523 13 13 13H5C4.44772 13 4 12.5523 4 12ZM4 16C4 15.4477 4.44772 15 5 15H13C13.5523 15 14 15.4477 14 16C14 16.5523 13.5523 17 13 17H5C4.44772 17 4 16.5523 4 16Z', fill='white')
        .test-a__add-zone-added-file-name {{completedTask.value}}

      .test-a__add-zone-added-file-wr-btn
        .test-a__add-zone-btn.test-a__btn.test-a__button-add-file.unactive Отправить
        p.test-a__add-zone-status Файл отправлен

          //      Благодарность после первого добавления файла

    //      Благодарность после первого добавления
    .test-a__thanks-passing(
      v-if="status_sent&&!requireModeration"
    )
      p.test-a__thanks-passing-title Благодарим за прохождение теста

      .test-a__final-result-label.test-a__final-result-label-frame
        p.test-a__thanks-passing-title-count Вы заработали:
        .test-a__thanks-passing-frame
          .test-a__final-result-unit
            p.test-a__thanks-passing-count +{{post_answer!=undefined?post_answer.score:0}}
            .test-a__final-result-unit-icon
              img(src="/dist/img/scored-icon1.png")
            p баллов

          .test-a__final-result-unit
            p.test-a__thanks-passing-count +{{post_answer!=undefined?post_answer.points:0}}
            .test-a__final-result-unit-icon
              img(src="/dist/img/scored-icon2.png")
            p очков

    //      Благодарность после перезагрузки
    .test-a__thanks-passing(
      v-if="status===3"
    )
      p.test-a__thanks-passing-title Благодарим за прохождение теста

      .test-a__final-result-label.test-a__final-result-label-frame
        p.test-a__thanks-passing-title-count Вы заработали:
        .test-a__thanks-passing-frame
          .test-a__final-result-unit
            p.test-a__thanks-passing-count +{{completedTask.score}}
            .test-a__final-result-unit-icon
              img(src="/dist/img/scored-icon1.png")
            p баллов

          .test-a__final-result-unit
            p.test-a__thanks-passing-count +{{completedTask.points}}
            .test-a__final-result-unit-icon
              img(src="/dist/img/scored-icon2.png")
            p очков

</template>
<script>
import vueDropzone from 'vue2-dropzone'
import Storage from '../development-tools/state.vue';
// import 'vue2-dropzone/dist/vue2Dropzone.min.css'




export default {
  name: 'AddFile',
  props: {
    param_component:Object,
    requireModeration:Boolean,
    id:Number,
    status:Number,
    userId:Number,
    completedTask:Object
  },
  data(){
    return {
      first_window:true,
      status_sent:false,
      active_btn:true,
      withoutModeration:false,
      dropzoneOptions: {
        url: '/api/local/gamedd/task/',
        // url: 'https://httpbin.org/post',
        headers: {
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        },
        autoProcessQueue:false,
        thumbnailWidth: 200,
        addRemoveLinks: true,
        maxFilesize:5,
        acceptedFiles: ".xls,.xlsx,.pdf,.jpg,.png",
        maxFiles:1,
      },

      post_answer:null

    }
  },
  methods:{
    autoHeight(){
      const element_height = this.$refs.addZone.querySelector('.test-a__add-zone-first-state').offsetHeight;
      this.$refs.myVueDropzone.$el.setAttribute('style', `height:${element_height}px`);
    },
    sendingEvent (file, xhr, formData) {
      formData.append('id', this.id);
      formData.append('itemId', this.param_component.id);
      formData.append('userId', this.userId);
    },
    sentFile(param){
      if (param.status=='error'&&param.accepted==true){
        const element = this.$refs.myVueDropzone.$el.querySelector('.dz-error-message');
        if (element) {
          element.querySelector('span').innerHTML = `Ошибка оправки на сервер`;
        }
      }
      else if (param.status=='success'){
        this.status_sent=true
        this.$refs.myVueDropzone.$el.querySelector('.dz-remove').remove();

      }

    },

    //Ответ от сервера

    uploadSuccess(file, response) {
      this.post_answer=response.result


      // this.post_answer={
      //   "id":1,
      //   "score":111, // баллы ДД
      //   "points":222, // наши очки
      //   "rightAnswers":9,
      //   "wrongAnswers":14,
      //   "showFinancialLevel": false, // выводить ли уровень фин.грамотности ТОЛЬКО для теста "фин.грамотности"
      //   "financialLevel": 1, // null | 1 | 2 | 3 - уровень фин.грамотности ТОЛЬКО для теста "фин.грамотности"
      // }
    },

    errorFile(param){
      const too_big = 'File is too big'
      const not_type = 'You can\'t upload files of this type'
      if (param.accepted === false) {
        const element = this.$refs.myVueDropzone.$el.querySelector('.dz-error-message');
        if (element) {
          const element_text = element.querySelector('span').textContent;
          if (element_text.includes(too_big)) {
            element.querySelector('span').innerHTML = `Размер файла не должен быть больше 5&nbsp;Mb`;
          }
          else if (element_text.includes(not_type)) {
            element.querySelector('span').textContent = 'Нельзя загрузить данный тип файла';
          }
          else {
            element.querySelector('span').textContent = 'Ошибка';
          }
        }
        this.active_btn = false;

      }

      else if (param.accepted===true){
        this.active_btn = true;
      }
    },
    afterAdditionsFile(param){
      this.active_btn = true;
      this.first_window=false

    },
    maxFiles(el){
      el.previewElement.className = "dz-preview dz-error dz-complete dz-image-preview excess-file"
    },
    deleteFiles(el){
      this.first_window=true
    },
    postFile(){
      this.$refs.myVueDropzone.processQueue()
    },

    dropAndDrag(){
    }
  },
  mounted() {
    this.dropAndDrag();
    if(this.$refs.addZone!==undefined){
      window.addEventListener('resize', ()=> {
        this.autoHeight()
      });
      this.autoHeight()
    }

  },
  computed: {
    status_internet() {
      return Storage.getters.STATUSINTERNET;
    },

  },
  watch: {
    post_answer() {
      if(this.post_answer!==undefined){
        const btn = this.$refs.mainContainer.closest('.js-p-wrap')
          .querySelector('.js--call-game-task');
        const arrow = this.$refs.mainContainer.closest('.js-p-wrap')
          .querySelector('.js--gamedd-next-task-control');
        const coundown = this.$refs.mainContainer.closest('.js-p-wrap')
          .querySelector('.gamedd-detailed__body-col-link');
        if (btn) {
          btn.removeAttribute('data-modal');
          btn.classList.add('unactive');
          btn.classList.remove('green');
        }
        if(arrow){
          if(this.post_answer.nextUrl!==''&&this.post_answer.nextUrl!==null&&this.post_answer.nextUrl!==undefined){
            arrow.querySelector('a').setAttribute('href',`${this.post_answer.nextUrl}`)
            arrow.classList.remove('unactive')
          }
        }
        if(coundown){
          coundown.classList.add('unactive')
        }
      }

    }
  },
  components: {
    vueDropzone
  },
};
</script>
<style scoped>
</style>
