<template lang="pug">
  .test-a__container.test-a__container-finansial-add
    .test-a__dual-selected-option-body.test-a__finansial-add-body
      .test-a__list(
        v-html="param_component.description"
      )
    .test-a__entry-field-fin-add-con
      p.test-a__entry-field-fin-add-des Ваша цель, ₽
      .test-a__entry-field-fin-add-wr
        .test-a__entry-field-fin-add.js--number-cost
          input(inputmode="numeric" type="text" placeholder="Введите сумму")(

            ref="InputField"
            @focus="focusInput"
            @blur="bindInput"
            @input="inputChange"
            @keydown="inputChangeDown"
            @paste="pasteNumber"
          )
          .test-a__entry-field-add-icon(
            @click="clearField"
            v-bind:class="target?'active':''"
          )
            svg(width='14', height='14', viewbox='0 0 14 14', fill='none', xmlns='http://www.w3.org/2000/svg')
              path(fill-rule='evenodd', clip-rule='evenodd', d='M5.58544 6.99975L0.635742 11.9495L2.04996 13.3637L6.99966 8.41396L11.9495 13.3638L13.3637 11.9495L8.41387 6.99975L13.3637 2.04996L11.9495 0.635742L6.99966 5.58553L2.04996 0.635835L0.635746 2.05005L5.58544 6.99975Z', fill='white')


        .test-a__add-zone-btn.green.test-a__btn(
          v-if="active_btn&&status_internet"
          @click="sendPost"
        ) Отправить
        .test-a__add-zone-btn.unactive.test-a__btn(
          v-if="!active_btn||status_internet===false"
        ) Отправить
        p.test-a__error-hint(v-if="status_internet===false") Нет интернета
        p.test-a__error-hint(v-if="hint!=''") {{hint}}
</template>

<script>
import IMask from 'imask';
import onlyNumbers from '../custom-scripts/only-numbers.js'
import axios from 'axios';
import Storage from '../development-tools/state.vue';
import inputField from '../mixin/inputField'
let mask;
export default {
  name: 'TestNFinansialAdd',
  mixins: [inputField],

  props: {
    param_component:Object,
    id:Number,
    userId:Number,

  },
  data() {
    return {
      answerValue: null,
      active_btn:false,
      stgMax:99999999,
      InputField:'',
      target:false
    }
  },

  methods: {
    focusInput(el){
      const element = el.currentTarget
      element.closest('.js--number-cost').classList.add('active')
    },
    bindInput(el){
      const element = el.currentTarget
      const val = element.value.length
      if(val===0){
        element.closest('.js--number-cost').classList.remove('active')
      }

    },
    clearField(el){
      const element = el.currentTarget
      // this.InputField=''
      mask.value=''
      element.closest('.js--number-cost').classList.remove('active')
      this.active_btn=false
    },
    sendPost(){
      let val = parseInt(this.$refs.InputField.value.replace(/\s/g, ''))
       Storage.dispatch('ActionFinansialAdd',[this.param_component.id,val])
    },
    inputChange(el){
      const element = el.currentTarget
      let val = element.value.replace(/\s/g, '')
      val = parseInt(val)
      // console.log(Number.isInteger(val));
      // console.log(typeof val);

      const array = element.value.split('');
      let sum = 0;

      // Running the for loop
      for (let i = 0; i < array.length; i++) {
        sum += parseInt(array[i])
      }
      if(element.value.length>0&&Number.isInteger(val)&&element.value!=='0'&&element.value!=='00'&&element.value!=='01'&&
        element.value!=='02'&&element.value!=='03'&&element.value!=='04'&&element.value!=='05'&&element.value!=='06'&&
        element.value!=='07'&&element.value!=='08'&&element.value!=='09'){
        this.target=true
        this.active_btn=true
      }
      else if(val.length===0||val.length===undefined){
        this.target=false
        this.active_btn=false
      }
    },
    pasteNumber(el){
      const element = el.currentTarget
      let char = (el.clipboardData || window.clipboardData).getData('text');
      if ( !char.match(/\d+/g)) {
        el.preventDefault();
      }
      if(char.match(/^0|\D/g)){
        el.preventDefault();
      }
    },
    inputChangeDown(event) {
      const element = event.currentTarget
      const val = element.value
      // console.log(event.which);

      // Разрешаем: backspace, delete, tab и escape
      if ( event.which == 46 || event.which == 8 || event.which == 9 || event.which == 27 ||
        // Разрешаем: Ctrl+A
        (event.which == 65 && event.ctrlKey === true) ||
        // Разрешаем: home, end, влево, вправо
        (event.which >= 35 && event.which <= 39)||event.which==86) {
        // Ничего не делаем
        return;
      }
      else {
        // Обеждаемся, что это цифра, и останавливаем событие keypress
        if ((event.which < 48 || event.which > 57) && (event.which < 96 || event.which > 105 )) {
          event.preventDefault();
        }
        if(event.which == 229){
          event.preventDefault();
        }

      }
      if(element.selectionStart===0&&(event.which == 96||event.which == 48||event.which == 229)){
        event.preventDefault();
      }




      // element.closest('.js--number-cost')
      //   .querySelector('b')
      //   .classList
      //   .remove('active');
    },
    inputCost(){
      const input_status = document.querySelectorAll('.js--number-cost input');
      const maskOptions = {
        mask: Number,
        thousandsSeparator: ' ',
        padFractionalZeros: false,
        normalizeZeros: false,
        signed: false,
        max:this.stgMax,
        // min:1,
        scale: 0,
      };
      for (const item of input_status) {
        mask = IMask(item, maskOptions);
      }
    },
    keyDown(el){
      // if (this.InputField.match(/[^0-9]|^0{1}/g)) {
      //   this.InputField =''
      // }
    },


  },



  computed: {
    status_internet() {
      return Storage.getters.STATUSINTERNET;
    },
    status_btn() {
      return Storage.getters.STATUSBTN;
    },
    hint() {
      return Storage.getters.HINT;
    },

  },
  watch: {


  },
  mounted() {
    this.inputCost()
  }

}
</script>
