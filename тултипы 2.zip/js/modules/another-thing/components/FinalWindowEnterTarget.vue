<template lang="pug">
  .test-a__container-final-add-target(
    ref="gamedd_wrapper"
  )
    .test-a__close-window.js--close--modals-window(
      @click="closeModal"
    )
      svg(width='24', height='24', viewbox='0 0 24 24', fill='none', xmlns='http://www.w3.org/2000/svg')
        circle(cx='12', cy='12', r='11', fill='#F1F2F4', stroke='#F1F2F4', stroke-width='2')
        path(d='M8.11137 15.8887C7.9161 15.6934 7.9161 15.3769 8.11137 15.1816L15.1824 8.11054C15.3777 7.91527 15.6943 7.91527 15.8895 8.11053V8.11053C16.0848 8.3058 16.0848 8.62238 15.8895 8.81764L8.81847 15.8887C8.62321 16.084 8.30663 16.084 8.11137 15.8887V15.8887Z', fill='#1C1B28')
        path(d='M15.8887 15.8896C15.6934 16.0849 15.3769 16.0849 15.1816 15.8896L8.11054 8.81855C7.91527 8.62328 7.91527 8.3067 8.11054 8.11144V8.11144C8.3058 7.91618 8.62238 7.91618 8.81764 8.11144L15.8887 15.1825C16.084 15.3778 16.084 15.6943 15.8887 15.8896V15.8896Z', fill='#1C1B28')

    .test-a__final-enter-target-icon
      svg(width='40', height='40', viewbox='0 0 40 40', fill='none', xmlns='http://www.w3.org/2000/svg')
        circle(cx='20', cy='20', r='20', fill='#82BF00')
        path(d='M11.1113 22.2224L17.5113 28.8891L28.8891 11.1113', stroke='white', stroke-width='3', stroke-linecap='round', stroke-linejoin='round')

    p.test-a__question.test-a__final-enter-target-question.
      Данные успешно внесены
    p.test-a__final-enter-target-des.
      Вы заработали

    .test-a__final-result-wr-count
      .test-a__final-result-unit
        //p.test-a__final-result-val +20
        p.test-a__final-result-val +{{post_answer!=undefined?post_answer.points:0}}
        .test-a__final-result-unit-icon
          img(src="/dist/img/scored-icon2.png")
        p.test-a__final-result-key очков
      .test-a__final-result-unit
        p.test-a__final-result-val +{{post_answer!=undefined?post_answer.score:0}}
        //p.test-a__final-result-val +100
        .test-a__final-result-unit-icon
          img(src="/dist/img/scored-icon1.png")
        p.test-a__final-result-key баллов

</template>
<script>
import Storage from '../development-tools/state.vue';

export default {
  name: 'FinalWindowEnterTarget',
  props:['param'],
  data(){
    return {

    }
  },
  methods: {
    callBonusWindow(){
      Storage.dispatch('ActionBonusWindow')
    },
    closeModal(el){
      const element = el.currentTarget
      element.closest('.modal-for-polls').classList.remove('open')
      document.body.classList.remove('body-unactive')
      document.body.classList.remove('body-modal')

      const scrollY = document.body.style.top;
      document.body.style.position = '';
      document.body.style.top = '';
      window.scrollTo(0, parseInt(scrollY || '0') * -1);

      document.ontouchmove =  (e)=> {
        return true;
      }
    },
  },
  mounted() {
  },
  computed: {
    post_answer(){
      return Storage.getters.POSTANSWER
    },
  },

};
</script>
<style scoped>
</style>
