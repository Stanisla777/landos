<template lang="pug">
  .test-a__container-final-win(
    ref="gamedd_wrapper"
  )
    p.test-a__question.
      Результат прохождения теста

    .test-a__final-wr-result.test-a__final-result-test
      .test-a__final-result-col
        .test-a__final-result-label-row
          p Уровень финграмотности:

        .test-a__final-financial-result
          //В зависимости от того, что придёт в financialLevel в посто запросе
          p.high(
            v-if="post_answer!=undefined&&post_answer.financialLevel===1"
          ) Высокий
          p.average(
            v-if="post_answer!=undefined&&post_answer.financialLevel===2"
          ) Средний
          p.short(
            v-if="post_answer!=undefined&&post_answer.financialLevel===3"
          ) Низкий

      //    приходит по api в post запросе
      .test-a__final-result-col
        .test-a__final-result-label-row
          p Вы заработали:
        .test-a__final-result-wr-count
          .test-a__final-result-unit
            p.test-a__final-result-val +{{post_answer!=undefined?post_answer.score:0}}
            .test-a__final-result-unit-icon
              img(src="/dist/img/scored-icon1.png")
            p.test-a__final-result-key баллов

          .test-a__final-result-unit
            p.test-a__final-result-val +{{post_answer!=undefined?post_answer.points:0}}
            .test-a__final-result-unit-icon
              img(src="/dist/img/scored-icon2.png")
            p.test-a__final-result-key очков

    .test-a__final-wr-btn.test-a__final-result-test-btn.js--close--modals-window
      .test-a__btn.green(
        @click="closeModal"
      ) Завершить

      //  будет или нет появляться по условию

</template>
<script>
import Storage from '../development-tools/state.vue';

export default {
  name: 'FinalWindowFinancialLiteracy',
  props:[],
  data(){
    return {
      lavel:1

    }
  },
  methods: {
    closeModal(el){
      const element = el.currentTarget
      element.closest('.modal-for-polls').classList.remove('open')
      document.body.classList.remove('body-unactive')
      document.body.classList.remove('body-modal')

      const scrollY = document.body.style.top;
      document.body.style.position = '';
      document.body.style.top = '';
      window.scrollTo(0, parseInt(scrollY || '0') * -1);

      document.ontouchmove =  (e)=> {
        return true;
      }
    },
  },
  mounted() {
  },
  computed: {
    post_answer(){
      return Storage.getters.POSTANSWER
    },

  },
};
</script>
<style scoped>
</style>
