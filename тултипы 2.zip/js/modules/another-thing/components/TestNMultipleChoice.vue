<template lang="pug">
  .test-a__container(
    ref="test_container"
  )
    .test-a__body(
      ref="BodyLabel"
    )
      .test-n-multiple-choice__row.test-n-multiple-choice__row_main
        .test-n-multiple-choice__elections
          span.test-n-multiple-choice__election-text Да
          span.test-n-multiple-choice__election-text Нет
      .test-n-multiple-choice__row.js--percent-row(v-for="(option, index) in param_component.options" :key="index")
        p.test-a__multiple-choice-text {{ option.name }}
        .test-n-multiple-choice__elections
          label.test-n-multiple-choice__checkbox-wrap
            .test-n-checkbox
              input(
                :value="true"
                :name="option.id+'-'+ param_component.id"
                type="radio"
                @change="changeVarint($event,param_component.id,option.id,true)"
              )
              .test-n-checkbox__icon
            span.test-n-multiple-choice__checkbox-text Да
          label.test-n-multiple-choice__checkbox-wrap
            .test-n-checkbox
              input(
                :value="false"
                :name="option.id+'-'+ param_component.id"
                type="radio"
                @change="changeVarint($event,param_component.id,option.id,false)"
              )
              .test-n-checkbox__icon
            span.test-n-multiple-choice__checkbox-text Нет
    .test-a__slider-btn(
      v-if="modal===true"
    )
      .test-a__btn.white(
        v-if="btn_prev"
        @click="btnPrev"
      ) Назад
      .test-a__btn.green(
        v-if="btn_next&&((status_internet===true&&status_btn===false)||(status_internet===false&&status_btn===false)||(status_internet===true&&status_btn===true))"
        @click="btnNext"
      ) Далее
      .test-a__btn.unactive(
        v-if="!btn_next||(status_btn&&status_internet===false)"
      ) Далее
      p.test-a__error-hint(v-if="status_internet===false") Нет интернета
      p.test-a__error-hint(v-if="hint!=''") {{hint}}
</template>

<script>


import Storage from '../development-tools/state.vue';
import eventBus from '../development-tools/eventBus.vue';


export default {
  name: 'TextNMultipleChoice',
  props: {
    param_component:Object,
    modal:Boolean
  },
  data() {
    return {
      btn_next:false,
      btn_prev:true,
      count:0
    }
  },

  methods: {
    autoHeight() {
      if (document.documentElement.clientWidth < 470) {
        const parent = this.$refs.test_container.closest('.js--test-cont');
        const title_height = parent.querySelector('.test-a__question').offsetHeight;
        parent.querySelector('.test-a__container')
          .setAttribute('style', `min-height:calc(100vh - 32px - 26px - 24px - ${title_height}px - 40px)`);
      }
    },

    btnNext(){
      this.count=0
      eventBus.$emit('eventbtnNext')
    },
    btnPrev(){
      this.count=0
      eventBus.$emit('eventbtnPrev')
    },

    fullnessCheck(){
      const array_label = this.$refs.BodyLabel.querySelectorAll('.js--percent-row');
      const array_input = this.$refs.BodyLabel.querySelectorAll('input:checked');
      if(array_label.length===array_input.length/2){
        this.btn_next=true
      }
    },



    changeVarint(elem,id_question,id_answer,state){
      const element = elem.currentTarget

      const array_label = this.$refs.BodyLabel.querySelectorAll('.js--percent-row');
      const array_input = this.$refs.BodyLabel.querySelectorAll('input:checked');
      if(array_label.length===array_input.length){
        this.btn_next=true
      }

      Storage.dispatch('ActionVariantMultiRadio',[id_question,id_answer,state])
    },

  },
  created(){
    eventBus.$on('slideNextTransition',()=>{
      if(this.count===0){
        this.fullnessCheck()
        this.count=1
      }
    })
    eventBus.$on('slidePrevTransition',()=>{
      if(this.count===0){
        this.fullnessCheck()
        this.count=1
      }
    })
    eventBus.$on('slideReachBeginning',()=>{
      // if(this.count_reach===0){
      this.btn_prev=false
      //   this.count_reach=1
      // }
    })
    eventBus.$on('slideFromEdge',()=>{
      // if(this.count_reach===0){
      this.btn_prev=true
      //   this.count_reach=1
      // }
    })

  },
  computed: {
    status_internet() {
      return Storage.getters.STATUSINTERNET;
    },
    status_btn() {
      return Storage.getters.STATUSBTN;
    },
    hint() {
      return Storage.getters.HINT;
    },
  },
  watch: {

  },
  updated() {
    // this.autoHeight()
  }
}
</script>
