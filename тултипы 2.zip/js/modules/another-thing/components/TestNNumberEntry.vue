<template lang="pug">
  .test-a__container(ref='mainContainer')
    .test-a__dual-selected-option-body
      .test-a__list(
        v-html="param_component.description"
      )
      .test-a__entry-field.test-a__entry-field-fin.js--number-cost(
        v-bind:class="sent?'unactive':''"
      )
        input(inputmode="numeric" type="text" placeholder="Введите сумму")(
          ref="InputField"
          @keyup="inputChange"
          @keydown="inputChangeDown"
          @input="inputField"
          @paste="pasteNumber"
        )
        //  появится, когда нажмётся отправить
        .test-a__entry-field-icon(
          v-if="sent"
        )
          svg(width='16', height='12', viewbox='0 0 16 12', fill='none', xmlns='http://www.w3.org/2000/svg')
            path(d='M14.6673 1L5.50065 10.1667L1.33398 6', stroke='white', stroke-width='2', stroke-linecap='round', stroke-linejoin='round')
        .test-a__entry-field-currency
          span
          b ₽
      .test-a__wr-btn.test-a__dual-selected-btn
        //чтобы заблокировать добавить класс .unactive класс .green убрать
        .test-a__add-zone-btn.green.test-a__btn(
          v-if="!sent&&active_btn&&status_internet"
          @click="sendPost"
        ) Отправить


        .test-a__add-zone-btn.unactive.test-a__btn(
          v-if="sent||!active_btn||!status_internet"
        ) Отправить
        p.test-a__error-hint(v-if="!status_internet") Нет интернета
        p.test-a__error-hint(v-if="hint!=''") {{hint}}
        //  появится, когда нажмётся отправить
        p.test-a__add-zone-final-des(
          v-if="sent"
        ) Сумма учтена и будет видна в личном кабинете

      .test-a__thanks-passing(
        v-if="sent"
      )
        p.test-a__thanks-passing-title Благодарим за прохождение теста

        .test-a__final-result-label
          p.test-a__thanks-passing-title-count Вы заработали:
          .test-a__final-result-unit
            p.test-a__thanks-passing-count +{{post_answer!=undefined?post_answer.score:0}}
            .test-a__final-result-unit-icon
              img(src="/dist/img/scored-icon1.png")
            p баллов

          .test-a__final-result-unit
            p.test-a__thanks-passing-count +{{post_answer!=undefined?post_answer.points:0}}
            .test-a__final-result-unit-icon
              img(src="/dist/img/scored-icon2.png")
            p очков

</template>

<script>
import IMask from 'imask';
import onlyNumbers from '../custom-scripts/only-numbers.js'
import axios from 'axios';
import Storage from '../development-tools/state.vue';
let maskName;

export default {
  name: 'TestNNumberEntry',
  props: {
    param_component:Object,
    id:Number,
    userId:Number,
  },
  data() {
    return {
      answerValue: null,
      sent:false,
      stgMax:99999999,
      active_btn:false,
      hint:'',
      attempt:0,
      post_answer:null
    }
  },

  methods: {
    sendPost(){
      this.$refs.InputField.closest('.js--number-cost').querySelector('.test-a__entry-field-currency span').textContent=(parseInt(this.$refs.InputField.value.replace(/\s/g, ''))).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
      if(this.attempt===0) {
        this.attempt = 1
        axios({
          method:'post',
          // url:'https://httpbin.org/post', //для раЗРАБОТКИ
          url:'/api/local/gamedd/task/',
          timeout: 10000,
          headers: {
            "Content-type": "application/json; charset=UTF-8",
            'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
          },

          data:{
            userId:this.userId,
            id: this.id,
            itemId:this.param_component.id,
            itemSelectedOption:this.data_tab,
            itemValue:parseInt(this.$refs.InputField.value.replace(/\s/g, ''))


          },
        })
          // Если запрос успешен
          .then((res) => {
            this.post_answer = res.data.result
            //
            // this.post_answer = {
            //   "id":1,
            //   "score":123, // баллы ДД
            //   "points":100, // наши очки
            //   "rightAnswers":9,
            //   "wrongAnswers":14,
            //   "showFinancialLevel": false, // выводить ли уровень фин.грамотности ТОЛЬКО для теста "фин.грамотности"
            //   "financialLevel": 1, // null | 1 | 2 | 3 - уровень фин.грамотности ТОЛЬКО для теста "фин.грамотности"
            // }
            this.sent = true
            this.hint=''
          })
          // Если запрос с ошибкой
          .catch((error)=> {
            if (error.response) {
              console.log(error.response);
              if (error.response.status == 401 || error.response.status == 403) {
                this.hint = `Время сессии истекло, перезагрузите страницу`
              } else {
                if (error.response && error.response.data.error != undefined && error.response.data.error.code) {
                  this.hint = `Ошибка ${error.response.data.error.code}. Обратитесь в колл-центр`
                } else {
                  this.hint = `Ошибка. Обратитесь в колл-центр`
                }
              }

              // if(error.response.status==404||error.response.status==522||error.response.status==524||error.response.status==523||error.response.status==503){
              //   this.hint=`Нет связи с сервером`
              // }
            } else if (error.request) {
              console.log(error.request);
              this.hint = `Нет связи с сервером`
            }
            this.attempt = 0
          });
      }


    },
    pasteNumber(el){
      const element = el.currentTarget
      let char = (el.clipboardData || window.clipboardData).getData('text');
      if ( !char.match(/\d+/g)) {
        el.preventDefault();
      }
      if(char.match(/^0|\D/g)){
        el.preventDefault();
      }
    },
    inputField(el) {
      const element = el.currentTarget;
      const val = element.value
      if(val.length===0 && val=='0'){
        el.preventDefault()
      }
      let char = el.data
      if (element.value.length > 0 && (Number.isInteger(parseInt(element.value))&&element.value.replace(/\s/g, '')>0)) {
        // eslint-disable-next-line no-undef
        this.active_btn = true;
      } else {
        this.active_btn = false;
      }

      if(element.value.length > 0&&parseInt(element.value.replace(/\s/g, ''))===0){
        maskName.value=''
        element.closest('.js--number-cost').querySelector('b').classList.remove('active')
        element.setAttribute('placeholder','Введите сумму')
      }


      if(val.length>0&&(val.length===1&&val!=0)){
        element.closest('.js--number-cost').querySelector('b').classList.add('active')
        element.setAttribute('placeholder','')
      }

      if(val.length===0){
        element.closest('.js--number-cost').querySelector('b').classList.remove('active')
        element.setAttribute('placeholder','Введите сумму')
      }
      element.closest('.js--number-cost').querySelector('span').textContent=val

    },
    inputChangeDown(event) {
      const element = event.currentTarget
      const val = element.value
      // console.log(event.which);

      // Разрешаем: backspace, delete, tab и escape
      if ( event.which == 46 || event.which == 8 || event.which == 9 || event.which == 27 ||
        // Разрешаем: Ctrl+A
        (event.which == 65 && event.ctrlKey === true) ||
        // Разрешаем: home, end, влево, вправо
        (event.which >= 35 && event.which <= 39)||event.which==86) {
        // Ничего не делаем
        return;
      }
      else {
        // Обеждаемся, что это цифра, и останавливаем событие keypress
        if ((event.which < 48 || event.which > 57) && (event.which < 96 || event.which > 105 )) {
          event.preventDefault();
        }
        if(event.which == 229){
          event.preventDefault();
        }

      }
      if(element.selectionStart===0&&(event.which == 96||event.which == 48||event.which == 229)){
        event.preventDefault();
      }
      if(val.length===10){
        event.preventDefault()
      }
    },
    inputChange(el){
      const element = el.currentTarget
      const val = element.value
      element.closest('.js--number-cost').querySelector('span').textContent=val

    },

    inputCost(){
      const input_status = document.querySelectorAll('.js--number-cost input');
      const maskOptions = {
        mask: Number,
        thousandsSeparator: ' ',
        padFractionalZeros: false,
        normalizeZeros: false,
        signed: false,
        max:this.stgMax,
        scale: 0,

      };
      for (const item of input_status) {
        new IMask(item, maskOptions);
      }
    },

  },



  computed: {
    status_internet() {
      return Storage.getters.STATUSINTERNET;
    },

  },
  watch: {
    post_answer() {
      const btn = this.$refs.mainContainer.closest('.js-p-wrap')
        .querySelector('.js--call-game-task');
      const arrow = this.$refs.mainContainer.closest('.js-p-wrap')
        .querySelector('.js--gamedd-next-task-control');
      const coundown = this.$refs.mainContainer.closest('.js-p-wrap')
        .querySelector('.gamedd-detailed__body-col-link');
      if (btn) {
        btn.removeAttribute('data-modal');
        btn.classList.add('unactive');
        btn.classList.remove('green');
      }
      if(arrow){
        if(this.post_answer!==undefined&&this.post_answer.nextUrl!==''&&this.post_answer.nextUrl!==null&&this.post_answer.nextUrl!==undefined){
          arrow.querySelector('a').setAttribute('href',`${this.post_answer.nextUrl}`)
          arrow.classList.remove('unactive')
        }
      }
      if(coundown){
        coundown.classList.add('unactive')
      }


    }
  },
  mounted() {
    this.inputCost()
  }

}
</script>
