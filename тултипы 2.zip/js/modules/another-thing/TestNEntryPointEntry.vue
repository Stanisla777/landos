<template lang="pug">
  div
    template
      test-n-entry(
        :userId="userId"
        :idTask="idTask"
      )

</template>
<script>
import Storage from './development-tools/state.vue';
const TestNEntry = () => import ("./TestNEntry.vue");


export default {
  name: 'TestNEntryPointEntry',
  data(){
    return {
      userId:null,
      idTask:null
    }
  },
  methods:{

  },
  mounted(){
    this.userId = this.$attrs.userid
    this.idTask = this.$attrs.id
  },
  computed:{
  },
  watch:{
  },
  components:{
    TestNEntry
  }
};
</script>
<style scoped>
</style>
