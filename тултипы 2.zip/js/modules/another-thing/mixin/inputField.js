export default {
  methods: {
    inputField(el) {
      const element = el.currentTarget;
      element.value = element.value.replace(/^0/, '');
      // eslint-disable-next-line radix
      if (element.value.length > 0 && Number.isInteger(parseInt(element.value))) {
        // eslint-disable-next-line no-undef
        this.active_btn = true;
      } else {
        this.active_btn = false;
      }
    },
  }
};
