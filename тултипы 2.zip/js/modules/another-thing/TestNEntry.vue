<template lang="pug">
  .test-a__main-container(ref='mainContainer')
    .test-a__final-window-container-common(
      v-if="finish_window&&QUESTIONS.finalType==='common'"
    )
      template(v-if="!bonus_window")
        final-window(
          :param ="QUESTIONS.bonusTaskClick"
        )
      template(v-if="bonus_window")
        bonus-task(
          :param ="QUESTIONS.bonusTaskClick"
        )

    .test-a__final-window-container-enter-target(
      v-if="finish_window&&QUESTIONS.finalType==='financial_add'"
    )
      template
        final-window-enter-target

    .test-a__final-window-container-fintest(
      v-if="finish_window&&QUESTIONS.finalType==='financial_test'"
    )
      template
        final-window-financial-literacy
    .test-a__container.js--test-container(
      v-if="!finish_window"
    )
      template(
        v-if="count_question>1"
      )
        slide-calculator(
          ref="slide_count"
          v-show="QUESTIONS.modal===true"
          :count_slide="count_question"

        )
      .swiper-container.js--test-a-slider(
        :class="'js--slider-'+QUESTIONS.taskId"
        ref="SliderCon"
        )
        .swiper-wrapper
          .swiper-slide(v-for="(slide,key,ind) in QUESTIONS.items")
            template
              test-n(
                :param ="slide"
                :id="QUESTIONS.id"
                :modal="QUESTIONS.modal"
                :requireModeration="QUESTIONS.requireModeration"
                :status="QUESTIONS.status"
                :userId="QUESTIONS.userId"
                :completedTask="QUESTIONS.completedTask"
              )


      //.test-a__slider-btn-opacity(
      //  v-if="QUESTIONS.items[0].type!=='financial_add'"
      //)
      //  .test-a__btn.white.js--test-a-btn-left(
      //    ref="BtnPrev"
      //  ) Назад
      //  .test-a__btn.green.js--test-a-btn-right(
      //    ref="BtnNext"
      //    @click="clickForward"
      //  ) Далее

      .test-a__slider-btn-opacity
        .js--test-a-btn-left(
          ref="BtnPrev"
          @click="clickBack"
        )
        .js--test-a-btn-right(
          ref="BtnNext"
          @click="clickForward"
        )



</template>

<script>
import Vue from 'vue';
import VueAxios from 'vue-axios';
import axios from 'axios';
import TestN from './TestN.vue';
import SlideCalculator from './components/SlideCalculator.vue';
import FinalWindow from './components/FinalWindow.vue';
import BonusTask from './components/BonusTask.vue';
import FinalWindowFinancialLiteracy from './components/FinalWindowFinancialLiteracy.vue';
import FinalWindowEnterTarget from './components/FinalWindowEnterTarget.vue';
import Swiper, {Navigation, Pagination} from 'swiper';
import Storage from './development-tools/state.vue';
import eventBus from './development-tools/eventBus.vue';
Swiper.use([Navigation, Pagination]);
let mySwiper;

Vue.use(VueAxios, axios);
const apiForGet = '/local/ajax/tests.php';
const apiForSend = '/local/ajax/add_tests.php';

export default {
  name: 'TestNEntry',

  props: ['userId','idTask'],
  data() {
    return {
      finalWindow:false,
      btn_next:false,
      colorTheme: 'black', // тип цветовой темы, может принимать значения: 'white', 'gray или 'black'
      buttonText: 'Проверить ответ', // текст кнопки проверки ответа,
      counter_slide:true,
      QUESTIONS:{},
      count_question:0,
      current_slide:1,
      status_btn:false,
      // в зависимости от того, что придёт в переменной "view" - frame или slider
      showElement:false
    }
  },
  methods: {

    clickSentResult(){
      Storage.dispatch('ActionClickForward')
    },
    clickBack(){
      Storage.dispatch('ActionClickBack')
    },
    clickForward(){
      if(this.status_btn===false){
        Storage.dispatch('ActionClickForward',false)
      }
      else {
        Storage.dispatch('ActionClickForward',true)
      }

    },

    //инициализация слайдера
    initSlider() {
      if(this.QUESTIONS.modal===false){
        let current_slide = this.current_slide
        mySwiper = new Swiper('.js--test-a-slider', {
          loop: false,
          simulateTouch: false,
          allowTouchMove: false,
          autoHeight:false,
          slidesPerView: 1,
          // navigation: {
          //   nextEl: '.js--test-a-btn-right',
          //   prevEl: '.js--test-a-btn-left'
          // },
          pagination: {
            el: '.test-pagination',
            clickable: true
          },
          on:{
            init: () => {
              // const parent = document.querySelector('.js--test-a-slider');
              // const height = parent.querySelector('.swiper-slide:first-child .test-cont').offsetHeight;
            },
            transitionEnd: ()=>{
              const slide_calculator = document.querySelectorAll('.test-a__counter')
              slide_calculator.forEach(function (item){
                // item.querySelector('.test-a__counter-des span:first-child').textContent = mySwiper.realIndex+1
              })
              this.$refs.slide_count.$el.querySelector('.test-a__counter-des span:first-child').textContent = mySwiper.realIndex+1
              this.current_slide = mySwiper.realIndex+1
            },
          }
        });
      }
      else {
        let current_slide = this.current_slide
        mySwiper = new Swiper(".js--test-a-slider", {

          loop: false,
          simulateTouch: false,
          allowTouchMove: false,
          spaceBetween: 35,
          autoHeight:true,
          resizeObserver:true,





          // navigation: {
          //   nextEl: '.js--forward',
          //   prevEl: '.js--back'
          // },
          pagination: {
            el: '.test-pagination',
            clickable: true
          },
          breakpoints: {
            0: {
              speed: 0,
              resizeObserver:true,
              // autoHeight:false
            },
            1024: {
              // effect: "slide",
              // speed: 300,
              // resizeObserver:false,
            }
          },
          on:{
            init: () => {
              // const parent = document.querySelector('.js--test-a-slider');
              // const height = parent.querySelector('.swiper-slide:first-child .test-cont').offsetHeight;
              eventBus.$emit('slideReachBeginning')
            },
            transitionEnd: ()=>{
              this.$refs.mainContainer.querySelector('.swiper-wrapper').classList.add('active');
              const slide_calculator = document.querySelectorAll('.test-a__counter')
              // mySwiper.update()
              slide_calculator.forEach(function (item){
                // item.querySelector('.test-a__counter-des span:first-child').textContent = mySwiper.realIndex+1
              })
              this.$refs.slide_count.$el.querySelector('.test-a__counter-des span:first-child').textContent = mySwiper.realIndex+1
              this.current_slide = mySwiper.realIndex+1
            },
            transitionStart: ()=>{
              this.$refs.mainContainer.querySelector('.swiper-wrapper').classList.remove('active');
            },



            slideNextTransitionEnd:()=>{
              eventBus.$emit('slideNextTransition')
            },
            slideChangeTransitionStart:()=>{
              eventBus.$emit('slideNextTransitionStart')
            },

            slidePrevTransitionEnd:()=>{
              eventBus.$emit('slidePrevTransition')
            },

            fromEdge:()=>{
              eventBus.$emit('slideFromEdge')
            },
            reachBeginning:()=>{
              eventBus.$emit('slideReachBeginning')

            },

          }

        });
      }


    },
    //Крличество слайдов
    countSlider(){
      this.count_question = this.QUESTIONS.items.length
    },

    /**
     * Запрашивает данные по api, заносит их в data
     */
    getData() {//от Аламикса
      axios.get(apiForGet, {
        params:{
          id: this.id
        }
      })
        .then((res) => {
          const { typeOfTest, options, title, description, end_text, end_title, btn, colorTheme } = res.data;
          this.typeOfTest = typeOfTest;
          this.options = options;
          this.title = title;
          this.description = description;
          this.answerText = end_text;
          this.answerTitle = end_title;
          if (btn) this.buttonText = btn; // если условие не выполнено, то останется дефолтный текст
          if (colorTheme) this.colorTheme = colorTheme; // если условие не выполнено, то останется дефолтная тема
        })
        .catch((err) => {
          console.error(err);
        });
    },

    dataGetParam(){
      // let userId = this.$attrs.userid
      // let idTask = this.$attrs.id
      const config_header = {
        headers: {
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        }
      }
      // axios.get(`http://localhost:3000/result`, { //локальное api
      axios.get(`/api/local/gamedd/task/?userId=${this.userId}&id=${this.idTask}`,{
        headers: {
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        }

      })
        .then((res) => {
          this.QUESTIONS=res.data.result //бой
          // this.QUESTIONS=res.data //моя локалка
        })
        .then((res)=>{
          this.initSlider();
          this.countSlider();
          // this.status_btn = this.current_slide === this.count_question;
          if(this.current_slide === this.count_question){
            this.status_btn=true
            Storage.dispatch('ActionStatusBtn',true)
          }
          else {
            this.status_btn=false
            Storage.dispatch('ActionStatusBtn',false)
          }
          Storage.dispatch('ActionCommonInfo',[this.QUESTIONS.id,this.QUESTIONS.userId])
        })
        .catch((err) => {
          console.error(err);
        });

    }

  },

  computed: {
    finish_window(){
      return Storage.getters.FINISHWINDOW
    },
    bonus_window(){
      return Storage.getters.BONUSWINDOW
    },
    final_win_target(){
      return Storage.getters.FINAL_WIN_TARGET
    },
    btn_next_slider(){
      return Storage.getters.BTNNEXT;
    },
    call_button_lock() {
      return Storage.getters.CALL_BUTTON_LOCK;
    },
    post_answer() {
      return Storage.getters.POSTANSWER;
    },
    status_internet() {
      return Storage.getters.STATUSINTERNET;
    },



  },
  mounted() {
    window.addEventListener('online', () => {
      Storage.dispatch('ActionInternet',true)
    });
    window.addEventListener('offline', () => {
      Storage.dispatch('ActionInternet',false)
    });
    //Это для боя раскоментировать
    this.dataGetParam()
    const modal = this.$refs.mainContainer.closest('#modal-for-at-tests')
    if(modal&&modal.classList.contains('open')){
      document.body.setAttribute('style',`top:-${window.scrollY}px;position: fixed;`);
    }

    // ////Закоментировать - это для разработки
    // this.initSlider();
    // this.countSlider();
    // // this.status_btn = this.current_slide === this.count_question;
    // if(this.current_slide === this.count_question){
    //   this.status_btn=true
    //   Storage.dispatch('ActionStatusBtn',true)
    // }
    // else {
    //   this.status_btn=false
    //   Storage.dispatch('ActionStatusBtn',false)
    // }
    // Storage.dispatch('ActionCommonInfo',[this.QUESTIONS.id,this.QUESTIONS.userId])
  },
  updated() {
    // this.initSlider();
  },
  watch:{
    current_slide(){
      // this.status_btn = this.current_slide === this.count_question;
      if(this.current_slide === this.count_question){
        this.status_btn=true
        Storage.dispatch('ActionStatusBtn',true)
      }
      else {
        this.status_btn=false
        Storage.dispatch('ActionStatusBtn',false)
      }
    },
    call_button_lock() {
      if (this.call_button_lock === true) {
        const btn = this.$refs.mainContainer.closest('.js-p-wrap')
          .querySelector('.js--call-game-task');
        const arrow = this.$refs.mainContainer.closest('.js-p-wrap')
          .querySelector('.js--gamedd-next-task-control');
        const coundown = this.$refs.mainContainer.closest('.js-p-wrap')
          .querySelector('.gamedd-detailed__body-col-link');

        if (btn) {
          btn.removeAttribute('data-modal');
          btn.classList.add('unactive');
          btn.classList.remove('green');
          btn.textContent='Тест пройден';
        }
        if(arrow){

          if(this.post_answer!=null&&this.post_answer.nextUrl!==''&&this.post_answer.nextUrl!==null&&this.post_answer.nextUrl!==undefined){
            arrow.querySelector('a').setAttribute('href',`${this.post_answer.nextUrl}`)
            arrow.classList.remove('unactive')
          }
        }
        if(coundown){
          coundown.classList.add('unactive')
        }

      }
    }
  },
  created(){
    eventBus.$on('eventbtnNext',()=>{
     this.$refs.BtnNext.click();
     //  debugger
     mySwiper.slideNext()
    })
    eventBus.$on('eventbtnPrev',()=>{
     this.$refs.BtnPrev.click();
      mySwiper.slidePrev()
    })

  },


  components: {
    TestN,
    SlideCalculator,
    FinalWindow,
    BonusTask,
    FinalWindowFinancialLiteracy,
    FinalWindowEnterTarget

  },

}
</script>
