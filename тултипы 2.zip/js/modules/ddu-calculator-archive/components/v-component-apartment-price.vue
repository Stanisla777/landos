<template lang="pug">
  .calculator_s__calculator-row.calculator_s__two-columns_col.margin
    .calculator_s__period-input-wrapper
      p.calculator_s__calculator-label Цена договора, ₽
    .calculator_s__calculator-input.calculator_s__placeholder-numeric-set.js--contract-price(
      @click="inputFocus"
    )
      input(type="text" inputmode="numeric" placeholder="Введите сумму")(
        @input="inputValue"
        @keyup="inp_sum"
        @keydown="inp_sum"
        @paste="inp_sum"
        @focus="inp_sum"
      )
      p(v-if="currency") ₽

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import numberFormatting from '../custom-scripts/number-formatting.js'
import IMask from 'imask';
import Storage from '../development-tools/state.vue';
export default {
  name: 'v-component-apartment-price',
  props:[],
  data(){
    return {
      stgMax:1000000000,
      currency:false
    }
  },
  methods:{
    inputCost(){
      const input_status = document.querySelector('.js--contract-price input');
      const maskOptions = {
        mask: Number,
        thousandsSeparator: ' ',
        // min: 0,
        max: this.stgMax
      };

      new IMask(input_status, maskOptions);
    },
    inp_sum(e){
      const e_field = e.currentTarget
      // numberFormatting(e_field)
    },

    inputValue(el){
      const element = el.currentTarget;
      // element.style.width = 0+'px';
      if(element.value.length>0&&parseInt(element.value.replace(/\s/g, ''))<=this.stgMax){
        element.setAttribute('placeholder',0)
        // this.currency=true
        const price_for_calculation = parseInt(element.value).toFixed(0)
        Storage.dispatch('ActionApartmentPrice',[parseInt(element.value.replace(/\s/g, '')),true])
      }
      if (element.value.length===0) {
        element.setAttribute('placeholder','Введите сумму')
        // this.currency=false
        // element.style.width=100+"%"
        Storage.dispatch('ActionApartmentPrice',[0,false])
      }


    },
    // sendInputChange(param){
    // },
    inputFocus(el){
      const element = el.currentTarget
      element.querySelector('input').focus()
    },
  },
  mounted(){
    this.inputCost()
  },
  computed:{},
  watch:{
  },
  created(){
    eventBus.$on('eventcheckboxChanged',(el)=>{

      if(el[1]==false){
        // this.currency=false
      }
    })
  },
  components:{}
};
</script>
<style scoped>
</style>
