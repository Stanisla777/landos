<template lang="pug">
  .credit-holiday__row-btn
    button.credit-holiday__btn(
      :class="[(state_approval[0].state===true&&state_approval[1].state===true&&state_approval[2].state===true&&state_approval[3].state===true&&state_approval[4].state===true)?'active':'unactive']"
      @click="calculateData"
    ) Рассчитать

</template>
<script>
import Vue from 'vue';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-component-button',
  props:[],
  data(){
    return {
      co_borrower:0,
      btn_active:[],
      button_active:true,
      button_status:[
        {
          name:'check_not_work',
          state:true
        },
        {
          name:'input_salary_per_year',
          state:true
        },
        {
          name:'input_date',
          state:false
        },
      ]
    }
  },
  methods:{

    calculateData(){
      Storage.dispatch('ActionCalculate');
      this.$emit('eventCalculate')
    }
  },
  mounted(){

  },
  computed:{

    check_not_work(){
     return Storage.getters.STATE_APPROVAL_CHECK_NOT_WORK
    },
    input_salary_per_year(){
      return Storage.getters.STATE_APPROVAL_INPUT_PER_YEAR
    },
    input_salary_monthly(){
      return Storage.getters.STATE_APPROVAL_INPUT_MONTHLY
    },
    input_date(){
      return Storage.getters.STATE_APPROVAL_INPUT_DATE
    },
    state_approval(){
      return Storage.getters.STATE_BUTTON_STATE
    },






  },
  watch:{
  },
  created(){
    eventBus.$on('eventRight',(param)=>{
      if(param===true&&this.btn_active.length===0){
        this.btn_active.push(true)
      }
      else{
        this.btn_active.splice(0);
      }

    })
  },

  components:{}
};
</script>
<style scoped>
</style>
