<template lang="pug">
  .calculator_s__calculator-row.calculator_s__two-columns_col.margin.js--wrap-date-actual
    .calculator_s__period-input-wrapper
      p.calculator_s__calculator-label Дата передачи объекта по ДДУ
    .calculator_s__calculator-input.js--calendar-input
      input(type="text" placeholder="дд.мм.гггг" inputmode="numeric")(
        @input="changeDate"
      )
    p.ddu__error-green(v-if="delivery_date&&appearance_error!==true&&first_date!==true") Дата передачи объекта ещё не наступила, расчёт может быть не точным
    p.ddu__error(v-if="appearance_error&&first_date!==true") Объект был сдан в срок
    p.ddu__error.ddu__error-first-date.js--first-date(
      v-if="first_date"
    ) Данных о периоде раньше этой даты нет
</template>
<script>
import IMask from 'imask';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import PopUp from '../components/v-component-pop-up.vue';
export default {
  name: 'v-date-transfer',
  props:['first_period_date'],
  data(){
    return {
      error_count:new Date(1982, 0, 1),
      first_date:false

    }
  },
  methods:{
    inputCalendar(){
      const input_status = document.querySelectorAll('.js--calendar-input input');
      const maskOptions = {
        mask: Date,
        // min: new Date(2013,8,13),
        // min: this.error_count,
        // max:new Date()
        // lazy:false
      };
      // eslint-disable-next-line no-restricted-syntax,camelcase,no-undef
      for (const item of input_status) {
        // eslint-disable-next-line no-new
        new IMask(item, maskOptions);
      }
    },
    changeDate(el) {
      const element = el.currentTarget;
      const container = element.closest('.js--tax-deduction_calculations');
      const data1 = new Date(element.value.replace(/(_|\s)+/g, "").substr(6, 4)+'-'+element.value.replace(/(_|\s)+/g, "").substr(3, 2)+"-"+element.value.replace(/(_|\s)+/g, "").substr(0, 2));
      const date2 = this.first_period_date;
      const oneDay = 1000 * 60 * 60 * 24;

      if (element.value.replace(/(_|\s)+/g, "").length===10) {

        const present_moratorium_begin = data1.getTime() - date2.getTime();
        const diffpresent_moratorium__begin = Math.round(present_moratorium_begin / oneDay);

        if(diffpresent_moratorium__begin<0){
          this.first_date=true
          Storage.dispatch('ActionInputDateTransfer', [null, false ]);
        }
        else {
          this.first_date=false
          const data = element.value.replace(/(_|\s)+/g, "").substr(6, 4)+'-'+element.value.replace(/(_|\s)+/g, "").substr(3, 2)+"-"+element.value.replace(/(_|\s)+/g, "").substr(0, 2);
          Storage.dispatch('ActionInputDateTransfer', [data, true ]);
        }


      }
      else if(element.value.replace(/(_|\s)+/g, "").length < 10){
        Storage.dispatch('ActionInputDateTransfer', [null, false ]);
      }

    }
  },
  mounted(){
    this.inputCalendar()
  },
  computed:{
    appearance_error(){
      return Storage.getters.STATE_DIFFERENCE_DAYS
    },
    delivery_date(){
      return Storage.getters.DELIVERY_DATE
    },
    // appearance_error(){
    //   return Storage.getters.STATE_DIFFERENCE_DAYS
    // },


  },
  watch:{
  },
  components:{
    PopUp
  }
};
</script>
<style scoped>
</style>
