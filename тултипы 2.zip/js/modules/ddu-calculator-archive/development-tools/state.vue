<script>
import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);


export default new Vuex.Store({
  state:{
    //массив из ключевых ставок
    array_key_rate:null,
    //дата и ставка последнего изменения ключевой ставки ЦБ
    last_change_key:{},

    //дата первого периода со ставкой
    first_period_data:null,



    //ключевая ставка на сегодняшний день
    key_rate:0,

    //ставка, кторая участвует в расчётах
    applicable_rate:0,

    //ключевая ставка на день сдачи объекта
    rate_day_delivery:0,
    //ключевая ставка на день начала просрочки
    rate_day_delay:0,
    //ключевая ставка на день сдачи объекта
    rate_day_fact_delivery:0,


    apartment_price:0,
    apartment_price_show:0,

    date_transfer:null,
    date_transfer_actual:null,


    //нужен, чтобы выводить ошибку "Дата начала периода не может быть позднее, чем дата окончания"
    difference_days:false,

    //нужен, чтобы выводить ошибку "Дата начала периода не может быть позднее, чем дата окончания"
    delivery_date:false,

    //нужен, чтобы выводить ошибку "Дата начала периода не может быть позднее, чем дата окончания"
    delivery_date_fact:false,

    //чекбокс юридическое лицо
    check_entity:false,
    //чекбокс физическое лицо
    checbox_individual:false,
    checbox_individual_show:null,

    //тип применение процентной ставки
    type_delay:'day_delivery_object',
    type_delay_show:'day_delivery_object',

    state_approval:[
      {
        name:'apartment_price',
        state:false
      },
      {
        name:'input_date_transfer',
        state:false
      },
      {
        name:'input_date_transfer_actual',
        state:false
      },
      {
        name:'difference_days',
        state:false
      },

      {
        name:'check_person',
        state:false
      },
      {
        name:'delivery_date',
        state:false
      },
      {
        name:'delivery_date_fact',
        state:false
      },






    ],

    // moratorium_dates:null,

    moratorium_dates:[
      //должно быть MM-DD-YEAR
      {
        begin:'29.03.2022',
        end:'30.06.2023',
        amount_days:0
      }
    ],

    lower_rate:[
      {
      begin:'25.02.2022',
      end:'31.12.2022'
    }
    ],
    // lower_rate:null,

    //разница дней сдачи объекта по договору и фактической сдачи
    days_of_delay:0,
    //сколько вычесть дней моратория
    array_minus_moratorium_days:[],
    minus_moratorium_days:0,

    day_show:0,

    calculate_result:0,

    rate_periods:[

    ],
    rate_periods_for_calc:[

    ],

    formula_for_show:[],
    show_final_block:false,






  },
  getters:{


    //*******
    STATE_APPROVAL_CHECK_NOT_WORK(state){ //*
      return state.state_approval[0].state
    },
    STATE_APPROVAL_INPUT_PER_YEAR(state){
      return state.state_approval[1].state
    },
    STATE_APPROVAL_INPUT_MONTHLY(state){
      return state.state_approval[2].state
    },
    STATE_APPROVAL_INPUT_DATE(state){
      return state.state_approval[3].state
    },

    //******

    //массив ключевых ставок
    ARRAY_KEY_RATE(state){
      return state.array_key_rate
    },
    // дата последнаго изменения ставки
    LAST_CHANGE_KEY(state){
      return state.last_change_key
    },



    STATE_DIFFERENCE_DAYS(state){
      return state.difference_days
    },
    DELIVERY_DATE(state){
      return state.delivery_date
    },
    DELIVERY_DATE_FACT(state){
      return state.delivery_date_fact
    },

    STATE_BUTTON_STATE(state){
      return state.state_approval
    },

    CALCULATE_RESULT(state){
      return state.calculate_result
    },

    APARTMENT_PRICE(state){
      return state.apartment_price
    },
    APARTMENT_PRICE_SHOW(state){
      return state.apartment_price_show
    },


    DAYS_OF_DELAY(state){
      return state.days_of_delay
    },

    MINUS_MORATORIUM_DAYS(state){
      return state.minus_moratorium_days
    },

    DAY_SHOW(state){
      return state.day_show
    },

    CHECBOX_INDIVIDUAL(state){
      return state.checbox_individual
    },
    CHECBOX_INDIVIDUAL_SHOW(state){
      return state.checbox_individual_show
    },


    CHECK_ENTITY(state){
      return state.check_entity
    },
    APPLICABLE_RATE(state){
      return state.applicable_rate
    },

    FIRST_PERIOD_DATA(state){
      return state.first_period_data
    },
    TYPE_DELAY(state){
      return state.type_delay
    },
    TYPE_DELAY_SHOW(state){
      return state.type_delay_show
    },

    FORMULA_FOR_SHOW(state){
      return state.formula_for_show
    },
    SHOW_FINAL_BLOCK(state){
      return state.show_final_block
    },

    RATE_PERIOD(state){
      return state.rate_periods
    }






  },
  mutations:{

    //подсчёт дней маратория нужно будет доработать, так как подсчёты только с одним отрезком маратория возможно удалить
    mutationMoratorium(state,received_perem){
      const oneDay = 1000 * 60 * 60 * 24;
      state.moratorium_dates=received_perem
      for(let i=0;i<state.moratorium_dates.length;i++){
        Vue.set(state.moratorium_dates[i],'begin',state.moratorium_dates[i].begin.substr(6, 4)+'-'+state.moratorium_dates[i].begin.substr(3, 2)+"-"+state.moratorium_dates[i].begin.substr(0, 2))
        Vue.set(state.moratorium_dates[i],'end',state.moratorium_dates[i].end.substr(6, 4)+'-'+state.moratorium_dates[i].end.substr(3, 2)+"-"+state.moratorium_dates[i].end.substr(0, 2))

        const date1 = new Date(state.moratorium_dates[i].begin);
        const date2 = new Date(state.moratorium_dates[i].end);

        //чтобы вбиваемая дата сдачи жилья по договору не была больше сегодняшней даты, тогда просрочки нет
        const present_dayTime = date2.getTime() - date1.getTime();
        let diffpresent_dayTime = Math.round(present_dayTime / oneDay);
        diffpresent_dayTime+=1
        Vue.set(state.moratorium_dates[i],'amount_days',diffpresent_dayTime)

      }

    },
    mutationLowerRate(state,received_perem){
      state.lower_rate=received_perem
      for(let i=0;i<state.lower_rate.length;i++){
        Vue.set(state.lower_rate[i],'begin',state.lower_rate[i].begin.substr(6, 4)+'-'+state.lower_rate[i].begin.substr(3, 2)+"-"+state.lower_rate[i].begin.substr(0, 2))
        Vue.set(state.lower_rate[i],'end',state.lower_rate[i].end.substr(6, 4)+'-'+state.lower_rate[i].end.substr(3, 2)+"-"+state.lower_rate[i].end.substr(0, 2))
      }

    },

    //Ключевая ставка + записываю дату начала последней ключевой ставки и саму последнюю ставку
    mutationKeyRates(state,received_perem){
      state.array_key_rate=received_perem
      Vue.set(state.last_change_key,'key',Object.values(received_perem[received_perem.length-1])[0])
      Vue.set(state.last_change_key,'date',Object.keys(received_perem[received_perem.length-1])[0])

      state.first_period_data = new Date(String(Object.keys(received_perem[0])[0]).substr(6, 4)+", "+String(Object.keys(received_perem[0])[0]).substr(3, 2)+", "+String(Object.keys(received_perem[0])[0]).substr(0, 2))


    },
    //Ключевая ставка получается это нужно юудет убрать
    mutationKeyRate(state,received_perem){
      state.key_rate=(parseFloat(received_perem))/100
    },



    //Стоимость квартиры
    mutationApartmentPrice(state,received_perem){
      state.state_approval[0].state=received_perem[1]
      state.apartment_price=received_perem[0]
    },
    mutationTypeDelay(state,received_perem){
      state.type_delay=received_perem

    },

    mutationChecboxEntity(state,received_perem){
      state.check_entity=received_perem
      state.checbox_individual=false


      if(state.checbox_individual==true || state.check_entity==true){
        state.state_approval[4].state=true
      }
      else {
        state.state_approval[4].state=false
      }

    },
    mutationChecboxIndividual(state,received_perem){
      state.checbox_individual=received_perem
      state.check_entity=false
      if(state.checbox_individual==true || state.check_entity==true){
        state.state_approval[4].state=true
      }
      else {
        state.state_approval[4].state=false
      }
    },


    mutationInputDateTransfer(state,received_perem){
      state.rate_periods=[]
      state.state_approval[1].state=received_perem[1]
      state.date_transfer=received_perem[0]
      //подсчёт разницы дней
      if(state.date_transfer!=null && state.date_transfer_actual!=null){
        const oneDay = 1000 * 60 * 60 * 24;
        const date1 = new Date(state.date_transfer);
        const date2 = new Date(state.date_transfer_actual);
        const date3 = new Date()


        // ----------------- МОРАТОРИЙ---------------------------------------------------

        //от фактической сдачи объекта
        const present_moratorium_end_3 = date2.getTime() - date1.getTime();
        const diffpresent_moratorium__end_3= Math.round(present_moratorium_end_3 / oneDay);

        state.array_minus_moratorium_days=[]
        for(let i =0;i<state.moratorium_dates.length;i++){
          //день начала маратория нужно будет доработать, так отрезков мораториев может быть несколько, а я пока беру 1
          const date_mor_begin = new Date(state.moratorium_dates[i].begin)
          const date_mor_end = new Date(state.moratorium_dates[i].end)
          //от даты сдачи по ДДУ

          const present_moratorium_begin = date1.getTime() - date_mor_begin.getTime();
          const diffpresent_moratorium__begin = Math.round(present_moratorium_begin / oneDay);

          //от фактической сдачи объекта
          const present_moratorium_end = date2.getTime() - date_mor_end.getTime();
          const diffpresent_moratorium__end = Math.round(present_moratorium_end / oneDay);

          //от фактической сдачи объекта
          const present_moratorium_end_2 = date2.getTime() - date_mor_begin.getTime();
          const diffpresent_moratorium__end_2 = Math.round(present_moratorium_end_2 / oneDay);


          if (diffpresent_moratorium__end_2<0){
            state.array_minus_moratorium_days.push(0)
          }
          if (diffpresent_moratorium__begin===0 && diffpresent_moratorium__end===0){
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days - 2)
          }
          if (diffpresent_moratorium__begin<0 && diffpresent_moratorium__end>0){
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days)
          }
          if (diffpresent_moratorium__begin===0 && diffpresent_moratorium__end>0){
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days-1)
          }
          if (diffpresent_moratorium__begin<0 && diffpresent_moratorium__end===0){
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days-1)
          }

          if (diffpresent_moratorium__begin>0 && diffpresent_moratorium__end>0){
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days - (diffpresent_moratorium__begin+1))
          }
          if (diffpresent_moratorium__begin>0 && diffpresent_moratorium__end===0){
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days - diffpresent_moratorium__begin-2)
          }
          if (diffpresent_moratorium__begin>0 && diffpresent_moratorium__end<0){

            state.array_minus_moratorium_days.push(diffpresent_moratorium__end_3-1)
          }
          //Посмотреть
          if (diffpresent_moratorium__begin<0 && diffpresent_moratorium__end<0 && diffpresent_moratorium__end_2>0){
            state.array_minus_moratorium_days.push(diffpresent_moratorium__end_2)
          }
          if (diffpresent_moratorium__begin===0 && diffpresent_moratorium__end<0 && diffpresent_moratorium__end_2>0){
            state.array_minus_moratorium_days.push(diffpresent_moratorium__end_2-1)
          }
        }

        //считаю просрочку дата по договору сдачи - дата фактической сдачи, только наоборот

        const diffInTime = date2.getTime() - date1.getTime();
        const diffInDays = Math.round(diffInTime / oneDay);
        state.days_of_delay = parseInt(diffInDays)-1

        if (diffInDays==0){
          state.days_of_delay=0
        }
        else if (diffInDays<=-1){
          state.state_approval[3].state=false
          state.difference_days=true
          state.days_of_delay=0
        }
        else {
          state.state_approval[3].state=true
          state.difference_days=false
        }

        state.array_minus_moratorium_days = state.array_minus_moratorium_days.filter(function(item) {
          return item > 0
        })

        state.minus_moratorium_days = state.array_minus_moratorium_days.reduce(function(acc, val) { return acc + val; }, 0)

        if(state.days_of_delay - state.minus_moratorium_days<0){
          // state.minus_moratorium_days=0
        }

        //----подсчитываю дни пониженной ставки в зависимости от вбиваемых дат

        const date_lower_begin = new Date(state.lower_rate[0].begin)
        const date_lower_end = new Date(state.lower_rate[0].end)

        const present_lower_contract_begin = date1.getTime() - date_lower_begin.getTime();
        const diffpresent_lower_contract_begin = Math.round(present_lower_contract_begin / oneDay);

        const present_lower_contract_end = date1.getTime() - date_lower_end.getTime();
        const diffpresent_lower_contract_end = Math.round(present_lower_contract_end / oneDay);

        const present_lower_fact_begin = date2.getTime() - date_lower_begin.getTime();
        const diffpresent_lower_fact_begin = Math.round(present_lower_fact_begin / oneDay);

        const present_lower_fact_end = date2.getTime() - date_lower_end.getTime();
        const diffpresent_lower_fact_end = Math.round(present_lower_fact_end / oneDay);

        //-------Подсчитываю, какую ставку использовать в зависимости от от дат

        let rate_entered_date=1;
        let rate_period_date = null

        let rate_entered_date_2=1;
        let rate_period_date_2 = null

        //ДЛЯ ПОНИЖЕННОЙ СТАВКИ

        for (let t = 0;t<state.lower_rate.length;t++){
          const present_day_key_fact_begin_lower_rate = date1.getTime() - new Date(state.lower_rate[t].begin).getTime();
          const diffpresent_day_key_fact_begin = Math.round(present_day_key_fact_begin_lower_rate / oneDay);

          const present_day_key_fact_end_lower_rate = date1.getTime() - new Date(state.lower_rate[t].end).getTime();
          const diffpresent_day_key_fact_end = Math.round(present_day_key_fact_end_lower_rate / oneDay);

          const present_day_key_fact_begin_lower_rate_2 = date2.getTime() - new Date(state.lower_rate[t].begin).getTime();
          const diffpresent_day_key_fact_begin_2 = Math.round(present_day_key_fact_begin_lower_rate_2 / oneDay);

          const present_day_key_fact_end_lower_rate_2 = date2.getTime() - new Date(state.lower_rate[t].end).getTime();
          const diffpresent_day_key_fact_end_2 = Math.round(present_day_key_fact_end_lower_rate_2 / oneDay);

          if(diffpresent_day_key_fact_begin>=0&&diffpresent_day_key_fact_end<0){
            rate_period_date=state.lower_rate[t].rate
          }

          if(diffpresent_day_key_fact_begin_2>=0&&diffpresent_day_key_fact_end_2<0){
            rate_period_date_2=state.lower_rate[t].rate
          }
        }

        // const promice = new Promise((resolve,reject) => {



        //ставка на день сдачи объекта
        for (let i = 0;i<state.array_key_rate.length; i++){
          if(i===state.array_key_rate.length-1){


          }
          let data_begin = String(Object.keys(state.array_key_rate[i])).substr(6, 4)+'-'+String(Object.keys(state.array_key_rate[i])).substr(3, 2)+"-"+String(Object.keys(state.array_key_rate[i])).substr(0, 2);
          const present_day_key_fact_begin = date1.getTime() - new Date(data_begin).getTime();
          const diffpresent_day_key_fact_begin = Math.round(present_day_key_fact_begin / oneDay);

          const present_day_key_fact_begin_2 = date2.getTime() - new Date(data_begin).getTime();
          const diffpresent_day_key_fact_begin_2 = Math.round(present_day_key_fact_begin_2 / oneDay);

          let data_end=null
          let present_day_key_fact_end = null
          let diffpresent_day_key_fact_end = null

          let present_day_key_fact_end_2 = null
          let diffpresent_day_key_fact_end_2 = null

          if(i!==state.array_key_rate.length-1){
            data_end = String(Object.keys(state.array_key_rate[i+1])).substr(6, 4)+'-'+String(Object.keys(state.array_key_rate[i+1])).substr(3, 2)+"-"+String(Object.keys(state.array_key_rate[i+1])).substr(0, 2);

            present_day_key_fact_end = date1.getTime() - new Date(data_end).getTime();
            diffpresent_day_key_fact_end = Math.round(present_day_key_fact_end / oneDay);

            present_day_key_fact_end_2 = date2.getTime() - new Date(data_end).getTime();
            diffpresent_day_key_fact_end_2 = Math.round(present_day_key_fact_end / oneDay);
          }

          if(i===state.array_key_rate.length-1){
            const present_day_key_fact_end_5 = date2.getTime() - new Date(data_end).getTime();
            const diffpresent_day_key_fact_end_5 = Math.round(present_day_key_fact_end_5 / oneDay);
            if(diffpresent_day_key_fact_end_5>0){
              data_end = state.date_transfer_actual
            }
          }

          //ДЛЯ ПОНИЖЕННОЙ СТАВКИ
          if(present_day_key_fact_begin>=0&&diffpresent_day_key_fact_end<0){

            rate_entered_date=parseFloat(Object.values(state.array_key_rate[i])[0])
          }

          if(diffpresent_day_key_fact_begin_2>=0&&diffpresent_day_key_fact_end_2<0){

            rate_entered_date_2=parseFloat(Object.values(state.array_key_rate[i])[0])
          }

          if(i===state.array_key_rate.length-1&&present_day_key_fact_begin>=0){

            rate_entered_date=parseFloat(Object.values(state.array_key_rate[i])[0])
          }

          if(i===state.array_key_rate.length-1&&diffpresent_day_key_fact_begin_2>=0){


            rate_entered_date_2=parseFloat(Object.values(state.array_key_rate[i])[0])
          }

          //для периода по ставкам
          const object_period = {}
          Vue.set(object_period,'begin',data_begin)
          Vue.set(object_period,'end',data_end)
          Vue.set(object_period,'rate',parseFloat(Object.values(state.array_key_rate[i])[0]))

          state.rate_periods.push(object_period)

        }


        //   resolve()
        // }).then(()=>{
        //   return new Promise((resolve,reject) => {
        //
        //     setTimeout(()=>{


        //пеприодам, кторые не входят во втитый деапазон ставлю null для дальнейшего удаления
        for(let t=0;t<state.rate_periods.length;t++){
          const present_day_key_period_begin_2 = date1.getTime() - new Date(state.rate_periods[t].end).getTime();
          const diffpresent_day_key_period_begin_2 = Math.round(present_day_key_period_begin_2 / oneDay);

          if (diffpresent_day_key_period_begin_2 >= 0 && state.rate_periods[t].end!==null) {
            Vue.set(state.rate_periods[t],'begin',null)
          }
          if (diffpresent_day_key_period_begin_2 >= 0 && state.rate_periods[t].end===null) {
            Vue.set(state.rate_periods[t],'end',state.date_transfer_actual)
            const present_begin = new Date(state.rate_periods[t].end).getTime() - new Date(state.rate_periods[t].begin).getTime();
            const diffpresent_begin = Math.round(present_begin / oneDay);

          }

          const present_day_key_period_end_2 = date2.getTime() - new Date(state.rate_periods[t].begin).getTime();
          const diffpresent_day_key_period_end_2 = Math.round(present_day_key_period_end_2 / oneDay);
          if (diffpresent_day_key_period_end_2 < 0) {
            Vue.set(state.rate_periods[t],'begin',null)
          }
        }

        //
        //       resolve()
        //     },200)
        //
        //   })
        // }).then(()=>{
        //   return new Promise(function (resolve,reject) {
        //
        //     setTimeout(()=>{


        var filtered = state.rate_periods.filter(function(el) { return el.begin != null; });
        state.rate_periods = []

        state.rate_periods = filtered



        //       resolve()
        //     },200)
        //   })
        // })
        //   .then(()=>{
        //   return new Promise((resolve,reject) => {
        //
        //     setTimeout(()=>{
        //       //учет пониженной ставки
        //       const lower_date_begin = new Date(state.lower_rate[0].begin);
        //       const lower_date_end = new Date(state.lower_rate[0].end);
        //
        //       resolve()
        //     },200)
        //   })
        // }).then(()=>{
        //   return new Promise((resolve,reject) => {

        // setTimeout(()=>{



        //количество дней в периодах
        for(let t=0;t<state.rate_periods.length;t++){

          const present_day_key_period_begin = date1.getTime() - new Date(state.rate_periods[t].begin).getTime();
          const diffpresent_day_key_period_begin = Math.round(present_day_key_period_begin / oneDay);

          const present_day_key_period_end = date2.getTime() - new Date(state.rate_periods[t].end).getTime();
          const diffpresent_day_key_period_end = Math.round(present_day_key_period_end / oneDay);

          if (diffpresent_day_key_period_end < 0 && state.rate_periods[t].begin!==null) {
            Vue.set(state.rate_periods[t],'end',state.date_transfer_actual)
            const present_begin = new Date(state.rate_periods[t].end).getTime() - new Date(state.rate_periods[t].begin).getTime();
            const diffpresent_begin = Math.round(present_begin / oneDay);
            Vue.set(state.rate_periods[t],'count',diffpresent_begin)
          }

          if (present_day_key_period_begin > 0) {
            Vue.set(state.rate_periods[t],'begin',state.date_transfer)

          }

          if (diffpresent_day_key_period_end > 0 && diffpresent_day_key_period_begin < 0 && state.rate_periods[t].begin!==null) {
            const present_begin = new Date(state.rate_periods[t].end).getTime() - new Date(state.rate_periods[t].begin).getTime();
            const diffpresent_begin = Math.round(present_begin / oneDay);
            Vue.set(state.rate_periods[t],'count',diffpresent_begin)
          }

        }

        //       resolve()
        //     },200)
        //   })
        // })

        //ДЛЯ ПОНИЖЕННОЙ СТАВКИ

        if(rate_period_date!==null&&parseFloat(rate_entered_date)>parseFloat(rate_period_date)){
          state.rate_day_delay = rate_period_date
        }
        else if(rate_period_date!==null&&parseFloat(rate_entered_date)<parseFloat(rate_period_date)){
          state.rate_day_delay = parseFloat(rate_entered_date)
        }
        if(rate_period_date===null){
          state.rate_day_delay = parseFloat(rate_entered_date)
        }

        if(rate_period_date_2!==null&&parseFloat(rate_entered_date_2)>parseFloat(rate_period_date_2)){
          state.rate_day_fact_delivery = parseFloat(rate_period_date_2)
        }
        else if(rate_period_date_2!==null&&parseFloat(rate_entered_date_2)<parseFloat(rate_period_date_2)){
          state.rate_day_fact_delivery = parseFloat(rate_entered_date_2)
        }
        if(rate_period_date_2===null){
          state.rate_day_fact_delivery = parseFloat(rate_entered_date_2)
        }


        //----------------------------------------------------------------------------------------

        //чтобы вбиваемая дата сдачи жилья по договору не была больше сегодняшней даты, тогда просрочки нет
        const present_dayTime = date3.getTime() - date1.getTime();
        const diffpresent_dayTime = Math.round(present_dayTime / oneDay);
        if(diffpresent_dayTime<=0){
          state.delivery_date=true
          state.state_approval[5].state=false
        }
        else {
          state.delivery_date=false
          state.state_approval[5].state=true
        }

        //чтобы вбиваемая дата фактической сдачи жилья  не была больше сегодняшней даты
        const present_dayTimeFact = date3.getTime() - date2.getTime();
        const diffpresent_dayTimeFact = Math.round(present_dayTimeFact / oneDay);
        if(diffpresent_dayTimeFact<=0){
          state.delivery_date_fact=true
          state.state_approval[6].state=false
        }
        else {
          state.delivery_date_fact=false
          state.state_approval[6].state=true
        }

      }
    },

    mutationInputDateActual(state,received_perem){
      state.rate_periods=[]
      state.state_approval[2].state=received_perem[1]
      state.date_transfer_actual=received_perem[0]


      //подсчёт разницы дней
      if(state.date_transfer!=null && state.date_transfer_actual!=null){
        const oneDay = 1000 * 60 * 60 * 24;
        const date1 = new Date(state.date_transfer);
        const date2 = new Date(state.date_transfer_actual);
        const date3 = new Date()


        // ----------------- МОРАТОРИЙ---------------------------------------------------

        //от фактической сдачи объекта
        const present_moratorium_end_3 = date2.getTime() - date1.getTime();
        const diffpresent_moratorium__end_3= Math.round(present_moratorium_end_3 / oneDay);

        state.array_minus_moratorium_days=[]
        for(let i =0;i<state.moratorium_dates.length;i++){
          //день начала маратория нужно будет доработать, так отрезков мораториев может быть несколько, а я пока беру 1
          const date_mor_begin = new Date(state.moratorium_dates[i].begin)
          const date_mor_end = new Date(state.moratorium_dates[i].end)
          //от даты сдачи по ДДУ

          const present_moratorium_begin = date1.getTime() - date_mor_begin.getTime();
          const diffpresent_moratorium__begin = Math.round(present_moratorium_begin / oneDay);

          //от фактической сдачи объекта
          const present_moratorium_end = date2.getTime() - date_mor_end.getTime();
          const diffpresent_moratorium__end = Math.round(present_moratorium_end / oneDay);

          //от фактической сдачи объекта
          const present_moratorium_end_2 = date2.getTime() - date_mor_begin.getTime();
          const diffpresent_moratorium__end_2 = Math.round(present_moratorium_end_2 / oneDay);


          if (diffpresent_moratorium__end_2<0){
            state.array_minus_moratorium_days.push(0)
          }
          if (diffpresent_moratorium__begin===0 && diffpresent_moratorium__end===0){
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days - 2)
          }
          if (diffpresent_moratorium__begin<0 && diffpresent_moratorium__end>0){
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days)
          }
          if (diffpresent_moratorium__begin===0 && diffpresent_moratorium__end>0){
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days-1)
          }
          if (diffpresent_moratorium__begin<0 && diffpresent_moratorium__end===0){
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days-1)
          }

          if (diffpresent_moratorium__begin>0 && diffpresent_moratorium__end>0){
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days - (diffpresent_moratorium__begin+1))
          }
          if (diffpresent_moratorium__begin>0 && diffpresent_moratorium__end===0){
            state.array_minus_moratorium_days.push(state.moratorium_dates[i].amount_days - diffpresent_moratorium__begin-2)
          }
         if (diffpresent_moratorium__begin>0 && diffpresent_moratorium__end<0){

            state.array_minus_moratorium_days.push(diffpresent_moratorium__end_3-1)
          }
          //Посмотреть
          if (diffpresent_moratorium__begin<0 && diffpresent_moratorium__end<0 && diffpresent_moratorium__end_2>0){
            state.array_minus_moratorium_days.push(diffpresent_moratorium__end_2)
          }
          if (diffpresent_moratorium__begin===0 && diffpresent_moratorium__end<0 && diffpresent_moratorium__end_2>0){
            state.array_minus_moratorium_days.push(diffpresent_moratorium__end_2-1)
          }
        }

        //считаю просрочку дата по договору сдачи - дата фактической сдачи, только наоборот

        const diffInTime = date2.getTime() - date1.getTime();
        const diffInDays = Math.round(diffInTime / oneDay);
        state.days_of_delay = parseInt(diffInDays)-1

        if (diffInDays==0){
          state.days_of_delay=0
        }
        else if (diffInDays<=-1){
          state.state_approval[3].state=false
          state.difference_days=true
          state.days_of_delay=0
        }
        else {
          state.state_approval[3].state=true
          state.difference_days=false
        }

        state.array_minus_moratorium_days = state.array_minus_moratorium_days.filter(function(item) {
          return item > 0
        })

        state.minus_moratorium_days = state.array_minus_moratorium_days.reduce(function(acc, val) { return acc + val; }, 0)

        if(state.days_of_delay - state.minus_moratorium_days<0){
          // state.minus_moratorium_days=0
        }

        //----подсчитываю дни пониженной ставки в зависимости от вбиваемых дат

        const date_lower_begin = new Date(state.lower_rate[0].begin)
        const date_lower_end = new Date(state.lower_rate[0].end)

        const present_lower_contract_begin = date1.getTime() - date_lower_begin.getTime();
        const diffpresent_lower_contract_begin = Math.round(present_lower_contract_begin / oneDay);

        const present_lower_contract_end = date1.getTime() - date_lower_end.getTime();
        const diffpresent_lower_contract_end = Math.round(present_lower_contract_end / oneDay);

        const present_lower_fact_begin = date2.getTime() - date_lower_begin.getTime();
        const diffpresent_lower_fact_begin = Math.round(present_lower_fact_begin / oneDay);

        const present_lower_fact_end = date2.getTime() - date_lower_end.getTime();
        const diffpresent_lower_fact_end = Math.round(present_lower_fact_end / oneDay);

        //-------Подсчитываю, какую ставку использовать в зависимости от от дат

        let rate_entered_date=1;
        let rate_period_date = null

        let rate_entered_date_2=1;
        let rate_period_date_2 = null

        //ДЛЯ ПОНИЖЕННОЙ СТАВКИ

        for (let t = 0;t<state.lower_rate.length;t++){
          const present_day_key_fact_begin_lower_rate = date1.getTime() - new Date(state.lower_rate[t].begin).getTime();
          const diffpresent_day_key_fact_begin = Math.round(present_day_key_fact_begin_lower_rate / oneDay);

          const present_day_key_fact_end_lower_rate = date1.getTime() - new Date(state.lower_rate[t].end).getTime();
          const diffpresent_day_key_fact_end = Math.round(present_day_key_fact_end_lower_rate / oneDay);

          const present_day_key_fact_begin_lower_rate_2 = date2.getTime() - new Date(state.lower_rate[t].begin).getTime();
          const diffpresent_day_key_fact_begin_2 = Math.round(present_day_key_fact_begin_lower_rate_2 / oneDay);

          const present_day_key_fact_end_lower_rate_2 = date2.getTime() - new Date(state.lower_rate[t].end).getTime();
          const diffpresent_day_key_fact_end_2 = Math.round(present_day_key_fact_end_lower_rate_2 / oneDay);

          if(diffpresent_day_key_fact_begin>=0&&diffpresent_day_key_fact_end<0){
            rate_period_date=state.lower_rate[t].rate
          }

          if(diffpresent_day_key_fact_begin_2>=0&&diffpresent_day_key_fact_end_2<0){
            rate_period_date_2=state.lower_rate[t].rate
          }
        }

        // const promice = new Promise((resolve,reject) => {



          //ставка на день сдачи объекта
          for (let i = 0;i<state.array_key_rate.length; i++){
            if(i===state.array_key_rate.length-1){


            }
            let data_begin = String(Object.keys(state.array_key_rate[i])).substr(6, 4)+'-'+String(Object.keys(state.array_key_rate[i])).substr(3, 2)+"-"+String(Object.keys(state.array_key_rate[i])).substr(0, 2);
            const present_day_key_fact_begin = date1.getTime() - new Date(data_begin).getTime();
            const diffpresent_day_key_fact_begin = Math.round(present_day_key_fact_begin / oneDay);

            const present_day_key_fact_begin_2 = date2.getTime() - new Date(data_begin).getTime();
            const diffpresent_day_key_fact_begin_2 = Math.round(present_day_key_fact_begin_2 / oneDay);

            let data_end=null
            let present_day_key_fact_end = null
            let diffpresent_day_key_fact_end = null

            let present_day_key_fact_end_2 = null
            let diffpresent_day_key_fact_end_2 = null

            if(i!==state.array_key_rate.length-1){
              data_end = String(Object.keys(state.array_key_rate[i+1])).substr(6, 4)+'-'+String(Object.keys(state.array_key_rate[i+1])).substr(3, 2)+"-"+String(Object.keys(state.array_key_rate[i+1])).substr(0, 2);

              present_day_key_fact_end = date1.getTime() - new Date(data_end).getTime();
              diffpresent_day_key_fact_end = Math.round(present_day_key_fact_end / oneDay);

              present_day_key_fact_end_2 = date2.getTime() - new Date(data_end).getTime();
              diffpresent_day_key_fact_end_2 = Math.round(present_day_key_fact_end / oneDay);
            }

            if(i===state.array_key_rate.length-1){
              const present_day_key_fact_end_5 = date2.getTime() - new Date(data_end).getTime();
              const diffpresent_day_key_fact_end_5 = Math.round(present_day_key_fact_end_5 / oneDay);
              if(diffpresent_day_key_fact_end_5>0){
                data_end = state.date_transfer_actual
              }
            }

            //ДЛЯ ПОНИЖЕННОЙ СТАВКИ
            if(present_day_key_fact_begin>=0&&diffpresent_day_key_fact_end<0){

              rate_entered_date=parseFloat(Object.values(state.array_key_rate[i])[0])
            }

            if(diffpresent_day_key_fact_begin_2>=0&&diffpresent_day_key_fact_end_2<0){

              rate_entered_date_2=parseFloat(Object.values(state.array_key_rate[i])[0])
            }

            if(i===state.array_key_rate.length-1&&present_day_key_fact_begin>=0){

              rate_entered_date=parseFloat(Object.values(state.array_key_rate[i])[0])
            }

            if(i===state.array_key_rate.length-1&&diffpresent_day_key_fact_begin_2>=0){


              rate_entered_date_2=parseFloat(Object.values(state.array_key_rate[i])[0])
            }

            //для периода по ставкам
            const object_period = {}
            Vue.set(object_period,'begin',data_begin)
            Vue.set(object_period,'end',data_end)
            Vue.set(object_period,'rate',parseFloat(Object.values(state.array_key_rate[i])[0]))

            state.rate_periods.push(object_period)

          }


        //   resolve()
        // }).then(()=>{
        //   return new Promise((resolve,reject) => {
        //
        //     setTimeout(()=>{


              //пеприодам, кторые не входят во втитый деапазон ставлю null для дальнейшего удаления
              for(let t=0;t<state.rate_periods.length;t++){
                const present_day_key_period_begin_2 = date1.getTime() - new Date(state.rate_periods[t].end).getTime();
                const diffpresent_day_key_period_begin_2 = Math.round(present_day_key_period_begin_2 / oneDay);

                if (diffpresent_day_key_period_begin_2 >= 0 && state.rate_periods[t].end!==null) {
                  Vue.set(state.rate_periods[t],'begin',null)
                }
                if (diffpresent_day_key_period_begin_2 >= 0 && state.rate_periods[t].end===null) {
                  Vue.set(state.rate_periods[t],'end',state.date_transfer_actual)
                  const present_begin = new Date(state.rate_periods[t].end).getTime() - new Date(state.rate_periods[t].begin).getTime();
                  const diffpresent_begin = Math.round(present_begin / oneDay);

                }

                const present_day_key_period_end_2 = date2.getTime() - new Date(state.rate_periods[t].begin).getTime();
                const diffpresent_day_key_period_end_2 = Math.round(present_day_key_period_end_2 / oneDay);
                if (diffpresent_day_key_period_end_2 < 0) {
                  Vue.set(state.rate_periods[t],'begin',null)
                }
              }

              //
        //       resolve()
        //     },200)
        //
        //   })
        // }).then(()=>{
        //   return new Promise(function (resolve,reject) {
        //
        //     setTimeout(()=>{


              var filtered = state.rate_periods.filter(function(el) { return el.begin != null; });
              state.rate_periods = []

              state.rate_periods = filtered



        //       resolve()
        //     },200)
        //   })
        // })
        //   .then(()=>{
        //   return new Promise((resolve,reject) => {
        //
        //     setTimeout(()=>{
        //       //учет пониженной ставки
        //       const lower_date_begin = new Date(state.lower_rate[0].begin);
        //       const lower_date_end = new Date(state.lower_rate[0].end);
        //
        //       resolve()
        //     },200)
        //   })
        // }).then(()=>{
        //   return new Promise((resolve,reject) => {

            // setTimeout(()=>{



              //количество дней в периодах
              for(let t=0;t<state.rate_periods.length;t++){

                const present_day_key_period_begin = date1.getTime() - new Date(state.rate_periods[t].begin).getTime();
                const diffpresent_day_key_period_begin = Math.round(present_day_key_period_begin / oneDay);

                const present_day_key_period_end = date2.getTime() - new Date(state.rate_periods[t].end).getTime();
                const diffpresent_day_key_period_end = Math.round(present_day_key_period_end / oneDay);

                if (diffpresent_day_key_period_end < 0 && state.rate_periods[t].begin!==null) {
                  Vue.set(state.rate_periods[t],'end',state.date_transfer_actual)
                  const present_begin = new Date(state.rate_periods[t].end).getTime() - new Date(state.rate_periods[t].begin).getTime();
                  const diffpresent_begin = Math.round(present_begin / oneDay);
                  Vue.set(state.rate_periods[t],'count',diffpresent_begin)
                }

                if (present_day_key_period_begin > 0) {
                  Vue.set(state.rate_periods[t],'begin',state.date_transfer)

                }

                if (diffpresent_day_key_period_end > 0 && diffpresent_day_key_period_begin < 0 && state.rate_periods[t].begin!==null) {
                  const present_begin = new Date(state.rate_periods[t].end).getTime() - new Date(state.rate_periods[t].begin).getTime();
                  const diffpresent_begin = Math.round(present_begin / oneDay);
                  Vue.set(state.rate_periods[t],'count',diffpresent_begin)
                }

              }

        //       resolve()
        //     },200)
        //   })
        // })

        //ДЛЯ ПОНИЖЕННОЙ СТАВКИ

        if(rate_period_date!==null&&parseFloat(rate_entered_date)>parseFloat(rate_period_date)){
          state.rate_day_delay = rate_period_date
        }
        else if(rate_period_date!==null&&parseFloat(rate_entered_date)<parseFloat(rate_period_date)){
          state.rate_day_delay = parseFloat(rate_entered_date)
        }
        if(rate_period_date===null){
          state.rate_day_delay = parseFloat(rate_entered_date)
        }

        if(rate_period_date_2!==null&&parseFloat(rate_entered_date_2)>parseFloat(rate_period_date_2)){
          state.rate_day_fact_delivery = parseFloat(rate_period_date_2)
        }
        else if(rate_period_date_2!==null&&parseFloat(rate_entered_date_2)<parseFloat(rate_period_date_2)){
          state.rate_day_fact_delivery = parseFloat(rate_entered_date_2)
        }
        if(rate_period_date_2===null){
          state.rate_day_fact_delivery = parseFloat(rate_entered_date_2)
        }


        //----------------------------------------------------------------------------------------

        //чтобы вбиваемая дата сдачи жилья по договору не была больше сегодняшней даты, тогда просрочки нет
        const present_dayTime = date3.getTime() - date1.getTime();
        const diffpresent_dayTime = Math.round(present_dayTime / oneDay);
        if(diffpresent_dayTime<=0){
          state.delivery_date=true
          state.state_approval[5].state=false
        }
        else {
          state.delivery_date=false
          state.state_approval[5].state=true
        }

        //чтобы вбиваемая дата фактической сдачи жилья  не была больше сегодняшней даты
        const present_dayTimeFact = date3.getTime() - date2.getTime();
        const diffpresent_dayTimeFact = Math.round(present_dayTimeFact / oneDay);
        if(diffpresent_dayTimeFact<=0){
          state.delivery_date_fact=true
          state.state_approval[6].state=false
        }
        else {
          state.delivery_date_fact=false
          state.state_approval[6].state=true
        }

      }

    },

    //Итоговый результат тут будет переделка, так как в расчётах участвует не просто ставка на сегодняшний день, а конкретная ставка
    mutationCalculate(state){

      if (state.checbox_individual===true){
        if(state.type_delay=='day_delivery_object'){
          state.calculate_result = (((state.apartment_price * (state.rate_day_fact_delivery/100)) / 150) * (state.days_of_delay - state.minus_moratorium_days)).toFixed(2)
          state.applicable_rate = state.rate_day_fact_delivery
          state.apartment_price_show = state.apartment_price
          state.checbox_individual_show = state.checbox_individual
          state.day_show = state.days_of_delay - state.minus_moratorium_days
          state.type_delay_show = state.type_delay

        }
        if(state.type_delay=='start_date_delay'){
          state.calculate_result = (((state.apartment_price * (state.rate_day_delay/100)) / 150) * (state.days_of_delay - state.minus_moratorium_days)).toFixed(2)
          state.applicable_rate = state.rate_day_delay
          state.apartment_price_show = state.apartment_price
          state.checbox_individual_show = state.checbox_individual
          state.day_show = state.days_of_delay - state.minus_moratorium_days
          state.type_delay_show = state.type_delay

        }
        if(state.type_delay=='period'){
          const lower_date_begin = new Date(state.lower_rate[0].begin);
          const lower_date_end = new Date(state.lower_rate[0].end);
          const oneDay = 1000 * 60 * 60 * 24;
          let sum = 0;


          for (let t = 0; t < state.rate_periods.length; t++) {

            const present_lower_begin = new Date(state.rate_periods[t].begin).getTime() - lower_date_begin.getTime();
            const diffpresent_lower_begin = Math.round(present_lower_begin / oneDay);

            const present_lower_end = new Date(state.rate_periods[t].end).getTime() - lower_date_end.getTime();
            const diffpresent_lower_end = Math.round(present_lower_end / oneDay);

            const present_lower_end_2 = new Date(state.rate_periods[t].end).getTime() - lower_date_begin.getTime();
            const diffpresent_lower_end_2 = Math.round(present_lower_end_2 / oneDay);

            const present_lower_begin_2 = new Date(state.rate_periods[t].begin).getTime() - lower_date_end.getTime();
            const diffpresent_lower_begin_2 = Math.round(present_lower_begin_2 / oneDay);

            const present_lower_begin_3 = new Date(state.rate_periods[t].end).getTime() - lower_date_begin.getTime();
            const diffpresent_lower_begin_3 = Math.round(present_lower_begin_3 / oneDay);

            for (let r = 0; r < state.lower_rate.length; r++) {

              const dlb = (new Date(state.rate_periods[t].begin).getTime() - new Date(state.lower_rate[r].begin).getTime()) / oneDay;
              const dle = (new Date(state.rate_periods[t].end).getTime() - new Date(state.lower_rate[r].end).getTime()) / oneDay;
              const dle_2 = (new Date(state.rate_periods[t].end).getTime() - new Date(state.lower_rate[r].begin).getTime()) / oneDay;
              const dle_3 = (new Date(state.rate_periods[t].begin).getTime() - new Date(state.lower_rate[r].end).getTime()) / oneDay;

              if (dlb < 0 && dle > 0) {
                const obj = {};
                const obj_2 = {};

                Vue.set(obj, 'begin', state.rate_periods[t].begin);
                Vue.set(obj, 'end', state.lower_rate[r].begin);
                Vue.set(obj, 'rate', state.rate_periods[t].rate);

                Vue.set(obj_2, 'begin', state.lower_rate[r].end);
                Vue.set(obj_2, 'end', state.rate_periods[t].end);
                Vue.set(obj_2, 'rate', state.rate_periods[t].rate);

                Vue.set(state.rate_periods[t], 'begin', state.lower_rate[r].begin);
                Vue.set(state.rate_periods[t], 'end', state.lower_rate[r].end);

                if (state.rate_periods[t].rate > state.lower_rate[r].rate) {
                  Vue.set(state.rate_periods[t], 'rate', state.lower_rate[r].rate);
                }

                state.rate_periods.splice(t, 0, obj);
                state.rate_periods.splice(t + 2, 0, obj_2);

              }

              if (dlb < 0 && dle <= 0 && dle_2 > 0) {
                const obj = {};
                const obj_2 = {};
                Vue.set(obj, 'begin', state.rate_periods[t].begin);
                Vue.set(obj, 'end', state.lower_rate[r].begin);
                Vue.set(obj, 'rate', state.rate_periods[t].rate);

                Vue.set(state.rate_periods[t], 'begin', state.lower_rate[r].begin);
                Vue.set(state.rate_periods[t], 'end', state.rate_periods[t].end);

                if (state.rate_periods[t].rate > state.lower_rate[r].rate) {
                  Vue.set(state.rate_periods[t], 'rate', state.lower_rate[r].rate);
                }
                state.rate_periods.splice(t, 0, obj);

              }

              if (dlb >= 0 && dle <= 0) {
                if (state.rate_periods[t].rate > state.lower_rate[r].rate) {
                  Vue.set(state.rate_periods[t], 'rate', state.lower_rate[r].rate);
                }

              }

              if (dlb >= 0 && dle > 0 && dle_3 < 0) {
                const obj = {};
                const obj_2 = {};

                Vue.set(obj, 'begin', state.rate_periods[t].begin);
                Vue.set(obj, 'end', state.lower_rate[r].end);

                if (parseFloat(state.rate_periods[t].rate) > parseFloat(state.lower_rate[r].rate)) {
                  Vue.set(obj, 'rate', state.lower_rate[r].rate);
                } else {
                  Vue.set(obj, 'rate', state.rate_periods[t].rate);
                }

                Vue.set(state.rate_periods[t], 'begin', state.lower_rate[r].end);
                Vue.set(state.rate_periods[t], 'end', state.rate_periods[t].end);
                Vue.set(state.rate_periods[t], 'rate', state.rate_periods[r].rate);
                state.rate_periods.splice(t, 0, obj);

              }
            }

          }
          for (let t = 0; t < state.rate_periods.length; t++) {
            const present_begin = new Date(state.rate_periods[t].end).getTime() - new Date(state.rate_periods[t].begin).getTime();
            const diffpresent_begin = Math.round(present_begin / oneDay);

            if (t === 0 && t === state.rate_periods.length - 1 && diffpresent_begin !== 0) {
              Vue.set(state.rate_periods[t], 'count', diffpresent_begin - 1);
            }
            if (t === 0 && t !== state.rate_periods.length - 1) {
              Vue.set(state.rate_periods[t], 'count', diffpresent_begin - 1);
            }
            if ((t !== 0 && t !== state.rate_periods.length - 1) && diffpresent_begin !== 0) {
              Vue.set(state.rate_periods[t], 'count', diffpresent_begin);
            }
            if ((t !== 0 && t === state.rate_periods.length - 1) && diffpresent_begin !== 0) {
              Vue.set(state.rate_periods[t], 'count', diffpresent_begin);
            }

          }
          for (let t = 0; t < state.rate_periods.length; t++) {
            //день начала маратория нужно будет доработать, так отрезков мораториев может быть несколько, а я пока беру 1
            const date_mor_begin = new Date(state.moratorium_dates[0].begin);
            const date_mor_end = new Date(state.moratorium_dates[0].end);
            //-----подсчитываю сколько нужно вычесть дней с учётом маратория-----
            //от даты сдачи по ДДУ
            const present_moratorium_begin = new Date(state.rate_periods[t].begin).getTime() - date_mor_begin.getTime();
            const diffpresent_moratorium__begin = Math.round(present_moratorium_begin / oneDay);

            //от фактической сдачи объекта
            const present_moratorium_end = new Date(state.rate_periods[t].end).getTime() - date_mor_end.getTime();
            const diffpresent_moratorium__end = Math.round(present_moratorium_end / oneDay);

            //от фактической сдачи объекта
            const present_moratorium_end_2 = new Date(state.rate_periods[t].end).getTime() - date_mor_begin.getTime();
            const diffpresent_moratorium__end_2 = Math.round(present_moratorium_end_2 / oneDay);

            //от фактической сдачи объекта
            const present_moratorium_end_3 = new Date(state.rate_periods[t].end).getTime() - new Date(state.rate_periods[t].begin).getTime();
            const diffpresent_moratorium__end_3 = Math.round(present_moratorium_end_3 / oneDay);

            for (let r = 0; r < state.moratorium_dates.length; r++) {
              const dmb = (new Date(state.rate_periods[t].begin).getTime() - new Date(state.moratorium_dates[r].begin).getTime()) / oneDay;
              const dme = (new Date(state.rate_periods[t].end).getTime() - new Date(state.moratorium_dates[r].end).getTime()) / oneDay;
              const dme_2 = (new Date(state.rate_periods[t].end).getTime() - new Date(state.moratorium_dates[r].begin).getTime()) / oneDay;
              const dme_3 = (new Date(state.rate_periods[t].begin).getTime() - new Date(state.moratorium_dates[r].end).getTime()) / oneDay;

              if (dmb < 0 && dme > 0) {
                Vue.set(state.rate_periods[t], 'count', parseInt(state.rate_periods[t].count) - state.moratorium_dates[r].amount_days);
              }

              if (dmb >= 0 && dme <= 0) { //-----
                Vue.set(state.rate_periods[t], 'count', 0);
              }

              if (dmb >= 0 && dme > 0 && dme_3 < 0) {
                Vue.set(state.rate_periods[t], 'count', (parseInt(state.rate_periods[t].count) - (new Date(state.moratorium_dates[r].end).getTime() - new Date(state.rate_periods[t].begin).getTime()) / oneDay) - 1);
              }
              if (dmb < 0 && dme <= 0 && dme_2 > 0) {
                Vue.set(state.rate_periods[t], 'count', parseInt(state.rate_periods[t].count) - (new Date(state.rate_periods[t].end).getTime() - new Date(state.moratorium_dates[r].begin).getTime()) / oneDay);
              }

            }

          }
          for (let t = 0; t < state.rate_periods.length; t++) {
            sum = sum + ((state.apartment_price * (state.rate_periods[t].rate / 100)) / 150) * state.rate_periods[t].count;
          }

          state.calculate_result = sum.toFixed(2);

          state.formula_for_show = [
            state.rate_periods[0], state.rate_periods[state.rate_periods.length - 1]
          ];
          state.apartment_price_show = state.apartment_price;
          state.checbox_individual_show = state.checbox_individual;
          state.type_delay_show = state.type_delay;








          // console.log(state.rate_periods);



        }
      }

      if (state.check_entity===true){
        if(state.type_delay=='day_delivery_object'){
          state.calculate_result = (((state.apartment_price * (state.rate_day_fact_delivery/100)) / 300) * (state.days_of_delay - state.minus_moratorium_days)).toFixed(2)
          state.applicable_rate = state.rate_day_fact_delivery
          state.apartment_price_show = state.apartment_price
          state.checbox_individual_show = state.checbox_individual
          state.day_show = state.days_of_delay - state.minus_moratorium_days
          state.type_delay_show = state.type_delay

        }
        if(state.type_delay=='start_date_delay'){
          state.calculate_result = (((state.apartment_price * (state.rate_day_delay/100)) / 300) * (state.days_of_delay - state.minus_moratorium_days)).toFixed(2)
          state.applicable_rate = state.rate_day_delay
          state.apartment_price_show = state.apartment_price
          state.checbox_individual_show = state.checbox_individual
          state.day_show = state.days_of_delay - state.minus_moratorium_days
          state.type_delay_show = state.type_delay

        }
        if(state.type_delay=='period'){
          const lower_date_begin = new Date(state.lower_rate[0].begin);
          const lower_date_end = new Date(state.lower_rate[0].end);
          const oneDay = 1000 * 60 * 60 * 24;
          let sum = 0;


          for (let t = 0; t < state.rate_periods.length; t++) {

            const present_lower_begin = new Date(state.rate_periods[t].begin).getTime() - lower_date_begin.getTime();
            const diffpresent_lower_begin = Math.round(present_lower_begin / oneDay);

            const present_lower_end = new Date(state.rate_periods[t].end).getTime() - lower_date_end.getTime();
            const diffpresent_lower_end = Math.round(present_lower_end / oneDay);

            const present_lower_end_2 = new Date(state.rate_periods[t].end).getTime() - lower_date_begin.getTime();
            const diffpresent_lower_end_2 = Math.round(present_lower_end_2 / oneDay);

            const present_lower_begin_2 = new Date(state.rate_periods[t].begin).getTime() - lower_date_end.getTime();
            const diffpresent_lower_begin_2 = Math.round(present_lower_begin_2 / oneDay);

            const present_lower_begin_3 = new Date(state.rate_periods[t].end).getTime() - lower_date_begin.getTime();
            const diffpresent_lower_begin_3 = Math.round(present_lower_begin_3 / oneDay);

            for (let r = 0; r < state.lower_rate.length; r++) {

              const dlb = (new Date(state.rate_periods[t].begin).getTime() - new Date(state.lower_rate[r].begin).getTime()) / oneDay;
              const dle = (new Date(state.rate_periods[t].end).getTime() - new Date(state.lower_rate[r].end).getTime()) / oneDay;
              const dle_2 = (new Date(state.rate_periods[t].end).getTime() - new Date(state.lower_rate[r].begin).getTime()) / oneDay;
              const dle_3 = (new Date(state.rate_periods[t].begin).getTime() - new Date(state.lower_rate[r].end).getTime()) / oneDay;

              if (dlb < 0 && dle > 0) {
                const obj = {};
                const obj_2 = {};

                Vue.set(obj, 'begin', state.rate_periods[t].begin);
                Vue.set(obj, 'end', state.lower_rate[r].begin);
                Vue.set(obj, 'rate', state.rate_periods[t].rate);

                Vue.set(obj_2, 'begin', state.lower_rate[r].end);
                Vue.set(obj_2, 'end', state.rate_periods[t].end);
                Vue.set(obj_2, 'rate', state.rate_periods[t].rate);

                Vue.set(state.rate_periods[t], 'begin', state.lower_rate[r].begin);
                Vue.set(state.rate_periods[t], 'end', state.lower_rate[r].end);

                if (state.rate_periods[t].rate > state.lower_rate[r].rate) {
                  Vue.set(state.rate_periods[t], 'rate', state.lower_rate[r].rate);
                }

                state.rate_periods.splice(t, 0, obj);
                state.rate_periods.splice(t + 2, 0, obj_2);

              }

              if (dlb < 0 && dle <= 0 && dle_2 > 0) {
                const obj = {};
                const obj_2 = {};
                Vue.set(obj, 'begin', state.rate_periods[t].begin);
                Vue.set(obj, 'end', state.lower_rate[r].begin);
                Vue.set(obj, 'rate', state.rate_periods[t].rate);

                Vue.set(state.rate_periods[t], 'begin', state.lower_rate[r].begin);
                Vue.set(state.rate_periods[t], 'end', state.rate_periods[t].end);

                if (state.rate_periods[t].rate > state.lower_rate[r].rate) {
                  Vue.set(state.rate_periods[t], 'rate', state.lower_rate[r].rate);
                }
                state.rate_periods.splice(t, 0, obj);

              }

              if (dlb >= 0 && dle <= 0) {
                if (state.rate_periods[t].rate > state.lower_rate[r].rate) {
                  Vue.set(state.rate_periods[t], 'rate', state.lower_rate[r].rate);
                }

              }

              if (dlb >= 0 && dle > 0 && dle_3 < 0) {
                const obj = {};
                const obj_2 = {};

                Vue.set(obj, 'begin', state.rate_periods[t].begin);
                Vue.set(obj, 'end', state.lower_rate[r].end);

                if (parseFloat(state.rate_periods[t].rate) > parseFloat(state.lower_rate[r].rate)) {
                  Vue.set(obj, 'rate', state.lower_rate[r].rate);
                } else {
                  Vue.set(obj, 'rate', state.rate_periods[t].rate);
                }

                Vue.set(state.rate_periods[t], 'begin', state.lower_rate[r].end);
                Vue.set(state.rate_periods[t], 'end', state.rate_periods[t].end);
                Vue.set(state.rate_periods[t], 'rate', state.rate_periods[r].rate);
                state.rate_periods.splice(t, 0, obj);

              }
            }

          }
          for (let t = 0; t < state.rate_periods.length; t++) {
            const present_begin = new Date(state.rate_periods[t].end).getTime() - new Date(state.rate_periods[t].begin).getTime();
            const diffpresent_begin = Math.round(present_begin / oneDay);

            if (t === 0 && t === state.rate_periods.length - 1 && diffpresent_begin !== 0) {
              Vue.set(state.rate_periods[t], 'count', diffpresent_begin - 1);
            }
            if (t === 0 && t !== state.rate_periods.length - 1) {
              Vue.set(state.rate_periods[t], 'count', diffpresent_begin - 1);
            }
            if ((t !== 0 && t !== state.rate_periods.length - 1) && diffpresent_begin !== 0) {
              Vue.set(state.rate_periods[t], 'count', diffpresent_begin);
            }
            if ((t !== 0 && t === state.rate_periods.length - 1) && diffpresent_begin !== 0) {
              Vue.set(state.rate_periods[t], 'count', diffpresent_begin);
            }

          }
          for (let t = 0; t < state.rate_periods.length; t++) {
            //день начала маратория нужно будет доработать, так отрезков мораториев может быть несколько, а я пока беру 1
            const date_mor_begin = new Date(state.moratorium_dates[0].begin);
            const date_mor_end = new Date(state.moratorium_dates[0].end);
            //-----подсчитываю сколько нужно вычесть дней с учётом маратория-----
            //от даты сдачи по ДДУ
            const present_moratorium_begin = new Date(state.rate_periods[t].begin).getTime() - date_mor_begin.getTime();
            const diffpresent_moratorium__begin = Math.round(present_moratorium_begin / oneDay);

            //от фактической сдачи объекта
            const present_moratorium_end = new Date(state.rate_periods[t].end).getTime() - date_mor_end.getTime();
            const diffpresent_moratorium__end = Math.round(present_moratorium_end / oneDay);

            //от фактической сдачи объекта
            const present_moratorium_end_2 = new Date(state.rate_periods[t].end).getTime() - date_mor_begin.getTime();
            const diffpresent_moratorium__end_2 = Math.round(present_moratorium_end_2 / oneDay);

            //от фактической сдачи объекта
            const present_moratorium_end_3 = new Date(state.rate_periods[t].end).getTime() - new Date(state.rate_periods[t].begin).getTime();
            const diffpresent_moratorium__end_3 = Math.round(present_moratorium_end_3 / oneDay);

            for (let r = 0; r < state.moratorium_dates.length; r++) {
              const dmb = (new Date(state.rate_periods[t].begin).getTime() - new Date(state.moratorium_dates[r].begin).getTime()) / oneDay;
              const dme = (new Date(state.rate_periods[t].end).getTime() - new Date(state.moratorium_dates[r].end).getTime()) / oneDay;
              const dme_2 = (new Date(state.rate_periods[t].end).getTime() - new Date(state.moratorium_dates[r].begin).getTime()) / oneDay;
              const dme_3 = (new Date(state.rate_periods[t].begin).getTime() - new Date(state.moratorium_dates[r].end).getTime()) / oneDay;

              if (dmb < 0 && dme > 0) {
                Vue.set(state.rate_periods[t], 'count', parseInt(state.rate_periods[t].count) - state.moratorium_dates[r].amount_days);
              }

              if (dmb >= 0 && dme <= 0) { //-----
                Vue.set(state.rate_periods[t], 'count', 0);
              }

              if (dmb >= 0 && dme > 0 && dme_3 < 0) {
                Vue.set(state.rate_periods[t], 'count', (parseInt(state.rate_periods[t].count) - (new Date(state.moratorium_dates[r].end).getTime() - new Date(state.rate_periods[t].begin).getTime()) / oneDay) - 1);
              }
              if (dmb < 0 && dme <= 0 && dme_2 > 0) {
                Vue.set(state.rate_periods[t], 'count', parseInt(state.rate_periods[t].count) - (new Date(state.rate_periods[t].end).getTime() - new Date(state.moratorium_dates[r].begin).getTime()) / oneDay);
              }

            }

          }
          for (let t = 0; t < state.rate_periods.length; t++) {
            sum = sum + ((state.apartment_price * (state.rate_periods[t].rate / 100)) / 300) * state.rate_periods[t].count;
          }

          state.calculate_result = sum.toFixed(2);

          state.formula_for_show = [
            state.rate_periods[0], state.rate_periods[state.rate_periods.length - 1]
          ];
          state.apartment_price_show = state.apartment_price;
          state.checbox_individual_show = state.checbox_individual;
          state.type_delay_show = state.type_delay;

        }
      }


    },


    //*******
    mutationChecboxNotWork(state,received_perem){
      state.state_approval[3].state=received_perem

    },

  },
  actions:{
    //Получаю ключевые ставкм
    ActionKeyRates({commit},param){
      commit('mutationKeyRates',param)
    },

    //  моратории

    ActionMoratorium({commit},param){
      commit('mutationMoratorium',param)
    },
    ActionLowerRate({commit},param){
      commit('mutationLowerRate',param)
    },


    // ActionKeyRate({commit},param){
    //   commit('mutationKeyRate',param)
    // },
    ActionApartmentPrice({commit},param){
      commit('mutationApartmentPrice',param)
    },


    //*********************
    //Проверка на заполенность и корректность всех необъодимых полей
    ActionChecboxNotWork({commit},param){
      commit('mutationChecboxNotWork',param)
    },



    ActionInputDateTransfer({commit},param){
      commit('mutationInputDateTransfer',param)
    },
    ActionInputDateActual({commit},param){
      commit('mutationInputDateActual',param)
    },

    ActionChecboxEntity({commit},param){
      commit('mutationChecboxEntity',param)
    },
    ActionChecboxIndividual({commit},param){
      commit('mutationChecboxIndividual',param)
    },
    ActionTypeDelay({commit},param){
      commit('mutationTypeDelay',param)
    },
    ActionCalculate({commit}){
      commit('mutationCalculate')
    },













  },
})
</script>
