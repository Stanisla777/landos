/* eslint-disable */
import contentNote from '../../content-note';
import catalogNew from "../../catalog-new";
import eventBus from '../development-tools/eventBus.vue';
import bodyLockMobileFilter from '../../redesign-site/body-lock-mobile-filter';
import bodyUnlockMobileFilter from '../../redesign-site/body-unlock-mobile-filter';
let count = 0;
export default {
  props: {
  },
  data() {
    return {
      isAnimatingHolidays:false

    };
  },
  watch: {
    array_block_early_repayment(){

    }
  },
  updated(){
    if (this.array_block_early_repayment!==undefined){
      if(this.array_block_early_repayment.length>count){
        catalogNew();
        count+=1
      }
    }


  },
  created() {
  },
  methods: {

    openTooltipMobile(el){
      const element = el.currentTarget;
      const parent = element.closest('.js--tooltip-parent')
      if (parent) {
        parent.classList.add('tooltip-active')
        bodyLockMobileFilter(parent);
      }
    },
    closeTooltipMobile(el){
      const element = el.currentTarget;
      const parent = element.closest('.js--tooltip-parent')
      if (parent) {
        parent.classList.remove('tooltip-active')
        bodyUnlockMobileFilter(parent)
      }
    },


    dropdownArea(e){
      const target = e.target
      const element = e.currentTarget;

      let parent = null

      if(!target.classList.contains('js--content-note-open-modal')){
        if (element.closest('.js-accordion-parent-calc')) {
          parent = element.closest('.js-accordion-parent-calc');
        }
        if (element.classList.contains('.js-accordion-parent-calc')) {
          parent = element;
        }
        if (parent){
          if (this.isAnimatingHolidays) return
          this.isAnimatingHolidays = true

          if(parent.classList.contains('active')){
            parent.classList.remove('active-overflow')
            setTimeout(()=>{
              parent.classList.remove('active')
            },300)
          }
          else{
            parent.classList.add('active')
            setTimeout(()=>{
              parent.classList.add('active-overflow')
            },500)
          }
        }
      }
    },
    handleTransitionEnd(event){
      if (event.propertyName==='grid-template-rows') {
        this.isAnimatingHolidays=false
      }
    },
    //очистить все поля блока
    clearAllField(el) {
      const element = el.currentTarget
      const parent = element.closest('.js--container-block');
      if (parent) {
        const array_block_input = parent.querySelectorAll('.js--for-clear-field')
        for (let item of array_block_input) {
          if (item.querySelector('input.js--normal-field')) {
            item.querySelector('input.js--normal-field').value = ''
          }
          //при клике очистить всё переключение в дефолтное состояние радиокнопки группы срок кредита в группе данные об ипотеке
          if (item.classList.contains('js--for-clear-radio-term')) {
            if(item.querySelector('input[type="radio"]').value==='year') {
              item.querySelector('input[type="radio"]').click();
            }
          }
          //при клике очистить всё переключение в дефолтное состояние радиокнопки группы тип платежав группе данные об ипотеке
          if (item.classList.contains('js--for-clear-radio-type-payment')) {
            if(item.querySelector('input[type="radio"]').value==='annuity') {
              item.querySelector('input[type="radio"]').click();
            }
          }


          //при клике очистить всё переключение в дефолтное состояние списка переодичность в блоке досрочное погашение
          if (item.classList.contains('js--for-clear-list-periodicity')) {
            if (item.querySelector('.js--select-option')) {
              item.querySelector('.js--select-option').classList.add('input-emty')
              item.querySelector('.js--select-option').textContent='Выберите параметр'
              if (item.querySelector('.js--openlist-item.active')) {
                item.querySelector('.js--openlist-item.active').classList.remove('active')
              }
            }

            this.select_period=null
            this.selected_repetition_period = 'all-term'
          }

          //при клике очистить всё переключение в дефолтное состояние радиокнопки группы что хотите уменьшить в блоке досрочное погашение
          if (item.classList.contains('js--for-clear-radio-what-reduce')) {
            if(item.querySelector('input[type="radio"]').value==='payment') {
              item.querySelector('input[type="radio"]').click();
            }
          }

          //при клике очистить всё очищение поля инпут календаря
          if (item.querySelector('input.js--calendar-field')) {
            item.querySelector('input.js--calendar-field').value = ''
          }



        }
      }
    },

    AddClassBody() {
      document.body.classList.add('body-modal');
      document.body.classList.add('body-additional-class');
      document.body.setAttribute('style', `top:-${window.scrollY}px;position: fixed;`);
      document.ontouchmove = (e) => {
        e.preventDefault();
      };
    },
    RemoveClassBody() {
      if (!document.body.classList.contains('body-modal-modals')) {
        document.body.classList.remove('body-modal');
        document.body.classList.remove('body-additional-class');
      }
      const scrollY = document.body.style.top;
      document.body.style.position = '';
      document.body.style.top = '';
      window.scrollTo(0, parseInt(scrollY || '0') * -1);
    },
    //ввод только цифр с тысячными в поле инпут 10 000 000
    numberFormattingThousandths(count,e) {
      const element = e.currentTarget;
      const target = e.target
      let position = target.selectionStart;
      const val = parseFloat(element.value.replace(/\s/g, ''))
      element.value = new Intl.NumberFormat("ru-RU").format(val);

      if (e.inputType==="deleteContentBackward"){
        target.selectionEnd = position;
      }
      if (element.value=='не число') {
        element.value=''
      }
      if (element.value.length > 0 && element.value[0] === '0'){
        element.value = '1' +  element.value.slice(1)
      }

      if (element.value.replace(/\s/g, '') > count){
        element.value=(count).toFixed(0)
          .toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
      }
    },

    //ввод цифр с возможностью вбивать точку
    calendarMask(count,e){
      // const element = e.currentTarget
      // element.value = element.value.replace(/[^\d.]/g, '');
      // if(element.value.length > count) {
      //   element.value = element.value.substring(0, count);
      // }
    },
    // маска для календаря
    InputMask(e){
      // const element = el.currentTarget
      // var v = element.value;
      // if (element.value.length===2) {
      //   element.value = v + '.';
      // }
      const input = e.target;
      let value = input.value.replace(/\D/g,'');
      let formattedValue = ''
      if (value.length>0) {
        let month = value.slice(0,2)
        if (parseInt(month) >12) month='12'
        if (month.length ===1 && parseInt(month) >1) month=`0${month}`;
        formattedValue=month;

        if (month.length>=2) {
          formattedValue+=','


          const year = value.slice(2,6)
          formattedValue+=year
        }
      }
      input.value = formattedValue;

    },
    inpFocus(el){
      const element = el.currentTarget;
      // element.classList.add('active_inp')
      element.closest('.js--tex-deduc-input').classList.add('input-focus')
    },
    inpBlur(el){
      const element = el.currentTarget;
      element.closest('.js--tex-deduc-input').classList.remove('input-focus')
    },
    //убрать содержание поля инпут
    clearInput(e){
      const element = e.currentTarget;
      const parent = element.closest('.js--tex-deduc-input');

      if (parent) {
        parent.querySelector('input').value='';
        parent.querySelector('input').classList.remove('active')
        element.classList.remove('active')
        if (parent.classList.contains('js--loan-amount')) {
          this.loan_amount=0
          this.status_mortgage_holidays_block=false
        }
      }
    },


    // //убрать содержание поля инпут в календаре блока данные об ипотеке
    // clearInputCalendarData(e){
    //   const element = e.currentTarget;
    //   const parent = element.closest('.js--tex-deduc-input');
    //
    //   if (parent) {
    //     parent.querySelector('input').value='';
    //     parent.querySelector('input').classList.remove('active')
    //     element.classList.remove('active')
    //   }
    //   // this.initPluginCalendarVanillaData();
    //   this.resetCalendar()
    //   eventBus.$emit('emitClearCalendarHolidaysPayment')
    //   //родителю календаря сказал, что поле очищено
    //   this.$emit('sendClearDateReceive')
    // },


    //убрать содержание поля инпут в календаре
    clearInputCalendar(e){
      const element = e.currentTarget;
      const parent = element.closest('.js--tex-deduc-input');

      if (parent) {
        parent.querySelector('input').value='';
        parent.querySelector('input').classList.remove('active')
        element.classList.remove('active')
      }
    },
    //состояние иконки удалить в полях инпут
    fieldNotEmpty(e){
      let element;
      if (e instanceof Event) {
        element = e.currentTarget;
      }
      else if(e instanceof HTMLElement ) {
        element = e;
      }

      const parent = element.closest('.js--calc-row-input')
      if (parent) {
        if (element.value.length > 0) {
          parent.querySelector('.js--clear-calc-tax').classList.add('active')
        }
        else {
          parent.querySelector('.js--clear-calc-tax').classList.remove('active')
        }
      }
    }
  },
  mounted() {
    contentNote();
    catalogNew();
  }
};
