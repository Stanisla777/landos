<script>
import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

export default new Vuex.Store({
  state:{},
  getters:{
    // MODAL_STATE(state){
    //   return state.modal_state
    // },
  },
  mutations: {
    // mutationModal(state, received_perem) {
    //   state.modal_state = received_perem
    // },
  },
  actions:{
    //Вызов закрытие модального окна !!
    ActionModal({commit,state},param){
      commit('mutationModal',param)
    },
  },
})
</script>
