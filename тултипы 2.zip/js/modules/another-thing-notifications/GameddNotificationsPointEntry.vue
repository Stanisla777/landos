<template lang="pug">
  div
    template
      gamedd-notifications

</template>
<script>
import Storage from './development-tools/state.vue';
const GameddNotifications = () => import ("./GameddNotifications.vue");


export default {
  name: 'GameddNotificationsPointEntry',
  data(){
    return {

    }
  },
  methods:{
  },
  mounted(){
  },
  computed:{
  },
  watch:{
  },
  components:{
    GameddNotifications
  }
};
</script>
<style scoped>
</style>
