export default function checkId() {
  const checBox = document.querySelectorAll('.test-window__radio-item');
  if (checBox.length > 0) {
    // eslint-disable-next-line no-unused-vars
    checBox.forEach((item, ind) => {
      item.querySelector('input').setAttribute('id', `check_${ind}`);
      item.querySelector('label').setAttribute('for', `check_${ind}`);
    });
  }
}
