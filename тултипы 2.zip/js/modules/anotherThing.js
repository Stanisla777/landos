/* eslint-disable */
import dropDown from './dropDown';
import axios from 'axios';
import IMask from 'imask';
let maskName;
let maskSurame;
let processing_rules=false;
let change_inp_surname = false
let change_inp_name = false
function accordionQuestion() {
  const accordion = document.querySelector('.js--select-at');
  // eslint-disable-next-line no-unused-vars
  if (accordion) {
    const array = accordion.querySelectorAll('.js-accordion-parent')
    for(let item of array){
      if(item.classList.contains('active')){
        item.querySelector('.js-accordion-body').style.maxHeight = item.querySelector('.js-accordion-body').scrollHeight+'px';
      }
    }
    const btn = accordion.querySelectorAll('.js-accordion-btn');
    for(let item of btn){
      item.onclick = (ev) => {
        const element = ev.currentTarget;
        // dropDown(element, 0);

        const parent = item.closest('.js-accordion-parent');
        const container = parent.querySelector('.js-accordion-body');
        if (parent.classList.contains('active')) {
          parent.classList.remove('active');
          // eslint-disable-next-line camelcase
          container.setAttribute('style', `max-height:0;`);
        } else {
          // eslint-disable-next-line no-restricted-syntax,camelcase
          parent.classList.add('active');
          container.style.maxHeight = `${container.scrollHeight}px`;
          // container.setAttribute('style', `max-height:${container.scrollHeight}px;`);
        }


      };
    }


  }
}
function buttonAppearance() {
  const buttons = document.querySelector('.js--header-fix-button-at');
  const header = document.querySelector('.js--header');

  if (buttons && header) {
    const top = header.offsetHeight;
    const array_elem = buttons.querySelectorAll('.un-active');
    if (window.pageYOffset >= top) {
      for (let i = 0; i < array_elem.length; i++) {
        array_elem[i].classList.remove('un-active');
      }
    }
    else{
      for (let i = 0; i < array_elem.length; i++) {
        array_elem[i].classList.add('un-active');
      }
    }

      document.addEventListener('scroll', () => {
        if (window.pageYOffset >= top) {
          for (let i = 0; i < array_elem.length; i++) {
            array_elem[i].classList.remove('un-active');
          }
        }
        else{
          for (let i = 0; i < array_elem.length; i++) {
            array_elem[i].classList.add('un-active');
          }
        }
    });
  }




}
function mediaMenu(){
  const btn = document.querySelector('.js-at-open-menu')
  const media_menu = document.querySelector('.js--at-media-menu')
  if(btn&&media_menu){
    btn.onclick = () => {
      if(btn.classList.contains('active')){
        media_menu.classList.remove('is-open')
        btn.classList.remove('active')
        document.body.classList.remove('body-modal')
        document.ontouchmove =  (e)=> {
          return true;
        }

        if (btn.closest('.js--header-fix-button-at')
          .querySelector('.js-header-connection').classList.contains('re-un-active')) {
          btn.closest('.js--header-fix-button-at')
            .querySelector('.js-header-connection').classList.remove('un-active');
          btn.closest('.js--header-fix-button-at')
            .querySelector('.js-header-connection').classList.remove('re-un-active');
        }

      }
      else {
        media_menu.classList.add('is-open')
        btn.classList.add('active');
        if (document.documentElement.scrollHeight !== document.documentElement.offsetHeight) {
          document.body.classList.add('body-modal')
          document.ontouchmove = (e) => {
            e.preventDefault();
          };
        }
        if (!btn.closest('.js--header-fix-button-at')
          .querySelector('.js-header-connection').classList.contains('un-active')) {
          btn.closest('.js--header-fix-button-at')
            .querySelector('.js-header-connection').classList.add('un-active');
          btn.closest('.js--header-fix-button-at')
            .querySelector('.js-header-connection').classList.add('re-un-active');
        }
      }

    }
  }
}
function blind() {
  const close_btn = document.querySelector('.js--blind-close')
  if(close_btn){
    close_btn.onclick = () => {
      close_btn.closest('.js--blind-parent').setAttribute('style', `max-height:0;`);
    }

  }
}
function shareYaAnotherThing(){
  const array_share = document.querySelectorAll('.js--share-another-thing')
  for(let i = 0;i<array_share.length;i++){
    const data_url = array_share[i].getAttribute('data-url')
    Ya.share2(array_share[i], {
      theme: {
        // limit:0,
        // bare:false,
        // moreButtonType:'short',
        // popupDirection:'auto',
        // popupPosition:'outer',
        size:'m',
        shape:'round',
        services:'telegram,vkontakte',
        copy:'extraItem'
      },
      content: {
        url: data_url
      }
    });
  }
}
function temporarilyWindow() {
  const array_btn = document.querySelectorAll('.js--not-working')
  for(let i=0;i<array_btn.length;i++){
    array_btn[i].onclick = () =>{
      if(array_btn[i].closest('.js--at-work-part').querySelector('.js--at-alert')){
        array_btn[i].closest('.js--at-work-part').querySelector('.js--at-alert').style.display='block'
      }

    }
  }

  const array_btn_close = document.querySelectorAll('.js--at-alert-close')
  for(let i=0;i<array_btn_close.length;i++){
    array_btn_close[i].onclick = () =>{
      array_btn_close[i].closest('.js--at-alert').style.display='none'
    }
  }
}
function scrollMenu() {
  const array_menu = document.querySelectorAll('.js--at-header-menu')
  array_menu.forEach(link => {

    link.addEventListener('click', function(e) {
      e.preventDefault();

      let href = this.getAttribute('data-link');

      const scrollTarget = document.getElementById(href);

      // const topOffset = document.querySelector('.scrollto').offsetHeight;
      // const topOffset = 0; // если не нужен отступ сверху
      const elementPosition = scrollTarget.getBoundingClientRect().top;
      // const offsetPosition = elementPosition - topOffset;
      window.scrollBy({
        top: elementPosition,
        behavior: 'smooth'
      });
    });
  });
}
function notificationsInfo() {
  const bell = document.querySelector('.js--private-bell');
  const profile = document.querySelector('.js--header-prof-menu');

  const empty_block = document.querySelector('.js--empty-container')
  const close = document.querySelector('.js--notifications-close')
  if(bell&&empty_block&&bell.closest('.js--header-office-row').querySelector('.js--at-notifications')){
    const notifications = bell.closest('.js--header-office-row').querySelector('.js--at-notifications')
    bell.onclick =()=>{
      if(!notifications.classList.contains('active')){
        if (document.documentElement.scrollHeight !== document.documentElement.offsetHeight) {
          document.body.classList.add('body-modal')
          document.ontouchmove = (e) => {
            e.preventDefault();
          };
        }
        // document.body.classList.add('body-modal')
        notifications.classList.add('active')
        empty_block.classList.add('active')
      }
      if(profile){
        profile.classList.remove('active')
      }
    }

    if (empty_block){
      empty_block.addEventListener('click', () => {
        if (notifications.classList.contains('active')) {
          notifications.classList.remove('active');
          empty_block.classList.remove('active');
          document.body.classList.remove('body-modal');
          document.ontouchmove =  (e)=> {
            return true;
          }
        }
      });
    }


    if(close){
      close.onclick = function () {
        document.body.classList.remove('body-modal')
        document.ontouchmove =  (e)=> {
          return true;
        }
        notifications.classList.remove('active')
        empty_block.classList.remove('active')
      }
    }
  }
}
function focusInput(){
  const array_inp = document.querySelectorAll('.js--user-form-input')
  for(let i=0;i<array_inp.length;i++){
   array_inp[i].querySelector('input').onfocus=()=>{
      array_inp[i].closest('.js--user-form-col').classList.add('active')
    }
    array_inp[i].querySelector('input').onblur=()=>{
      array_inp[i].closest('.js--user-form-col').classList.remove('active')
      if(array_inp[i].classList.contains('js--user-input-name')||array_inp[i].classList.contains('js--user-input-surname')){
        array_inp[i].closest('.js--user-form-col').querySelector('.gameddreg__input-error').style.display='none'
      }
    }
  }
}
function closeFlip() {
  const btn_close = document.querySelector('.js--flip-tip-close')
  if(btn_close){
    btn_close.onclick = () => {
      btn_close.closest('.personal-office__flip-tip').style.display = 'none'
    }
  }
}
function headerProfile() {
  const profile = document.querySelectorAll('.js--header-user');
  const empty_block = document.querySelector('.js--empty-container');
  const wr_notification = document.querySelector('.js--at-notifications');
  for (let item of profile) {
    item.onclick = () => {
      const notifications = item.closest('.js--header-office-row')
        .querySelector('.js--header-prof-menu');
      if (notifications && !notifications.classList.contains('active')) {
        if (document.documentElement.scrollHeight !== document.documentElement.offsetHeight) {
          document.body.classList.add('body-modal');
          document.ontouchmove = (e) => {
            e.preventDefault();
          };
        }
        notifications.classList.add('active');
        if (empty_block) {
          empty_block.classList.add('active');
        }

      }
      if (wr_notification) {
        wr_notification.classList.remove('active')
      }
    };
  }

  if(empty_block) {
    empty_block.addEventListener('click', () => {
      if(empty_block){
        const parent_notifications = empty_block.closest('.js--header')
        if(parent_notifications){
          const notifications = parent_notifications.querySelector('.js--header-prof-menu')
          if (notifications&&notifications.classList.contains('active')) {
            notifications.classList.remove('active')
            empty_block.classList.remove('active')
            document.body.classList.remove('body-modal')
            document.ontouchmove =  (e)=> {
              return true;
            }
          }
        }

      }

    })
  }



  // // if(profile&&empty_block){
  //   const notifications = profile.closest('.js--header-office-row').querySelector('.js--header-prof-menu')
  //   profile.onclick =()=>{
  //     if(!notifications.classList.contains('active')){
  //       document.body.classList.add('body-modal')
  //       notifications.classList.add('active')
  //       empty_block.classList.add('active')
  //     }
  //   }



  // }
}
// изменение имени и фамилии в личном кабинете
function changeName(){
  const user_form = document.querySelector('.js--lc-user-form')
  let inp_name
  let inp_surname
  let inp_mail
  let val_name
  let val_surname
  let val_name_change
  let val_surname_change
  let len = 25
  if (user_form){
    inp_name = user_form.querySelector('.js--user-input-name input')
    inp_surname = user_form.querySelector('.js--user-input-surname input')
    if (inp_name&&inp_surname){
      val_name = inp_name.value
      val_surname = inp_surname.value



      inp_name.onpaste = (el)=>{
        const element = el.currentTarget
        let char = (el.clipboardData || window.clipboardData).getData('text');


        if (char==val_name){
          el.preventDefault();
        }
        if ( char.search(/^[а-яё\-\s]*$/i) == -1 ) {
          el.preventDefault();
          element.closest('.js--user-form-col').querySelector('.gameddreg__input-error').style.display='block'
        }
        else {
          maskName.value = ''
          if(char!=val_name&&char.length>0){
            change_inp_name=true
          }
          if((change_inp_name||change_inp_surname)){
            user_form.querySelector('.js--user-form-btn').classList.add('active')
          }
          if(change_inp_name===false&&change_inp_surname===false){
            user_form.querySelector('.js--user-form-btn').classList.remove('active')
          }

        }
      }

      inp_surname.onpaste = (el)=>{
        const element = el.currentTarget
        let char = (el.clipboardData || window.clipboardData).getData('text');
        if ( char.search(/^[а-яё\-\s]*$/i) == -1 ) {
          el.preventDefault();
          element.closest('.js--user-form-col').querySelector('.gameddreg__input-error').style.display='block'
        }
        else {
          maskSurame.value = ''
          if(char!=val_surname&&char.length>0){
            change_inp_surname=true
          }
          if((change_inp_name||change_inp_surname)){
            user_form.querySelector('.js--user-form-btn').classList.add('active')
          }
          if(change_inp_name===false&&change_inp_surname===false){
            user_form.querySelector('.js--user-form-btn').classList.remove('active')
          }

        }
      }

      inp_name.onkeyup = (e)=>{
        val_name_change = inp_name.value
        if(val_name_change!=val_name&&val_name_change.length>0){
          change_inp_name=true
        }
        else {
          change_inp_name=false
        }

        if((change_inp_name||change_inp_surname)){
          user_form.querySelector('.js--user-form-btn').classList.add('active')
        }
        if(change_inp_name===false&&change_inp_surname===false){
          user_form.querySelector('.js--user-form-btn').classList.remove('active')
        }

        if(val_name_change.length===0){
          user_form.querySelector('.js--user-form-btn').classList.remove('active')
        }
      }
      inp_surname.onkeyup = (e)=>{
        val_surname_change = inp_surname.value
        if(val_surname_change!=val_surname&&val_surname_change.length>0){
          change_inp_surname=true
        }
        else {
          change_inp_surname=false
        }


        if((change_inp_name||change_inp_surname)){
          user_form.querySelector('.js--user-form-btn').classList.add('active')
        }
        if(change_inp_name===false&&change_inp_surname===false){
          user_form.querySelector('.js--user-form-btn').classList.remove('active')
        }
        if(val_name_change.length===0||val_surname_change.length===0){
          user_form.querySelector('.js--user-form-btn').classList.remove('active')
        }
      }

      inp_name.oninput = (e) =>{
        const element = e.currentTarget
        let char = e.data
        if (/^[а-яё\-\s]*$/i.test(char)&&element.closest('.js--user-form-col').querySelector('.gameddreg__input-error')) {
          element.closest('.js--user-form-col').querySelector('.gameddreg__input-error').style.display='none'
        }
        if(e.inputType==='historyUndo'||e.inputType==='deleteContentBackward'||e.inputType!=='deleteContentForward'||e.inputType!=='insertFromPaste'){
          if(element.closest('.js--user-form-col').querySelector('.gameddreg__input-error')){
            element.closest('.js--user-form-col').querySelector('.gameddreg__input-error').style.display='none'
          }

        }
        if (!/^[а-яё\-\s]*$/i.test(char)&&e.inputType!=='deleteContentBackward'&&e.inputType!=='deleteContentForward'&&e.inputType!=='insertFromPaste'&&e.inputType!=='historyUndo') {
          if(element.closest('.js--user-form-col').querySelector('.gameddreg__input-error')){
            element.closest('.js--user-form-col').querySelector('.gameddreg__input-error').style.display='block'
          }

        }



        if (inp_name.value.length > len) {
          inp_name.value = inp_name.value.substring(0, len);
        }


      }
      inp_surname.oninput = (e) =>{
        if (inp_surname.value.length > len) {
          inp_surname.value = inp_surname.value.substring(0, len);
        }

        const element = e.currentTarget
        let char = e.data
        if (/^[а-яё\-\s]*$/i.test(char)&&element.closest('.js--user-form-col').querySelector('.gameddreg__input-error')) {
          element.closest('.js--user-form-col').querySelector('.gameddreg__input-error').style.display='none'
        }
        if(e.inputType==='historyUndo'||e.inputType==='deleteContentBackward'||e.inputType!=='deleteContentForward'||e.inputType!=='insertFromPaste'){
          if(element.closest('.js--user-form-col').querySelector('.gameddreg__input-error')){
            element.closest('.js--user-form-col').querySelector('.gameddreg__input-error').style.display='none'
          }

        }
        if (!/^[а-яё\-\s]*$/i.test(char)&&e.inputType!=='deleteContentBackward'&&e.inputType!=='deleteContentForward'&&e.inputType!=='insertFromPaste'&&e.inputType!=='historyUndo') {
          if(element.closest('.js--user-form-col').querySelector('.gameddreg__input-error')){
            element.closest('.js--user-form-col').querySelector('.gameddreg__input-error').style.display='block'
          }

        }


      }
    }
  }

}
//выбор чекбокса вна изменение имени и фамилии в личном кабинете

//вызов пост запроса в кнопке Сохранить в личном кабинете наизменение фамилии и Имени
function postSandCangeName(){
  const user_form = document.querySelector('.js--lc-user-form')
  if(user_form){
    const btn = user_form.querySelector('.js--user-form-btn')
    btn.onclick=()=>{
      const odj_data = {}
      const name = btn.closest('.js--lc-user-form').querySelector('.js--user-input-name input').value
      const surname = btn.closest('.js--lc-user-form').querySelector('.js--user-input-surname input').value
      odj_data.NAME = name
      odj_data.LAST_NAME = surname
      // if ((change_inp_name||change_inp_surname)&&processing_rules){
      if ((change_inp_name||change_inp_surname)){
        axios({
          method:'post',
          url:'/api/local/gamedd/profile/user/',
          // url:'https://httpbin.org/post',
          headers: {
            'Content-type': 'application/json',
            'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
          },
          data:odj_data
        })
          // Если запрос успешен
          .then( (res)=> {
            // processing_rules=false;
            change_inp_surname = false
            change_inp_name = false
            btn.classList.remove('active')
            btn.closest('.js--lc-user-form').querySelector('.js--user-checkbox input').checked = false;
          })
          // Если запрос с ошибкой
          .catch( (error)=> {
            console.log(error);
          });
      }
    }
  }
}

//Тултип
function toolTip(){
  const array_block = document.querySelectorAll('.js--personal-office-tasks')
  const empty_block = document.querySelector('.js--empty-container')
  for(let item of array_block){
    const tooltip = item.querySelector('.js--tasks-notification')
    if(tooltip){
      item.onclick = (e) => {
        if(empty_block){
          empty_block.classList.add('active')
        }

        tooltip.querySelector('p').onclick = function (w) {
          w.stopPropagation();
        }
        if(!tooltip.classList.contains('active')){
          for (let i=0;i<array_block.length;i++){
            array_block[i].querySelector('.js--tasks-notification').classList.remove('active')
          }
          tooltip.classList.add('active')
          tooltip.classList.add('zoomInNot')
          if (document.documentElement.scrollHeight !== document.documentElement.offsetHeight) {
            document.body.classList.add('body-modal')
            document.ontouchmove = (e) => {
              e.preventDefault();
            };
          }

          var distanceScrolled = document.body.scrollTop;
          var c = item.getBoundingClientRect()



          if (window.innerWidth> 770) {
            // tooltip.style.left = (c.left + 10) + "px";
            // tooltip.style.top = (c.top + 10) + "px";
          }
          else {
            // tooltip.style.left = c.left + "px";
            // tooltip.style.top = c.top + "px";
          }
        }
        else {
          tooltip.classList.remove('active')
          tooltip.classList.remove('zoomInNot')
          document.body.classList.remove('body-modal')
          if(empty_block) {
            empty_block.classList.remove('active')
            document.ontouchmove =  (e)=> {
              return true;
            }
          }
        }



      }

    }
  }
  if(empty_block) {
    empty_block.addEventListener('click', (e) => {
      if(empty_block.classList.contains('active')){

        for(let item of array_block){
          item.querySelector('.js--tasks-notification').classList.remove('active')
          empty_block.classList.remove('active')
          item.querySelector('.js--tasks-notification').classList.remove('zoomInNot')
          document.body.classList.remove('body-modal')
          document.ontouchmove =  (e)=> {
            return true;
          }
        }

      }

    })
  }
}

function inputCost(){
  const input_status = document.querySelectorAll('.js--user-input-tel input');
  const maskOptions = {
    mask: '+{7} 000 000 00 00',
    prepare: (appended, masked) => {
      if (appended === '8' && masked.value === '') {
        return '';
      }

      return appended;
    },
    // lazy: false,  // make placeholder always visible
    // placeholderChar: ''

  };
  for (const item of input_status) {
    IMask(item, maskOptions);
  }
}

// //для почты
// function inputMail(){
//   const input_status = document.querySelectorAll('.js--user-input-mail input');
//   const maskOptions = {
//     mask: /^[a-z0-9@.\-\s]*$/,
//     // lazy: false,  // make placeholder always visible
//     // placeholderChar: ''
//
//   };
//   for (const item of input_status) {
//     IMask(item, maskOptions);
//   }
// }

//для имени
function inputName(){
  const input_status = document.querySelectorAll('.js--user-input-name input');
  const user_form = document.querySelector('.js--lc-user-form')
  const maskOptions = {
    mask: /^[а-яё]+(?:[ -]{1}[а-яё]*)?$/i
    // lazy: false,  // make placeholder always visible
    // placeholderChar: ''

  };
  for (const item of input_status) {
    maskName = IMask(item, maskOptions);
    // if(user_form){
    //   let inp_name = user_form.querySelector('.js--user-input-name input')
    //   if(inp_name){
    //     mask.value = inp_name.value
    //   }
    // }
  }
}

//для фамилии
function inputSurName(){
  const input_status = document.querySelectorAll('.js--user-input-surname input');
  const maskOptions = {
    mask: /^[а-яё]+(?:[ -]{1}[а-яё]*)?$/i
    // lazy: false,  // make placeholder always visible
    // placeholderChar: ''

  };
  for (const item of input_status) {
    maskSurame = IMask(item, maskOptions);
  }
}

function mediaMenuList(){

    const navItems = document.querySelector('.personal-office__container-nav');
    if(navItems){
      const navItemActive = navItems.querySelector('li.active');
      if (!navItemActive) {
        return;
      }
      const navItemsRect = navItems.getBoundingClientRect();
      const navItemActiveRect = navItemActive.getBoundingClientRect();
      const navItemsLeft = navItemActiveRect.left - navItemsRect.left + (navItemActiveRect.width - navItemsRect.width) / 2;
      // navItems.scrollLeft = navItemsLeft;
      navItems.scrollTo({left: navItemsLeft, behavior: 'smooth'});
    }


}
function portraitResize() {
  if(document.body.classList.contains('body-another-thing')){
    window.onresize = function() {
      document.body.height = window.innerHeight;
    }
    window.onresize();
  }
}
function referralLink(){
  const referral_link = document.querySelectorAll('.js--referral-link')

  for(let item of referral_link){
    item.onclick=(evt)=>{
      if(!item.querySelector('.js--referral-hint').classList.contains('active')){

      }
      navigator.clipboard.writeText(item.getAttribute('data-ref-link')).then(() => {
        item.querySelector('.js--referral-hint').classList.add('active')
        // При нажатие на кнопку в профиле "пригласить друга", срабатывает яндекс-цель "referal_link_copied"
        if (typeof ym === 'function'){
          const data_atrr_user = item.getAttribute('data-user')
          ym(47257560, 'reachGoal', 'referal_link_copied',{userId: data_atrr_user})
          console.log('ya - reachGoal: referal_link_copied',{userId: data_atrr_user})
        }
        if(item.querySelector('.js--referral-hint')){
          item.querySelector('.js--referral-hint').classList.add('active-suc')
          setTimeout(()=>{
            item.querySelector('.js--referral-hint').classList.remove('active-suc')
            item.querySelector('.js--referral-hint').classList.remove('active')
          },1500)
        }
      }, () => {
        item.querySelector('.js--referral-hint').classList.add('active-fail')
        setTimeout(()=>{
          item.querySelector('.js--referral-hint').classList.remove('active-fail')
          item.querySelector('.js--referral-hint').classList.remove('active')
        },1500)
      });

    }
    const area = item.closest('.js-p-wrap')
    if(area){
      area.addEventListener('click', (e) => {
        if (e.target != document.querySelector('.personal-office__referral-title')
          && e.target != document.querySelector('.personal-office__referral-hint-text')
          && e.target != document.querySelector('svg')) {
          item.querySelector('.js--referral-hint').classList.remove('active')
          item.querySelector('.js--referral-hint').classList.remove('active-suc')
          item.querySelector('.js--referral-hint').classList.remove('active-fail')
        }
      });
    }

  }
}

function closeWindowWarningEnd(){
  const close_btn = document.querySelectorAll('.js--window-warnin--close')
  for(let item of close_btn){

    item.onclick = ()=>{
      const parent = item.closest('.window-warning')
      if(parent){
        parent.classList.remove('open')
        let now = new Date();
        let expireTime = now.getTime() + 1000*60*60*24;
        now.setTime(expireTime);
        document.cookie = 'BITRIX_SM_gamedd_ending_notification=hide;expires='+now.toUTCString()+';path=/';
      }
    }

  }
}

export default function anotherThing() {
  toolTip();
  accordionQuestion();
  blind();
  temporarilyWindow();
  scrollMenu();
  notificationsInfo();
  focusInput();
  closeFlip();
  headerProfile();
  changeName();
  // changeCheckRules();
  postSandCangeName();
  inputCost();
  inputName();
  inputSurName();
  mediaMenuList();
  portraitResize();
  referralLink();
  closeWindowWarningEnd();
}
