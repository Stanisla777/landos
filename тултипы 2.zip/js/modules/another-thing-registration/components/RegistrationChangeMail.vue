<template lang="pug">
  .gameddreg__wrapper(
    ref="gamedd_wrapper"
  )
    .gameddreg__come-back.gameddreg__come-back-change-mail(@click="comeBack")
      svg(width='24', height='24', viewbox='0 0 24 24', fill='none', xmlns='http://www.w3.org/2000/svg')
        path(d='M19 12H5', stroke='white', stroke-width='2', stroke-linecap='round', stroke-linejoin='round')
        path(d='M12 19L5 12L12 5', stroke='white', stroke-width='2', stroke-linecap='round', stroke-linejoin='round')
    template
      registration-close
    p.gameddreg__title  Укажите другой email
    p.gameddreg__sub-title.margin.
      Введите новую почту для регистрации

    .gameddreg__container-input
      .gameddreg__wr-input(
        ref="parentInput"
      )
        p.test-a__entry-field-fin-add-des Электронная почта
        .test-a__entry-field-fin-add.gameddreg__input.js--reg-input.js--reg-input-mail
          input(type="text" placeholder="xxx@xxx.xx")(
            ref="inputMail"
            @focus="focusInput"
            @blur="lossFocus"
            @keyup="inputVal"
            @paste="pasteMail"
            @input="InputMailChange"

          )
          .test-a__entry-field-add-icon(
            @click="clearFieldState"
            @mouseover="elemMouseOver"
            @mouseout="elemMouseOut"
          )
            svg(width='14', height='14', viewbox='0 0 14 14', fill='none', xmlns='http://www.w3.org/2000/svg')
              path(fill-rule='evenodd', clip-rule='evenodd', d='M5.58544 6.99975L0.635742 11.9495L2.04996 13.3637L6.99966 8.41396L11.9495 13.3638L13.3637 11.9495L8.41387 6.99975L13.3637 2.04996L11.9495 0.635742L6.99966 5.58553L2.04996 0.635835L0.635746 2.05005L5.58544 6.99975Z', fill='white')
          p.gameddreg__input-error(
            v-if="!inputError"
          ) Некорректное значение в поле
          p.gameddreg__attempt-input-error(
            v-if="inputError"
          ) Попытка ввести недопустимый символ
    .gameddreg__wr-btn-input.gameddreg__button
      .test-a__add-zone-btn.green.test-a__btn(
        v-if="active_btn"
        @click="sendPost"
      ) Отправить письмо
      .test-a__add-zone-btn.unactive.test-a__btn(
        v-if="!active_btn"
      ) Отправить письмо
      p.gameddreg__input-error.gameddreg__input-error-hint(ref="hintText")

</template>

<script>
import IMask from 'imask';
import Storage from '../development-tools/state.vue';
import RegistrationClose from './RegistrationClose.vue';
import inputField from '../mixin/inputField';
import axios from 'axios';
import Cookies from 'js-cookie';
let mask;
let maskMail;


export default {
  name: 'RegistrationChangeMail',

  props: {


  },
  data() {
    return {
      active_btn:false,
      InputName:'',
      InputSurName:'',
      InputMail:'',
      InputTel:'',
      error:false,
      error_tel:false,
      inputError:false
    }
  },

  methods: {
    comeBack(){
      Storage.dispatch('ActionStep','finish')

    },

    elemMouseOver(el){
      const element = el.currentTarget
      element.closest('.js--reg-input').classList.add('not_error')
    },
    elemMouseOut(el){
      const element = el.currentTarget
      element.closest('.js--reg-input').classList.remove('not_error')

    },
    pasteMail(el){
      const element = el.currentTarget
      maskMail.value=''
      let char = (el.clipboardData || window.clipboardData).getData('text');
      if ( char.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)) {
        element.closest('.js--reg-input').classList.remove('error')
        this.active_btn=true
      }
      else{
        element.closest('.js--reg-input').classList.add('error')
        this.active_btn=false
      }
      element.closest('.js--reg-input').querySelector('.test-a__entry-field-add-icon').classList.add('active')
    },

    InputMailChange(e){
      const element = e.currentTarget
      let char = e.data
      if (/^[a-z0-9a-z0-9@!#$%&'.+-=?^_"`{|}~\s]*$/i.test(char)) {
        // element.closest('.js--reg-input').querySelector('.gameddreg__input-error').style.display="none"
        // element.closest('.js--reg-input').classList.add('error-input')
        this.inputError=true
      }
      if(e.inputType==='historyUndo'||e.inputType==='deleteContentBackward'||e.inputType!=='deleteContentForward'||e.inputType!=='insertFromPaste'){
        // element.closest('.js--reg-input').querySelector('.gameddreg__input-error').style.display="none"
        // element.closest('.js--reg-input').classList.remove('error-input')
        this.inputError=false
      }
      if (!/^[a-z0-9a-z0-9@!#$%&'.+-=?^_"`{|}~\s]*$/i.test(char)&&e.inputType!=='deleteContentBackward'&&e.inputType!=='deleteContentForward'&&e.inputType!=='insertFromPaste'&&e.inputType!=='historyUndo') {
        // element.closest('.js--reg-input').classList.add('error-input')
        this.inputError=true
      }
    },



    inputVal(el){
      const element = el.currentTarget
      if(element.value.length===0){
        element.closest('.js--reg-input').querySelector('.test-a__entry-field-add-icon').classList.remove('active')
        element.closest('.js--reg-input').classList.remove('error')
      }
      if(element.value.length>0) {
        element.closest('.js--reg-input').querySelector('.test-a__entry-field-add-icon').classList.add('active')
      }

      if(element.value.length>0&&element.value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)){
        element.closest('.js--reg-input-mail').classList.remove('error')
        this.active_btn=true
        // element.closest('.js--reg-input-mail').classList.add('error');
      }
      else {
        this.active_btn=false
        // element.closest('.js--reg-input-mail').classList.add('error');
      }


    },
    focusInput(el){
      const element = el.currentTarget
      element.closest('.js--reg-input').classList.add('active')
    },
    //потеря фокуса
    lossFocus(el){
      const element = el.currentTarget
      const val = element.value.length
      this.inputError=false
      if(val===0){
        element.closest('.js--reg-input').classList.remove('active')
        element.closest('.js--reg-input').querySelector('.test-a__entry-field-add-icon').classList.remove('active')
      }
      if (element.closest('.js--reg-input')
        .classList.contains('js--reg-input-mail') && !element.closest('.js--reg-input').classList.contains('not_error')) {
        if (val > 0 && !element.value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)) {
          element.closest('.js--reg-input-mail').classList.add('error');
        }
      }
      if (val > 0 && !element.value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)) {
        this.active_btn=false
      }
    },
    clearFieldState(el){
      const element = el.currentTarget
      element.closest('.js--reg-input').classList.remove('active')
      element.classList.remove('active')
      element.closest('.js--reg-input').querySelector('input').value=''
      element.closest('.js--reg-input').classList.remove('error')
      // element.closest('.js--reg-input').classList.remove('error-input')
      this.inputError=false
      this.active_btn=false
      maskMail.value=''
    },


    //для почты
    inputMail(){
      const input_status = document.querySelectorAll('.js--reg-input-mail input');
      const maskOptions = {
        mask: /^[a-z0-9a-z0-9@!#$%&'.+-=?^_"`{|}~\s]*$/i,
        // lazy: false,  // make placeholder always visible
        // placeholderChar: ''

      };
      for (const item of input_status) {
        maskMail = IMask(item, maskOptions);
      }
    },

    sendPost(){
      //как и везде передаю объект
      const obj={}

      const val_mail = this.$refs.inputMail.value
      obj.EMAIL=val_mail


      axios({
        method:'post',
        // url:'https://httpbin.org/post', //для раЗРАБОТКИ
        url:'/api/local/gamedd/profile/user/',

        headers: {
          "Content-type": "application/json; charset=UTF-8",
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        },
        data:obj
      })
        // Если запрос успешен
        .then((res) => {
          Storage.dispatch('ActionStep','finish')
          Storage.dispatch('ActionChangeMail',obj)
          this.$refs.hintText.textContent=''
        })
        // Если запрос с ошибкой
        //вот тут в переменную  буду записывать ошибки, которые будет возвращать бэк
        // и в зависимости от неё выводить ошибку(неправильный код и так далее)
        .catch((error)=> {
          if(error.response){
            console.log(error.response);
            if(error.response.data.error!=undefined&&error.response.data.error.description!=undefined){
              this.$refs.hintText.textContent = error.response.data.error.description
            }
          }
        });

    },

  },

  computed: {
    user_data_state(){
      return Storage.getters.USERDATA.EMAIL
    },
  },
  watch: {

  },
  mounted() {
    this.inputMail()

  },
  updated() {

  },
  components:{
    RegistrationClose
  }

}
</script>
