<template lang="pug">
  .gameddreg__wrapper(
    ref="gamedd_wrapper"
  )
    template
      registration-close
    p.gameddreg__title  Регистрация окончена
    p.gameddreg__sub-title.gameddreg__sub-title-vk.
      Регистрация новых участников завершилась 24&nbsp;августа. Благодарим за&nbsp;проявленный интерес к&nbsp;нашей онлайн-игре по&nbsp;финансовой грамотности.

</template>

<script>
import { Config, Connect} from '@vkontakte/superappkit';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import RegistrationClose from './RegistrationClose.vue';

export default {
  name: 'RegistrationEndRegistration',

  props: [],
  data() {
    return {

    }
  },
  computed: {

  },
  methods: {

  },
  mounted() {

  },
  created(){},
  updated() {

  },
  components:{
    RegistrationClose
  }

}
</script>
