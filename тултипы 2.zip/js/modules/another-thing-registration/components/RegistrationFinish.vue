<template lang="pug">
  .gameddreg__wrapper
    template
      registration-close
    .gameddreg__finish-alarm-img
      img(src="/dist/img/alarm.png")
    p.gameddreg__title  Почти закончили
    p.gameddreg__sub-title.gameddreg__finish-sub-title.margin.
      Мы выслали ссылку для подтверждения адреса на&nbsp;вашу электронную почту. Она будет активна в течение 24 часов.
    p.gameddreg__finish-mail {{user_data.EMAIL}}
    p.gameddreg__finish-change-mail(
      @click="changeMail"
    ) Изменить почту

</template>

<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import RegistrationClose from './RegistrationClose.vue'


export default {
  name: 'RegistrationFinish',

  props: {

  },
  data() {
    return {
      status_btn:false,
    }
  },
  computed: {
    user_data(){
      return Storage.getters.USERDATA
    },
  },
  methods: {
    changeMail(el){
      const element = el.currentTarget
      Storage.dispatch('ActionStep','change_mail')
    },


  },
  created(){


  },
  updated() {

  },
  components:{
    RegistrationClose

  }

}
</script>
