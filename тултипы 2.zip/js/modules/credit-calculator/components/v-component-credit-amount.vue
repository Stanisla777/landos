<template lang="pug">
  .property-calculator__row.margin
    p.property-calculator__row-label Сумма кредита, ₽
    .property-calculator__input-field.js--number-debt(@click="inputFocus")
      input.property-calculator__value(inputmode="numeric")(


        type="text"
        ref="realtyInput"
        @keydown="inputField"
        @keyup="keyUp"
        @change ="inputValue"
        @paste="inputPast"
        @blur="moveAnotherElement"
        @input="numberFormattingThousandths(stgMax,$event)"
      )

      .range-input__slider(ref="mortgagePrice")
    .property-calculator__wr-range
      p.property-calculator__range {{stgMin}}
      p.property-calculator__range {{String(stgMax).slice(0,2)}} млн
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import noUiSlider from 'nouislider';
import Storage from '../development-tools/state.vue';
import IMask from 'imask';
import onlyNumbers from '../custom-scripts/only-numbers.js'
export default {
  name: 'v-credit-amount',
  data(){
    return {
      realtySlider: '', // Слайдер "Стоимость недвижимости"
      dataField: 0, // Стоимость недвижимости
      dataFieldForCalculation: 0,
      subsidies: 0,
      stepApartment: 1, // Шаг для range инпутов
      stgMin: 1, // Минимальное значение поля стоимости
      stgMiddle: 27000000, // Значение по середине (стоимость)
      stgMax: 50000000, // Максимальное значение поля стоимости
      input_salary:false,
      start:5000
    }
  },
  methods:{
    initRealtySlider() {
      this.realtySlider = noUiSlider.create(this.$refs.mortgagePrice, {
        start: [this.start],
        connect: 'lower',
        step: this.stepApartment,
        initial: this.stgMin,
        range: {
          min: this.stgMin,
          max: this.stgMax
        },
      });
      this.realtySlider.on('start', (val,handle) => {

      });
      this.realtySlider.on('update', (val,handle) => {

        this.input_salary = false
        this.$refs.realtyInput.value = parseInt(val[handle]).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        this.dataField = parseInt(val[handle]).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
      });

      this.realtySlider.on('set', (val,handle) => {

        this.input_salary = false
        this.$refs.realtyInput.value = parseInt(val[handle]).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        this.dataField = parseInt(val[handle]).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        this.dataFieldForCalculation = parseInt(val[handle]).toFixed(0)
        this.$nextTick(() => {
          setTimeout(()=>{
            Storage.dispatch('ActionDebtOldCredit',parseInt(val[handle]))
          },300)
        })

      });


      this.realtySlider.on('end', (val,handle) => {


        // this.dataFieldForCalculation = parseInt(val[handle]).toFixed(0)
        // this.$nextTick(() => {
        //   setTimeout(()=>{
        //     Storage.dispatch('ActionDebtOldCredit',parseInt(val[handle]))
        //   },300)
        // })

      });

    },

    numberFormattingThousandths(count,e) {
      const element = e.currentTarget;
      const target = e.target
      let position = target.selectionStart;
      const val = parseFloat(element.value.replace(/\s/g, ''))
      element.value = new Intl.NumberFormat("ru-RU").format(val);

      if (e.inputType==="deleteContentBackward"){
        target.selectionEnd = position;
      }
      if (element.value=='не число') {
        element.value=''
      }
      if (element.value.length > 0 && element.value[0] === '0'){
        element.value = '1' +  element.value.slice(1)
      }

      if (element.value.replace(/\s/g, '') > count){
        element.value=(count).toFixed(0)
          .toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
      }
      // if (element.value.replace(/\s/g, '') < this.stgMin){
      //   element.value=this.stgMin
      // }
      this.dataField=element.value


    },
    inputCost(){
      const input_status = document.querySelectorAll('.js--number-debt input');
      const maskOptions = {
        mask: Number,
        thousandsSeparator: ' ',
        // max:this.stgMax
      };
      for (const item of input_status) {
        new IMask(item, maskOptions);
      }
    },

    //Ввод значения пользователем
    inputField(event){
      // onlyNumbers(event)
      const element = event.currentTarget
      let value = element.value
      value = parseInt(value.replace(/\s/g, ''));
      if(event.keyCode == 13){
        const parent = element.closest('.js--number-debt')
        let value = parent.querySelector('input').value
      }
      if(value>this.stgMax){

      }
    },


    keyUp(e) {
      const element = e.currentTarget


      if(element.value!==''&&(parseInt(element.value.replace(/\s/g, ''))>=this.stgMin)&&parseInt(element.value.replace(/\s/g, ''))<=this.stgMax){
        // Storage.dispatch('ActionFinalWindow',true)
        Storage.dispatch('ActionDebtOldCredit',parseInt(element.value.replace(/\s/g, '')))
        this.realtySlider.set(parseInt(element.value.replace(/\s/g, '')));
      }

      else if(parseInt(element.value.replace(/\s/g, ''))>this.stgMax)  {
        // Storage.dispatch('ActionFinalWindow',true)
        Storage.dispatch('ActionDebtOldCredit',parseInt(this.stgMax))
        this.realtySlider.set(this.stgMax);
      }
      else if(parseInt(element.value.replace(/\s/g, ''))<this.stgMin)  {
        // Storage.dispatch('ActionFinalWindow',true)
        Storage.dispatch('ActionDebtOldCredit',parseInt(this.stgMin))
      }

      if(parseInt(element.value.replace(/\s/g, ''))>=this.stgMax){
        this.dataField = this.stgMax.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
      }


    },
    inputValue(el){
      const element = el.currentTarget;
      let value = element.value
      value = parseInt(value.replace(/\s/g, ''));
      if(value>this.stgMax)  {
        this.dataFieldForCalculation = this.stgMax

      }
      if(value<this.stgMin)  {
        this.dataFieldForCalculation = this.stgMin
        this.realtySlider.set(this.stgMin);
      }
    },
    inputPast(el){
      const element = el.currentTarget;
      let element_val = (el.clipboardData || window.clipboardData).getData('text');
      if ( element_val.search(/[^0-9]/g) != -1 ) {
        el.preventDefault();
      }
    },

    inputFocus(el){
      const element = el.currentTarget
      element.querySelector('input').focus()
    },

    moveAnotherElement(el) {
      const element = el.currentTarget;
      if (element.value==='') {
        element.value = this.stgMin;
        this.realtySlider.set(this.stgMin);
        // Storage.dispatch('ActionFinalWindow',true)
        Storage.dispatch('ActionDebtOldCredit',this.stgMin)

      }
    },

    calculationPageLoad(){
      // Storage.dispatch('ActionFinalWindow',true)
      Storage.dispatch('ActionDebtOldCredit',parseInt(this.dataFieldForCalculation))
    },

  },
  mounted(){
    this.initRealtySlider()
    // this.inputCost()
    Storage.dispatch('ActionDebtOldCredit',parseInt(this.dataField.replace(/\s/g, '')))
  },
  computed:{
  },
  watch:{
    dataField(){
      // const elem = document.querySelector('.property-calculator__final-preload')
      // if (elem){
      //   elem.setAttribute('style','display:block;')
      // }
      Storage.dispatch('ActionFinalWindow',true)

    },
  },
  created(){
  },
  components:{}
};
</script>
<style scoped>
</style>
