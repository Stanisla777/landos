<template lang="pug">
  .property-calculator__row
    p.property-calculator__row-label Дата начала выплат
    .property-calculator__input-field.js--credit-calendar-input
      input.property-calculator__value(type="text" placeholder="дд.мм.гггг" inputmode="numeric")(
        @input="changeDate"
        @click ="showCalendar"
        v-bind:value="new Date().toLocaleDateString('ru')"

      )
      .js__vanilla-calendar-calc.vanilla-calendar-style.property-calculator__vanilla-calendar(
        @click.stop ="showCalendar"
      )
      .property-calculator__input-additional-elem(
        @click ="showCalendar"
      )
        svg(width='20', height='20', viewbox='0 0 20 20', fill='none', xmlns='http://www.w3.org/2000/svg')
          path(d='M4.16658 0V0.833333H0.833252V19.1667H19.1666V0.833333H15.8333V0H14.1666V0.833333H5.83325V0H4.16658ZM2.49992 2.5H4.16658V3.33333H5.83325V2.5H14.1666V3.33333H15.8333V2.5H17.4999V4.16667H2.49992V2.5ZM2.49992 5.83333H17.4999V17.5H2.49992V5.83333ZM4.16658 10.8333V12.5H5.83325V10.8333H4.16658ZM7.49992 10.8333V12.5H9.16658V10.8333H7.49992ZM10.8333 10.8333V12.5H12.4999V10.8333H10.8333ZM14.1666 10.8333V12.5H15.8333V10.8333H14.1666ZM4.16658 14.1667V15.8333H5.83325V14.1667H4.16658ZM7.49992 14.1667V15.8333H9.16658V14.1667H7.49992ZM10.8333 14.1667V15.8333H12.4999V14.1667H10.8333Z', fill='black')


</template>
<script>
import IMask from 'imask';
import VanillaCalendar from '../../vanilla-calendar';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import PopUp from '../components/v-component-pop-up.vue';
import Vue from 'vue';
export default {
  name: 'v-date-transfer',
  props:['first_period_date'],
  data(){
    return {
      error_count:new Date(1982, 0, 1),
      first_date:false,
      dataInput:'',
      calendar:''

    }
  },
  methods:{
    inputCalendar(){
      const input_status = document.querySelectorAll('.js--credit-calendar-input input');
      const maskOptions = {
        mask: Date,

      };
      for (const item of input_status) {
        // eslint-disable-next-line no-new
        new IMask(item, maskOptions);
      }
    },
    initPluginCalendarVanilla(dates,month,year){
      this.calendar = new VanillaCalendar('.js__vanilla-calendar-calc', {
        settings: {
          lang: 'ru',
          range: {
            // max: new Date().toISOString().slice(0, 10)
          },
          selected: {
            dates: dates,
            month: month,
            year:year
          },
          selection: {

          },
        },
        actions: {
          clickDay(e, dates) {
            const data = String(dates[0])
              .substr(8, 2) + '.' + String(dates[0])
              .substr(5, 2) + '.' + String(dates[0])
              .substr(0, 4);
            if (dates.length !== 0) {
              const parent = e.target.closest('.js--credit-calendar-input');
              if(parent!==null){
                parent.querySelector('input').value = data;
                Storage.dispatch('ActionStartPayment', data);
                Storage.dispatch('ActionStartPayment', [dates[0], String(dates[0])
                  .substr(8, 2)]);
                e.target.closest('.js__vanilla-calendar-calc').classList.remove('active');
              }
            }
          }
        }
      })
      this.calendar.init();
    },
    changeDate(el) {
      const element = el.currentTarget;
      const container = element.closest('.js--tax-deduction_calculations');
      const data1 = new Date(element.value.replace(/(_|\s)+/g, "").substr(6, 4)+'-'+element.value.replace(/(_|\s)+/g, "").substr(3, 2)+"-"+element.value.replace(/(_|\s)+/g, "").substr(0, 2));
      const date2 = this.first_period_date;
      const oneDay = 1000 * 60 * 60 * 24;


      if (element.value.replace(/(_|\s)+/g, "").length===10&&element.value.replace(/(_|\s)+/g, "").substr(3, 2)<=12) {
        const date = element.value.replace(/(_|\s)+/g, "").substr(6, 4)+'-'+element.value.replace(/(_|\s)+/g, "").substr(3, 2)+"-"+element.value.replace(/(_|\s)+/g, "").substr(0, 2)
        const month = parseInt(element.value.replace(/(_|\s)+/g, "").substr(3, 2)) - 1;
        const year = element.value.replace(/(_|\s)+/g, "").substr(6, 4)

        this.calendar = null
        this.initPluginCalendarVanilla([`${date}`],month,year)

        const date_begin = element.value.replace(/(_|\s)+/g, "").substr(0, 2)
        Storage.dispatch('ActionStartPayment',[element.value.replace(/(_|\s)+/g, "").substr(6, 4)+'-'+element.value.replace(/(_|\s)+/g, "").substr(3, 2)+"-"+element.value.replace(/(_|\s)+/g, "").substr(0, 2),date_begin])
        setTimeout(()=>{
          element.closest('.js--credit-calendar-input').querySelector('.js__vanilla-calendar-calc').classList.remove('active')
        },500)

      }
      else if(element.value.replace(/(_|\s)+/g, "").length < 10){

      }

    },
    showCalendar(el){
      const element = el.currentTarget;
      element.closest('.js--credit-calendar-input').querySelector('.js__vanilla-calendar-calc').classList.add('active')

    },
    todayDate(){
      const today_date = new Date().toLocaleDateString('ru')
      Storage.dispatch('ActionStartPayment',[today_date.substr(6, 4)+'-'+today_date.substr(3, 2)+"-"+today_date.substr(0, 2),today_date.substr(0, 2)])
    },
    CalendarVanillaClose() {
      let count = 0;
      document.body.onclick = () => {
        const array_parent = document.querySelectorAll('.js--credit-calendar-input');
        const array_element = document.querySelectorAll('.js__vanilla-calendar-calc.active');
        for (const item of array_parent) {
          item.onclick = function (w) {
            w.stopImmediatePropagation();
          };
        }
        if (count > 0) {
          for (let i = 0; i < array_element.length; i++) {
            array_element[i].classList.remove('active');
          }
        }
        if (count < 1) {
          count += 1;
        }

      };
    }
  },
  mounted(){
    this.inputCalendar()
    this.initPluginCalendarVanilla()
    this.todayDate()
    this.CalendarVanillaClose()
  },
  computed:{
    appearance_error(){
      return Storage.getters.STATE_DIFFERENCE_DAYS
    },
    delivery_date(){
      return Storage.getters.DELIVERY_DATE
    },


  },
  watch:{

  },
  components:{
    PopUp
  }
};
</script>
<style scoped>
</style>
