<template lang="pug">
  .property-calculator__row.margin

    p.property-calculator__row-label  Срок кредита
    .property-calculator__input-field.js--number-cost-pr.js--wrapper-select(@click="inputFocus")
      input.property-calculator__value(inputmode="numeric")(

        v-model="dataField"
        type="text"
        ref="realtyInput"
        @keydown="inputField"
        @input ="inputValue"
        @paste="inputPast"
        @click="inpRemoveMark"
        @blur="moveAnotherElement"
      )


      .property-calculator__input-list-button(
        @click="openList"
      )
        p.js--selected-value лет
        svg(width='7', height='5', viewbox='0 0 7 5', fill='none', xmlns='http://www.w3.org/2000/svg')
          path(d='M3.79102 4.39999L0.791016 0.799988L6.79102 0.799988L3.79102 4.39999Z', fill='black')


      ul.property-calculator__select__list.js--list-wrapper
          li.js--select-item(
            v-bind:data-period="item.data"
            v-for="item in type_period"
            @click="periodSelection"
          ) {{item.period}}
      .range-input__slider(ref="mortgagePrice")
    .calculator_s__cost-flat
      p.property-calculator__range {{stgMin}}
      p.property-calculator__range {{stgMax}}
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import noUiSlider from 'nouislider';
import Storage from '../development-tools/state.vue';
import IMask from 'imask';
import onlyNumbers from '../custom-scripts/only-numbers.js'
export default {
  name: 'v-credit-time',
  data(){
    return {
      realtySlider: '', // Слайдер "Стоимость недвижимости"
      dataField: '', // Стоимость недвижимости
      dataFieldForCalculation: 0,
      subsidies: 0,
      stepInput: 1, // Шаг для range инпутов
      stgMin: 1, // Минимальное значение поля стоимости
      stgMiddle: 20, // Значение по середине (стоимость)
      stgMax: 30, // Максимальное значение поля стоимости
      input_salary:false,
      start:1,
      type_period: [
        {
          period:'Лет',
          data:'year',
          status:true
        },
        {
          period:'Мес',
          data:'month',
          status:false
        },
      ]
    }
  },
  methods:{
    initRealtySlider() {
      this.realtySlider = noUiSlider.create(this.$refs.mortgagePrice, {
        start: [this.start],
        connect: 'lower',
        step: this.stepInput,
        initial: this.stgMin,
        range: {
          min: this.stgMin,
          max: this.stgMax
        },
      });
      this.realtySlider.on('start', (val,handle) => {

      });
      this.realtySlider.on('update', (val,handle) => {
        this.input_salary = false
        this.dataField = parseInt(val[handle])
      });

      this.realtySlider.on('set', (val,handle) => {
        this.input_salary = false
        this.dataField = parseInt(val[handle])
        if (this.dataFieldForCalculation===parseInt(val[handle])) {
          setTimeout(()=>{
            Storage.dispatch('ActionFinalWindow',false)
          },300)
        }
        this.dataFieldForCalculation = parseInt(val[handle])

      });
      this.realtySlider.on('end', (val,handle) => {
        // if (this.dataFieldForCalculation===parseInt(val[handle])) {
        //   setTimeout(()=>{
        //     Storage.dispatch('ActionFinalWindow',false)
        //   },300)
        // }
        // this.dataFieldForCalculation = parseInt(val[handle])

      });
    },
    inputFocus(el){
      const element = el.currentTarget
      element.querySelector('input').focus()
    },
    //Ввод значения пользователем
    inputField(event){
      onlyNumbers(event)
      const element = event.currentTarget
      let value = element.value
      value = parseInt(value.replace(/\s/g, ''));
      if(event.keyCode == 13){
        const parent = element.closest('.js--number-cost-pr')
        let value = parent.querySelector('input').value
        value = parseInt(value.replace(/\s/g, ''));
        // this.realtySlider.set(value);
      }
      if(value>this.stgMax){
        event.preventDefault();
      }
    },

    inputValue(el){
      const element = el.currentTarget;
      let value = element.value
      value = parseInt(value.replace(/\s/g, ''));



      if(!isNaN(value)&&value<=parseInt(this.stgMax)&&value>=parseInt(this.stgMin)){
        this.realtySlider.set(value);
        Storage.dispatch('ActionTimeOldCredit',parseInt(value))
      }

      if(value>this.stgMax)  {
        this.dataFieldForCalculation = this.stgMax
        this.realtySlider.set(this.stgMax);
        Storage.dispatch('ActionTimeOldCredit',parseInt(this.stgMax))
      }
      else if(value<this.stgMin){
        this.dataFieldForCalculation = this.stgMin
        this.realtySlider.set(this.stgMin);
        Storage.dispatch('ActionTimeOldCredit',parseInt(this.stgMin))
      }
    },
    inputPast(el){
      const element = el.currentTarget;
      let element_val = (el.clipboardData || window.clipboardData).getData('text');
      if ( element_val.search(/[^0-9]/g) != -1 ) {
        el.preventDefault();
      }
    },
    inpRemoveMark(el){
      const element = el.currentTarget
      if(element.value==0||element.value=='0 %'){
        element.value=''
      }
      else if(element.value.includes(' лет')||element.value.includes(' год')){
        element.value=parseInt(element.value.replace(/\s/g, ''))
      }
    },
    moveAnotherElement(el) {
      const element = el.currentTarget;
      if (element.value==='') {
        element.value = this.stgMin;
        this.realtySlider.set(this.stgMin);
        Storage.dispatch('ActionTimeOldCredit',this.stgMin)

      }
    },

    openList(el){
      const item = el.currentTarget;
      const parent = item.closest('.js--wrapper-select');
      const container = parent.querySelector('.js--list-wrapper');

      if (parent.classList.contains('active')) {
        parent.classList.remove('active');
        container.style.maxHeight = 0;
      } else {
        parent.classList.add('active');
        container.style.maxHeight = `${container.scrollHeight}px`;
      }
    },
    periodSelection(el){
      const element = el.currentTarget
      const type = element.getAttribute('for-type')
      const value = element.textContent
      const data = element.getAttribute('data-period')
      const parent = element.closest('.js--wrapper-select')
      const value_input = parent.querySelector('input.property-calculator__value').value
      const container = parent.querySelector('.js--list-wrapper');
      const main_container = element.closest('.js--container-loan-time')
      parent.querySelector('.js--selected-value').textContent = value;
      parent.classList.remove('active');
      container.style.maxHeight = 0;


      if(data==='year'){
        this.type_period[0].status=true
        this.type_period[1].status=false
        this.stgMin=1
        this.stgMax=30
      }
      else if(data==='month'){
        this.type_period[1].status=true
        this.type_period[0].status=false
        this.stgMin=1
        this.stgMax=360
      }
      if(value_input>this.stgMax){
        this.dataField=this.stgMax
      }
      this.realtySlider.updateOptions({
        range: {
          min: this.stgMin,
          max: this.stgMax
        }
      });

      Storage.dispatch('ActionTypePeriodOldCredit',data)
      Storage.dispatch('ActionTimeOldCredit',this.dataField)

    },


    calculationPageLoad(){

      Storage.dispatch('ActionTimeOldCredit',parseInt(this.dataFieldForCalculation))
    },

    //  Склонение
    declOfNum(n, text_forms) {
      n = Math.abs(n) % 100;
      var n1 = n % 10;
      if (n > 10 && n < 20) { return text_forms[2]; }
      if (n1 > 1 && n1 < 5) { return text_forms[1]; }
      if (n1 == 1) { return text_forms[0]; }
      return text_forms[2];
    }
  },
  mounted(){
    this.initRealtySlider()
    Storage.dispatch('ActionTimeOldCredit',parseInt(this.dataField))

  },
  computed:{

  },
  watch:{
    dataField(){
      // const elem = document.querySelector('.property-calculator__final-preload')
      // if (elem){
      //   elem.setAttribute('style','display:block;')
      // }
      Storage.dispatch('ActionFinalWindow',true)

    },
    dataFieldForCalculation(){
      this.calculationPageLoad()
    }
  },
  created(){
  },
  components:{}
};
</script>
<style scoped>
</style>
