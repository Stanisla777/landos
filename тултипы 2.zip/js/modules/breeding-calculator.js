function maxLength() {
  // eslint-disable-next-line camelcase
  const array_input = document.querySelectorAll('.js--chat-text');
  // eslint-disable-next-line no-restricted-syntax,camelcase
  for (const item of array_input) {
    item.oninput = () => {
      if (item.value.length === 300) {
        item.closest('.textarea').classList.add('textarea_error');
        // eslint-disable-next-line no-empty
      } else {
        item.closest('.textarea').classList.remove('textarea_error');
      }
    };
  }
}
function callModallField() {
  // eslint-disable-next-line camelcase
  const array_btn = document.querySelectorAll('.js--call-game-tak');
  // eslint-disable-next-line no-restricted-syntax,camelcase
  for (const item of array_btn) {
    item.addEventListener('click', () => {
      const attrib = item.getAttribute('data-modal');
      const modal = document.querySelector(`#${attrib}`);
      if (modal) {
        modal.classList.add('open');
      }
      // eslint-disable-next-line eqeqeq
      if (attrib === 'modal-for-polls') {
        document.body.classList.add('body-modal');
      }
    });
  }
}
function callMarathonModallField() {
  // eslint-disable-next-line camelcase
  const array_btn = document.querySelectorAll('.js--call-marathon-modal-offer');
  // eslint-disable-next-line no-restricted-syntax,camelcase
  for (const item of array_btn) {
    item.addEventListener('click', () => {
      const attrib = item.getAttribute('data-modal');
      const modal = document.querySelector(`#${attrib}`);
      if (modal) {
        modal.classList.add('open');
      }
      // eslint-disable-next-line eqeqeq
      if (attrib === 'modal-for-marathon-polls') {
        document.body.classList.add('body-modal');
      }
    });
  }
}
function scrollCallModallField() {
  // eslint-disable-next-line no-unused-vars
  let count = 0;
  let showScrollTop;
  const elementID = document.querySelector('.js--call-poll-on-scroll');
  if (elementID) {
    // eslint-disable-next-line prefer-const
    showScrollTop = () => {
      const currentScrollPosition = window.pageYOffset;
      const elementOffsetTop = elementID.offsetTop;

      if (elementID && currentScrollPosition > elementOffsetTop) {
        if (count === 0) {
          const attrib = elementID.getAttribute('data-modal');
          const modal = document.querySelector(`#${attrib}`);
          if (modal) {
            modal.classList.add('open');
          }
          // eslint-disable-next-line eqeqeq
          if (attrib === 'modal-for-polls') {
            document.body.classList.add('body-modal');
          }
          count = 1;
        } else {
          return false;
        }
        // eslint-disable-next-line no-empty
      }
    };
    window.addEventListener('scroll', showScrollTop);
  }
}
function closeModalForPolls() {
  // eslint-disable-next-line camelcase
  const btn_close = document.querySelectorAll('.js--modal-for-polls-closer');
  // eslint-disable-next-line no-restricted-syntax,camelcase
  for (const item of btn_close) {
    // alert();
    item.onclick = () => {
      item.closest('.modal-for-polls').classList.remove('open');
      document.body.classList.remove('body-modal');
    };
  }
}
export default function breedingCalculator() {
  // eslint-disable-next-line camelcase
  const array_icon = document.querySelectorAll('.js--title-icon');
  // eslint-disable-next-line no-restricted-syntax,camelcase
  for (const item of array_icon) {
    // eslint-disable-next-line camelcase
    const pop_up = item.closest('.calculator-preview__title').querySelector('.calculator-preview__pop-up');
    const parent = item.closest('.calculator-preview__item');
    item.onmouseover = () => {
      item.closest('.calculator-preview__title').querySelector('.calculator-preview__pop-up').classList.add('active');
    };
    pop_up.onmouseout = () => {
      item.closest('.calculator-preview__title').querySelector('.calculator-preview__pop-up').classList.remove('active');
    };
    parent.onmouseleave = () => {
      item.closest('.calculator-preview__title').querySelector('.calculator-preview__pop-up').classList.remove('active');
    };
  }
  maxLength();
  callModallField();
  callMarathonModallField();
  scrollCallModallField();
  closeModalForPolls();
}
