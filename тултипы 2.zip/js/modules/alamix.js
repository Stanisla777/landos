/* eslint-disable */
import Vue from 'vue';
import TestN from './test-n/TestN.vue';
export default function alamix() {
  const h1_title = document.querySelector('.js--h1')
  const wrap = document.querySelector('.js--container-alamix')
  var test_dual= '{"images": [], "colorTheme": "black", "title": "О двух городах", "end_text": "<p>«По́весть о двух города́х» — изданный в 1859 году исторический роман Чарльза Диккенса о временах Французской революции.<a href=\\"https://xn-h1alcedd.xnd1aqf.xn-p1ai/catalog/selskaya-ipoteka/\\"></a></p>", "end_title": "", "name": "my_poll_yes", "taglist": [{ "id": "dark", "title": "Тёмно-синее" }, { "id": "white", "title": "Белое" }, { "id": "gray", "title": "Серое" }], "answerlist": [{ "id": "", "title": "Выберите ответ" }, { "id": "yes", "title": "Да" }, { "id": "no", "title": "Нет" }], "description": "<p>Кто написал \\"Повесть о двух городах\\"?</p>", "settings": [], "layout": "0,0", "options":{ "btn_no": "Диккенс", "btn_yes": "Моэм", "correctAnswer": false },"typeOfTest": "dual"}'
  h1_title.onclick = () =>{
    const Test = document.createElement('div');
    Test.classList.add('test-n-wrap')
    Test.classList.add('js-test-n')
    Test.id=`test-n-8`
    const Polls = document.createElement('test-n');
    Polls.setAttribute('param',test_dual)
    Polls.setAttribute('param',test_dual)

    Test.prepend(Polls)
    wrap.prepend(Test)
    new Vue({
      el: `#test-n-8`,
      components: {
        'test-n': TestN,
      }
    });
  }
}
