<template lang="pug">
  .calc-tax-deduc-new__block.mobile-padding.grey.js-scroll
    template
      pre-load
    template
      final-calc

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import ToolTip from './v-component-modal-tooltip.vue';
import FinalCalc from './v-component-final-result.vue';
import ChartDebtInterest from './v-component-chart-debt-to-interest.vue';
import PaymentList from './v-component-payment-list.vue';
import PreLoad from './v-component-preload.vue';
export default {
  name: 'v-component-final-result',
  data(){
    return {

    }
  },
  methods:{

  },
  mounted(){
  },
  computed:{
  //  Сюда помещаются в том числе GETTTERS
    arr_data_small_debt(){
      return  Storage.getters.ARRDATASMALLDEBT
    },

  },

  watch:{

  },
  components:{
    ToolTip,
    FinalCalc,
    PaymentList,
    ChartDebtInterest,
    PreLoad
  },
  created(){
  //  Тут помещаюстя Шина событий
  }
};
</script>
<style scoped>
</style>
