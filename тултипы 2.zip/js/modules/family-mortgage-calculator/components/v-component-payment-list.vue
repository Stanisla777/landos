<template lang="pug">
  .calc-tax-deduc-new__block.mobile-padding.mor-rep-calculators__block-schedule.grey(
    v-if="shedule.length>0"
  )
    .calc-tax-deduc-new__container-title
      h3.calc-tax-deduc-new__block-title.big График платежей
    .calc-tax-deduc-new__payment-schedule.mor-rep-calculators__payment-schedule
      .calc-tax-deduc-new__payment-schedule-row-container.header-row
        .calc-tax-deduc-new__payment-schedule-row.thead
          .calc-tax-deduc-new__payment-schedule-col
            p №
          .calc-tax-deduc-new__payment-schedule-col
            p Месяц и год платежа
          .calc-tax-deduc-new__payment-schedule-col
            p Задолженность
          .calc-tax-deduc-new__payment-schedule-col
            p Погашение процентов
          .calc-tax-deduc-new__payment-schedule-col
            p Погашение основного долга
          .calc-tax-deduc-new__payment-schedule-col
            p Сумма платежа

      .calc-tax-deduc-new__payment-schedule-tbody
        .calc-tax-deduc-new__payment-schedule-row-container(
          v-for='(item,index) in shedule' :key="index"
        )
          .calc-tax-deduc-new__payment-schedule-row
            .calc-tax-deduc-new__payment-schedule-col
              p {{index+1}}
            .calc-tax-deduc-new__payment-schedule-col
              p {{item.nameMonth}}, {{item.year}}
            .calc-tax-deduc-new__payment-schedule-col
              p {{item.remainingBalance | format_decimal}} ₽

            .calc-tax-deduc-new__payment-schedule-col
              p {{item.interest | format_decimal}} ₽
            .calc-tax-deduc-new__payment-schedule-col
              p {{item.principal | format_decimal}} ₽
            .calc-tax-deduc-new__payment-schedule-col
              p {{item.payment | format_decimal}}  ₽

    .mor-rep-calculators__shedule-footer-share
      //.mor-rep-calculators__shedule-footer-share-item-programm-hover.mor-rep-calculators__shedule-footer-share-item-share(v-if="can_share===1&&answerLink!==null")
      .mor-rep-calculators__shedule-footer-share-item.mor-rep-calculators__shedule-footer-share-item-share(
        v-if="can_share===1&&answerLink!==null"
      )
        .btn_s.transparent_black_border.hover-green.btn-icon-share.js--calc-shedule-footer-share(

        ) Отправить расчёт


        .select-list__selection-window.mor-rep-calculators__selection-window-share.modal-special-styles(ref="TooltipShare")
          template
            component-payment-list-soc
    .mor-rep-calculators__input-error.mor-rep-calculators__after-sand-error(v-show="description_after_sand!==null") {{description_after_sand}}


</template>
<script>
import Vue from 'vue';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import numberFormatting from '../mixin/numberFormatting.js';
import ComponentPaymentListSoc from '../components/v-component-payment-list-soc.vue';

export default {
  name: 'v-component-payment-list',
  mixins: [numberFormatting],
  props:[],
  data(){
    return {
      description_after_sand_mail:null,
    }
  },
  methods:{


  },
  mounted(){

  },
  filters:{
  },
  computed:{
    shedule(){
      return Storage.getters.SHEDULE
    },
    description_after_sand(){
      return Storage.getters.DESCRIPTIONAFTERSAND
    },

  },
  watch:{
  },
  created(){

  },
  components:{
    ComponentPaymentListSoc
  }
};
</script>
<style scoped>
</style>
