<template lang="pug">
  .calc-tax-deduc-new__container-block.mor-rep-calculators__parent-tooltip-mobile.js--tooltip-parent
    .calc-tax-deduc-new__row-title-main-container(
      v-if="hasTooltipInfo && (tooltipSize === '' || tooltipSize === 'small')"
    )
      .calc-tax-deduc-new__row-title-container
        p.calc-tax-deduc-new__row-title Стоимость недвижимости, ₽
        span.content-note.desctop.content-note__center.js--content-note
          span.content-note__text {{ tooltipInfo }}
        span.content-note.mobile(@click="openTooltipMobile" v-if="tooltipInfo")
      div(v-if="tooltipInfo")
        .select__background.modal-special-background(@click="closeTooltipMobile")
        .select-list__selection-window.modal-special-styles.js--openlist-body
          .select-list__head
            p Стоимость недвижимости, ₽
            .select-list__head-close(@click="closeTooltipMobile")
              svg(width="10" height="10" viewBox="0 0 10 10" fill="none")
                path(d="M0.209 0.209C0.488 -0.07 0.94 -0.07 1.219 0.209L5 3.989L8.781 0.209C9.06 -0.07 9.512 -0.07 9.791 0.209C10.07 0.488 10.07 0.94 9.791 1.219L6.01 5L9.791 8.781C10.07 9.06 10.07 9.512 9.791 9.791C9.512 10.07 9.06 10.07 8.781 9.791L5 6.01L1.219 9.791C0.94 10.07 0.488 10.07 0.209 9.791C-0.07 9.512 -0.07 9.06 0.209 8.781L3.99 5L0.209 1.219C-0.07 0.94 -0.07 0.488 0.209 0.209Z", fill="#252628")
          .select-list__wr-search.mor-rep-calculators__wr-search
            p {{ tooltipInfo }}
    .calc-tax-deduc-new__row-title-main-container(
      v-else-if="hasTooltipInfo && tooltipSize === 'big'"
    )
      .calc-tax-deduc-new__row-title-container
        p.calc-tax-deduc-new__row-title Стоимость недвижимости, ₽
        .content-note(@click="openModal", :data-tooltip="tooltipName || ''")
    .calc-tax-deduc-new__row-title-main-container(v-else)
      .calc-tax-deduc-new__row-title-container
        p.calc-tax-deduc-new__row-title Стоимость недвижимости, ₽
    .calc-tax-deduc-new__col-input.js--number-debt.js--tex-deduc-input
      input(
        type="text"
        inputmode="numeric"
        ref="realtyInput"
        @input="onInput"
        @blur="onBlur"
        @paste="onPaste"
      )
      .range-input__slider(ref="mortgagePrice")
    .calc-tax-deduc-new__wr-range
      p {{ formatMillionsFloor(stgMin) }} млн
      p {{ formatMillions((stgMin + stgMax) / 2) }} млн
      p {{ formatMillions(stgMax) }} млн
</template>

<script>
import noUiSlider from 'nouislider';
import Storage from '../development-tools/state.vue';
import numberFormatting from '../mixin/numberFormatting.js';

export default {
  name: 'v-credit-amount',
  mixins: [numberFormatting],
  data() {
    return {
      realtySlider: null,
      dataField: '',
      dataFieldForCalculation: 0,
      stepApartment: 1,
      stgMin: 625000,
      stgMax: 60000000,
      start: 6000000,
      isTyping: false,
      rawInputValue: ''
    };
  },
  computed: {
    transfer_tooltip() {
      return Storage.getters.TRANSFERTOOLTIP || null;
    },
    tooltipData() {
      return this.transfer_tooltip && this.transfer_tooltip['cost-property']
        ? this.transfer_tooltip['cost-property']
        : null;
    },
    hasTooltipInfo() {
      const data = this.tooltipData;
      return data && data.info && data.info !== '';
    },
    tooltipInfo() {
      return this.tooltipData ? this.tooltipData.info : '';
    },
    tooltipSize() {
      return this.tooltipData ? this.tooltipData.size : '';
    },
    tooltipName() {
      return this.tooltipData ? this.tooltipData.name : '';
    },
    answers() {
      return Storage.getters.ANSWERS || null;
    }
  },
  methods: {
    onInput(e) {
      const el = e.target;
      this.isTyping = true;
      this.dataField = el.value;
      this.rawInputValue = el.value.replace(/\D/g, '');
      this.numberFormattingThousandths(this.stgMax, e);
    },
    onBlur(e) {
      const el = e.target;
      this.isTyping = false;
      let value = parseInt(this.rawInputValue || el.value.replace(/\s/g, ''), 10) || this.stgMin;

      if (value < this.stgMin) value = this.stgMin;
      if (value > this.stgMax) value = this.stgMax;

      el.value = new Intl.NumberFormat('ru-RU').format(value);
      this.dataField = el.value;
      this.dataFieldForCalculation = value;

      this.realtySlider.set(value);
      Storage.dispatch('ActionCostProperty', value);
    },
    onPaste(e) {
      const data = (e.clipboardData || window.clipboardData).getData('text');
      if (!/^\d+$/.test(data)) {
        e.preventDefault();
      }
    },
    initRealtySlider() {
      this.realtySlider = noUiSlider.create(this.$refs.mortgagePrice, {
        start: [this.start],
        connect: 'lower',
        step: this.stepApartment,
        range: {
          min: this.stgMin,
          max: this.stgMax
        }
      });

      this.realtySlider.on('update', (values, handle) => {
        const value = Math.round(values[handle]);
        this.$refs.realtyInput.value = new Intl.NumberFormat('ru-RU').format(value);
        this.dataField = this.$refs.realtyInput.value;
      });

      this.realtySlider.on('set', (values, handle) => {
        const value = Math.round(values[handle]);
        this.dataFieldForCalculation = value;
        Storage.dispatch('ActionCostProperty', value);
      });

      this.realtySlider.on('start', () => {
        this.$refs.realtyInput.closest('.js--tex-deduc-input').classList.add('input-focus');
      });

      this.realtySlider.on('end', () => {
        this.$refs.realtyInput.closest('.js--tex-deduc-input').classList.remove('input-focus');
      });
    },
    formatMillions(val) {
      return (val / 1000000).toFixed(0).replace('.',',');
    },
    formatMillionsFloor(val) {
      return (Math.floor(val / 100000) / 10).toString().replace('.',',');
    }
  },
  mounted() {
    this.initRealtySlider();

    if (this.answers) {
      const val = parseInt(this.answers.loanAmount) || this.stgMin;
      this.realtySlider.set(val);
      Storage.dispatch('ActionCostProperty', val);
    } else {
      this.realtySlider.set(this.start);
    }
  },
  watch: {
    stgMax(newVal) {
      if (this.realtySlider && this.realtySlider.updateOptions) {
        this.realtySlider.updateOptions({
          range: { min: this.stgMin, max: newVal }
        });
        const currentValue = parseInt(this.realtySlider.get());
        if (currentValue > newVal) {
          this.realtySlider.set(newVal);
        }
      }
    }
  },
  beforeDestroy() {
    if (this.realtySlider && this.realtySlider.destroy) {
      this.realtySlider.destroy();
    }
  }
};
</script>
