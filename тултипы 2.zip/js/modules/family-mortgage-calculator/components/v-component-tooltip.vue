<template lang="pug">
  .calc-tax-deduc-new__result-col.mor-rep-calculators__parent-tooltip-mobile.js--tooltip-parent(v-if="shedule.length > 0")
    //- Основной контейнер заголовка
    .calc-tax-deduc-new__row-title-main-container(v-if="transfer_tooltip && transfer_tooltip[tooltip]")
      .calc-tax-deduc-new__result-label.calc-tax-deduc-new__row-title-container
        p {{titleText}}

        //- Вариант для маленького тултипа или мобильной версии
        template(v-if="!transfer_tooltip[tooltip]['size'] || transfer_tooltip[tooltip]['size'] === 'small'")
          span.content-note.desctop.content-note__center.js--content-note
            span.content-note__text {{ transfer_tooltip[tooltip]["info"] }}
          span.content-note.mobile(
            v-if="transfer_tooltip[tooltip]['info'] !== ''"
            @click="openTooltipMobile"
          )

        //- Вариант для большого тултипа, КОТОРЫЙ МОЖЕТ ВЫЗЫВАТЬСЯ ЛИБО ПО КЛИКУ, ЛИБО ПО НАВЕДЕНИЮ
        template(v-else-if="transfer_tooltip[tooltip]['size'] === 'big'")
          .content-note(
            v-if="!transfer_tooltip[tooltip].hasOwnProperty('show') || transfer_tooltip[tooltip]['show'] === 'clickEl'"
            @click="openModal"
            :data-tooltip="transfer_tooltip[tooltip]['name'] || ''"
          )
          .content-note(
            v-else-if="transfer_tooltip[tooltip]['show'] === 'mouseoverEl'"
            @mouseover="openModal"
            :data-tooltip="transfer_tooltip[tooltip]['name'] || ''"
          )

      //- Модальное окно для мобильной версии
      div(v-if="transfer_tooltip[tooltip]['info'] !== '' && (!transfer_tooltip[tooltip]['size'] || transfer_tooltip[tooltip]['size'] === 'small')")
        .select__background.modal-special-background(@click="closeTooltipMobile")
        .select-list__selection-window.modal-special-styles.js--openlist-body
          .select-list__head
            p {{titleText}}
            .select-list__head-close(@click="closeTooltipMobile")
              svg(width='10', height='10', viewbox='0 0 10 10', fill='none', xmlns='http://www.w3.org/2000/svg')
                path(fill-rule='evenodd', clip-rule='evenodd', d='M0.209209 0.209209C0.488155 -0.0697365 0.940416 -0.0697365 1.21936 0.209209L5 3.98985L8.78064 0.209209C9.05958 -0.0697365 9.51184 -0.0697365 9.79079 0.209209C10.0697 0.488155 10.0697 0.940416 9.79079 1.21936L6.01015 5L9.79079 8.78064C10.0697 9.05958 10.0697 9.51184 9.79079 9.79079C9.51184 10.0697 9.05958 10.0697 8.78064 9.79079L5 6.01015L1.21936 9.79079C0.940416 10.0697 0.488155 10.0697 0.209209 9.79079C-0.0697365 9.51184 -0.0697365 9.05958 0.209209 8.78064L3.98985 5L0.209209 1.21936C-0.0697365 0.940416 -0.0697365 0.488155 0.209209 0.209209Z', fill='#252628')
          .select-list__wr-search.mor-rep-calculators__wr-search
            p {{ transfer_tooltip[tooltip]["info"] }}

    //- Заголовок по умолчанию (если нет данных для тултипа)
    .calc-tax-deduc-new__row-title-main-container(v-else)
      .calc-tax-deduc-new__result-label.calc-tax-deduc-new__row-title-container
        p.calc-tax-deduc-new__row-title {{titleText}}


    .calc-tax-deduc-new__result-container-value
      p.calc-tax-deduc-new__result-value(
        v-if="tooltip==='data-interest-rate'"
      ) {{ infoValue.toString().replace(".",",")}} %
      p.calc-tax-deduc-new__result-value(
        v-else
      ) {{ infoValue | format_decimal }} ₽



</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import numberFormatting from '../mixin/numberFormatting.js';

export default {
  name: 'v-tooltip',
  mixins: [numberFormatting],
  props:{
    tooltip:{
      type: String,
      required:true
    },
    infoValue:{
      type: Number,
      required:true
    },
    titleText:{
      type: String,
      default:''
    },


  },
  data(){
    return {

    }
  },
  methods:{

  },
  mounted(){

  },
  computed:{
    transfer_tooltip(){
      return Storage.getters.TRANSFERTOOLTIP
    },
    loanAmount(){
      return Storage.getters.LOANAMOUNT
    },
    annualInterestRate(){
      return Storage.getters.ANNUALINTERESTRATE
    },
    shedule(){
      return Storage.getters.SHEDULE
    },
    debt_interest(){
      return Storage.getters.DEBTINTEREST
    },
    total_tax_deduction(){
      return Storage.getters.TOTALTAXDEDUCTION
    },
    required_income(){
      return Storage.getters.REQUIREDINCOME
    },


  },
  watch:{

  },
  components:{},
  created() {

  }
};
</script>
<style scoped>
</style>
