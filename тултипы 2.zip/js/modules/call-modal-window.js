function closeModalWindow() {
  // eslint-disable-next-line camelcase
  const modal_btn_close = document.querySelectorAll('.js--modal-closer');
  // eslint-disable-next-line camelcase,no-restricted-syntax
  for (const item_btn of modal_btn_close) {
    const parent = item_btn.closest('.js--window-modal');
    item_btn.onclick = () => {
      parent.classList.remove('open');
    };
  }
}
function closeModalWindowWorkspace() {
  // eslint-disable-next-line camelcase
  const modal_workspace = document.querySelector('.js--window-modal');
  // eslint-disable-next-line camelcase
  if (modal_workspace) {
    modal_workspace.onclick = () => {
      modal_workspace.classList.remove('open');
    };
  }
}
export default function callModalWindow() {
  const btn = document.querySelectorAll('.js--call-modal-window');
  // eslint-disable-next-line no-restricted-syntax,camelcase
  for (const item_btn of btn) {
    item_btn.onclick = (e) => {
      e.preventDefault();
      // eslint-disable-next-line no-unused-vars
      const data = item_btn.getAttribute('data-topic');
      // eslint-disable-next-line camelcase
      const window_modal = document.querySelector(`.js--window-modal[data-topic=${data}]`);
      // eslint-disable-next-line camelcase
      if (window_modal) {
        window_modal.classList.add('open');
      }
    };
  }
  closeModalWindow();
  closeModalWindowWorkspace();
}
