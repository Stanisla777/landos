function textValidator(fld) {
  const field = fld;

  field.addEventListener('input', () => {
    if (field.value[0] === ' ') {
      field.value = '';
    }
  });
}

function CommentsFormValidation() {
  const form = document.querySelector('.js--form-comments');
  if (form) {
    const name = form.querySelector('.js--form-comments-title');
    const text = form.querySelector('.js--form-comments-text');
    const check = form.querySelector('.js--form-comments-check');

    textValidator(text);
    form.addEventListener('submit', (event) => {
      const errors = {
        name: false,
        text: false,
        check: false
      };

      if (text.value.length > 300) {
        errors.text = true;
        text.nextElementSibling.innerHTML = 'Максимальное количество символов — 300';
        text.nextElementSibling.classList.add('textarea_error');
      } else if (text.value.length === 0) {
        errors.text = true;
        text.nextElementSibling.innerHTML = 'Это поле обязательно для заполнения';
        text.nextElementSibling.classList.add('textarea_error');
      } else {
        // eslint-disable-next-line no-empty,no-lonely-if
        if (text.nextElementSibling !== null) {
          text.nextElementSibling.classList.remove('textarea_error');
        }
      }

      if (name.value.length > 30) {
        errors.name = true;
        name.nextElementSibling.innerHTML = 'Максимальное количество символов — 30';
        name.nextElementSibling.classList.add('input-text_error');
      } else if (name.value.length === 0) {
        errors.name = true;
        name.nextElementSibling.innerHTML = 'Это поле обязательно для заполнения';
        name.nextElementSibling.classList.add('input-text_error');
      } else {
        name.nextElementSibling.classList.remove('input-text_error');
      }

      if (!(check.checked)) {
        errors.check = true;
        document.querySelector('.form-comments__checkbox-label').nextElementSibling.classList.add('checkbox_error');
      } else {
        document.querySelector('.form-comments__checkbox-label').nextElementSibling.classList.remove('checkbox_error');
      }

      if (errors.name || errors.check || errors.text) {
        event.preventDefault();
      }
    });
  }
}
function CommentsFormValidationAnswer() {
  const form = document.querySelectorAll('.js--comments__item-form-answer');
  if (form) {
    form.forEach((item) => {
      const name = item.querySelector('.js--form-comments-title');
      const text = item.querySelector('.js--form-comments-text');
      const check = item.querySelector('.js--form-comments-check');

      textValidator(text);
      item.addEventListener('submit', (event) => {
        const errors = {
          name: false,
          text: false,
          check: false
        };

        if (text.value.length > 300) {
          errors.text = true;
          text.nextElementSibling.innerHTML = 'Максимальное количество символов — 300';
          text.nextElementSibling.classList.add('textarea_error');
        } else if (text.value.length === 0) {
          errors.text = true;
          text.nextElementSibling.innerHTML = 'Это поле обязательно для заполнения';
          text.nextElementSibling.classList.add('textarea_error');
        } else {
          text.nextElementSibling.classList.remove('textarea_error');
        }

        if (name.value.length > 30) {
          errors.name = true;
          name.nextElementSibling.innerHTML = 'Максимальное количество символов — 30';
          name.nextElementSibling.classList.add('input-text_error');
        } else if (name.value.length === 0) {
          errors.name = true;
          name.nextElementSibling.innerHTML = 'Это поле обязательно для заполнения';
          name.nextElementSibling.classList.add('input-text_error');
        } else {
          name.nextElementSibling.classList.remove('input-text_error');
        }

        if (!(check.checked)) {
          errors.check = true;
          item.querySelector('.checkbox').classList.add('checkbox_error');
        } else {
          item.querySelector('.checkbox').classList.remove('checkbox_error');
        }

        if (errors.name || errors.check || errors.text) {
          event.preventDefault();
        }
      });
    });
  }
}
function CommentsFormValidationEdit() {
  const form = document.querySelectorAll('.js--comments__item-form-edit');
  if (form) {
    form.forEach((item) => {
      const text = item.querySelector('.js--form-comments-text');

      item.addEventListener('submit', (event) => {
        const errors = {
          text: false,
        };
        if (text.value.length > 300) {
          errors.text = true;
          // eslint-disable-next-line no-param-reassign
          item.querySelector('.textarea').innerHTML = 'Максимальное количество символов — 300';
          item.querySelector('.textarea').classList.add('textarea_error');
        } else if (text.value.length === 0) {
          errors.text = true;
          // eslint-disable-next-line no-param-reassign
          item.querySelector('.textarea').innerHTML = 'Это поле обязательно для заполнения';
          item.querySelector('.textarea').classList.add('textarea_error');
        } else {
          item.querySelector('.textarea').classList.remove('textarea_error');
        }
        if (errors.text) {
          event.preventDefault();
        }
      });
    });
  }
}
function CommentsFormValidationComplain() {
  const form = document.querySelector('.js--comments__item-form-complain');
  if (form) {
    const select = form.querySelector('.js--form-comments-select');

    form.addEventListener('submit', (event) => {
      const errors = {
        select: false,
      };
      if (select.value.length === 0) {
        errors.select = true;
        form.querySelector('.input-text').innerHTML = 'Выберите категорию';
        form.querySelector('.input-text').classList.add('input-text_error');
      } else {
        form.querySelector('.input-text').classList.remove('input-text_error');
      }
      if (errors.select) {
        event.preventDefault();
      }
    });
  }
}

export default function CommentsFormValidationInit() {
  CommentsFormValidationComplain();
  CommentsFormValidationEdit();
  CommentsFormValidationAnswer();
  CommentsFormValidation();
}
