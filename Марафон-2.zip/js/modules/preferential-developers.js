export default function openUlList() {
  const btn = document.querySelector('#btn-ul-list');
  const list = document.querySelector('.preferential-developers__block-hidden-desc');

  if (!btn) { return false; }

  btn.addEventListener('click', () => {
    list.classList.toggle('open');
  });
}
