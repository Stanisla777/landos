<template lang="pug">
  .test-a__container(
    ref="test_container"
  )
    .test-a__body.js--row-img-radio(ref="BodyLabel")
      .test-n-row-img-radio.test-n-row-radio
        label.test-n-multiple-choice__checkbox-wrap.test-n-just-checkbox__label.js--percent-row(
          v-for="(answer, index) in param_component.options"
          :key="index"
        )
          .test-n-radio-btn
            input(
              v-if="!time_end"
              :data-radio="answer.id"
              type="radio"
              :name="param_component.id"
              @change="changeVarint($event,param_component.id,answer.id)"
            )
            input(
              v-else
              :data-radio="answer.id"
              type="radio"
              :name="param_component.id"
              disabled
            )
            .test-n-radio-btn__icon(
              :class="time_end?'disabled':''"
            )
          p.test-n-percent__text {{answer.name}}

      .test-n-row-img
        .test-n-row-img-item(
          v-for="(answer, index) in param_component.options"
          :key="index"
          :data-radio="answer.id"
          @click="clickPicture"
        )
          .test-n-row-img-number
            p {{answer.id}}

          img(
            :src="answer.image"
          )
    template
      test-button(
        :modal='modal'
        :status_internet='status_internet'
        :btn_next='btn_next'
        :status_btn='status_btn'
        :btn_prev='btn_prev'
        :error_sand_variant='error_sand_variant'
        :error_sand_variant_text='error_sand_variant_text'
      )

</template>

<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import TestButton from './TestButton.vue';


export default {
  name: 'TextRadioImg',
  props: {
    param_component:Object,
    current_slide:Number,
    modal:Boolean
  },
  data() {
    return {
      btn_next:false,
      btn_prev:true,
      count:0,
      count_reach:0
    }
  },
  computed: {
    error_sand_variant() {
      return Storage.getters.ERRORSANDVARIANT;
    },
    error_sand_variant_text() {
      return Storage.getters.ERRORSANDVARIANTTEXT;
    },

    status_internet() {
      return Storage.getters.STATUSINTERNET;
    },
    status_btn() {
      return Storage.getters.STATUSBTN;
    },
    hint() {
      return Storage.getters.HINT;
    },
    time_end() {
      return Storage.getters.TIMEEND;
    }

  },
  methods: {
    clickPicture(e){
      const element = e.currentTarget;
      const data = element.getAttribute('data-radio')
      element.closest('.js--row-img-radio').querySelector(`input[data-radio="${data}"]`).click()
    },

    autoHeight() {
      if (document.documentElement.clientWidth < 470) {
        const parent = this.$refs.test_container.closest('.js--test-cont');
        const title_height = parent.querySelector('.test-a__question').offsetHeight;
        parent.querySelector('.test-a__container')
          .setAttribute('style', `min-height:calc(100vh - 32px - 26px - 24px - ${title_height}px - 40px)`);
      }
    },


    // btnNext(){
    //   this.count=0
    //   eventBus.$emit('eventbtnNext')
    // },


    fullnessCheck(){
      const array_label = this.$refs.BodyLabel.querySelectorAll('.js--percent-row input:checked');
      if(array_label.length!==0){
        this.btn_next=true
      }
    },


    changeVarint(elem,id_question,id_answer){
      const element = elem.currentTarget
      Storage.dispatch('ActionVariantRadio',[id_question,id_answer])
      this.btn_next=true

    },

  },
  created(){
    eventBus.$on('slideNextTransition',()=>{
      if(this.count===0){
        // this.fullnessCheck()
        this.count=1
      }
    })
    eventBus.$on('slidePrevTransition',()=>{
      if(this.count===0){
        // this.fullnessCheck()
        this.count=1
      }
    })
    eventBus.$on('slideReachBeginning',()=>{
        this.btn_prev=false
    })
    eventBus.$on('slideFromEdge',()=>{
      this.btn_prev=true
    })


  },
  mounted() {
  },
  updated() {
  },
  components: {
    TestButton
  }

}
</script>
