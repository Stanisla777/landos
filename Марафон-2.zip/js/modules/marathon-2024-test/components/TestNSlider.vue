<template lang="pug">
  .test-a__container.marathon-new-last__test-vue-slider(
    ref="test_container"
  )
    .test-a__body(
      ref="BodyLabel"
    )
      .test-n-slider__line
      .test-n-slider__line.right.js--slider-line-right
      .test-n-slider.test-a__slider(ref="ContainerSlider")
        //.test-n-slider__line
        vue-slider(
          v-model="answerValue"
          ref="slider"
          :marks="this.array_param"
          :max="maxValue"
          :min="minValue"
          :process="true"
          :tooltip="'none'"
          :dot-size="24"
          :dot-style="{ height: '24px', width: '24px' }"
          :label-style="{ marginTop: '45px' }"
          :height="4"
          :disabled="time_end?true:false"
          @drag-end="onPriceChange"
          @drag-start="onPriceChangeStart"

          contained
          included
          silent
        )
    template
      test-button(
        :modal='modal'
        :status_internet='status_internet'
        :btn_next='btn_next'
        :status_btn='status_btn'
        :btn_prev='btn_prev'
        :error_sand_variant='error_sand_variant'
        :error_sand_variant_text='error_sand_variant_text'
      )
</template>

<script>
import VueSlider from 'vue-slider-component';
import Storage from '../development-tools/state.vue';
import Vue from 'vue';
import eventBus from '../development-tools/eventBus.vue';
import TestButton from './TestButton.vue';

export default {
  name: 'TextNSlider',

  props: {
    param_component:Object,
    modal:Boolean
  },
  data() {
    return {
      answerValue: null,
      isAnswerValueCorrect: null,
      btn_next:true,
      btn_prev:true,
      count:0,
      count_slide:0,

      array_param:{}

    }
  },
  methods: {
    updateScreenWidth() {
      // const line = this.$refs.ContainerSlider.querySelector('.js--test-n-slider-line')
      // if (line) {
      //   const width = this.$refs.slider.$el.querySelector('.vue-slider-rail').offsetLeft
      //   line.style.width = (width + 25)+'px';
      // }

    },
    onPriceChange(val){
      const dot = this.$refs.slider.$el.querySelector('.vue-slider-dot')
      let index = this.$refs.slider.getIndex();
      console.log(this.param_component.options.length - 1 == index);
      const line = document.querySelectorAll('.js--slider-line-right')
      if(this.param_component.options.length -1 == index){
        // if (line) {
        //
        //
        // }
        for (let item of line) {
          // if (line) {
          setTimeout(()=>{
            item.classList.add('active')
          },200)
          // }
        }
      }
      else {

      }
    },
    onPriceChangeStart(val){
      let index = this.$refs.slider.getIndex();
      const line = document.querySelectorAll('.js--slider-line-right')

        if(this.param_component.options.length -1 == index){
          for (let item of line) {
          // if (line) {
            item.classList.remove('active')
          // }
        }
      }

    },

    //В этом компоненте миксин расчёт высоты не подключал, так тут ингдивидуально

    autoHeight() {
      if (document.documentElement.clientWidth < 470) {
        const parent = this.$refs.test_container.closest('.js--test-cont');
        const title_height = parent.querySelector('.test-a__question').offsetHeight;
        parent.querySelector('.test-a__container')
          .setAttribute('style', `min-height:calc(100vh - 32px - 26px - 24px - ${title_height}px - 65px)`);
      }
    },
    btnPrev(){
      this.count=0
      eventBus.$emit('eventbtnPrev')
    },
    fullnessCheck(){
      const array_label = this.$refs.BodyLabel.querySelectorAll('.js--percent-row input:checked');
      if(array_label.length!==0){
        this.btn_next=true
      }
    },
    /**
     * Проставляем класс active для лейбла выбранного значения, убираем у остальных
     */
    setActiveLabel() {
      const sliderEl = this.$refs.slider.$el;
      const labelEls = sliderEl.querySelectorAll('.vue-slider-mark-label');
      const param = this.array_param[this.answerValue]

      if (document.documentElement.clientWidth > 767) {
        labelEls.forEach((labelEl) => {
          labelEl.classList.remove('active');
          const text = labelEl.textContent
          if(text==param){
            labelEl.classList.add('active')
          }
        });
      }
      else if(document.documentElement.clientWidth <= 767){
        for(let i=0;i<labelEls.length;i++) {
          labelEls[0].textContent=param;
        }
      }


    },

    mobileActiveLabel(){
      const sliderEl = this.$refs.slider.$el;
      const labelEls = sliderEl.querySelectorAll('.vue-slider-mark-label');
      const param = this.array_param[this.answerValue]

    },
    checkAnswerValue() {
      this.isAnswerValueCorrect = this.answerValue === this.options.correctAnswer;
    },
    setDefault() {
      this.answerValue = null;
      this.isAnswerValueCorrect = null;
      this.$emit('valuesIsUnchosen');
    },
    /**
     * Подготавливает необходимые данные и вызывает событие для отправки
     */
    prepareDataForSend() {
      const data = {
        answerValue: this.answerValue,
        isAnswerValueCorrect: this.isAnswerValueCorrect
      };
      this.$emit('readyForDataSending', data);
    },

    dataTransformation(){
      for(let i = 0; i<this.param_component.options.length;i++){
        if (this.param_component.options[i].name) {
          Vue.set(this.array_param,this.param_component.options[i].id,this.param_component.options[i].name)
        }
      }
    }
  },
  watch: {
    answerValue() {
      this.setActiveLabel()
      Storage.dispatch('ActionVariantSlider',[this.param_component.id,this.answerValue])
    },
    current_slide(){
      const line = document.querySelectorAll('.js--slider-line-right')
      for (let item of line) {
        item.classList.remove('active')
      }
      this.dataTransformation();
      Storage.dispatch('ActionVariantSlider',[this.param_component.id,this.param_component.options[0].id])
    }

  },
  computed: {
    minValue() {
      return +Object.keys(this.array_param)[0]; // минимальное значение, первое значение из массива ответов
    },
    maxValue() {
      return +Object.keys(this.array_param).at(-1); // максимальное значение, первое значение из массива ответов
    },

    error_sand_variant() {
      return Storage.getters.ERRORSANDVARIANT;
    },
    error_sand_variant_text() {
      return Storage.getters.ERRORSANDVARIANTTEXT;
    },

    status_internet() {
      return Storage.getters.STATUSINTERNET;
    },
    status_btn() {
      return Storage.getters.STATUSBTN;
    },
    hint() {
      return Storage.getters.HINT;
    },
    time_end() {
      return Storage.getters.TIMEEND;
    },
    current_slide() {
      return Storage.getters.CURRENTSLIDE;
    },


  },
  mounted() {
    this.dataTransformation();
    // const dot = this.$refs.slider.$el.querySelector('.vue-slider-dot')
    // if (dot){
    //   dot.style.transform='translate(100%, -50%)'
    // }
    this.updateScreenWidth();
    window.addEventListener('resize', this.updateScreenWidth);
    Storage.dispatch('ActionVariantSlider',[this.param_component.id,this.param_component.options[0].id])
  },
  created(){
    eventBus.$on('slideReachBeginning',()=>{
      this.btn_prev=false
    })
    eventBus.$on('slideFromEdge',()=>{
      this.btn_prev=true
    })
  },

  updated() {

    //вот это старое закомментировано
    // if(this.count_slide===0){
    //   const label = this.$refs.slider.$el.querySelectorAll('.vue-slider-mark-label');
    //   label[0].classList.add('active')
    //   this.count_slide=1;
    // }

  },
  components: {
    VueSlider,
    TestButton
  },
}
</script>
