<template lang="pug">
  .test-n.polls__swiper-container.test-n__area-final-window.js--final-window-success(ref="finalWindow")
    .test-new__final-icon
      svg(width='48', height='48', viewbox='0 0 48 48', fill='none', xmlns='http://www.w3.org/2000/svg')
        path(fill-rule='evenodd', clip-rule='evenodd', d='M31.9378 6.42123C28.0968 4.71941 23.8055 4.29781 19.7039 5.21929C15.6022 6.14078 11.91 8.35599 9.17796 11.5346C6.44588 14.7131 4.82023 18.6847 4.54359 22.857C4.2669 27.0292 5.35394 31.1788 7.64266 34.6865C9.93137 38.1943 13.2991 40.8724 17.2435 42.3214C21.1879 43.7705 25.4978 43.9128 29.5302 42.7273C33.5627 41.5417 37.1017 39.0918 39.6195 35.7428C42.1373 32.3938 43.4989 28.3252 43.5013 24.1439V22.163C43.5013 20.9731 44.4713 20.0086 45.668 20.0086C46.8646 20.0086 47.8346 20.9731 47.8346 22.163V24.1451C47.8317 29.2556 46.1675 34.2296 43.0902 38.3228C40.0129 42.416 35.6874 45.4104 30.7589 46.8594C25.8304 48.3084 20.5628 48.1344 15.7418 46.3633C10.9208 44.5923 6.80474 41.319 4.00742 37.0318C1.21012 32.7445 -0.11853 27.6729 0.219632 22.5734C0.557788 17.474 2.54464 12.6198 5.88389 8.73494C9.22307 4.85004 13.7358 2.14255 18.7489 1.01628C23.762 -0.109985 29.0069 0.405298 33.7015 2.48529C34.7945 2.96957 35.2858 4.24325 34.7987 5.33014C34.3117 6.41697 33.0308 6.90547 31.9378 6.42123ZM47.1993 5.38514C48.0458 6.2261 48.0465 7.5902 47.2008 8.432L25.5342 29.9983C25.1279 30.4026 24.5767 30.6299 24.0019 30.6301C23.4271 30.6302 22.8757 30.4032 22.4692 29.9991L15.9692 23.5356C15.1231 22.6942 15.1231 21.3301 15.9692 20.4887C16.8154 19.6474 18.1872 19.6474 19.0334 20.4887L24.0006 25.4279L44.1352 5.38663C44.9809 4.54484 46.3527 4.54419 47.1993 5.38514Z', fill='#252628')



    .test-new__wr-title
      p.test-new__title.center <span class="highlighting">Поздравляем!</span>
      p.test-new__title.center Вы участвуете в розыгрыше призов

    .test-new__sub-title.center
      p Мы получили ваши данные и направили сертификат на почту. По окончании марафона все участники получат результаты тестирования, включая правильные и неправильные ответы

    .test-new__code-word.center
      p Кодовое слово для участников игры <a target="_blank" :href="marathon_vk_url">МыСчитаем</a>:
      p.js--instead-copyable(@click="copyLink") НЕДВИЖИМОСТЬ
    .test-new__take-points.center
      p Благодарим за прохождение теста и дарим вам бонусные баллы проекта «Другое дело». Заберите их, перейдя по кнопке ниже
    .test-new__take-points-wr-btn
      a(
        :href="marathon_page_url"
      ).btn_s.black.mobile-100 Смотреть рейтинг
      a(:href="marathon_vk_url" target="_blank").btn_s.transparent_black_border.mobile-100 Получить баллы
</template>
<script>
import Storage from '../development-tools/state.vue';
import numberFormatting from '../../family-mortgage-calculator/mixin/numberFormatting';
import copyLink from '../../vue-component-templates/copyLink';


let mask;
let maskMail;

export default {
  name: 'WindowSuccessfulSending',
  props:[],
  mixins: [copyLink],
  data(){
    return {


    }
  },
  methods: {},
  computed: {
    status_internet() {
      return Storage.getters.STATUSINTERNET;
    },
    marathon_page_url() {
      return Storage.getters.MARATHONPAGEURL;
    },
    marathon_vk_url() {
      return Storage.getters.MARATHONVKURL;
    },


  },
  mounted(){

  },
  beforeMount() {
  },
  watch:{
  }

};
</script>
<style scoped>
</style>
