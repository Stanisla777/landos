<template lang="pug">
  .marathon-new-last__wr-container-final-test(v-if="data_open!==0")

    div(v-if="!window_successful_sending")
      p.marathon-new-last__final-test-title Приветствуем, <span class="highlighting light-green">{{nickname}}</span>!
      p.marathon-new-last__final-test-sub-title Пожалуйста, запомните или запишите эти цифры, с их помощью вы сможете найти себя в рейтинге
    div(v-else)
      p.marathon-new-last__final-test-title Приветствуем, <span class="highlighting light-green">{{nickname}}</span>!
      p.marathon-new-last__final-test-title.second Вы уже прошли тест
      p.marathon-new-last__final-test-sub-title Вы можете посмотреть свое место в рейтинге участников


    p.marathon-new-last__final-test-title.marathon-new-last__answer(
      v-if="!finish_window&&!window_successful_sending&&loading_complete"
    ) Ответьте на вопросы
    p.marathon-new-last__test-field-error(v-if="error_first_send") {{error_first_send_text}}

    .test-a__main-container.marathon-new-last__test-main-container(ref='mainContainer')
      .test-a__final-window-container-common(
        v-if="finish_window"
      )
        .polls__swiper-container-load-block(v-if="loader")
          .polls__swiper-container-load-icon
            img(src="/dist/img/test-loader.svg")
        template
          final-window(
            :correct_answers="correct_answers"
            :count_question="count_question"
            :nickname="nickname"
            :inn="inn"
          )

      .test-a__final-window-container-common(
        v-if="window_successful_sending"
      )
        template
          window-successful-sending


      .test-a__container.js--test-container(
        v-if="!finish_window&&!window_successful_sending"
      )
        template(
          v-if="count_question>0"
        )
          slide-calculator(
            ref="slide_count"
            v-show="QUESTIONS.modal===true"
            :count_slide="count_question"
            :current_slide="current_slide"
            :count_down="count_down"

          )
        .swiper-container.polls__swiper-container.js--test-a-slider(
          :class="'js--slider-'+QUESTIONS.taskId"
          ref="SliderCon"
          )
          .polls__swiper-container-load-block(v-if="loader")
            .polls__swiper-container-load-icon
              img(src="/dist/img/test-loader.svg")
          .swiper-wrapper
            .swiper-slide(v-for="(slide,key,ind) in count_questions")
              template
                test-n(
                  :param ="next_question"
                  :id="id_user"
                  :modal="QUESTIONS.modal"
                )

        .test-a__slider-btn-opacity
          .js--test-a-btn-right(
            ref="BtnNext"
          )



</template>

<script>
import Vue from 'vue';
import VueAxios from 'vue-axios';
import axios from 'axios';
import TestN from './TestN.vue';
import SlideCalculator from './components/SlideCalculator.vue';
import FinalWindow from './components/FinalWindow.vue';
import WindowSuccessfulSending from './components/WindowSuccessfulSending.vue';
import Swiper, {Navigation, Pagination} from 'swiper';
import Storage from './development-tools/state.vue';
import eventBus from './development-tools/eventBus.vue';
import state from '../marathon-2024/development-tools-rating/state.vue'
Swiper.use([Navigation, Pagination]);
let mySwiper;

Vue.use(VueAxios, axios);
const apiForGet = '/local/ajax/tests.php';
const apiForTest = 'http://localhost:3000/result';
const apiForSend = '/local/ajax/add_tests.php';

export default {
  name: 'TestNEntry',

  props: ['userId','idTask'],
  data() {
    return {
      error_first_send:false,
      error_first_send_text:'Что-то пошло не так',

      count_down:false,
      count_questions:0,
      finalWindow:false,
      btn_next:false,
      colorTheme: 'black', // тип цветовой темы, может принимать значения: 'white', 'gray или 'black'
      buttonText: 'Проверить ответ', // текст кнопки проверки ответа,
      counter_slide:true,
      QUESTIONS:{
        modal:true,
        taskId:1
      }, //раскоментировать - это для боя
      // count_question:0,
      // current_slide:1,
      status_btn:false,
      // в зависимости от того, что придёт в переменной "view" - frame или slider
      showElement:false,
      // time_limit:null,

    //  Закоментировать - это для разработки
      data: {
        "id": 777, // id задания (нужен в ответе фронт-приложения)
        "name": "Название блока", // Название блока, не выводится, для отладки
        "modal": true , // true - при генерации сразу открывать в модальном popup-окнке | false - выводить "фреймом"

        "required":true, // флаг обязательного задания. Если false - выводим кнопку-крестик для закрытия-пропуска задания
        "nickname":"Марафонец 777",// true - требуется модерация

        "items": [ // массив с одним или несколькими элементами-тестами-вопросами
          //



          // {
          //   "id": "да-нет",
          //   "name": "Выберите одну из двух кнопок",
          //   "description": "",
          //   "type": "test_dualbuttons",
          //   "options": [
          //     {
          //       "id": 1,
          //       "name": "Кнопка 1"
          //     },
          //     {
          //       "id": 2,
          //       "name": "Кнопка 2"
          //     }
          //   ]
          // },
          // {
          //   "id": "слайдер",
          //   "name": "Сколько средств вам потребуется откладывать каждый месяц, чтобы накопить 300 тыс. ₽ за 2 года?",
          //   "description": "",
          //   "type": "test_slider",
          //   "options": [
          //     {
          //       "id": 1,
          //       "name": "100 000 Р"
          //     },
          //     {
          //       "id": 2,
          //       "name": "30 Р"
          //     },
          //     {
          //       "id": 3,
          //       "name": "600 000 Р"
          //     },
          //     {
          //       "id": 4,
          //       "name": "800 000 Р"
          //     },
          //     {
          //       "id": 5,
          //       "name": "650 000 Р"
          //     }
          //   ]
          // },
          //
          // {
          //   "id": "картинка-1",
          //   "name": "Выберите одну или несколько картинок",
          //   "description": "",
          //   "type": "test_radioimages",
          //   "options": [
          //     {
          //       "id": 10,
          //       "name": "картинка 1",
          //       "image": "img/content-img_03.png"
          //     },
          //     {
          //       "id": 20,
          //       "name": "картинка 2",
          //       "image": "img/banner_mortgage_marathon_2022.png"
          //     },
          //     {
          //       "id": 30,
          //       "name": "картинка 3",
          //       "image": "img/banner_itmortgage_main.png"
          //     },
          //     {
          //       "id": 40,
          //       "name": "картинка 4",
          //       "image": "img/banner-programs-2x.png"
          //     }
          //   ]
          // },
          //
          // {
          //   "id": "чекбокс1",
          //   "name": "Выберите один или несколько чекбоксов",
          //   "description": "",
          //   "type": "test_checkboxes",
          //   "options": [
          //     {
          //       "id": 1,
          //       "name": "Чекбокс 1"
          //     },
          //     {
          //       "id": 2,
          //       "name": "Чекбокс 2"
          //     },
          //     {
          //       "id":3,
          //       "name": "Чекбокс 3"
          //     },
          //     {
          //       "id": 4,
          //       "name": "Чекбокс 4"
          //     }
          //   ]
          // },
          {
            'type': 'test_radiogroup',
            'id': "раиокнопка-1", // id теста-вопроса (нужен в ответе фронт-приложения)
            'name': 'Можете ли вы получить кредитные каникулы для военнослужащих?', // название вопроса
            'description': '', // html-описание, где-то может и используется (необязателен)
            "timeLimit": 5,
            "totalCount": 20,
            'options': [
              {
                'id': 1,
                'name': '70 тыс. рублей'
              },
              {
                'id': 2,
                'name': '60 тыс. рублей'
              }
            ]

          },
        ],
      },
    }
  },
  methods: {

    //инициализация слайдера
    initSlider() {
      if(this.QUESTIONS.modal===false){
        let current_slide = this.current_slide
        mySwiper = new Swiper('.js--test-a-slider', {
          loop: false,
          simulateTouch: false,
          allowTouchMove: false,
          autoHeight:true,
          slidesPerView: 1,
          pagination: {
            el: '.test-pagination',
            clickable: true
          },
          on:{
            transitionEnd: ()=>{
              // const slide_calculator = document.querySelectorAll('.test-a__counter')
              // slide_calculator.forEach(function (item){
              // })
              // this.$refs.slide_count.$el.querySelector('.test-a__counter-des span:first-child').textContent = mySwiper.realIndex+1
              // this.current_slide = mySwiper.realIndex+1
            },
          }
        });
      }
      else {
        let current_slide = this.current_slide
        mySwiper = new Swiper(".js--test-a-slider", {

          loop: false,
          simulateTouch: false,
          allowTouchMove: false,
          spaceBetween: 35,
          autoHeight:true,
          resizeObserver:true,
          pagination: {
            el: '.test-pagination',
            clickable: true
          },
          breakpoints: {
            0: {
              speed: 0,
              resizeObserver:true,
            },
            1024: {

            }
          },
          on:{
            init: () => {
              eventBus.$emit('slideReachBeginning')
            },
            transitionEnd: ()=>{
              // this.$refs.mainContainer.querySelector('.swiper-wrapper').classList.add('active');
              // const slide_calculator = document.querySelectorAll('.test-a__counter')
              // slide_calculator.forEach(function (item){
              // })
              // this.$refs.slide_count.$el.querySelector('.test-a__counter-des span:first-child').textContent = mySwiper.realIndex+1
              // this.current_slide = mySwiper.realIndex+1
            },
            transitionStart: ()=>{
              // this.$refs.mainContainer.querySelector('.swiper-wrapper').classList.remove('active');
            },

            slideNextTransitionEnd:()=>{
              eventBus.$emit('slideNextTransition')
            },
            slideChangeTransitionStart:()=>{
              eventBus.$emit('slideNextTransitionStart')
            },

            slidePrevTransitionEnd:()=>{
              eventBus.$emit('slidePrevTransition')
            },

            fromEdge:()=>{
              eventBus.$emit('slideFromEdge')
            },
            reachBeginning:()=>{
              eventBus.$emit('slideReachBeginning')
            },
          }
        });
      }


    },

    /**
     * Запрашивает данные по api, заносит их в data
     */


    dataGetParam(){
      Storage.dispatch('ActionLoader',true)

      // axios.post(`/api/local/marathon/test/question/`, {
        axios({
          method:'post',
          url:'/api/local/marathon/test/question/', //бой
          // url:'http://localhost:3000/result3', // разработка
          headers: {
            "Content-type": "application/json; charset=UTF-8",
            'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
          },
          data:{}

      })
        .then((res) => {
          //бой
          if(res.data.result.items) {
            this.count_questions = res.data.result.items[0].totalCount
          }
          Storage.dispatch('ActionFirstDataGet',res.data.result)
          setTimeout(()=>{
            this.count_down=true
          })

          //отладка

          // setTimeout(()=>{
          //   if(this.data.items) {
          //     this.count_questions = this.data.items[0].totalCount
          //   }
          //   Storage.dispatch('ActionFirstDataGet',this.data)
          //   setTimeout(()=>{
          //     this.count_down=true
          //   })
          // },2000)


        })
        .then((res)=>{
          this.initSlider();


          //Здесь логика другая, активации кнопки для финального окна не происходит, когда
          // чел нажимает кнопку далее на последнем вопросе, выводить финальное окно
          if(this.current_slide === this.count_question){
            this.status_btn=true
            Storage.dispatch('ActionStatusBtn',true)
          }
          else {
            this.status_btn=false
            Storage.dispatch('ActionStatusBtn',false)
          }
        })
        .catch((err) => {
          console.error(err);
          if(error.response){
            if (error.response.data.description!=undefined){
              this.error_first_send=true
              // this.error_first_send_text=error.response.data.description
            }
          }

        });

    },

  },

  computed: {
    loading_complete(){
      return Storage.getters.LOADINGCOMPLETE
    },
    final_window_form(){
      return Storage.getters.FINALWINDOWFORM
    },
    data_open(){
      return Storage.getters.DATAOPEN
    },
    data_state(){
      return Storage.getters.DATASTATE
    },

    correct_answers(){
      return Storage.getters.CORRECTANSWERS
    },

    count_question(){
      return Storage.getters.COUNTQUESTION
    },
    time_limit(){
      return Storage.getters.TIMELIMIT
    },
    current_slide(){
      return Storage.getters.CURRENTSLIDE
    },
    id_user(){
      return Storage.getters.IDUSER
    },
    nickname(){
      return Storage.getters.NICKNAME
    },
    inn(){
      return Storage.getters.INN
    },
    window_successful_sending(){
      return Storage.getters.WINDOWSUCCESSFULSENDING
    },







    loader2(){
      return Storage.getters.LOADER2
    },
    loader(){
      return Storage.getters.LOADER
    },
    next_question(){
      return Storage.getters.NEXTQUESTION
    },
    finish_window(){
      return Storage.getters.FINISHWINDOW
    },
    bonus_window(){
      return Storage.getters.BONUSWINDOW
    },
    final_win_target(){
      return Storage.getters.FINAL_WIN_TARGET
    },
    btn_next_slider(){
      return Storage.getters.BTNNEXT;
    },
    call_button_lock() {
      return Storage.getters.CALL_BUTTON_LOCK;
    },
    post_answer() {
      return Storage.getters.POSTANSWER;
    },
    status_internet() {
      return Storage.getters.STATUSINTERNET;
    },



  },
  mounted() {
    window.addEventListener('online', () => {
      Storage.dispatch('ActionInternet',true)
    });
    window.addEventListener('offline', () => {
      Storage.dispatch('ActionInternet',false)
    });

    if (this.data_open===1 && this.data_state!==1) {
      this.dataGetParam()
    }


    //Это для боя раскоментировать
    // this.dataGetParam() // тут это не нужно


    // const modal = this.$refs.mainContainer.closest('#modal-for-at-tests')
    // if(modal&&modal.classList.contains('open')){
    //   document.body.setAttribute('style',`top:-${window.scrollY}px;position: fixed;`);
    // }

    // ////Закоментировать - это для разработки
    // this.initSlider();
    // this.countSlider();
    // if(this.current_slide === this.count_question){
    //   this.status_btn=true
    //   Storage.dispatch('ActionStatusBtn',true)
    // }
    // else {
    //   this.status_btn=false
    //   Storage.dispatch('ActionStatusBtn',false)
    // }
    // Storage.dispatch('ActionCommonInfo',[this.QUESTIONS.id,this.QUESTIONS.userId])
  },
  updated() {
  },
  watch:{
    window_successful_sending() {

      if (this.window_successful_sending) {
        setTimeout(()=>{
          const block_success = document.querySelector('.js--final-window-success')
          console.log(block_success);
          if (block_success) {
            const elementPosition = block_success.getBoundingClientRect().top;
            window.scrollBy({
              top: elementPosition - 20,
              behavior: 'smooth'
            });
          }
        },200)

        axios({
          method:'post',
          url:'/api/local/marathon/rating/',
          // url:'http://localhost:3000/result3', //убрать
          headers: {
            "Content-type": "application/json; charset=UTF-8",
            'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
          },

          data: {}
        })
          .then((res)=>{
            //бой
            state.state.rating=res.data.result

            if (res.data.result.topRating.length >= 10) {
              state.state.rating_main = true;
            } else {
              state.state.rating_main = false;
            }
            if (res.data.result.other.length > 0) {
              state.state.rating_other = true;
            } else {
              state.state.rating_other = false;
            }






            //разработка
            // const rating = {
            //   "topRating": [ // ТОП-10 участников
            //     {
            //       "position": 1,
            //       "points": 100,
            //       "name": "Стасоооон",
            //       "active": true, // отметка искомого или текущего (ИНН в куки) участника
            //       "isCurrent": true, // отметка ТОЛЬКО текущего (ИНН в куки) участника - для надписи "Это Вы!"
            //     },
            //     {
            //       "position": 2,
            //       "points": 90,
            //       "name": "Наташа",
            //       "active": false, // отметка искомого или текущего (ИНН в куки) участника
            //       "isCurrent": false, // отметка ТОЛЬКО текущего (ИНН в куки) участника - для надписи "Это Вы!"
            //     },
            //     {
            //       "position": 3,
            //       "points": 80,
            //       "name": "Соня",
            //       "active": false, // отметка искомого или текущего (ИНН в куки) участника
            //       "isCurrent": false, // отметка ТОЛЬКО текущего (ИНН в куки) участника - для надписи "Это Вы!"
            //     }
            //   ],
            //   "other": [
            //     { //объект заполняется только, если искомый или текущий (ИНН в куки) участник НЕ в ТОПЕ
            //       "position": 1254,
            //       "points": 23,
            //       "name": "Мама Галя",
            //       "active": true, // отметка искомого или текущего (ИНН в куки) участника
            //       "isCurrent": false, // отметка ТОЛЬКО текущего (ИНН в куки) участника - для надписи "Это Вы!"
            //     }
            //   ],
            //   "notFound":false
            // }
            //
            // state.state.rating=rating
            //
            // if (rating.topRating.length >0) {
            //   state.state.rating_main = true;
            // } else {
            //   state.state.rating_main = false;
            // }
            // if (rating.other.length > 0) {
            //   state.state.rating_other = true;
            // } else {
            //   state.state.rating_other = false;
            // }

            //-----END---------------

          })

          // Если запрос с ошибкой
          .catch((error)=> {
            if(error.response){
              if (error.response.data.description!=undefined){
                this.field_error=true
                this.error_text_under_button=error.response.data.description
              }
            }
            console.log(error);
          });

      }

    },

    data_open(){
      this.dataGetParam()
    },

    current_slide(){
      if(this.current_slide === this.count_question){
        this.status_btn=true
        Storage.dispatch('ActionStatusBtn',true)
      }
      else {
        this.status_btn=false
        Storage.dispatch('ActionStatusBtn',false)
      }
    },
    call_button_lock() {
      if (this.call_button_lock === true) {
        const btn = this.$refs.mainContainer.closest('.js-p-wrap')
          .querySelector('.js--call-game-task');
        const arrow = this.$refs.mainContainer.closest('.js-p-wrap')
          .querySelector('.js--gamedd-next-task-control');
        const coundown = this.$refs.mainContainer.closest('.js-p-wrap')
          .querySelector('.gamedd-detailed__body-col-link');

        if (btn) {
          btn.removeAttribute('data-modal');
          btn.classList.add('unactive');
          btn.classList.remove('green');
          btn.textContent='Тест пройден';
        }
        if(arrow){

          if(this.post_answer!=null&&this.post_answer.nextUrl!==''&&this.post_answer.nextUrl!==null&&this.post_answer.nextUrl!==undefined){
            arrow.querySelector('a').setAttribute('href',`${this.post_answer.nextUrl}`)
            arrow.classList.remove('unactive')
          }
        }
        if(coundown){
          coundown.classList.add('unactive')
        }
      }
    }
  },
  created(){
    // this.dataGetParam()
    eventBus.$on('eventbtnNext',()=>{
     this.$refs.BtnNext.click();
     mySwiper.slideNext()
    })
  },
  beforeCreate() {
  },

  components: {
    TestN,
    SlideCalculator,
    FinalWindow,
    WindowSuccessfulSending
  },

}
</script>
