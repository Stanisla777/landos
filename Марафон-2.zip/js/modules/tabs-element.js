export default function tabElement() {
  // eslint-disable-next-line camelcase
  const tab_btn = document.querySelectorAll('.js--tab-button');
  // eslint-disable-next-line no-unused-vars
  const tabPanels = document.querySelectorAll('.js--tab-panel');
    for (let i = 0; i < tab_btn.length; i++) {
      // eslint-disable-next-line no-use-before-define
      tab_btn[i].onclick = function () {
        // eslint-disable-next-line no-unused-vars
        const data = this.getAttribute('data-tab');
        const parent = this.closest('.js-tab');
        // eslint-disable-next-line camelcase
        const tabs_button = parent.querySelectorAll('.js--tab-button');
        for (let j = 0; j < tabs_button.length; j++) {
          if (tabs_button[j].classList.contains('active')) {
            tabs_button[j].classList.remove('active');
          } else {
            tabs_button[j].classList.add('active');
          }
        }
        // eslint-disable-next-line no-unused-vars
        const childrenTab = parent.querySelectorAll('.js--tab-panel');
        for (let k = 0; k < childrenTab.length; k++) {
          const dataTab = childrenTab[k].getAttribute('data-tab');
          if (dataTab === data) {
            childrenTab[k].setAttribute('style', 'display:block');
          } else {
            childrenTab[k].setAttribute('style', 'display:none');
          }
        }
      };
    }
  // eslint-disable-next-line no-empty
  for (let j = 0; j < tabPanels.length; j++) {
  }
}
