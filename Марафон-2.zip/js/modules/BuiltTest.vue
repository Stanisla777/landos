<template lang="pug">
  .form-test-list
    template
      slider-test(
        v-if="viewsTest==='Test1'"
        :idTest ="idTest"
      )
    template
      step-test(
        v-if="viewsTest==='Test2'"
        :idTest ="idTest"
      )
</template>
<script>

import Vue from 'vue';
import SliderTest from './components/Test/SliderTest.vue';
import StepTest from './components/Test/StepTest.vue';


export default {
  name:'Test',
  data(){
    return {
      viewsTest:'',
      idTest:0
    }
  },
  methods:{
    testType(){
      const container_test = document.querySelectorAll('.form-test-list')
      container_test.forEach(function (item){
        const attr = item.getAttribute('views')
      })
    }
  },
  mounted() {
    const viewsTest = document.querySelector('.form-test-list').getAttribute('views')
    const idTest = document.querySelector('.form-test-list').getAttribute('id')
    this.viewsTest = viewsTest
    this.idTest = parseInt(idTest)
  },
  components:{
    'slider-test':SliderTest,
    'step-test':StepTest,
  },
}
</script>
