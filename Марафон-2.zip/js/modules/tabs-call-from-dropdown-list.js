function windowSelection(element) {
  // eslint-disable-next-line no-unused-vars
  const attr = element.getAttribute('data-param');
  // eslint-disable-next-line no-unused-vars
  if (!element.classList.contains('active')) {
    // eslint-disable-next-line no-shadow
    const parent = element.closest('.js-accordion-body');
    // eslint-disable-next-line camelcase
    const users_active = parent.querySelectorAll('.js--dropdown-list-item');

    // eslint-disable-next-line no-restricted-syntax,camelcase
    for (const elem of users_active) {
      elem.classList.remove('active');
    }
    element.classList.add('active');
    const container = element.closest('.js-tabs-container');

    // eslint-disable-next-line camelcase
    const block_users = container.querySelectorAll('.js-tabs-item');

    // eslint-disable-next-line no-restricted-syntax,camelcase
    for (const item of block_users) {
      const data = item.getAttribute('data-param');
      // eslint-disable-next-line eqeqeq
      if (data == attr) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    }
  } else return false;
}
export default function SelectListChoice() {
  // eslint-disable-next-line camelcase
  const select_list = document.querySelectorAll('.js--dropdown-list-item');
  // eslint-disable-next-line camelcase,no-restricted-syntax
  for (const item of select_list) {
    // eslint-disable-next-line no-loop-func
    item.onclick = () => {
      const text = item.textContent;
      const parent = item.closest('.js-accordion-parent');
      parent.querySelector('.js-accordion-btn p').textContent = text;
      if (parent.classList.contains('active')) {
        parent.classList.remove('active');
        // eslint-disable-next-line camelcase
        parent.querySelector('.js-accordion-body ').style.maxHeight = 0;
      }
      windowSelection(item);
    };
  }
}
