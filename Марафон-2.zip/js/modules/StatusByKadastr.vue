<template>
  <div class="status-kadastr-block">
    <h3 class="status-kadastr-block__title">
      Введите кадастровый номер объекта
    </h3>
    <p class="status-kadastr-block__description">
      Укажите кадастровый номер со всеми двоеточиями и без пробелов<br>
      Например: 77:01:0001004:1047
    </p>
    <form class="status-kadastr-block__form" @submit.prevent="handlerSendForm">
      <div class="status-kadastr-block__form-wrapper">
        <button type="submit" class="status-kadastr-block__search">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M7.40741 3.33333C5.15736 3.33333 3.33333 5.15736 3.33333 7.40741C3.33333 9.65746 5.15736 11.4815 7.40741 11.4815C8.50311 11.4815 9.49779 11.0489 10.23 10.3453C10.2466 10.3241 10.2646 10.3037 10.2842 10.2842C10.3037 10.2646 10.3241 10.2466 10.3453 10.23C11.0489 9.49779 11.4815 8.50311 11.4815 7.40741C11.4815 5.15736 9.65746 3.33333 7.40741 3.33333ZM11.6734 10.7306C12.3887 9.81376 12.8148 8.66035 12.8148 7.40741C12.8148 4.42098 10.3938 2 7.40741 2C4.42098 2 2 4.42098 2 7.40741C2 10.3938 4.42098 12.8148 7.40741 12.8148C8.66035 12.8148 9.81376 12.3887 10.7306 11.6734L12.8619 13.8047C13.1223 14.0651 13.5444 14.0651 13.8047 13.8047C14.0651 13.5444 14.0651 13.1223 13.8047 12.8619L11.6734 10.7306Z" fill="#252628"/>
          </svg>
        </button>
        <input @input="onInput" class="status-kadastr-block__input" v-model="value" placeholder="ХХ:ХХ:ХХХХХХХ:ХХ">
        <button class="status-kadastr-block__cancel" @click="onCancel" v-if="value.length > 0">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M3.20921 3.20921C3.48816 2.93026 3.94042 2.93026 4.21936 3.20921L8 6.98985L11.7806 3.20921C12.0596 2.93026 12.5118 2.93026 12.7908 3.20921C13.0697 3.48816 13.0697 3.94042 12.7908 4.21936L9.01015 8L12.7908 11.7806C13.0697 12.0596 13.0697 12.5118 12.7908 12.7908C12.5118 13.0697 12.0596 13.0697 11.7806 12.7908L8 9.01015L4.21936 12.7908C3.94042 13.0697 3.48816 13.0697 3.20921 12.7908C2.93026 12.5118 2.93026 12.0596 3.20921 11.7806L6.98985 8L3.20921 4.21936C2.93026 3.94042 2.93026 3.48816 3.20921 3.20921Z" fill="#252628"/>
          </svg>
      </button>
      </div>
      <button type="submit" :class="isDisabled ? 'status-kadastr-block__submit_disabled' : ''" class="status-kadastr-block__submit">
       Проверить
      </button>
      <div id="yandex-captcha-kadastr"></div>
    </form>
    <div class="status-kadastr-block__answer-container" v-if="response">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" v-if="response.status === 'no_information'">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M15.663 3.77342C13.8902 2.98352 11.9096 2.78783 10.0166 3.21555C8.12351 3.64326 6.41942 4.67145 5.15845 6.14678C3.89749 7.62211 3.14721 9.46552 3.01951 11.4021C2.89181 13.3387 3.39354 15.2646 4.44987 16.8928C5.50619 18.5209 7.06051 19.764 8.88102 20.4365C10.7015 21.1091 12.6907 21.1752 14.5518 20.6249C16.413 20.0746 18.0464 18.9375 19.2084 17.3831C20.3705 15.8286 20.9989 13.9402 21 11.9994V11.08C21 10.5277 21.4477 10.08 22 10.08C22.5523 10.08 23 10.5277 23 11.08V12C22.9986 14.3721 22.2305 16.6807 20.8103 18.5806C19.39 20.4804 17.3936 21.8703 15.1189 22.5428C12.8442 23.2154 10.413 23.1346 8.18792 22.3126C5.96285 21.4906 4.06312 19.9713 2.77206 17.9813C1.48099 15.9914 0.86777 13.6374 1.02384 11.2705C1.17992 8.90358 2.09693 6.65052 3.63811 4.84734C5.17929 3.04416 7.26206 1.78748 9.57581 1.26472C11.8896 0.74196 14.3103 0.981129 16.477 1.94656C16.9815 2.17134 17.2082 2.76252 16.9834 3.26699C16.7587 3.77146 16.1675 3.9982 15.663 3.77342ZM22.7068 3.29253C23.0975 3.68286 23.0978 4.31602 22.7075 4.70674L12.7075 14.7167C12.52 14.9044 12.2656 15.0099 12.0003 15.01C11.735 15.0101 11.4805 14.9047 11.2929 14.7171L8.2929 11.7171C7.90237 11.3266 7.90237 10.6934 8.2929 10.3029C8.68342 9.91236 9.31659 9.91236 9.70711 10.3029L11.9997 12.5954L21.2925 3.29323C21.6829 2.90251 22.316 2.9022 22.7068 3.29253Z" fill="#82BF00"/>
      </svg>
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" v-else-if="response.status === 'payment_was_approved'">
          <path fill-rule="evenodd" clip-rule="evenodd" d="M12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2ZM0 12C0 5.37258 5.37258 0 12 0C18.6274 0 24 5.37258 24 12C24 18.6274 18.6274 24 12 24C5.37258 24 0 18.6274 0 12Z" fill="#CB4022"/>
          <path fill-rule="evenodd" clip-rule="evenodd" d="M12 7C10.5331 7 9.5 8.06743 9.5 9.2C9.5 9.75229 9.05229 10.2 8.5 10.2C7.94772 10.2 7.5 9.75229 7.5 9.2C7.5 6.79795 9.60095 5 12 5C14.399 5 16.5 6.79795 16.5 9.2C16.5 11.2605 14.954 12.8765 13 13.2944V14C13 14.5523 12.5523 15 12 15C11.4477 15 11 14.5523 11 14V12.4C11 11.8477 11.4477 11.4 12 11.4C13.4669 11.4 14.5 10.3326 14.5 9.2C14.5 8.06743 13.4669 7 12 7Z" fill="#CB4022"/>
          <path d="M13 18C13 18.5523 12.5523 19 12 19C11.4477 19 11 18.5523 11 18C11 17.4477 11.4477 17 12 17C12.5523 17 13 17.4477 13 18Z" fill="#CB4022"/>
      </svg>
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" v-else-if="response.status === '1'">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2ZM0 12C0 5.37258 5.37258 0 12 0C18.6274 0 24 5.37258 24 12C24 18.6274 18.6274 24 12 24C5.37258 24 0 18.6274 0 12Z" fill="#DE4A2A"/>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 5C12.5523 5 13 5.44772 13 6V14C13 14.5523 12.5523 15 12 15C11.4477 15 11 14.5523 11 14V6C11 5.44772 11.4477 5 12 5Z" fill="#DE4A2A"/>
        <path d="M13 18C13 18.5523 12.5523 19 12 19C11.4477 19 11 18.5523 11 18C11 17.4477 11.4477 17 12 17C12.5523 17 13 17.4477 13 18Z" fill="#DE4A2A"/>
      </svg>
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" v-else>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2ZM0 12C0 5.37258 5.37258 0 12 0C18.6274 0 24 5.37258 24 12C24 18.6274 18.6274 24 12 24C5.37258 24 0 18.6274 0 12Z" fill="#EEA20F"/>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M12 7C10.5331 7 9.5 8.06743 9.5 9.2C9.5 9.75229 9.05229 10.2 8.5 10.2C7.94772 10.2 7.5 9.75229 7.5 9.2C7.5 6.79795 9.60095 5 12 5C14.399 5 16.5 6.79795 16.5 9.2C16.5 11.2605 14.954 12.8765 13 13.2944V14C13 14.5523 12.5523 15 12 15C11.4477 15 11 14.5523 11 14V12.4C11 11.8477 11.4477 11.4 12 11.4C13.4669 11.4 14.5 10.3326 14.5 9.2C14.5 8.06743 13.4669 7 12 7Z" fill="#EEA20F"/>
        <path d="M13 18C13 18.5523 12.5523 19 12 19C11.4477 19 11 18.5523 11 18C11 17.4477 11.4477 17 12 17C12.5523 17 13 17.4477 13 18Z" fill="#EEA20F"/>
      </svg>
      <p class="status-kadastr-block__answer" v-html="response.message"></p>
    </div>
  </div>
</template>
<script>
import IMask from 'imask';
import axios from 'axios';
export default {
  name: "StatusByKadastr",
  data(){
    return {
      value: '',
      response: null,
      isDisabled: false,
      captcha_id:null
    }
  },
  methods:{
    onCancel(e){
      e.preventDefault()
      this.value = ''
    },
    //яндекс капча
    captchaInit() {
      this.captcha_id = window.smartCaptcha.render('yandex-captcha-kadastr', {
        sitekey: conf.smartcaptcha_key,
        invisible: true,
        callback: (token) => {
          this.onSubmit(token);
        },
      });
    },
    handlerSendForm() {
      this.captchaInit();
      let recaptchaKey = null;
      if (typeof conf !== 'undefined') {
        recaptchaKey = conf.smartcaptcha_key;
      }
      if ((typeof recaptchaKey !== 'undefined') && recaptchaKey !== null) {
        window.smartCaptcha.execute(this.captcha_id);
      } else {
        const result = {
          'status': '1',
          'message': 'Ошибка при проверке безопасности. Перезагрузите страницу и попробуйте снова'
        };
        this.response = result;
      }
    },
    onSubmit(token){
      if(this.value.length === 0) return
      let key = conf.smartcaptcha_key
      // if (key && typeof window.grecaptcha !== 'undefined') {
        this.isDisabled = true
        // window.grecaptcha.ready(() => {
        //       window.grecaptcha.execute(key).then((token) => {
                    axios.post('/api/local/program450/statusbykadastr/', {
                      kadastr: this.value,
                      'smart-token': token,
                    },{
                      headers: {
                        'Content-Type': 'application/json',
                        'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
                        Accept: 'application/json',
                      },
                    })
                        .then((response) => {
                          this.response = response.data.result
                          this.isDisabled = false
                        })
                        .catch((error) => {
                          const result = {
                            "status": '1',
                            "message": error.response.data.description
                          }
                          this.response = result
                          this.isDisabled = false
                        })
              // })
            // })
      // } else {
      //   const result = {
      //     "status": '1',
      //     "message": "Ошибка при проверке безопасности. Перезагрузите страницу и попробуйте снова"
      //   }
      //   this.response = result
      // }

    },
    onInput(){
      if(this.value){
        const result = this.value.match(/[0-9:]/g)
        this.value = result === null ? '' : result.join('')
      }

    },
    inputCost(){
      const input_tel = document.querySelectorAll('.status-kadastr-block__input');
      const maskOptions = {
        mask: '[0-9:]'
      };
      for (const item of input_tel) {
        new IMask(item, maskOptions);
      }

    },
  },
  mounted() {
    // this.captchaInit();
  }
}
</script>
