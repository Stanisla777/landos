/* eslint-disable */
function housingCooperativeMapTooltip() {
  const arrayCooperativeTooltip = document.querySelectorAll('.js--housing-cooperative-filter .js--content-note');
  document.addEventListener('mouseover', (e) => {
    if (!e.target.matches('.js--housing-cooperative-map-list .js--content-note')) return;
    const toolTip = e.target.querySelector('.content-note__text');
    const cardHouse = e.target.closest('.card-housing-cooperative');
    const labelLeft = e.target.getBoundingClientRect();
    const cardLeft = cardHouse.getBoundingClientRect();
    toolTip.style.transform = `translateX(${-(labelLeft.left - cardLeft.left + 4) + (cardHouse.offsetWidth / 2) - (toolTip.offsetWidth / 2)}px)`;

  });


  // for (let item of arrayCooperativeTooltip) {
  //   item.addEventListener('mouseover', () => {
  //     const toolTip = item.querySelector('.content-note__text');
  //     const cardHouse = item.closest('.card-housing-cooperative');
  //     const labelLeft = item.getBoundingClientRect();
  //     const cardLeft = cardHouse.getBoundingClientRect();
  //     toolTip.style.transform = `translateX(${-(labelLeft.left - cardLeft.left + 4) + (cardHouse.offsetWidth / 2) - (toolTip.offsetWidth / 2)}px)`;
  //   })
  // }
}
export default function housingCooperativeFilter() {
  const filterWrap = document.querySelector('.js--housing-cooperative-filter');
  if (!filterWrap) return;
  filterWrap.addEventListener('click', (e) => {
    const modalOpener = e.target.closest('.js--hcp-modal-opener');
    const modalCloser = e.target.closest('.js--hcp-modal-closer');
    const modal = filterWrap.querySelector('.js--hcp-modal');
    const body = document.querySelector('body');
    const wrap = document.getElementsByClassName('js-p-wrap')[0];

    if (modalOpener) {
      modal.classList.add('is-open');
      wrap.classList.add('is-hidden');
      body.classList.add('menu-opened');
    } else if (modalCloser) {
      modal.classList.remove('is-open');
      wrap.classList.remove('is-hidden');
      body.classList.remove('menu-opened');
    }
  });
  housingCooperativeMapTooltip();
}
