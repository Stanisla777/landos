/* eslint-disable */
export default function AddClassBody() {
  document.body.classList.add('body-modal');
  document.body.classList.add('body-additional-class');
  document.body.setAttribute('style', `top:-${window.scrollY}px;position: fixed;`);
  document.ontouchmove = (e) => {
    e.preventDefault();
  };
}

