/* eslint-disable */
import AddClassBody from './disallow-body-scrolling';
import RemoveClassBody from './allow-body-scrolling';

function focusInput(element) {
  if (element.querySelector('input.ya-site-form__input-text')) {
    // scrollTo();
    scrollTo2();
    element.querySelector('input.ya-site-form__input-text').focus();

  }
}

function activeSearch() {
  const btnyandexSearch = document.querySelector('.js--btn-yandex-search');
  const containerYandexSearch = document.querySelector('.js--yandex-search'); //поиск в хедере
  const containerYandexSearchResult = document.querySelector('.js--yandex-search-result');//поиск на странице


  const mobileMenu = document.querySelector('.js--mobile-menu');
  const btn = document.querySelector('.js--header-burger');
  if (btnyandexSearch) {
    btnyandexSearch.onclick = () => {
      if (containerYandexSearch) {
        btnyandexSearch.classList.toggle('active');
        containerYandexSearch.classList.toggle('active');
        if ((document.body.classList.contains('body-modal') && document.body.classList.contains('body-additional-class'))&&
          mobileMenu && !mobileMenu.classList.contains('active')) {
          RemoveClassBody();
        }
        else if ((!document.body.classList.contains('body-modal') && !document.body.classList.contains('body-additional-class'))&&
          mobileMenu && !mobileMenu.classList.contains('active')){
          AddClassBody();
        }

        focusInput(containerYandexSearch);
      }
      if (containerYandexSearchResult) {
        focusInput(containerYandexSearchResult);
        if (mobileMenu && mobileMenu.classList.contains('active')) {
          RemoveClassBody();
          if (btn) {
            btn.classList.remove('open');
            mobileMenu.classList.remove('active')
            const header = btn.closest('.js--page-content').querySelector('.header');
            if (header) {
              header.classList.remove('z-ind');
            }
          }
        }
      }
    };
  }
  if (containerYandexSearchResult) {
    const i = setInterval(() => {
      if (containerYandexSearchResult.querySelector('input.ya-site-form__input-text')) {
        clearInterval(i);
        containerYandexSearchResult.querySelector('input.ya-site-form__input-text').addEventListener('focus', () => {
          if (btnyandexSearch) {
            btnyandexSearch.classList.add('active');
          }
        });
        containerYandexSearchResult.querySelector('input.ya-site-form__input-text').addEventListener('blur', () => {
          if (btnyandexSearch) {
            btnyandexSearch.classList.remove('active');
          }
        });
      }
    });
  }
}
function scrollTo() {
  const target = document.querySelector('.block-page-main .h1_title');
  if (target) {
    const offset = 5
    const position = target.getBoundingClientRect().top + window.scrollY;
    window.scrollTo({
      top:position - offset,
      bahavior:'smooth'
    })
  }
}

function scrollTo2() {
  const targetElement = document.querySelector('.block-page-main .h1_title');
  if (targetElement) {
    const startPosition = window.pageYOffset;
    const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset;

    const distance = targetPosition -startPosition - 10;
    const duration = 800;
    let startTime = null;

    function animation(currentTime) {
      if (startTime === null) startTime = currentTime;
      const timeElapsed = currentTime - startTime;

      const progress = Math.min(timeElapsed / duration, 1);
      const ease = easeInOutQuad(progress)

      window.scrollTo(0, startPosition + distance * ease);
      if (timeElapsed < duration) {
        requestAnimationFrame(animation)
      }
    }
    function easeInOutQuad(t){
      return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
    }
    requestAnimationFrame(animation)
  }
}





function closeSearch() {
  const containerYandexSearch = document.querySelector('.js--yandex-search');
  const btnyandexSearch = document.querySelector('.js--btn-yandex-search');
  const mobileMenu = document.querySelector('.js--mobile-menu');
  if (containerYandexSearch) {
    containerYandexSearch.onclick = (e) => {
      if (e.target === containerYandexSearch) {
        containerYandexSearch.classList.remove('active');
        if (mobileMenu && !mobileMenu.classList.contains('active')){
          RemoveClassBody();
        }
        if (btnyandexSearch) {
          btnyandexSearch.classList.remove('active');
        }
      }
    };
  }
}

function loopOutputBillet(arrayBillet,btnElse,peremWidthBlock) {

  let widthBillet = 0;
  const widthBlock = peremWidthBlock;
  for (let i = 0; i<arrayBillet.length; i++) {
    widthBillet += arrayBillet[i].offsetWidth;
    if (widthBillet > widthBlock && !arrayBillet[i].classList.contains('js--round-billet-else')) {
      arrayBillet[i].classList.add('unactive');
    }
  }
  if (widthBillet > widthBlock && btnElse && !btnElse.classList.contains('active')) {
    btnElse.classList.add('active')
  }
  widthBillet = 0;
}

function countBillet() {
  const blockBillet = document.querySelector('.js--ya-billet');
  if (blockBillet) {
    const peremWidthBlock = blockBillet.offsetWidth - 20;
    const btnElse = blockBillet.querySelector('.js--round-billet-else');
    const arrayBillet = blockBillet.querySelectorAll('.round-billet__item');
    loopOutputBillet(arrayBillet,btnElse,peremWidthBlock);
    // blockBillet.classList.add('ready')
    if(btnElse && btnElse.classList.contains('active')) {
      btnElse.onclick = () => {
        if (!btnElse.classList.contains('up')) {
          btnElse.classList.add('up');
          blockBillet.classList.remove('no-wrap')
          for (let i = 0; i<arrayBillet.length; i++) {
            if (arrayBillet[i].classList.contains('unactive')) {
              arrayBillet[i].classList.remove('unactive')
            }
          }
        }
        else {
          btnElse.classList.remove('up');
          blockBillet.classList.add('no-wrap')
          loopOutputBillet(arrayBillet,btnElse,peremWidthBlock);
        }
      }
    }
    setTimeout(() => {
      blockBillet.classList.add('ready')
    },1000)
  }

}

export default function yandexSearch() {
  activeSearch();
  closeSearch();
  countBillet();
  // window.addEventListener('resize',  countBillet);
}

