/* eslint-disable */
import AddClassBody from './disallow-body-scrolling';
import RemoveClassBody from './allow-body-scrolling';
let property;

function checkingChatActivity() {
  let state=false;
  const chat_bot = document.querySelector('.js--chat-bot');
  if (chat_bot && chat_bot.classList.contains('active')) {
    state=true
  }
  return state;
}

function gettingProperty() {
  property = window.innerWidth;
  // console.log(property);
  // console.log(window.innerWidth);
  const chat_bot = document.querySelector('.js--chat-bot');
  if (property>480 && chat_bot && chat_bot.classList.contains('active')) {
    RemoveClassBody();
  }
  if (property<=480 && chat_bot && chat_bot.classList.contains('active')) {
    AddClassBody();
  }
}

function openChatBot() {
  const btn = document.querySelectorAll('.js--open-chat-bot');
  btn.forEach((item) => {
    const parent = item.closest('.js--chat-bot');
    item.onclick = () => {
      if(parent) {
        if (property<=480) {
          AddClassBody();
        }
        parent.classList.add('active');
      }
    }
  })
}

function closeChatBot() {
  const btn = document.querySelectorAll('.js--chat-bot-close');
  btn.forEach((item) => {
    item.onclick = () => {
      if(item.closest('.js--chat-bot')) {
        item.closest('.js--chat-bot').classList.remove('active');
      }
      if(document.body.classList.contains('body-modal')) {
        RemoveClassBody();
      }
    }
  })
}

//закрытие окна на мобильнике при клике вне окна
function outAreaClose() {
  const chat_bot = document.querySelector('.js--chat-bot');
  if (chat_bot) {
    chat_bot.onclick = (e) => {
      if (e.target.classList.contains('js--chat-bot') && e.target.classList.contains('active') &&
        document.body.classList.contains('body-modal')) {
        RemoveClassBody();
        e.target.classList.remove('active');
      }
    };
  }
}

function outAreaCloseClickBody() {
  const chat_bot = document.querySelector('.js--chat-bot');
  if(chat_bot) {
    document.addEventListener( 'click', (e) => {
      const withinBoundaries = e.composedPath().includes(chat_bot);
      if ( ! withinBoundaries  && chat_bot.classList.contains('active') &&
        !document.body.classList.contains('body-modal')) {
        chat_bot.classList.remove('active')
      }
      if (e.target.classList.contains('js--chat-bot') && e.target.classList.contains('active') &&
        document.body.classList.contains('body-modal')) {
        RemoveClassBody();
        e.target.classList.remove('active');
      }

    })
  }
}

//меняю класс кнопки, когда она вчёрном футере
function handleScroll() {
  let obj = document.querySelector('.footer');
  let {top,bottom} = obj.getBoundingClientRect();
  let height = document.documentElement.clientHeight;

  const btn = document.querySelector('.js--open-chat-bot');

  if (btn) {
    if (top < (height - 50)) {
      btn.classList.remove('black')
      btn.classList.add('white_color_black')
    }
    else {
      btn.classList.add('black')
      btn.classList.remove('white_color_black')
    }
  }

}


export default function chatBot() {
  openChatBot();
  closeChatBot();
  gettingProperty();
  // outAreaClose();
  outAreaCloseClickBody();
  if (document.querySelector('.js--chat-bot')) {
    window.addEventListener('resize', gettingProperty);
    window.addEventListener('scroll', handleScroll);
  }

}
