/* eslint-disable */

function insructionScroll() {
  var sections = document.querySelectorAll('.js--anchor-block');
  var nav = document.querySelector('.js--information-block-document');
  const blockViewportOffset = document.querySelectorAll('.js--anchor-block');

  if (nav && blockViewportOffset[0]) {
    var nav_height = nav.offsetHeight;
    var cur_pos = window.pageYOffset;
    // console.log(cur_pos);



    if (blockViewportOffset[0].getBoundingClientRect().top > 20) {
      nav.querySelector('a[href="#' + blockViewportOffset[0].id + '"]').classList.remove('active');
    }

    sections.forEach(function(section) {

      // var top = section.offsetTop - nav_height;
      // var bottom = top + section.offsetHeight;


      let viewportOffset = section.getBoundingClientRect();
      let top = viewportOffset.top;

      // if (cur_pos >= top && cur_pos <= bottom) {
      if (top<=20) {
        nav.querySelectorAll('.js--anchor').forEach(function(a) {
          a.classList.remove('active');
        });
        sections.forEach(function(s) {
          s.classList.remove('active');
        });

        section.classList.add('active');
        if (nav.querySelector('a[href="#' + section.id + '"]')) {
          nav.querySelector('a[href="#' + section.id + '"]').classList.add('active');
        }


      }
    });
  }


  // const observer = new IntersectionObserver((entries) => {
  //     entries.forEach((entry) => {
  //       if (entry.isIntersecting) {
  //         document.querySelectorAll('.js--anchor')
  //           .forEach((link) => {
  //             let id = link.getAttribute('href').replace('#', '');
  //
  //             if (id == entry.target.id) {
  //               console.log(id);
  //               link.classList.add('active')
  //             }
  //             else {
  //               link.classList.remove('active')
  //             }
  //           });
  //       }
  //     });
  //   },
  //   {
  //     threshold: 0
  //   });
  // document.querySelectorAll('.js--anchor-block').forEach(section => {
  //   observer.observe(section);
  // })
}
function activeInput() {
  const array_input = document.querySelectorAll('.js--instr-input');
  for (let item of array_input) {
    item.oninput = () => {
      if (item.value.length > 0) {
        item.closest('.js--inp-wr').classList.add('active')
      }
      else {
        item.closest('.js--inp-wr').classList.remove('active')
      }
    }
    item.onfocus = () => {
      item.closest('.js--inp-wr').classList.add('focus')
    }
    item.onblur = () => {
      item.closest('.js--inp-wr').classList.remove('focus')
    }
  }
}
function clearInput() {
  const parent = document.querySelector('.js--inp-wr');
  if (parent && parent.querySelector('.js--search-col-clear') && parent.querySelector('.js--instr-input')) {
    parent.querySelector('.js--search-col-clear').onclick = () => {
      parent.querySelector('.js--instr-input').value=''
      const event = new Event('change');
      parent.querySelector('.js--instr-input').dispatchEvent(event);
    }
  }
}
export default function instruction() {
  window.addEventListener('scroll', insructionScroll);
  insructionScroll();
  activeInput();
}
