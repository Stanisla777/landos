/* eslint-disable */
import dropDown from '../dropDown';

function addingClass() {
  const array_footer_columns = document.querySelectorAll('.js--footer-nav-list');
  for (let i = 0;i<array_footer_columns.length;i++) {
    array_footer_columns[i].classList.add(`column-${i+1}`);
  }
}

function dropDownTags() {
  const btnTags = document.querySelectorAll('.js--footer-tags')
    for (let item of btnTags) {
      item.onclick = (el) => {
        if (!el.target.classList.contains('js--footer-tags-link') && document.documentElement.clientWidth <= 480) {
          dropDown(el.target,0)
        }
      }
    }

}

function dropDownDirection() {
  const btn_direction = document.querySelectorAll('.js--directions-accordion-btn')
  for (let item of btn_direction) {
    item.onclick = (el) => {
      dropDown(el.target,0)
      // if (item.closest('.js-accordion-parent') && !item.closest('.js-accordion-parent').classList.contains('active')) {
      //   item.closest('.js-accordion-parent').classList.add('active')
      // }
      // else if (item.closest('.js-accordion-parent') && item.closest('.js-accordion-parent').classList.contains('active')) {
      //   item.closest('.js-accordion-parent').classList.remove('active')
      // }
    }
  }

}

export default function footerDropDown() {
  // addingClass();
  dropDownTags();
  window.addEventListener('resize', dropDownTags);
  dropDownDirection();
}
