/* eslint-disable */
export default function paginationSlider(el) {
  // console.log(el);
  if (el.el.closest('.general-style-slider')) {
    const array = el.el.closest('.general-style-slider').querySelectorAll('.swiper-pagination-bullet');
    if (array.length < 2
      && el.el.closest('.general-style-slider').querySelector('.js--pagination-slider_s')) {
      el.el.closest('.general-style-slider').querySelector('.js--pagination-slider_s').classList.add('unactive');
      // eslint-disable-next-line no-param-reassign
      el.passedParams.simulateTouch = false;
      // eslint-disable-next-line no-param-reassign
      el.allowTouchMove = false;
    } else if (array.length >= 2
      && el.el.closest('.general-style-slider').querySelector('.js--pagination-slider_s')) {
      el.el.closest('.general-style-slider').querySelector('.js--pagination-slider_s').classList.remove('unactive');
    }
  }


  if (el.el.closest('.general-style-slider')) {
    const array_arrow = el.el.closest('.general-style-slider').querySelectorAll('.swiper-button-disabled');
    if (array_arrow.length === 2
      && el.el.closest('.general-style-slider').querySelector('.js--container-swiper-arrow') ) {
      el.el.closest('.general-style-slider').querySelector('.js--container-swiper-arrow').classList.add('unactive');
      el.allowTouchMove = false;
      el.passedParams.simulateTouch = false;
    }
    else if (array_arrow.length < 2
      && el.el.closest('.general-style-slider').querySelector('.js--container-swiper-arrow') ) {
      el.el.closest('.general-style-slider').querySelector('.js--container-swiper-arrow').classList.remove('unactive');
    }
  }


}
