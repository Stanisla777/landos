/* eslint-disable */
import dropDown from '../dropDown';
import AddClassBody from './disallow-body-scrolling';
import RemoveClassBody from './allow-body-scrolling';

function dropDownSubMenu() {
  const menuHeaderBtn = document.querySelectorAll('.js--mobile-menu-btn')
  for (let item of menuHeaderBtn) {
    item.onclick = (el) => {
      if (!el.target.classList.contains('js--mobile-menu-link')) {
        dropDown(el.target,0)
      }
    }
  }
}

function callMobileMenu() {
  const btn = document.querySelector('.js--header-burger');
  const mobileMenu = document.querySelector('.js--mobile-menu');
  const containerYandexSearch = document.querySelector('.js--yandex-search');
  if (btn && btn.closest('.js--page-content')) {
    btn.onclick = (el) => {
      const header = btn.closest('.js--page-content').querySelector('.header');
      if (header) {
        header.classList.toggle('z-ind');
      }

      if (containerYandexSearch) {
        if (containerYandexSearch.classList.contains('active') && document.body.classList.contains('body-modal') && document.body.classList.contains('body-additional-class')) {
          AddClassBody();
        }
        else if (!containerYandexSearch.classList.contains('active')
          && !document.body.classList.contains('body-modal')
          && !document.body.classList.contains('body-additional-class')) {
          AddClassBody();
        }
        else if (!containerYandexSearch.classList.contains('active')
          && document.body.classList.contains('body-modal')
          && document.body.classList.contains('body-additional-class')) {
          RemoveClassBody();
        }
      }
      else {
        if (document.body.classList.contains('body-modal') && document.body.classList.contains('body-additional-class')) {
          RemoveClassBody()
        }


        else if (!document.body.classList.contains('body-modal') && !document.body.classList.contains('body-additional-class')){
          AddClassBody();
        }
      }

      // document.body.classList.toggle('body-modal');
      // document.body.classList.toggle('body-additional-class');
      // btn.closest('.header').classList.toggle('not-border')
      btn.classList.toggle('open');
      if (mobileMenu) {
        mobileMenu.classList.toggle('active');
      }

    };
  }
}

export default function headerMenu() {
  dropDownSubMenu();
  callMobileMenu();
}
