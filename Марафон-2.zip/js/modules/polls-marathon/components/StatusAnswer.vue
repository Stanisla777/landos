<template lang="pug">
  .test-cotainer-result-answers
    p.marathon-detail__answer-question-title Ответ
    p.marathon-detail__answer-question-content(
      v-html="response_description[0]"
    )
</template>

<script>
export default {
  name: "StatusAnswer",
  data(){
    return{
      status_answer:this.correct,
      status:this.win,
      response_description:[]
    }
  },
  props:['correct','description','win'],
  methods:{
    heightIntermediateWindow(){

      const elem = document.querySelector('.test-cotainer-result-answers')
      const elem_em = elem.querySelector('.test-cotainer-result-emty-block')
      const elem_em_2= elem.querySelector('.test-cotainer-result-answers')
      const height_el = elem.clientHeight
    },
    sameAnswers(){
      this.response_description = Array.from(new Set(this.description))
    }

  },
  watch:{
    description() {
      this.sameAnswers()
    }
  },
  mounted() {
  }

}
</script>

<style scoped>

</style>
