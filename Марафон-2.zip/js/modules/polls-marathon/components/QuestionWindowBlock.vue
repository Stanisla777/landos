<template lang="pug">
  .test-cotainer-answer(
    v-bind:class="{mandatory:req}"
  )
    .test-window__number(
      v-if="circle_number"
      v-bind:data-color="[`${item_key}`]"
    )
      p <span>{{item_key}}</span>/<span>{{count_answers}}</span>
    p.test-window__question(
      v-html="question"
    )
    .test-item
      .test-window__col-variant.test-window__height-limitation(
        v-for ="(item,key,ind) in variants"
      )
        .test-window__item.test-window__radio-item.test-window__col-variant-item(
          v-for ="answer in item.DROPDOWN"
          @click="pass_clickVariant($event,answer.FIELD_WIDTH,(answer['~FIELD_PARAM'] || answer.FIELD_PARAM),answer.COLOR,answer.NAME_INPUT,answer.VALUE_INPUT)"
          v-bind:class="[answer.FIELD_WIDTH==1?'test-wintdow__item':'test-winfdow__item' ]"
        )
          input(
            v-bind:name="[`radio-${item_key}`]"
          )(type="radio",value="")
          p.fs-1rem.test-window__possible-answer(
            v-html="answer.MESSAGE"
          )
    .fty(
      v-if="btn_answer"
    )
    button.test-window__btn.btn.btn-slide-sub(type="button")(
      v-bind:class="{unact:req}"
      v-show="btn_answer"
      @click="pass_clickButtonAnswer"
    ) Ответить
</template>
<!---->
<script>
export default {
  name: "QuestionWindowBlock",
  props:['question','variants','item_key','btn_answer','circle_number','count_answers','required','current_answer','button_text'],
  data(){
    return{
      req:null,
    }
  },

  methods:{

    pass_clickVariant(elem,param_1,param_2,param_3,param_4,param_5){
      const element = elem.currentTarget
      this.$emit('event_clickVariant',[element,elem,param_1,param_2,param_3,param_4,param_5])
    },
    pass_clickButtonAnswer(elem){
      const element = elem.currentTarget
      this.$emit('event_clickButtonAnswer',[element])
    },
    requiredButton(){
      if(this.required==="Y"){
        this.req=true
      }
      else if(this.required==="N"){
        this.req=false
      }
    },
  },
  watch:{
    current_answer(){
      if(this.current_answer===true){

        const er = document.querySelectorAll('.test-window')
        er.forEach(function (item){
          const coor = item.getBoundingClientRect()
          const height = item.clientHeight

          const btn = item.querySelectorAll('.test-window__btn');
          for (let i=0;i<btn.length;i++){
            btn[i].setAttribute('style',`top:600px`)
          }
        })
      }

    }
  },
  mounted() {
    this.requiredButton()
  }
}
</script>

<style scoped>

</style>
