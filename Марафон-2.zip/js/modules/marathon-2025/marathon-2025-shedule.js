/* eslint-disable */
import Vue from 'vue';
import axios from 'axios';

export default function marathon2025Shedule() {
  const app = new Vue({
    el: '#marathon-2025-shedule',
    data: {
      currentMonth: null,
      currentYear: null,
      selectedDate: null,
      events: [],
      minDate: null,
      maxDate: null,
      screenWidth: window.innerWidth,
      screenHeight: window.innerHeight,
      contentObserver: null,
      resizeTimeout: null,
    },
    computed: {
      weekdays() {
        return ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
      },
      currentMonthName() {
        const months = [
          'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
          'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
        ];
        return months[this.currentMonth];
      },

      getDaysInGrid() {
        const days = [];
        const firstDay = new Date(this.currentYear, this.currentMonth, 1).getDay();
        const daysInMonth = new Date(this.currentYear, this.currentMonth + 1, 0).getDate();

        const prevMonth = this.currentMonth === 0 ? 11 : this.currentMonth - 1;
        const prevYear = this.currentMonth === 0 ? this.currentYear - 1 : this.currentYear;
        const daysInPrevMonth = new Date(prevYear, prevMonth + 1, 0).getDate();

        const prevDaysCount = firstDay === 0 ? 6 : firstDay - 1;

        for (let i = 0; i < prevDaysCount; i++) {
          const dayNumber = daysInPrevMonth - (prevDaysCount - 1 - i);
          const date = new Date(prevYear, prevMonth, dayNumber);
          const dateStr = this.formatDateForData(date);
          const normalizedDate = this.normalizeDate(dateStr);
          const eventItem = this.events.find(e => this.normalizeDate(e.date) === normalizedDate);

          days.push({
            number: dayNumber,
            date: dateStr,
            isPrevMonth: true,
            isNextMonth: false,
            hasEvents: !!eventItem,
            events: eventItem ? eventItem.events : [],
            month: prevMonth,
            year: prevYear
          });
        }

        for (let day = 1; day <= daysInMonth; day++) {
          const date = new Date(this.currentYear, this.currentMonth, day);
          const dateStr = this.formatDateForData(date);
          const normalizedDate = this.normalizeDate(dateStr);
          const eventItem = this.events.find(e => this.normalizeDate(e.date) === normalizedDate);

          days.push({
            number: day,
            date: dateStr,
            isPrevMonth: false,
            isNextMonth: false,
            hasEvents: !!eventItem,
            events: eventItem ? eventItem.events : [],
            month: this.currentMonth,
            year: this.currentYear
          });
        }

        const nextMonth = this.currentMonth === 11 ? 0 : this.currentMonth + 1;
        const nextYear = this.currentMonth === 11 ? this.currentYear + 1 : this.currentYear;

        while (days.length < 42) {
          const dayNumber = days.length - daysInMonth - prevDaysCount + 1;
          const date = new Date(nextYear, nextMonth, dayNumber);
          const dateStr = this.formatDateForData(date);
          const normalizedDate = this.normalizeDate(dateStr);
          const eventItem = this.events.find(e => this.normalizeDate(e.date) === normalizedDate);

          days.push({
            number: dayNumber,
            date: dateStr,
            isPrevMonth: false,
            isNextMonth: true,
            hasEvents: !!eventItem,
            events: eventItem ? eventItem.events : [],
            month: nextMonth,
            year: nextYear
          });
        }

        const weeks = [];
        for (let i = 0; i < days.length; i += 7) {
          weeks.push(days.slice(i, i + 7));
        }

        const filteredWeeks = weeks.filter(week => {
          return week.some(day => day.month === this.currentMonth && day.year === this.currentYear);
        });

        return filteredWeeks.flat();
      },

      eventsForSelectedDay() {
        if (!this.selectedDate) return [];
        const normalized = this.normalizeDate(this.selectedDate);
        const dayData = this.events.find(e => this.normalizeDate(e.date) === normalized);
        if (!dayData) return [];

        return [...dayData.events].sort((a, b) => {
          const order = [3, 1, 2];
          return order.indexOf(a.type) - order.indexOf(b.type);
        });
      },

      canGoPrev() {
        if (!this.minDate) return false;
        const current = this.currentYear * 12 + this.currentMonth;
        const min = this.minDate.year * 12 + this.minDate.month;
        return current > min;
      },

      canGoNext() {
        if (!this.maxDate) return false;
        const current = this.currentYear * 12 + this.currentMonth;
        const max = this.maxDate.year * 12 + this.maxDate.month;
        return current < max;
      },
    },

    methods: {
      // Плавный скролл
      handleEventLinkClick(event, link) {
        console.log('link');
        console.log(link);
        if (link && link.startsWith('#')) {
          event.preventDefault();
          const targetId = link.substring(1);
          const scrollTarget = document.getElementById(targetId);
          if (scrollTarget) {
            this.scrollToElement(scrollTarget, 1);
          }
        }
      },

      scrollToElement(targetElement, flag) {
        if (targetElement) {
          const startPosition = window.pageYOffset;
          const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset;

          let distance;
          if (flag === 0) {
            distance = targetPosition - startPosition - 118;
          } else if (flag === 1) {
            distance = targetPosition - startPosition;
          }

          const duration = 800;
          let startTime = null;

          const animation = (currentTime) => {
            if (startTime === null) startTime = currentTime;
            const timeElapsed = currentTime - startTime;
            const progress = Math.min(timeElapsed / duration, 1);
            const ease = easeInOutQuad(progress);
            window.scrollTo(0, startPosition + distance * ease);
            if (timeElapsed < duration) {
              requestAnimationFrame(animation);
            }
          };

          function easeInOutQuad(t) {
            return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
          }

          requestAnimationFrame(animation);
        }
      },

      updateScreenWidth() {
        const oldWidth = this.screenWidth;
        this.screenWidth = window.innerWidth;
        this.screenHeight = window.innerHeight;

        if (this.screenWidth >= 991 && oldWidth < 991) {
          // Переход на десктоп — пересчитываем
          this.$nextTick(() => {
            this.calculateCellHeightsForFixedHeight();
          });
        } else if (this.screenWidth < 991 && oldWidth >= 991) {
          // Переход на мобильный — сбрасываем inline-стили
          this.resetCellHeightsForMobile();
        }
      },

      // Рассчитываем высоту ячеек для фиксированной высоты календаря (510px)
      calculateCellHeightsForFixedHeight() {
        const calendarColumn = this.$refs.calendarColumn;
        if (!calendarColumn) return;

        const cells = calendarColumn.querySelectorAll('.marathon-2025__calendar-day');
        if (cells.length === 0) return;

        const calendarHeader = calendarColumn.querySelector('.marathon-2025__calendar-header');
        const dayHeaders = calendarColumn.querySelector('.marathon-2025__calendar-grid:first-child');

        const headerHeight = calendarHeader ? calendarHeader.offsetHeight : 0;
        const dayHeaderHeight = dayHeaders ? dayHeaders.offsetHeight : 0;

        const fixedCalendarHeight = 510;
        const availableHeight = fixedCalendarHeight - headerHeight - dayHeaderHeight;
        const rowCount = Math.ceil(this.getDaysInGrid.length / 7);
        const cellHeight = availableHeight / rowCount;

        cells.forEach(cell => {
          cell.style.height = `${cellHeight}px`;
        });
      },

      // Сбрасываем inline-стили высоты → используем CSS
      resetCellHeightsForMobile() {
        // Явная проверка вместо ?.
        if (this.$refs.calendarColumn) {
          const cells = this.$refs.calendarColumn.querySelectorAll('.marathon-2025__calendar-day');
          if (cells) {
            cells.forEach(cell => {
              cell.style.height = ''; // Удаляем inline-style
            });
          }
        }
      },

      setupContentObserver() {
        const eventsColumn = this.$el.querySelector('.marathon-2025__events-column');
        if (!eventsColumn) return;

        this.contentObserver = new MutationObserver(() => {
          // Для скролла в событиях — ничего не нужно делать
        });

        this.contentObserver.observe(eventsColumn, {
          childList: true,
          subtree: true,
          characterData: true,
          attributes: true
        });
      },

      parseEvents() {
        const eventAttr = this.$el.getAttribute('data-event');
        if (!eventAttr) return;

        try {
          let rawData = JSON.parse(eventAttr);

          this.events = rawData.map(item => ({
            date: this.normalizeBackendDate(item.date),
            events: Array.isArray(item.events) ? item.events : []
          }));

        } catch (e) {
          console.error('Ошибка парсинга data-event', e);
        }
      },

      normalizeBackendDate(backendDateStr) {
        if (!backendDateStr) return '';
        const [y, m, d] = backendDateStr.split('-');
        return `${d}.${m}.${y}`;
      },

      normalizeDate(dateStr) {
        if (!dateStr) return '';
        const [d, m, y] = dateStr.split('.');
        const dd = String(parseInt(d, 10)).padStart(2, '0');
        const mm = String(parseInt(m, 10)).padStart(2, '0');
        return `${dd}.${mm}.${y}`;
      },

      formatDateForData(date) {
        const d = String(date.getDate()).padStart(2, '0');
        const m = String(date.getMonth() + 1).padStart(2, '0');
        const y = date.getFullYear();
        return `${d}.${m}.${y}`;
      },

      formatDate(dateStr) {
        if (!dateStr) return '';
        const normalized = this.normalizeDate(dateStr);
        const [d, m, y] = normalized.split('.').map(Number);
        const months = [
          'января', 'февраля', 'марта', 'апреля', 'мая', 'июня',
          'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'
        ];
        return `${d} ${months[m - 1]} ${y}`;
      },

      getEventTypesForDay(day) {
        const uniqueTypes = [...new Set(day.events.map(event => event.type))];
        const order = [3, 1, 2];
        return uniqueTypes.sort((a, b) => order.indexOf(a) - order.indexOf(b));
      },

      getEventTitleByType(type) {
        const map = {
          1: 'Эфир',
          2: 'Розыгрыш',
          3: 'Тестирование'
        };
        return map[type] || 'Событие';
      },

      getEventTitle(eventObj) {
        return eventObj.title || 'Событие';
      },

      getEventDescription(eventObj) {
        return '';
      },

      selectDay(day) {
        if (!day.hasEvents) return;

        this.selectedDate = day.date;

        const selectedDateObj = this.parseDate(day.date);
        const selectedMonth = selectedDateObj.getMonth();
        const selectedYear = selectedDateObj.getFullYear();

        if (selectedMonth !== this.currentMonth || selectedYear !== this.currentYear) {
          this.currentMonth = selectedMonth;
          this.currentYear = selectedYear;
        }
      },

      isSelected(dateStr) {
        if (!this.selectedDate || !dateStr) return false;
        return this.normalizeDate(this.selectedDate) === this.normalizeDate(dateStr);
      },

      parseDate(dateStr) {
        const normalized = this.normalizeDate(dateStr);
        const [d, m, y] = normalized.split('.').map(Number);
        const date = new Date(y, m - 1, d);

        if (isNaN(date.getTime())) {
          console.warn('Invalid date parsed:', dateStr);
          return new Date(0);
        }

        return date;
      },

      calculateDateBounds() {
        if (this.events.length === 0) {
          const now = new Date();
          this.minDate = this.maxDate = { year: now.getFullYear(), month: now.getMonth() };
          return;
        }

        const dates = this.events.map(e => this.parseDate(e.date));
        const minDate = new Date(Math.min(...dates));
        const maxDate = new Date(Math.max(...dates));

        this.minDate = { year: minDate.getFullYear(), month: minDate.getMonth() };
        this.maxDate = { year: maxDate.getFullYear(), month: maxDate.getMonth() };
      },

      setDefaultMonth() {
        const now = new Date();

        const futureEvents = this.events
          .map(e => ({ ...e, dateObj: this.parseDate(e.date) }))
          .filter(e => e.dateObj >= now)
          .sort((a, b) => a.dateObj - b.dateObj);

        if (futureEvents.length > 0) {
          const targetDate = futureEvents[0].dateObj;
          this.currentYear = targetDate.getFullYear();
          this.currentMonth = targetDate.getMonth();
          return;
        }

        const pastEvents = this.events
          .map(e => ({ ...e, dateObj: this.parseDate(e.date) }))
          .sort((a, b) => b.dateObj - a.dateObj);

        if (pastEvents.length > 0) {
          const targetDate = pastEvents[0].dateObj;
          this.currentYear = targetDate.getFullYear();
          this.currentMonth = targetDate.getMonth();
          return;
        }

        this.currentYear = now.getFullYear();
        this.currentMonth = now.getMonth();
      },

      setDefaultSelection() {
        const now = new Date();

        const futureEvents = this.events
          .filter(e => this.parseDate(e.date) >= now)
          .sort((a, b) => this.parseDate(a.date) - this.parseDate(b.date));

        if (futureEvents.length > 0) {
          this.selectedDate = futureEvents[0].date;
          return;
        }

        const pastEvents = this.events
          .filter(e => this.parseDate(e.date) < now)
          .sort((a, b) => this.parseDate(b.date) - this.parseDate(a.date));

        if (pastEvents.length > 0) {
          this.selectedDate = pastEvents[0].date;
          return;
        }

        this.selectedDate = null;
      },

      prevMonth() {
        if (!this.canGoPrev) return;

        if (this.currentMonth === 0) {
          this.currentMonth = 11;
          this.currentYear--;
        } else {
          this.currentMonth--;
        }
      },

      nextMonth() {
        if (!this.canGoNext) return;

        if (this.currentMonth === 11) {
          this.currentMonth = 0;
          this.currentYear++;
        } else {
          this.currentMonth++;
        }
      }
    },

    watch: {
      currentMonth() {
        this.$nextTick(() => {
          if (this.screenWidth >= 991) {
            this.calculateCellHeightsForFixedHeight();
          } else {
            this.resetCellHeightsForMobile();
          }
        });
      }
    },

    mounted() {
      this.parseEvents();
      this.calculateDateBounds();
      this.setDefaultMonth();
      this.setDefaultSelection();

      this.$nextTick(() => {
        if (this.screenWidth >= 991) {
          this.calculateCellHeightsForFixedHeight();
        } else {
          this.resetCellHeightsForMobile();
        }
      });

      window.addEventListener('resize', this.updateScreenWidth);
      this.setupContentObserver();
    },

    beforeDestroy() {
      window.removeEventListener('resize', this.updateScreenWidth);
      if (this.contentObserver) {
        this.contentObserver.disconnect();
      }
    }
  });
}
