// eslint-disable-next-line no-unused-vars
function scroolToSection() {
  // eslint-disable-next-line camelcase
  const scroll_btn = document.querySelector('.js--scroll-to');
  // eslint-disable-next-line no-empty,camelcase
  if (scroll_btn) {
    scroll_btn.onclick = () => {
      const yOffset = -20;
      const element = document.querySelector('.js-educational-scroll');
      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    };
  }
}
function closeRemindCourse() {
  const close = document.querySelectorAll('.js--education-reminder-close');
  // eslint-disable-next-line no-restricted-syntax
  for (const item of close) {
    const parent = item.closest('.js-accordion-parent');
    const container = parent.querySelector('.js-accordion-body ');
    window.onresize = () => {
      container.style.maxHeight = `${container.scrollHeight}px`;
    };
    item.onclick = () => {
      // eslint-disable-next-line no-unused-vars,camelcase
      // eslint-disable-next-line no-restricted-syntax
      if (parent.classList.contains('active')) {
        parent.classList.remove('active');
        // eslint-disable-next-line camelcase
        container.style.maxHeight = 0;
        setTimeout(() => {
          parent.closest('.education__course-reminder').setAttribute('style', 'display:none');
        }, 500);
      }
    };
  }
}
// Эта не рабочая, но пригодится
// eslint-disable-next-line no-unused-vars
function closeRemindCourseScroll() {
  // eslint-disable-next-line func-names
  window.onscroll = function () {
    const fixed = document.querySelector('.education__course-reminder');
    // const intro = document.querySelector('.footer').offsetTop;
    const scrolled = window.pageYOffset + 857;
    const element = document.querySelector('.footer');
    const y = element.getBoundingClientRect().top + window.pageYOffset;
    // eslint-disable-next-line no-undef
    if (fixed && element && !fixed.classList.contains('unactive')) {
      if (scrolled > y) {
        fixed.style = 'display: none';
      } else {
        fixed.style = 'display: block';
      }
    }
  };
}

export default function educationalSection() {
  scroolToSection();
  closeRemindCourse();
  // closeRemindCourseScroll();
}
