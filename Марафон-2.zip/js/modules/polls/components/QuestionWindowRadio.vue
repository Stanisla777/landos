<template lang="pug" xmlns:true_answer="">
  .test-cotainer-answer(
    v-bind:class="{mandatory:req}"
  )
    .test-window__number(
      v-if="circle_number"
      v-bind:data-color="[`${item_key}`]"
    )
      p <span>{{item_key}}</span>/<span>{{count_answers}}</span>
    p.test-window__question(
      v-html="question"
    )
    .test-item
      .test-window__wrap-chec
        .test-window__radio.test-window__height-limitation
          .test-window__item.test-window__radio-item.choose(
            v-for ="(answer,key,ind) in variants"
            @click="pass_clickVariant($event,answer.FIELD_WIDTH,(answer['~FIELD_PARAM'] || answer.FIELD_PARAM),answer.COLOR,answer.NAME_INPUT,answer.VALUE_INPUT)"
            v-bind:class="[(answer.FIELD_WIDTH==1)?'test-wintdow__item':(answer.FIELD_WIDTH==2)?'test-winadow__item':'test-winfdow__item' ]"
          )
            .test-window__item-container-answer
              input(
                v-bind:id="[`radio-${item_key}-${key}`]"
                v-on:click.stop=""
                v-bind:name="[`radio-${item_key}`]"
              )(type="radio",value="")
              label.fs-1rem.test-window__possible-answer(
                v-bind:for="[`radio-${item_key}-${key}`]"
                v-html="answer.MESSAGE"
                )
              .test-window__field-for-variant(
                v-if="answer.FIELD_WIDTH==2"
              )
                .test-window__item.test-window__textarea
                  textarea.radio-for-variant(
                    @change="pass_input_radio_another($event)"
                    @input="limitInput"
                    v-bind:placeholder="answer.PLACEHOLDER"
                  )(name="",maxlength="1001")
                  p.test-window__textarea-error.
                    Превышено допустимое количество в 1000 символов
    button.test-window__btn.btn.btn-slide-sub(type="button")(
      v-bind:class="{unact:req}"
      v-if="btn_answer"
      @click="pass_clickButtonAnswer"
    ) {{button_text}}
</template>

<script>
export default {
  name: "QuestionWindowRadio",
  props:['question','variants','item_key','btn_answer','circle_number','count_answers','required','current_answer','button_text'],

  data(){
    return{
      true_answer:0,
      req:null,
      top:0,
      name_radio:null,
      input:null
    }
  },
  methods:{
    pass_clickVariant(elem,param_1,param_2,param_3,param_4,param_5){
      const element = elem.currentTarget
      this.name_radio=param_4
      this.$emit('event_clickVariant',[element,elem,param_1,param_2,param_3,param_4,param_5])
    },
    pass_clickButtonAnswer(elem){
      const element = elem.currentTarget
      this.$emit('event_clickButtonAnswer',[element])
    },
    trueAnswer(item){
      const countTru = this.countTrueAnswer
      const variant = this.variants
      const keys = Object.values(variant)
      let el = this.true_answer
      let true_answer=0
      keys.forEach(function (item){
        if(item.FIELD_PARAM==='Y'){
          countTru()
        }
      })
      this.true_answer = true_answer
    },
    requiredButton(){
      if(this.required==="Y"){
        this.req=true
      }
      else if(this.required==="N"){
        this.req=false
      }
    },
    pass_input_radio_another(elem){
      const element = elem.currentTarget
      this.$emit('event_input_radio_another',[element,element.value,this.name_radio])
    },
    limitInput(el) {
      const max = 1001
      const field=el.currentTarget
      // field.value = field.value.substring(0, max);
      const parent = field.closest('.test-window__item')
      const item = parent.querySelectorAll('.test-window__textarea-error')
      if (field.value.length === max) {
        item.forEach(function (item){
          item.setAttribute('style','display:block')
        })
      }
      else
      {
        item.forEach(function (item){
          item.setAttribute('style','display:none')
        })
      }
    }
  },
  mounted() {
    this.requiredButton()
  },
  watch:{
    current_answer(){
      if(this.current_answer===true){

        const er = document.querySelectorAll('.test-window')
        er.forEach(function (item){
          const coor = item.getBoundingClientRect()
          const height = item.clientHeight

          const btn = item.querySelectorAll('.test-window__btn');
          for (let i=0;i<btn.length;i++){
            btn[i].setAttribute('style',`top:600px`)
          }
        })
      }

    }
  },


}
</script>

<style scoped>

</style>
