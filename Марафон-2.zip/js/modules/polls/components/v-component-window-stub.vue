<template lang="pug">
  .polls__window-stub.js--window-stub
</template>
<script>
import Storage from '../development-tools/state.vue';
import eventBus from '../development-tools/eventBus.vue';

export default {
  name: 'v-conponent-window-stub',
  props:[],
  data(){
    return {
    }
  },
  methods:{


  },
  mounted(){

  },
  computed:{


  },
  created() {
  },
  watch:{
  },
  components:{
  }
};
</script>
<style scoped>
</style>
