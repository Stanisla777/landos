<script>
import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios';

Vue.use(Vuex);

export default new Vuex.Store({
  state:{
    number_tel_show:'',

  },
  getters:{

    NUMBERTELSHOW(state){
      return state.number_tel_show
    },

  },
  mutations:{

    mutationUserData(state,received_perem){
      state.user_data = received_perem
    },


  },
  actions:{
  //данные пользователя
    ActionUserData({commit,state},param){
      commit('mutationUserData',param)
    },


  },
})
</script>
