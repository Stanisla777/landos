<template lang="pug">
  .property-calculator__final-calc
    .refinancing-calc__final-item-block
      p.refinancing-calc__final-main-title Результаты расчета


    .refinancing-calc__final-item-block
      .property-calculator__final-item-row
        .credit-calc__final-item-col
          p.refinancing-calc__final-item-value(
            v-if="annuity_monthly_payment_old_credid!=='не число'"
          ) {{annuity_monthly_payment_old_credid}} ₽
          p.refinancing-calc__final-item-value(
            v-if="annuity_monthly_payment_old_credid==='не число'"
          ) 0 ₽

          p.property-calculator__final-item-key.credit-calc__final-item-key Ежемесячный платеж
        .credit-calc__final-item-col
          p.refinancing-calc__final-item-value(
            v-if="annuity_overpayment_old_credit!=='не число'"
          ) {{annuity_overpayment_old_credit}} ₽
          p.refinancing-calc__final-item-value(
            v-if="annuity_overpayment_old_credit==='не число'"
          ) 0 ₽

          p.property-calculator__final-item-key.credit-calc__final-item-key Переплата
    .refinancing-calc__final-item-block
      .property-calculator__final-item-row
        .credit-calc__final-item-col
          p.refinancing-calc__final-item-value(
            v-if="annuity_debt_plus_interest!=='не число'"
          ) {{annuity_debt_plus_interest}} ₽
          p.refinancing-calc__final-item-value(
            v-else
          ) 0 ₽

          p.property-calculator__final-item-key.credit-calc__final-item-key Всего выплат
        .credit-calc__final-item-col
          p.refinancing-calc__final-item-value {{psk}} %
          p.property-calculator__final-item-key.credit-calc__final-item-key  Полная стоимость кредита




    button(type="button").property-calculator__final-btn-call-schedule(
     @click="callModal"
    ) График платежей


</template>
<script>
import Vue from 'vue';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-component-final-calc',
  props:[],
  data(){
    return {
      data_type_payment:null
    }
  },
  methods:{
    callModal(){
      if (this.annuity_monthly_payment_old_credid!=='не число') {
        Storage.dispatch('ActionModal',true)
        document.body.classList.add('body-modal')
      }



    },

  },
  mounted(){


  },
  computed:{

    annuity_monthly_payment_old_credid(){

      return Storage.getters.ANNUITYMONTHLYPAYMENTOLDCREDIT.toLocaleString('ru')
    },
    annuity_overpayment_old_credit(){
      return Storage.getters.ANNUITYOVERPAYMENTOLDCREDIT.toLocaleString('ru')
    },

    annuity_debt_plus_interest(){
      return Storage.getters.ANNUITYDEBTPLUSINTEREST.toLocaleString('ru')
    },

    psk(){
      return Storage.getters.PSK
    },
    payment_list(){
      return Storage.getters.PAYMENTLIST
    }



  },
  watch:{
    annuity_monthly_payment_old_credid(){
      // const elem = document.querySelector('.property-calculator__final-preload')
      // if (elem){
      //   elem.setAttribute('style','display:none;')
      // }
    },
    payment_list(){
      // const elem = document.querySelector('.property-calculator__final-preload')
      // if (elem){
      //   elem.setAttribute('style','display:none;')
      // }
    }
  },
  created(){
    // eventBus.$on('receivePaymentType',(param)=>{
    //   this.data_type_payment=param
    // })
  },

  components:{}
};
</script>
<style scoped>
</style>
