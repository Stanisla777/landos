export default function keySelect() {
    const select = document.querySelector('.js--key-select');

    if (select) {
        select.addEventListener('click', (e) => {
            if (e.target.classList.contains('js--key-select-field')) {
                select.classList.toggle('active');
            } else if (e.target.classList.contains('js--key-select-back')) {
                select.classList.remove('active');
            } else if (e.target.classList.contains('js--key-select-item')) {
                e.target.classList.toggle('active');
            } else {
                e.preventDefault();
            }
        });
    }
}
