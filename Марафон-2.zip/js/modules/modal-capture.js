// eslint-disable-next-line import/prefer-default-export
export default function modalCapture() {
  // eslint-disable-next-line no-unused-vars,camelcase
  const btnCall = document.querySelector('#modalchat');
  // eslint-disable-next-line camelcase
  const footer = document.querySelector('.footer');
  // eslint-disable-next-line camelcase
  const feedbackForm = document.querySelector('.capture-form');
  if (btnCall && footer && feedbackForm) {
    // eslint-disable-next-line func-names
    document.onscroll = function () {
      // eslint-disable-next-line camelcase
      const top_el = footer.getBoundingClientRect().top;
      const heightScreen = document.documentElement.clientHeight;
      // eslint-disable-next-line no-unused-vars
      const body = document.querySelector('body');
      // eslint-disable-next-line camelcase
      const g = top_el - heightScreen;
      if (g <= 0) {
        btnCall.classList.add('open');
      } else if (g > 0) {
        btnCall.classList.remove('open');
      }
    };
  }
}
