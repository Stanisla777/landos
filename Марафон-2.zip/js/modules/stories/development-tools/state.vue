<script>
import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios';

Vue.use(Vuex);

export default new Vuex.Store({
  state:{
    STORIES: {
      "OPEN":{
        "story_id": null,
        "slide_id": null
      },
      "SLIDER_STORIES_MAIN_PAGE": [
        {
          "id": "1077",
          "image": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/cc1/cd69jl27vee4lj8ln3y8z13zihxh3v6j/1-_4_.jpg",
          "title": "IT-ипотекаР"
        },
        {
          "id": "1048",
          "image": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/70b/134e0jxv6frpy8mew2gx6c1lzg1r44wx/2-_3_.jpg",
          "title": "IT-ипотека"
        },
        {
          "id": "1141",
          "image": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/70b/134e0jxv6frpy8mew2gx6c1lzg1r44wx/2-_3_.jpg",
          "title": "Льготная <b>ипотека</b>"
        },
        {
          "id": "1075",
          "image": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/70b/134e0jxv6frpy8mew2gx6c1lzg1r44wx/2-_3_.jpg",
          "title": "О нас"
        },
        {
          "id": "1072",
          "image": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/70b/134e0jxv6frpy8mew2gx6c1lzg1r44wx/2-_3_.jpg",
          "title": "Свежее на сайте"
        },
        {
          "id": "1066",
          "image": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/70b/134e0jxv6frpy8mew2gx6c1lzg1r44wx/2-_3_.jpg",
          "title": "Последние"
        },
        {
          "id": "1063",
          "image": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/70b/134e0jxv6frpy8mew2gx6c1lzg1r44wx/2-_3_.jpg",
          "title": "Новости"
        },
        {
          "id": "1057",
          "image": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/70b/134e0jxv6frpy8mew2gx6c1lzg1r44wx/2-_3_.jpg",
          "title": "Сервисы"
        },
        {
          "id": "1054",
          "image": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/70b/134e0jxv6frpy8mew2gx6c1lzg1r44wx/2-_3_.jpg",
          "title": "Каталог жилищных программ"
        },
        {
          "id": "1051",
          "image": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/70b/134e0jxv6frpy8mew2gx6c1lzg1r44wx/2-_3_.jpg",
          "title": "Ипотечные программы"
        },
        {
          "id": "1088",
          "image": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/70b/134e0jxv6frpy8mew2gx6c1lzg1r44wx/2-_3_.jpg",
          "title": "Ипотечные программы"
        }
      ],
      "DETAIL": [
        {
          "story_id": "1077",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1714&utm-source=story&utm-story-code=kak-snyat-obremenenie-s-kvartiry",
          "slides": [
            {
              "slide_id": "23680",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1714&storySlideId=23680&utm-source=story-slide&utm-story-code=kak-snyat-obremenenie-s-kvartiry",
              "text_color": "LIGHT",
              "title": {
                "type": 1,
                "text": "Как снять обременение с квартиры?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": ""
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/cc1/cd69jl27vee4lj8ln3y8z13zihxh3v6j/1-_4_.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://спроси.дом.рф/instructions/kak-snyat-obremenenie-s-kvartiri/?utm_source=site&utm_medium=stories&utm_campaign=1714_%D0%9A%D0%B0%D0%BA+%D1%81%D0%BD%D1%8F%D1%82%D1%8C+%D0%BE%D0%B1%D1%80%D0%B5%D0%BC%D0%B5%D0%BD%D0%B5%D0%BD%D0%B8%D0%B5+%D1%81+%D0%BA%D0%B2%D0%B0%D1%80%D1%82%D0%B8%D1%80%D1%8B%3F&utm_content=23689&utm_term=https%3A%2F%2F%D1%81%D0%BF%D1%80%D0%BE%D1%81%D0%B8.%D0%B4%D0%BE%D0%BC.%D1%80%D1%84%2Finstructions%2Fkak-snyat-obremenenie-s-kvartiri%2F"
                }
              ]
            },
            {
              "slide_id": "23683",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1714&storySlideId=23683&utm-source=story-slide&utm-story-code=kak-snyat-obremenenie-s-kvartiry",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Обременение",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "После оформления ипотеки квартира переходит в собственность покупателя, но до момента полного погашения кредита она остается в залоге (или под обременением)"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/70b/134e0jxv6frpy8mew2gx6c1lzg1r44wx/2-_3_.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "23686",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1714&storySlideId=23686&utm-source=story-slide&utm-story-code=kak-snyat-obremenenie-s-kvartiry",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Снять обременение",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "можно только после выплаты ипотечного кредита (после внесения последнего платежа по ипотеке или полного досрочного погашения долга)"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/8a3/jimc347mvcrz0jw5qrx0aqwzzob0hodq/3-_5_.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "23689",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1714&storySlideId=23689&utm-source=story-slide&utm-story-code=kak-snyat-obremenenie-s-kvartiry",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Как правильно",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "оформить снятие обременения? Подробнее об этом – в нашем материале"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/283/9yzjeygrh8xj2z392xxjqg5ia1i79ptm/4-_2_.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://спроси.дом.рф/instructions/kak-snyat-obremenenie-s-kvartiri/?utm_source=site&utm_medium=stories&utm_campaign=1714_%D0%9A%D0%B0%D0%BA+%D1%81%D0%BD%D1%8F%D1%82%D1%8C+%D0%BE%D0%B1%D1%80%D0%B5%D0%BC%D0%B5%D0%BD%D0%B5%D0%BD%D0%B8%D0%B5+%D1%81+%D0%BA%D0%B2%D0%B0%D1%80%D1%82%D0%B8%D1%80%D1%8B%3F&utm_content=23689&utm_term=https%3A%2F%2F%D1%81%D0%BF%D1%80%D0%BE%D1%81%D0%B8.%D0%B4%D0%BE%D0%BC.%D1%80%D1%84%2Finstructions%2Fkak-snyat-obremenenie-s-kvartiri%2F"
                }
              ]
            }
          ]
        },
        {
          "story_id": "1048",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1684&utm-source=story&utm-story-code=kak-postroit-dom",
          "slides": [
            {
              "slide_id": "19840",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1684&storySlideId=19840&utm-source=story-slide&utm-story-code=kak-postroit-dom",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Как построить дом?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "Мы запустили новый бесплатный обучающий курс «Как построить дом от А до Я»"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/45a/z41wpg3h5tu7mtxm5vmg1zftmwstqttw/1.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "19843",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1684&storySlideId=19843&utm-source=story-slide&utm-story-code=kak-postroit-dom",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "О чем этот курс?",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Вы узнаете весь путь частного домостроения: от поиска земельного участка до строительства дома"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/896/meky5mo4gz2744sgn6l8fkz9yd4q0ubn/2.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "19846",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1684&storySlideId=19846&utm-source=story-slide&utm-story-code=kak-postroit-dom",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Для кого этот курс?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "Курс предназначен для всех, кто только мечтает построить свой дом или уже находится на этом пути и хочет узнать больше о частном домостроении"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/99f/gsxv1ndj0f03xz7k3lb0pijimbbvyxm5/3.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "19849",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1684&storySlideId=19849&utm-source=story-slide&utm-story-code=kak-postroit-dom",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Благодаря курсу вы сможете:",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "— Выбрать правильный участок<br />\n— Безопасно оформить сделку<br />\n— Сэкономить благодаря господдержке<br />\n— Выбрать проект, подрядчика и построить дом<br />\n— Оформить все документы корректно и своевременно"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/c32/q96iovk7xafyanzt6wp75kp003fv9sk9/4.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "19852",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1684&storySlideId=19852&utm-source=story-slide&utm-story-code=kak-postroit-dom",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Сколько стоит курс?",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Курс «Как построить дом от А до Я» каждый может пройти абсолютно бесплатно"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/c01/2vhs9xj41b83pdosw229ew2xcq44dg8k/5.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Пройти курс",
                  "url": "https://спроси.дом.рф/education/courses/kak-postroit-dom-ot-a-do-ya/?utm_source=site&utm_medium=stories&utm_campaign=1684_%D0%9A%D0%B0%D0%BA+%D0%BF%D0%BE%D1%81%D1%82%D1%80%D0%BE%D0%B8%D1%82%D1%8C+%D0%B4%D0%BE%D0%BC%3F&utm_content=19852&utm_term=https%3A%2F%2F%D1%81%D0%BF%D1%80%D0%BE%D1%81%D0%B8.%D0%B4%D0%BE%D0%BC.%D1%80%D1%84%2Feducation%2Fcourses%2Fkak-postroit-dom-ot-a-do-ya%2F"
                }
              ]
            }
          ]
        },
        {
          "story_id": "1648",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1648&utm-source=story&utm-story-code=kak-vygodno-vzyat-ipoteku",
          "slides": [
            {
              "slide_id": "19174",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1648&storySlideId=19174&utm-source=story-slide&utm-story-code=kak-vygodno-vzyat-ipoteku",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Как выгодно взять ипотеку?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "Какие меры господдержки позволяют сэкономить до 2 млн рублей на ипотечном кредите?"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/d12/63w0dzoa5k1v3tlfbvlmxynkbxuk0da5/1.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "19177",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1648&storySlideId=19177&utm-source=story-slide&utm-story-code=kak-vygodno-vzyat-ipoteku",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "В России",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "действует целый ряд программ, позволяющих&nbsp;значительно сэкономить при покупке жилья в&nbsp;ипотеку"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/8a3/kkrmlx8zq5e7ll5v6dznmywf2o7ix9ov/2.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "19180",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1648&storySlideId=19180&utm-source=story-slide&utm-story-code=kak-vygodno-vzyat-ipoteku",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Какие программы помогут?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "— Государственная программа «Семейная ипотека»<br>\r\n — Материнский (семейный) капитал<br>\r\n — Выплата на погашение кредита для многодетных семей<br>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/ac3/j6gv4c4ak6xquckx0huxetjkjno2n0tg/3.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "19183",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1648&storySlideId=19183&utm-source=story-slide&utm-story-code=kak-vygodno-vzyat-ipoteku",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Какие программы помогут?",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "<p>\r\n\t — Имущественный вычет при покупке жилья\r\n</p>\r\n<p>\r\n\t — Налоговый вычет с процентов по ипотечному кредиту\r\n</p>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/6f7/egdwbbdftm8s2naqrbgeha5wlfs0uq77/4.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "19186",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1648&storySlideId=19186&utm-source=story-slide&utm-story-code=kak-vygodno-vzyat-ipoteku",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Другие льготные программы",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "В&nbsp;России также действуют и&nbsp;другие программы поддержки семей, планирующих улучшить жилищные условия"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/4af/adg5vvs68hglbrpdkoe4xxc3ua5l5lp6/5.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "19189",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1648&storySlideId=19189&utm-source=story-slide&utm-story-code=kak-vygodno-vzyat-ipoteku",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Подробнее",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "о&nbsp;программах&nbsp;поддержки рассказали в нашей статье"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/a79/086ivs91g0w7w9k2cpkm8konjynelzq6/6.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Узнать",
                  "url": "https://спроси.дом.рф/instructions/kak-sekonomit-na-ipoteke/?utm_source=site&utm_medium=stories&utm_campaign=1648_%D0%9A%D0%B0%D0%BA+%D0%B2%D1%8B%D0%B3%D0%BE%D0%B4%D0%BD%D0%BE+%D0%B2%D0%B7%D1%8F%D1%82%D1%8C+%D0%B8%D0%BF%D0%BE%D1%82%D0%B5%D0%BA%D1%83%3F&utm_content=19189&utm_term=https%3A%2F%2F%D1%81%D0%BF%D1%80%D0%BE%D1%81%D0%B8.%D0%B4%D0%BE%D0%BC.%D1%80%D1%84%2Finstructions%2Fkak-sekonomit-na-ipoteke%2F"
                }
              ]
            }
          ]
        },
        {
          "story_id": "1618",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1618&utm-source=story&utm-story-code=kak-sekonomit-na-kommunalke",
          "slides": [
            {
              "slide_id": "18679",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1618&storySlideId=18679&utm-source=story-slide&utm-story-code=kak-sekonomit-na-kommunalke",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Как сэкономить на коммунальных платежах?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "— Государственная поддержка в оплате ЖКУ;<br>\r\n — Отказ от ненужных расходов по квартплате;<br>\r\n —&nbsp;Простые правила и хитрости, которые позволяют платить за квартиру меньше.<br>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/752/cyn7t0y9l2jq1ua2ladhkr4avdj27vgk/1_5_.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "18682",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1618&storySlideId=18682&utm-source=story-slide&utm-story-code=kak-sekonomit-na-kommunalke",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Кто может получить субсидию на оплату ЖКУ:",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "— Ветераны<br>\r\n — Инвалиды и семьи с детьми-инвалидами<br>\r\n — Семьи с низкими доходами<br>\r\n — Отдельные категории, установленные регионами<br>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/013/iovbv3celwyx340vk3e9z942raxs0thm/2_3_.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "18685",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1618&storySlideId=18685&utm-source=story-slide&utm-story-code=kak-sekonomit-na-kommunalke",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "От каких коммунальных услуг можно отказаться?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "— ТВ антенна<br>\r\n — Стационарный телефон<br>\r\n — Радиоточка<br>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/e6f/gicy8o40yhappj5ptbmimwu9p5itka7q/3_2_.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "18688",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1618&storySlideId=18688&utm-source=story-slide&utm-story-code=kak-sekonomit-na-kommunalke",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Как еще сэкономить на коммунальных платежах?",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Читайте в нашей инструкции"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/iblock/7f0/7ex65spkbkb1mfylkfmf2voig7gztxck/4_1_.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://спроси.дом.рф/instructions/kak-sekonomit-na-kommunalnykh-platezhakh/?utm_source=site&utm_medium=stories&utm_campaign=1618_%D0%9A%D0%B0%D0%BA+%D1%81%D1%8D%D0%BA%D0%BE%D0%BD%D0%BE%D0%BC%D0%B8%D1%82%D1%8C+%D0%BD%D0%B0+%D0%BA%D0%BE%D0%BC%D0%BC%D1%83%D0%BD%D0%B0%D0%BB%D0%BA%D0%B5%3F&utm_content=18688&utm_term=https%3A%2F%2F%D1%81%D0%BF%D1%80%D0%BE%D1%81%D0%B8.%D0%B4%D0%BE%D0%BC.%D1%80%D1%84%2Finstructions%2Fkak-sekonomit-na-kommunalnykh-platezhakh%2F"
                }
              ]
            }
          ]
        },
        {
          "story_id": "1554",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1554&utm-source=story&utm-story-code=kak-vybrat-vklad",
          "slides": [
            {
              "slide_id": "17787",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1554&storySlideId=17787&utm-source=story-slide&utm-story-code=kak-vybrat-vklad",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Как выбрать вклад?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "<b> Рассказываем, от чего зависит доходность, на какие параметры стоит обратить внимание и как выбрать самый выгодный вклад"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/b6d/pj1bb6s3otacz0uq7p8prh12hah35exw/470.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17790",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1554&storySlideId=17790&utm-source=story-slide&utm-story-code=kak-vybrat-vklad",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Какие бывают вклады?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "- Срочные вклады<br>\r\n- Бессрочные вклады <br>(\"до востребования\")<br>\r\n- Накопительные счета<br>\r\n<br>\r\nПри открытии вклада учитывайте, что его доходность напрямую зависит от условий размещения"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/8d0/803gb1p2slmyk6ws2xvmj2dz0of53dfl/465.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17793",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1554&storySlideId=17793&utm-source=story-slide&utm-story-code=kak-vybrat-vklad",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Как рассчитать доход <br>по вкладу?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "Воспользуйтесь калькулятором и изучите, какие параметры влияют на доходность <br>\r\n <br>\r\n- Выберите валюту вклада<br>\r\n- Укажите сумму вклада и срок размещения&nbsp;<br>\r\n- Отметьте опции, которые вам нужны<br>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/d77/mb40w2h4dszdngsa7jiy3m5edps2lyqu/466.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17799",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1554&storySlideId=17799&utm-source=story-slide&utm-story-code=kak-vybrat-vklad",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Подробнее",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "о выборе подходящего<br>для вас вклада рассказали в статье"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/30a/ljbw42dl0tvzcbmr1d2nff5ktu2tt31k/467.jpg"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://domrfbank.ru/blog/kak-vybrat-vklad/?utm_source=sprosi.dom.rf&utm_medium=referral&utm_campaign=ref_602_deposit_rf_main.banner&utm_content=https://спроси.дом.рф/"
                }
              ]
            }
          ]
        },
        {
          "story_id": "1497",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1497&utm-source=story&utm-story-code=vyplata-450-tys-cherez-gosuslugi",
          "slides": [
            {
              "slide_id": "17196",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1497&storySlideId=17196&utm-source=story-slide&utm-story-code=vyplata-450-tys-cherez-gosuslugi",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Знаете ли вы?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "<p>\r\n\t<b> Что подать заявление на выплату <br> 450 тыс. рублей можно через <br> Госуслуги? <b>\r\n</p>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/968/fj5122fa95gkat1uxal3r1z4bmx8b0f6/29.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17199",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1497&storySlideId=17199&utm-source=story-slide&utm-story-code=vyplata-450-tys-cherez-gosuslugi",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Какие документы нужны?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "<p>\r\n\t- Паспорт<br>\r\n\t- Свидетельства о рождении детей<br>\r\n\t- Паспорта детей, которым <br> исполнилось 14 лет<br>\r\n\t- Текущий кредитный договор<br>\r\n\t- Все договоры о <br> рефинансировании (при наличии)<br>\r\n\t- Документы о приобретении <br> или строительстве недвижимости\r\n</p>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/b0e/2wlhtg5cxoadcckzr2871c56463ngmnm/30.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17202",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1497&storySlideId=17202&utm-source=story-slide&utm-story-code=vyplata-450-tys-cherez-gosuslugi",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Подробнее",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "<p>\r\n\t о том, как подать заявление <br> на выплату 450 тыс. рублей <br> через Госуслуги рассказали <br> в материале:\r\n</p>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/9d9/41c54zalc340qm2hia8r741saw6kaswh/31.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/instructions/kak-podat-zayavlenie-na-vyplatu-450-tys-rubley-cherez-gosuslugi/?utm_source=site&utm_medium=stories&utm_campaign=instruction&utm_content=28-02-23&utm_term=utm-stories-sprosi "
                }
              ]
            }
          ]
        },
        {
          "story_id": "1485",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1485&utm-source=story&utm-story-code=paevoy-vznos",
          "slides": [
            {
              "slide_id": "17133",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1485&storySlideId=17133&utm-source=story-slide&utm-story-code=paevoy-vznos",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Паевой взнос",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "<p>\r\n\t<b>  Рассказываем, как вернуть <br> паевой взнос при выходе <br> из кооператива <b> \r\n</p>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/96e/idy260i1o44e8dk6j3pouq7noeb1pirn/25.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17136",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1485&storySlideId=17136&utm-source=story-slide&utm-story-code=paevoy-vznos",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Как вернуть паевой <br> взнос при выходе из кооператива?",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "<p>\r\n</p>\r\n 1. Подать заявление<br>\r\n2. Дождитесь соответствующего решения<br>\r\n3. Получите средства своего пая<br>\r\n4. Верните квартиру ЖСК<br>\r\n<p>\r\n</p>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/64a/b9yiadvnr24fcfxols2d5f0yisd2eyp7/26.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17139",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1485&storySlideId=17139&utm-source=story-slide&utm-story-code=paevoy-vznos",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Как долго ждать возврата?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "<p>\r\n\tСрок выплаты пая <br> устанавливается ЖСК, <br> но он не должен <br> превышать 2 месяцев\r\n</p>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/b38/41zpip4skq90jwmp9e0pjia7nq2pojgb/27.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17142",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1485&storySlideId=17142&utm-source=story-slide&utm-story-code=paevoy-vznos",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Как выйти из ЖСК?",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "<p>\r\n\tРассказали в статье\r\n</p>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/b42/y9harhnflmfs2cp3eideb8u9akydmwa0/28.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/instructions/kak-vyyti-iz-zhsk/?utm_source=site&utm_medium=stories&utm_campaign=instruction&utm_content=27-02-23&utm_term=utm-stories-sprosi"
                }
              ]
            }
          ]
        },
        {
          "story_id": "1482",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1482&utm-source=story&utm-story-code=nedeystvitelnaya-sdelka",
          "slides": [
            {
              "slide_id": "17106",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1482&storySlideId=17106&utm-source=story-slide&utm-story-code=nedeystvitelnaya-sdelka",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Недействительная сделка",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "Рассказываем, почему <br> сделку могут признать <br> недействительной"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/b96/12bcdlg594nvapw3eu1a8y3kv3bldrnr/20.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17109",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1482&storySlideId=17109&utm-source=story-slide&utm-story-code=nedeystvitelnaya-sdelka",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Недействительна, если:",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "- Сделка заключена с  нарушением <br> требований  закона\r\n<br>\r\n<br>\r\n- Цель сделки заведомо <br> противоречит закон"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/5f8/av32uu1donmb970wgs547i1n53e85y55/21.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17112",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1482&storySlideId=17112&utm-source=story-slide&utm-story-code=nedeystvitelnaya-sdelka",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Недействительна, если:",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "- Стороны не  намеревались <br> создать правовые последствия <br> или заключили договор <br> для прикрытия другой сделки\r\n<br>\r\n<br>\r\n- Если сделка заключена с <br> представителем, который <br> не обладает такими <br> полномочиями"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/1c3/lyhd11l91r9xp95xti78rbj2vstw01qi/23.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17115",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1482&storySlideId=17115&utm-source=story-slide&utm-story-code=nedeystvitelnaya-sdelka",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Недействительна, если:",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "- Если лицо заключило сделку <br> под влиянием  существенного <br> заблуждения, обмана, насилия или угрозы\r\n<br>\r\n<br>\r\n- Кабальная сделка"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/851/dkpce3d0kw2wkl51upq6f2l13ahnesg8/22.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17118",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1482&storySlideId=17118&utm-source=story-slide&utm-story-code=nedeystvitelnaya-sdelka",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Подробнее",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "о том, почему сделку могут <br> признать недействительной, <br> рассказали в материале:"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/4ad/o38l7rexbcjvv5lj3z0lkpk791wpesih/24.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/instructions/priznanie-sdelki-nedeystvitelnoy/?utm_source=site&utm_medium=stories&utm_campaign=instruction&utm_content=21-02-23&utm_term=utm-stories-sprosi"
                }
              ]
            }
          ]
        },
        {
          "story_id": "1476",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1476&utm-source=story&utm-story-code=nalog-pri-nasledovanie",
          "slides": [
            {
              "slide_id": "17079",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1476&storySlideId=17079&utm-source=story-slide&utm-story-code=nalog-pri-nasledovanie",
              "text_color": "LIGHT",
              "title": {
                "type": 1,
                "text": "Налог при вступлении в наследование",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": ""
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/16b/7cfselhnh0um93e53k2t5dmts3o08am9/17.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17082",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1476&storySlideId=17082&utm-source=story-slide&utm-story-code=nalog-pri-nasledovanie",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Нужно ли платить?",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "<p>\r\n\t<b>Да. </b>Наследуемые денежные средства, недвижимость и другие вещи, считаются доходом. Однако наследство не облагается НДФЛ\r\n</p>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/0e2/udkf5fk76r4jivst5c6r2ipg6ei32g28/2.1.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17085",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1476&storySlideId=17085&utm-source=story-slide&utm-story-code=nalog-pri-nasledovanie",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Важно!",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "<p>\r\n\t Наследникам необходимо&nbsp; оплатить госпошлину:\r\n</p>\r\n<p>\r\n\t- Близкие родственники — 0,3%\r\n</p>\r\n<p>\r\n\t- Все остальные наследники — 0,6%\r\n</p>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/f8a/xp769q3t4xzhk15j80z3lverbd1h1ju3/19.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17088",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1476&storySlideId=17088&utm-source=story-slide&utm-story-code=nalog-pri-nasledovanie",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Подробнее",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "<p>\r\n\t о налоге на наследование рассказали в материале\r\n</p>\r\n <br>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/771/r8va7al9ngemia6y1h8zbu8peseuz36r/4.1.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/instructions/nalog-na-nasledstvo/?utm_source=site&utm_medium=stories&utm_campaign=nalogi&utm_term=utm-stories-sprosi"
                }
              ]
            }
          ]
        },
        {
          "story_id": "1470",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1470&utm-source=story&utm-story-code=nalogovyy-vychet-v-2023",
          "slides": [
            {
              "slide_id": "17064",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1470&storySlideId=17064&utm-source=story-slide&utm-story-code=nalogovyy-vychet-v-2023",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Как получить налоговый вычет в 2023",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "<p>\r\n\tРассказываем, кто и как может получить выплату\r\n</p>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/b63/f6bd23g49gfzety9w3exprkblesstyzr/1445.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17067",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1470&storySlideId=17067&utm-source=story-slide&utm-story-code=nalogovyy-vychet-v-2023",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Кто имеет право на вычет?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "<p>\r\n\t Есть несколько обязательных требований:\r\n</p>\r\n<p>\r\n\t –&nbsp;Быть налоговым резидентом РФ\r\n</p>\r\n<p>\r\n\t –&nbsp;Платить НДФЛ&nbsp;\r\n</p>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/a53/51jbywb6s67c9g2k2kl9y3iqq2cpfu2h/1378.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17070",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1470&storySlideId=17070&utm-source=story-slide&utm-story-code=nalogovyy-vychet-v-2023",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Где оформить налоговый вычет?",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "<p>\r\n\tЧерез Федеральную налоговую службу или через работодателя\r\n</p>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/1ff/lruflu94x681a4zjgc9jd19873t3xvg5/1345.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17073",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1470&storySlideId=17073&utm-source=story-slide&utm-story-code=nalogovyy-vychet-v-2023",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Подробнее о вычетах",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "<p>\r\n\tРассказали в материале\r\n</p>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/468/1tw2hat1j7pwzdhp0oylaf1zp1s8twoa/1678.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/news/kak-poluchit-nalogovyy-vychet-v-2023-godu/?utm_source=site&utm_medium=stories&utm_campaign=nalogi&utm_term=utm-stories-sprosi"
                }
              ]
            }
          ]
        },
        {
          "story_id": "1467",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1467&utm-source=story&utm-story-code=sotsvyplaty-semyam-s-detmi-2023",
          "slides": [
            {
              "slide_id": "17037",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1467&storySlideId=17037&utm-source=story-slide&utm-story-code=sotsvyplaty-semyam-s-detmi-2023",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Соцвыплаты семьям с детьми 2023",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "Актуальные суммы выплат на следующей карточке"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/e3c/rr0toesy4gmlrqm6a7balh3zp5iqvzyo/st9.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17040",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1467&storySlideId=17040&utm-source=story-slide&utm-story-code=sotsvyplaty-semyam-s-detmi-2023",
              "text_color": "DARK",
              "title": {
                "type": 1,
                "text": "Соцвыплаты семьям с детьми 2023",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": ""
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/b25/rwf5iewypjqa2e24ig062jwlq2tohdli/st12.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            }
          ]
        },
        {
          "story_id": "1464",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1464&utm-source=story&utm-story-code=kak-raspoznat-moshennikov-pri-arende-kvartiry",
          "slides": [
            {
              "slide_id": "17010",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1464&storySlideId=17010&utm-source=story-slide&utm-story-code=kak-raspoznat-moshennikov-pri-arende-kvartiry",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Как распознать мошенников при аренде квартиры?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "4 пункта, которые уберегут вас"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/a12/gvkhjdwr4gam2l2nzrfomvytppy39sjw/1.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17013",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1464&storySlideId=17013&utm-source=story-slide&utm-story-code=kak-raspoznat-moshennikov-pri-arende-kvartiry",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Слишком низкая цена",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Если цена аренды на 20% и более отличается от средней стоимости аренды без какой-либо видимой причины, стоит насторожиться: возможно, она обнаружится после сделки"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/070/rl8dj0y1mlotb1i2e3bapo813g82k5bv/2.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17016",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1464&storySlideId=17016&utm-source=story-slide&utm-story-code=kak-raspoznat-moshennikov-pri-arende-kvartiry",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Чрезмерно высокая сумма депозита​",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "Он не должен превышать стоимость аренды пары месяцев. Иначе есть риск, что жильца выселят и вернут только часть залога, ссылаясь на порчу недвижимости или иные причины"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/b6d/i19972i9wq56hd49h3su3qgg7bsm3nx8/3.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17019",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1464&storySlideId=17019&utm-source=story-slide&utm-story-code=kak-raspoznat-moshennikov-pri-arende-kvartiry",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Владелец не показывает документы на квартиру",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Отказ показать документы означает, что арендодатель не может подтвердить свои права собственности и это может обернуться неожиданными проблемами в будущем. В этом случае следует поискать другую квартиру"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/5c0/2u2y18m2fjkx67nfzpn7ox198y1ff0gy/4.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17022",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1464&storySlideId=17022&utm-source=story-slide&utm-story-code=kak-raspoznat-moshennikov-pri-arende-kvartiry",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Владелец отказывается заключить договор",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "Добросовестные арендодатели не станут предлагать квартиру без заключения договора, так как для собственника это гарантия своевременной и полной оплаты за сдаваемую в аренду квартиру"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/eb4/1qh74eealyuq55ouf19nw70l04prck5r/5.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "17025",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1464&storySlideId=17025&utm-source=story-slide&utm-story-code=kak-raspoznat-moshennikov-pri-arende-kvartiry",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Как снять квартиру",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Читайте инструкцию, как легко и безопасно снять квартиру в нашем материале"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/9a5/3exwpsy7ypmp4rajothwnnxzovmmyr0u/6.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/instructions/kak-pravilno-snyat-kvartiru-instruktsiya/?utm_source=site&utm_medium=stories&utm_campaign=1464_%D0%9C%D0%BE%D1%88%D0%B5%D0%BD%D0%BD%D0%B8%D1%87%D0%B5%D1%81%D1%82%D0%B2%D0%BE+%D0%BF%D1%80%D0%B8+%D0%B0%D1%80%D0%B5%D0%BD%D0%B4%D0%B5+%D0%BA%D0%B2%D0%B0%D1%80%D1%82%D0%B8%D1%80%D1%8B&utm_content=17025&utm_term=https%3A%2F%2Fxn--h1alcedd.xn--d1aqf.xn--p1ai%2Finstructions%2Fkak-pravilno-snyat-kvartiru-instruktsiya%2F"
                }
              ]
            }
          ]
        },
        {
          "story_id": "1434",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1434&utm-source=story&utm-story-code=kak-sekonomit-na-kommunalnykh-platezhakh-5-sovetov",
          "slides": [
            {
              "slide_id": "16602",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1434&storySlideId=16602&utm-source=story-slide&utm-story-code=kak-sekonomit-na-kommunalnykh-platezhakh-5-sovetov",
              "text_color": "LIGHT",
              "title": {
                "type": 1,
                "text": "Как сэкономить на коммунальных платежах: <br>4 совета",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": ""
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/47e/8uqkvekcfnlhnncj4ojf9ph3gjxq2z8v/1stor.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "16605",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1434&storySlideId=16605&utm-source=story-slide&utm-story-code=kak-sekonomit-na-kommunalnykh-platezhakh-5-sovetov",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Отключите все услуги, которыми вы не пользуетесь:",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "- Радиоточка<br>\r\n- Телеантенна<br>\r\n- Городской телефон<br>\r\n <br>\r\n <b>Экономия: 300 – 750 рублей в месяц</b>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/dad/6jznioh3cyylnsr2baibflgf2hw0u92i/stor2.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "16608",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1434&storySlideId=16608&utm-source=story-slide&utm-story-code=kak-sekonomit-na-kommunalnykh-platezhakh-5-sovetov",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Установите многотарифный счетчик электроэнергии",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Приборы учета сами переключают дневной и ночной режимы. Ночной тариф существенно ниже дневного. <br>\r\n <br>\r\n <b>Экономия: более 200 рублей в месяц</b>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/0ba/96xjuh281wtaoz2c0mpxa403v3i5ewyg/3.11.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "16611",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1434&storySlideId=16611&utm-source=story-slide&utm-story-code=kak-sekonomit-na-kommunalnykh-platezhakh-5-sovetov",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Поставьте счетчики на воду",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "Без счетчиков расход воды считается по нормам, которые гораздо выше среднестатистического потребления воды. Кроме того, для таких квартир применяются повышающие коэффициенты. <br>\r\n <br>\r\n <b>Экономия: от 600 до 1000 рублей в месяц</b>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/da2/pf3ve3w093hg4ymn792odfzxg1lryrj0/stor4.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "16614",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1434&storySlideId=16614&utm-source=story-slide&utm-story-code=kak-sekonomit-na-kommunalnykh-platezhakh-5-sovetov",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Расходуйте воду разумно",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "- Следите за состоянием сантехники <br />\n- Выбирайте однорычажные смесители<br />\n- По возможности используйте посудомойку <br />\n- Пользуйтесь экономичными режимами на бытовой технике<br />\n- Закрывайте кран&nbsp;&nbsp;<br />\n- Переиспользуйте воду<br />\n"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/cd5/ji44e3a7zu4nqvfzrgitm3nqhx4qzki0/stor5.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            }
          ]
        },
        {
          "story_id": "1410",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1410&utm-source=story&utm-story-code=universalnoe-posobie",
          "slides": [
            {
              "slide_id": "16377",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1410&storySlideId=16377&utm-source=story-slide&utm-story-code=universalnoe-posobie",
              "text_color": "LIGHT",
              "title": {
                "type": 1,
                "text": "С 1 января 2023 года в России появится  универсальное пособие для семей с детьми",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": ""
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/24c/io6do0bgw9v5ri7ib6h8e7r9vjwdvqr2/fon.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "16380",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1410&storySlideId=16380&utm-source=story-slide&utm-story-code=universalnoe-posobie",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Что такое универсальное пособие?:",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "Это единое пособие для семей с невысокими доходами и беременных женщин"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/71b/cvurvr6sl3yathwmyox2po32n7xpvqqe/2.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "16383",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1410&storySlideId=16383&utm-source=story-slide&utm-story-code=universalnoe-posobie",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Универсальное пособие объединит:",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "- пособие беременным<br>\r\n- пособие для ухода за ребенком до 1,5 лет для неработающих родителей<br>\r\n- выплаты на первого ребенка до 3 лет<br>\r\n- выплаты на третьего ребенка <br>\r\n- пособие на детей от 3 до 7 лет включительно<br>\r\n- пособие для детей от 3 до 17 лет<br>"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/8ec/41i7fbwbypfml9risrnc510xchv7ix3z/3.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "16386",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1410&storySlideId=16386&utm-source=story-slide&utm-story-code=universalnoe-posobie",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Размер пособия:",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "50, 75 или 100&#37; от регионального прожиточного минимума"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/f1d/u5nz7exwbkohp4hnuexdi522e2ovu2wb/fon_3.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "16389",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1410&storySlideId=16389&utm-source=story-slide&utm-story-code=universalnoe-posobie",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Кто будет выплачивать?",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Выплаты будет осуществлять Социальный фонд России, который начнет функционировать с 1 января 2023 года."
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/3f0/c7nakl6rbzuv7d8kqr3wdv1x2fb4d3za/fon_4.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://t.me/otvechaemrf/875?utm_source=site&utm_medium=stories&utm_campaign=1410_%D0%A3%D0%BD%D0%B8%D0%B2%D0%B5%D1%80%D1%81%D0%B0%D0%BB%D1%8C%D0%BD%D0%BE%D0%B5+%D0%BF%D0%BE%D1%81%D0%BE%D0%B1%D0%B8%D0%B5&utm_content=16389&utm_term=https%3A%2F%2Ft.me%2Fotvechaemrf%2F875"
                }
              ]
            }
          ]
        },
        {
          "story_id": "1407",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1407&utm-source=story&utm-story-code=chto-delat-esli-na-vas-oformili-kredit",
          "slides": [
            {
              "slide_id": "16353",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1407&storySlideId=16353&utm-source=story-slide&utm-story-code=chto-delat-esli-na-vas-oformili-kredit",
              "text_color": "LIGHT",
              "title": {
                "type": 1,
                "text": "Что делать, если на вас оформили кредит?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": ""
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/52f/67rptiqictaied082we4jdbzccrjeq4q/11.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "16338",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1407&storySlideId=16338&utm-source=story-slide&utm-story-code=chto-delat-esli-na-vas-oformili-kredit",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Узнали, что мошенники оформили на вас кредит?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "Сразу обратитесь с заявлением в банк или микрофинансовую организацию, где он был выдан."
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/242/puv7b5szypmz25uj72rh7pmhyhz67d84/12.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "16341",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1407&storySlideId=16341&utm-source=story-slide&utm-story-code=chto-delat-esli-na-vas-oformili-kredit",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Что должно быть в обращении?",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Напишите, что вы не заключали договор и не получали денег. Попросите провести внутреннее расследование и прекратить требовать долг с вас. <br />\n<br />\n "
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/c11/02sfeqaothrop875pi4xn3purxzulm21/9.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "16344",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1407&storySlideId=16344&utm-source=story-slide&utm-story-code=chto-delat-esli-na-vas-oformili-kredit",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Что-то еще?",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Не забудьте оставить жалобу на портале Центробанка. Подробно опишите проблему, предоставьте всю информацию и документы."
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/6a9/jiy2uift9e88120k86m723swz9rayk4l/15.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://cbr.ru/Reception/?utm_source=site&utm_medium=stories&utm_campaign=1407_%D0%A7%D1%82%D0%BE+%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C%2C+%D0%B5%D1%81%D0%BB%D0%B8+%D0%BD%D0%B0+%D0%B2%D0%B0%D1%81+%D0%BE%D1%84%D0%BE%D1%80%D0%BC%D0%B8%D0%BB%D0%B8+%D0%BA%D1%80%D0%B5%D0%B4%D0%B8%D1%82%3F&utm_content=16344&utm_term=https%3A%2F%2Fcbr.ru%2FReception%2F"
                }
              ]
            },
            {
              "slide_id": "16347",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1407&storySlideId=16347&utm-source=story-slide&utm-story-code=chto-delat-esli-na-vas-oformili-kredit",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Нужно ли обращаться в полицию?",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Обязательно подайте заявление в полицию. Оформление кредита на чужое имя - это преступление."
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/da2/wjnenk63hbi9loq9khrnsyx4cpvgg6va/5.1.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "16350",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1407&storySlideId=16350&utm-source=story-slide&utm-story-code=chto-delat-esli-na-vas-oformili-kredit",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Можно ли еще что-то сделать?",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Да, например, запросить свою кредитную историю через портал Госуслуги. Это поможет убедиться, что на вас не оформили других кредитов."
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/c64/gv19yvf4rbt2rw9x1asn3jbg6816knre/16.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://www.gosuslugi.ru/help/faq/credit_bureau/100748?utm_source=site&utm_medium=stories&utm_campaign=1407_%D0%A7%D1%82%D0%BE+%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C%2C+%D0%B5%D1%81%D0%BB%D0%B8+%D0%BD%D0%B0+%D0%B2%D0%B0%D1%81+%D0%BE%D1%84%D0%BE%D1%80%D0%BC%D0%B8%D0%BB%D0%B8+%D0%BA%D1%80%D0%B5%D0%B4%D0%B8%D1%82%3F&utm_content=16350&utm_term=https%3A%2F%2Fwww.gosuslugi.ru%2Fhelp%2Ffaq%2Fcredit_bureau%2F100748"
                }
              ]
            }
          ]
        },
        {
          "story_id": "1371",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1371&utm-source=story&utm-story-code=kak-gosudarstvo-uluchshaet-zhilishchnye-usloviya-rossiyan",
          "slides": [
            {
              "slide_id": "15783",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1371&storySlideId=15783&utm-source=story-slide&utm-story-code=kak-gosudarstvo-uluchshaet-zhilishchnye-usloviya-rossiyan",
              "text_color": "LIGHT",
              "title": {
                "type": 1,
                "text": "Как государство улучшает жилищные условия россиян?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": ""
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/49b/stbsy3d2twr3a4zdjw2ahz5fhp4m3o2j/7.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "15786",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1371&storySlideId=15786&utm-source=story-slide&utm-story-code=kak-gosudarstvo-uluchshaet-zhilishchnye-usloviya-rossiyan",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Национальный проект «Жилье и городская среда»",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Создает комфортные условия и обеспечивает граждан доступным жильем"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/0d3/adh8rwzc36wkcthy7ysgjw13snos7bou/2.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "15789",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1371&storySlideId=15789&utm-source=story-slide&utm-story-code=kak-gosudarstvo-uluchshaet-zhilishchnye-usloviya-rossiyan",
              "text_color": "LIGHT",
              "title": {
                "type": 0,
                "text": "Портал строительного комплекса",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Вся информация и актуальные новости проекта на stroi.gov.ru"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/8ad/a6cwtu6rjjyjiygc2d8julj4jhkyxxxg/9.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Перейти",
                  "url": "https://stroi.gov.ru/?utm_source=sprosi.dom.rf&utm_medium=referral&utm_campaign=ref_602_stroi.gov.ru_rf_main.banner&utm_content=https://спроси.дом.рф/"
                }
              ]
            }
          ]
        },
        {
          "story_id": "1063",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1063&utm-source=story&utm-story-code=novosti",
          "slides": [
            {
              "slide_id": "16359",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1063&storySlideId=16359&utm-source=story-slide&utm-story-code=novosti",
              "text_color": "LIGHT",
              "title": {
                "type": 1,
                "text": "Кабмин продлил Дальневосточную ипотеку до 2030 года",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": ""
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/2b9/66ol96o1ds22qciqrkc3tyak300xlv5u/fon.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://спроси.дом.рф/news/pravitelstvo-prodlilo-dalnevostochnuyu-ipoteku-do-2030-goda/?utm_source=site&utm_medium=stories&utm_campaign=1063_%D0%9D%D0%BE%D0%B2%D0%BE%D1%81%D1%82%D0%B8&utm_content=16359&utm_term=https%3A%2F%2F%D1%81%D0%BF%D1%80%D0%BE%D1%81%D0%B8.%D0%B4%D0%BE%D0%BC.%D1%80%D1%84%2Fnews%2Fpravitelstvo-prodlilo-dalnevostochnuyu-ipoteku-do-2030-goda%2F"
                }
              ]
            },
            {
              "slide_id": "16362",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1063&storySlideId=16362&utm-source=story-slide&utm-story-code=novosti",
              "text_color": "LIGHT",
              "title": {
                "type": 1,
                "text": "МРОТ в 2023 году составит<br>16 242 рубля",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": ""
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/d83/xaj36pxillbij96cw9axvctfmfqjzj1h/fon_1.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://спроси.дом.рф/news/gosduma-utverdila-razmer-mrot-na-2023-god/?utm_source=site&utm_medium=stories&utm_campaign=1063_%D0%9D%D0%BE%D0%B2%D0%BE%D1%81%D1%82%D0%B8&utm_content=16362&utm_term=https%3A%2F%2F%D1%81%D0%BF%D1%80%D0%BE%D1%81%D0%B8.%D0%B4%D0%BE%D0%BC.%D1%80%D1%84%2Fnews%2Fgosduma-utverdila-razmer-mrot-na-2023-god%2F"
                }
              ]
            },
            {
              "slide_id": "16368",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1063&storySlideId=16368&utm-source=story-slide&utm-story-code=novosti",
              "text_color": "LIGHT",
              "title": {
                "type": 1,
                "text": "Когда ждать окончания льготных ипотечных программ?",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": ""
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/ba1/wh9a4zu08qykbh2l1bex3kqf5ezak0t8/fon_3.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://спроси.дом.рф/news/eksperty-nazvali-sroki-deystviya-lgotnykh-ipotechnykh-programm/?utm_source=site&utm_medium=stories&utm_campaign=1063_%D0%9D%D0%BE%D0%B2%D0%BE%D1%81%D1%82%D0%B8&utm_content=16368&utm_term=https%3A%2F%2F%D1%81%D0%BF%D1%80%D0%BE%D1%81%D0%B8.%D0%B4%D0%BE%D0%BC.%D1%80%D1%84%2Fnews%2Feksperty-nazvali-sroki-deystviya-lgotnykh-ipotechnykh-programm%2F"
                }
              ]
            },
            {
              "slide_id": "16365",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1063&storySlideId=16365&utm-source=story-slide&utm-story-code=novosti",
              "text_color": "LIGHT",
              "title": {
                "type": 1,
                "text": "Прожиточный минимум повысится до <br> 14 375 рублей",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": ""
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/d7b/saz3ud3nsk6h5544gq652lum8cprth7z/fon_2.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://спроси.дом.рф/news/prozhitochnyy-minimum-povysili-do-14-375-rubley/?utm_source=site&utm_medium=stories&utm_campaign=1063_%D0%9D%D0%BE%D0%B2%D0%BE%D1%81%D1%82%D0%B8&utm_content=16365&utm_term=https%3A%2F%2F%D1%81%D0%BF%D1%80%D0%BE%D1%81%D0%B8.%D0%B4%D0%BE%D0%BC.%D1%80%D1%84%2Fnews%2Fprozhitochnyy-minimum-povysili-do-14-375-rubley%2F"
                }
              ]
            },
            {
              "slide_id": "16371",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1063&storySlideId=16371&utm-source=story-slide&utm-story-code=novosti",
              "text_color": "LIGHT",
              "title": {
                "type": 1,
                "text": "ЦБ рекомендовал банкам не выселять должников по ипотеке",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": ""
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/ead/98kpqj15eyyqebertbizncglof0zt21c/fon_4.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://спроси.дом.рф/news/bank-rossii-rekomendoval-ne-shtrafovat-i-ne-vyselyat-dolzhnikov-po-ipoteke/?utm_source=site&utm_medium=stories&utm_campaign=1063_%D0%9D%D0%BE%D0%B2%D0%BE%D1%81%D1%82%D0%B8&utm_content=16371&utm_term=https%3A%2F%2F%D1%81%D0%BF%D1%80%D0%BE%D1%81%D0%B8.%D0%B4%D0%BE%D0%BC.%D1%80%D1%84%2Fnews%2Fbank-rossii-rekomendoval-ne-shtrafovat-i-ne-vyselyat-dolzhnikov-po-ipoteke%2F"
                }
              ]
            }
          ]
        },
        {
          "story_id": "1072",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1072&utm-source=story&utm-story-code=svezhee-na-sayte-instruktsii-voprosy-otvety-servisy-stranits",
          "slides": [
            {
              "slide_id": "13393",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1072&storySlideId=13393&utm-source=story-slide&utm-story-code=svezhee-na-sayte-instruktsii-voprosy-otvety-servisy-stranits",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Узнай о жилье больше",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "Отвечаем на часто задаваемые вопросы и подробно рассказываем о жилищной сфере "
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/617/af9aj2fjjjjqbnns1f6yr29e29jgev25/Stories-1.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "13396",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1072&storySlideId=13396&utm-source=story-slide&utm-story-code=svezhee-na-sayte-instruktsii-voprosy-otvety-servisy-stranits",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Почему отключают горячую воду?",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Рассказываем о причинах и законных сроках отключения воды"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/f0d/4ewdb7sa1l62276hwaah5ps01j7epm40/With-button.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/questions/pochemu-otklyuchayut-goryachuyu-vodu/?utm_source=site&utm_medium=stories&utm_campaign=1072_%D0%A1%D0%B2%D0%B5%D0%B6%D0%B5%D0%B5+%D0%BD%D0%B0+%D1%81%D0%B0%D0%B9%D1%82%D0%B5&utm_content=13396&utm_term=https%3A%2F%2Fxn--h1alcedd.xn--d1aqf.xn--p1ai%2Fquestions%2Fpochemu-otklyuchayut-goryachuyu-vodu%2F"
                }
              ]
            },
            {
              "slide_id": "13399",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1072&storySlideId=13399&utm-source=story-slide&utm-story-code=svezhee-na-sayte-instruktsii-voprosy-otvety-servisy-stranits",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Меры поддержки застройщиков",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Мы собрали в одном месте все меры поддержки, которые помогут застройщикам в нынешних экономических условиях"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/8b1/f0zp3fhcm8vwk594c83bylhr21ztusxd/With-button_1.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/services/mery-podderzhki-zastrojshchikov/?utm_source=site&utm_medium=stories&utm_campaign=1072_%D0%A1%D0%B2%D0%B5%D0%B6%D0%B5%D0%B5+%D0%BD%D0%B0+%D1%81%D0%B0%D0%B9%D1%82%D0%B5&utm_content=13399&utm_term=https%3A%2F%2Fxn--h1alcedd.xn--d1aqf.xn--p1ai%2Fservices%2Fmery-podderzhki-zastrojshchikov%2F"
                }
              ]
            },
            {
              "slide_id": "13402",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1072&storySlideId=13402&utm-source=story-slide&utm-story-code=svezhee-na-sayte-instruktsii-voprosy-otvety-servisy-stranits",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "ЖСК с господдержкой",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Узнайте, как вступить или создать жилищно-строительный кооператив с господдержкой"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/277/5lls13xcgd014ldqulxo4ivto2lohq5v/With-button_3.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/zhsk-support/?utm_source=site&utm_medium=stories&utm_campaign=1072_%D0%A1%D0%B2%D0%B5%D0%B6%D0%B5%D0%B5+%D0%BD%D0%B0+%D1%81%D0%B0%D0%B9%D1%82%D0%B5&utm_content=13402&utm_term=https%3A%2F%2Fxn--h1alcedd.xn--d1aqf.xn--p1ai%2Fzhsk-support%2F"
                }
              ]
            },
            {
              "slide_id": "13405",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1072&storySlideId=13405&utm-source=story-slide&utm-story-code=svezhee-na-sayte-instruktsii-voprosy-otvety-servisy-stranits",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Раздел имущества при разводе",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Рассказываем, какое имущество можно считать совместно нажитым и как оно делится через суд"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/da1/800hjhcgoj8d652elnmw4de2fuv70aa1/With-button_6.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/instructions/razdel-imushchestva-pri-razvode?utm_source=site&utm_medium=stories&utm_campaign=1072_%D0%A1%D0%B2%D0%B5%D0%B6%D0%B5%D0%B5+%D0%BD%D0%B0+%D1%81%D0%B0%D0%B9%D1%82%D0%B5&utm_content=13405&utm_term=https%3A%2F%2Fxn--h1alcedd.xn--d1aqf.xn--p1ai%2Finstructions%2Frazdel-imushchestva-pri-razvode"
                }
              ]
            },
            {
              "slide_id": "13408",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1072&storySlideId=13408&utm-source=story-slide&utm-story-code=svezhee-na-sayte-instruktsii-voprosy-otvety-servisy-stranits",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Как индивидуальному предпринимателю получить ипотеку?",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Разбираемся, почему банки не так охотно выдают ипотеку ИП и как им увеличить шансы на одобрение кредита"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/6e0/00gmzci5b8terb5s6rrrowkkymdkbyns/With-button_7.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/instructions/ipoteka-dlya-individualnykh-predprinimateley/?utm_source=site&utm_medium=stories&utm_campaign=1072_%D0%A1%D0%B2%D0%B5%D0%B6%D0%B5%D0%B5+%D0%BD%D0%B0+%D1%81%D0%B0%D0%B9%D1%82%D0%B5&utm_content=13408&utm_term=https%3A%2F%2Fxn--h1alcedd.xn--d1aqf.xn--p1ai%2Finstructions%2Fipoteka-dlya-individualnykh-predprinimateley%2F"
                }
              ]
            },
            {
              "slide_id": "13411",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1072&storySlideId=13411&utm-source=story-slide&utm-story-code=svezhee-na-sayte-instruktsii-voprosy-otvety-servisy-stranits",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Что такое хостел?",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Перед тем как отправиться в отпуск или командировку, узнайте об особенностях разных видов гостиниц"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/131/mo25biuh19ynl19la9ys21fzka9ze5i2/With-button_8.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/questions/chto-takoe-khostel/?utm_source=site&utm_medium=stories&utm_campaign=1072_%D0%A1%D0%B2%D0%B5%D0%B6%D0%B5%D0%B5+%D0%BD%D0%B0+%D1%81%D0%B0%D0%B9%D1%82%D0%B5&utm_content=13411&utm_term=https%3A%2F%2Fxn--h1alcedd.xn--d1aqf.xn--p1ai%2Fquestions%2Fchto-takoe-khostel%2F"
                }
              ]
            },
            {
              "slide_id": "13414",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1072&storySlideId=13414&utm-source=story-slide&utm-story-code=svezhee-na-sayte-instruktsii-voprosy-otvety-servisy-stranits",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Аренда квартиры с последующим выкупом",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Разбираем набирающую популярность альтернативу ипотеке"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/f12/55ia6vxxn5tpp0o0lo37m1ev2iqatim5/With-button_10.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/instructions/arenda-kvartiry-s-posleduyushchim-vykupom/?utm_source=site&utm_medium=stories&utm_campaign=1072_%D0%A1%D0%B2%D0%B5%D0%B6%D0%B5%D0%B5+%D0%BD%D0%B0+%D1%81%D0%B0%D0%B9%D1%82%D0%B5&utm_content=13414&utm_term=https%3A%2F%2Fxn--h1alcedd.xn--d1aqf.xn--p1ai%2Finstructions%2Farenda-kvartiry-s-posleduyushchim-vykupom%2F"
                }
              ]
            },
            {
              "slide_id": "13417",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1072&storySlideId=13417&utm-source=story-slide&utm-story-code=svezhee-na-sayte-instruktsii-voprosy-otvety-servisy-stranits",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Где оформить Льготную ипотеку на ИЖС?",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Ознакомьтесь с перечнем банков-участников программы"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/b21/2ddg6lc1fl63x20lfytr90oyt3e0e1cw/With-button_12.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/instructions/banki-uchastniki-programmy-lgotnaya-ipoteka-po-stavke-7-na-stroitelstvo-doma-svoimi-silami/?utm_source=site&utm_medium=stories&utm_campaign=1072_%D0%A1%D0%B2%D0%B5%D0%B6%D0%B5%D0%B5+%D0%BD%D0%B0+%D1%81%D0%B0%D0%B9%D1%82%D0%B5&utm_content=13417&utm_term=https%3A%2F%2Fxn--h1alcedd.xn--d1aqf.xn--p1ai%2Finstructions%2Fbanki-uchastniki-programmy-lgotnaya-ipoteka-po-stavke-7-na-stroitelstvo-doma-svoimi-silami%2F"
                }
              ]
            }
          ]
        },
        {
          "story_id": "1141",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1141&utm-source=story&utm-story-code=ipoteka-na-lgotnykh-usloviyakh-v-belgorodskoy-oblasti",
          "slides": [
            {
              "slide_id": "13840",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1141&storySlideId=13840&utm-source=story-slide&utm-story-code=ipoteka-na-lgotnykh-usloviyakh-v-belgorodskoy-oblasti",
              "text_color": "DARK",
              "title": {
                "type": 1,
                "text": "Белгородцы могут купить жилье с пониженной ставкой",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": ""
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/9bf/o3zh0sftid754md3m5x0z7r1efy5tytb/Stories-7.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "13843",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1141&storySlideId=13843&utm-source=story-slide&utm-story-code=ipoteka-na-lgotnykh-usloviyakh-v-belgorodskoy-oblasti",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Условия программы",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Программа позволяет оформить ипотеку по ставке на 3% ниже любой ставки банка (семейной, льготной и др.). Максимальная сумма кредита — 6 млн рублей"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/407/xpdr0yn5vcr37g88hv8pr1o638ljg0i2/Stories-6.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/catalog/ipoteka-na-lgotnykh-usloviyakh-v-belgorodskoy-oblasti/?utm_source=site&utm_medium=stories&utm_campaign=1141_%D0%9B%D1%8C%D0%B3%D0%BE%D1%82%D0%BD%D0%B0%D1%8F+%D0%B8%D0%BF%D0%BE%D1%82%D0%B5%D0%BA%D0%B0+%D0%B2+%D0%91%D0%B5%D0%BB%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%D0%B5&utm_content=13843&utm_term=https%3A%2F%2Fxn--h1alcedd.xn--d1aqf.xn--p1ai%2Fcatalog%2Fipoteka-na-lgotnykh-usloviyakh-v-belgorodskoy-oblasti%2F"
                }
              ]
            },
            {
              "slide_id": "13846",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1141&storySlideId=13846&utm-source=story-slide&utm-story-code=ipoteka-na-lgotnykh-usloviyakh-v-belgorodskoy-oblasti",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Требования к участникам",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "Постоянное проживание на территории Белгородской области и работа в бюджетной сферы Белгородской области"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/12d/zwuh7dv9dfmm1xhi6zwoy1c1wwi5vag3/Stories-3.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "13849",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1141&storySlideId=13849&utm-source=story-slide&utm-story-code=ipoteka-na-lgotnykh-usloviyakh-v-belgorodskoy-oblasti",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "На какое жилье выдают льготный кредит",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": "В рамках программы можно приобрести:"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/d17/k35iqy43buzloes10qdgmy38m2rdyemr/Stories-10.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "13852",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1141&storySlideId=13852&utm-source=story-slide&utm-story-code=ipoteka-na-lgotnykh-usloviyakh-v-belgorodskoy-oblasti",
              "text_color": "LIGHT",
              "title": {
                "type": 1,
                "text": "Узнайте подробнее о программе в нашем материале",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": ""
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/487/rnmkwi510qn6d8y61c9742bc7ta4fvpt/Stories-5.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/catalog/ipoteka-na-lgotnykh-usloviyakh-v-belgorodskoy-oblasti/?utm_source=site&utm_medium=stories&utm_campaign=1141_%D0%9B%D1%8C%D0%B3%D0%BE%D1%82%D0%BD%D0%B0%D1%8F+%D0%B8%D0%BF%D0%BE%D1%82%D0%B5%D0%BA%D0%B0+%D0%B2+%D0%91%D0%B5%D0%BB%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%D0%B5&utm_content=13852&utm_term=https%3A%2F%2Fxn--h1alcedd.xn--d1aqf.xn--p1ai%2Fcatalog%2Fipoteka-na-lgotnykh-usloviyakh-v-belgorodskoy-oblasti%2F"
                }
              ]
            }
          ]
        },
        {
          "story_id": "1066",
          "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1066&utm-source=story&utm-story-code=poslednie-izmeneniya-programm",
          "slides": [
            {
              "slide_id": "13378",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1066&storySlideId=13378&utm-source=story-slide&utm-story-code=poslednie-izmeneniya-programm",
              "text_color": "DARK",
              "title": {
                "type": 1,
                "text": "Какие изменения произошли в программах господдержки?",
                "vertical_align": 0
              },
              "description": {
                "type": null,
                "text": ""
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/607/i5sgly29ylsjh9iw3pixyueuse9e8eao/Stories-11.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": []
            },
            {
              "slide_id": "13381",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1066&storySlideId=13381&utm-source=story-slide&utm-story-code=poslednie-izmeneniya-programm",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Важно!",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Семьям с детьми упростили использование маткапитала на погашение рефинансированной ипотеки"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/24d/k4mvp0h5yu0duhzpurm5oi5utfx90q3l/With-button_5.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/news/pravitelstvo-uprostilo-refinansirovanie-ipoteki-dlya-semei-s-detmi/?utm_source=site&utm_medium=stories&utm_campaign=1066_%D0%9F%D0%BE%D1%81%D0%BB%D0%B5%D0%B4%D0%BD%D0%B8%D0%B5+%D0%B8%D0%B7%D0%BC%D0%B5%D0%BD%D0%B5%D0%BD%D0%B8%D1%8F+%D0%BF%D1%80%D0%BE%D0%B3%D1%80%D0%B0%D0%BC%D0%BC&utm_content=13381&utm_term=https%3A%2F%2Fxn--h1alcedd.xn--d1aqf.xn--p1ai%2Fnews%2Fpravitelstvo-uprostilo-refinansirovanie-ipoteki-dlya-semei-s-detmi%2F"
                }
              ]
            },
            {
              "slide_id": "13384",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1066&storySlideId=13384&utm-source=story-slide&utm-story-code=poslednie-izmeneniya-programm",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Важно!",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Правительство увеличило размер кредита по льготной ипотеке для IT-специалистов"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/9d0/22u6jmfwdmlda1hq7ys2w5241er3cvn7/With-button_8.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/news/pravitelstvo-uvelichilo-razmer-kredita-po-lgotnoy-ipoteke-dlya-itspetsialistov/?utm_source=site&utm_medium=stories&utm_campaign=1066_%D0%9F%D0%BE%D1%81%D0%BB%D0%B5%D0%B4%D0%BD%D0%B8%D0%B5+%D0%B8%D0%B7%D0%BC%D0%B5%D0%BD%D0%B5%D0%BD%D0%B8%D1%8F+%D0%BF%D1%80%D0%BE%D0%B3%D1%80%D0%B0%D0%BC%D0%BC&utm_content=13384&utm_term=https%3A%2F%2Fxn--h1alcedd.xn--d1aqf.xn--p1ai%2Fnews%2Fpravitelstvo-uvelichilo-razmer-kredita-po-lgotnoy-ipoteke-dlya-itspetsialistov%2F"
                }
              ]
            },
            {
              "slide_id": "13387",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1066&storySlideId=13387&utm-source=story-slide&utm-story-code=poslednie-izmeneniya-programm",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Важно!",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Действие программы «Дальневосточная ипотека» распространили на врачей и учителей"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/cc7/wtz5q79tbs6w6et8nazrzwot8506oz9j/With-button.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/news/dalnevostochnuyu-ipoteku-rasprostranili-na-vrachey-i-uchiteley/?utm_source=site&utm_medium=stories&utm_campaign=1066_%D0%9F%D0%BE%D1%81%D0%BB%D0%B5%D0%B4%D0%BD%D0%B8%D0%B5+%D0%B8%D0%B7%D0%BC%D0%B5%D0%BD%D0%B5%D0%BD%D0%B8%D1%8F+%D0%BF%D1%80%D0%BE%D0%B3%D1%80%D0%B0%D0%BC%D0%BC&utm_content=13387&utm_term=https%3A%2F%2Fxn--h1alcedd.xn--d1aqf.xn--p1ai%2Fnews%2Fdalnevostochnuyu-ipoteku-rasprostranili-na-vrachey-i-uchiteley%2F"
                }
              ]
            },
            {
              "slide_id": "13390",
              "share_url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/?storyId=1066&storySlideId=13390&utm-source=story-slide&utm-story-code=poslednie-izmeneniya-programm",
              "text_color": "DARK",
              "title": {
                "type": 0,
                "text": "Важно!",
                "vertical_align": 1
              },
              "description": {
                "type": null,
                "text": "Программу выплаты 450 тыс. рублей на ипотеку для многодетных семей продлили в России"
              },
              "image": {
                "type": 0,
                "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/upload/medialibrary/af3/hwmwy232jgox7ks84tbf1bvisf9l50bc/With-button_9.png"
              },
              "video": {
                "type": null,
                "url": null,
                "preimg": null
              },
              "buttons": [
                {
                  "type": 0,
                  "text": "Подробнее",
                  "url": "https://xn--h1alcedd.xn--d1aqf.xn--p1ai/news/programma-vyplaty-450-tys-rubley-na-ipoteku-dlya-mnogodetnykh-prodlena/?utm_source=site&utm_medium=stories&utm_campaign=1066_%D0%9F%D0%BE%D1%81%D0%BB%D0%B5%D0%B4%D0%BD%D0%B8%D0%B5+%D0%B8%D0%B7%D0%BC%D0%B5%D0%BD%D0%B5%D0%BD%D0%B8%D1%8F+%D0%BF%D1%80%D0%BE%D0%B3%D1%80%D0%B0%D0%BC%D0%BC&utm_content=13390&utm_term=https%3A%2F%2Fxn--h1alcedd.xn--d1aqf.xn--p1ai%2Fnews%2Fprogramma-vyplaty-450-tys-rubley-na-ipoteku-dlya-mnogodetnykh-prodlena%2F"
                }
              ]
            }
          ]
        }
      ]
      // "OPEN":null,

    },



    modal_show:false,

    massive_main_slider:[], //массив для слайдера историй на главной странице
    massive_carousels_slider:null, //массив для слайдера историй в модальном окне
    massive_carousels_slider_click: {
      status:false,
      massive:null,
      id_stories:null,
      id_slide:null,
      id_index:null,
    }, //массив для слайдера историй в модальном окне на основе клика по определённой истории
  },
  getters:{
    //массив историй на основной странице
    MASSIVEMAINSLIDERSTORIES(state){
      return state.massive_main_slider
    },

  //  сформированный массив слайдов историй в модальном окне на основе клика по определённой истории
    MASSIVECAROUSELSSLIDERCLICK(state){
      return state.massive_carousels_slider_click
    },

  },
  mutations:{
    //массив для слайдера историй на главной странице
    mutationOpen(state,received_perem){
      // console.log(received_perem);
      if(received_perem.OPEN!=null && received_perem.OPEN.story_id!=null && received_perem.OPEN.slide_id!=null){
        state.massive_carousels_slider_click.massive = state.massive_carousels_slider
        state.massive_carousels_slider_click.id_stories=received_perem.OPEN.story_id
        state.massive_carousels_slider_click.id_slide=received_perem.OPEN.slide_id
        state.massive_carousels_slider_click.status='open'

        const id_story = received_perem.OPEN.story_id
        const array_story = received_perem.SLIDER_STORIES_MAIN_PAGE
        for(let i =0;i<array_story.length;i++){
          if(array_story[i].id==id_story){
            state.massive_carousels_slider_click.id_index=i
          }
        }
      }
    },
    //массив для слайдера историй на главной странице
    mutationMainSliderStories(state,received_perem){
      for (let i = 0; i<8;i++) {
        state.massive_main_slider.push(received_perem[i])
      }
      // state.massive_main_slider=received_perem
    },


    //массив для слайдера историй в модальном окне
    mutationStoriesSlider(state,received_perem){
      state.massive_carousels_slider=received_perem
    },
    //массив для слайдера историй в модальном окне на основе клика
    mutationarraySorting(state,received_perem){
      let array_slides = state.massive_carousels_slider
      state.massive_carousels_slider_click.massive = array_slides
      state.massive_carousels_slider_click.status=true
      state.massive_carousels_slider_click.id_stories=received_perem[0]
      state.massive_carousels_slider_click.id_index=received_perem[1]
    },
    mutationmodalClose(state){
      state.massive_carousels_slider_click.massive = null
      state.massive_carousels_slider_click.status=false
      state.massive_carousels_slider_click.id_stories=null
    },

  },
  actions:{
    // Получаю данные для слайдера историй на главной странице
    axiosGetParametr({commit,state}){
      //это закомментировать
      // commit('mutationMainSliderStories',state.STORIES.SLIDER_STORIES_MAIN_PAGE)
      // commit('mutationStoriesSlider',state.STORIES.DETAIL)
      // setTimeout(()=>{
      //   commit('mutationOpen',state.STORIES)
      // },1000)




      //------------------------это для боя расскоментировать при необходимости
      const config_header = {
        headers: {
          'Content-Type': 'application/json',
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(), //расскоментировать
          Accept: 'application/json',
        }
      }

      return axios.get(`/api/local/story/`,config_header) //расскоментировать
      // return axios.get(`http://localhost:3000/result`,config_header) //убрать
        .then((res)=>{

          // для слайдера историй на основной странице это тестовая закомментировать
          // commit('mutationMainSliderStories',res.data.STORIES.SLIDER_STORIES_MAIN_PAGE)
          // commit('mutationStoriesSlider',res.data.STORIES.DETAIL)
          // commit('mutationOpen',res.data.STORIES)


          // для слайдера историй на основной странице это боевая расскоментировать
          commit('mutationMainSliderStories',res.data.result.STORIES.SLIDER_STORIES_MAIN_PAGE)
          commit('mutationStoriesSlider',res.data.result.STORIES.DETAIL)
          commit('mutationOpen',res.data.result.STORIES)


        }).catch((error) => {
          console.log(error);
        });


    },
    arraySorting({commit,state},param){
      commit('mutationarraySorting',param)
    },
    modalClose({commit,state}){
      commit('mutationmodalClose')
    },



  },
})
</script>
