export default function headerConnection() {
    const connectContainer = document.querySelector('.js-header-connection');
    if (!connectContainer) { return false; }
    const connectOpener = connectContainer.querySelector('.header-buttons__connection-opener');
    const connectCloser = connectContainer.querySelector('.header-buttons__connection-close');
    const modalOpeners = connectContainer.querySelectorAll('.js--modal-opener');

    connectOpener.addEventListener('click', () => {
        connectContainer.classList.add('open');
    });

    connectCloser.addEventListener('click', () => {
        connectContainer.classList.remove('open');
    });

    // каждые 5 секунд меняем иконку звонка и чата местами, таким образом отображаем их по очереди
    setInterval(() => {
        connectContainer.classList.toggle('chat-show');
    }, 5000);

    for (let i = 0; i < modalOpeners.length; i++) {
        modalOpeners[i].addEventListener('click', () => {
            connectContainer.classList.remove('open');
        });
    }
}
