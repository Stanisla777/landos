export default function setImageAttr() {
    const pageWrapper = document.querySelector('.page-wrap');
    if (pageWrapper) {
        pageWrapper.querySelectorAll('a').forEach((link) => {
            const linkAttr = link.getAttribute('href');
            if (linkAttr) {
                let hrefArr = linkAttr.split('://');
                if (hrefArr.length > 1) {
                    link.setAttribute('target', '_blank');
                } else {
                    hrefArr = linkAttr.split('.');
                    const permit = hrefArr[hrefArr.length - 1].toLowerCase();
                    if (permit === 'pdf') {
                        link.setAttribute('target', '_blank');
                    }
                }
            }
        });
    }
}
