/* eslint-disable */
function callback() {
  const i = setInterval(() => {
    const beesenderchat = document.querySelector('.beesenderchat-conversation-parts>span');
    if(beesenderchat){
      clearInterval(i);
      const container = beesenderchat.closest('.beesenderchat-conversation-body-parts-wrapper');
      // eslint-disable-next-line camelcase,no-unused-vars
      const first_div = container.querySelector('div[data-v-bdc03fa4]');
      // eslint-disable-next-line camelcase
      if (!first_div) {
        container.querySelector('.beesenderchat-conversation-parts').classList.add('active');
        // eslint-disable-next-line camelcase
      } else if (first_div && !first_div.querySelector('.beesenderchat-additional-message')) {
        container.querySelector('.beesenderchat-conversation-parts').classList.remove('active');
        // eslint-disable-next-line no-unused-vars
        const parts = container.querySelector('.beesenderchat-conversation-parts>span>div');
        // eslint-disable-next-line no-unused-vars
        const divelem = document.createElement('div');
        divelem.setAttribute('style', 'margin-top: 50px;');
        divelem.className = 'beesenderchat-additional-message';
        // eslint-disable-next-line max-len
        let html = '<p style="font-size: 12px;line-height: 14px;font-family: Gilroy-SemiBold,sans-serif;color: #2A2936;">В нашем чате мы не&nbsp;обрабатываем сообщения, которые содержат ваши персональные данные. ';
        if (typeof conf !== 'undefined' && conf !== null && conf.hasOwnProperty('UF_PHONE') && conf.hasOwnProperty('UF_EMAIL')) {
          // eslint-disable-next-line max-len
          html += '<span style="margin-top: 7px;display: block;">Позвонить <a style="font-size: 13px;color: #8BC540;white-space: nowrap;" href="tel:' + conf.UF_PHONE + '">' + conf.UF_PHONE_formatted + '</a>';
          // eslint-disable-next-line max-len
          // html += '<br/> Написать письмо на&nbsp;<a style="font-size: 13px;color: #8BC540;white-space: nowrap;" href="mailto:' + conf.UF_EMAIL + '">' + conf.UF_EMAIL + '</a></span>';
        }
        html +='</p>';
        divelem.innerHTML = html;
        // element.after(divelem);
        parts.append(divelem);
      }
    }
  })

}
function observeBeesender () {
  const r = setInterval(() => {
    const beesenderchat = document.querySelector('.beesenderchat-conversation-parts>span');
    const observerOptions = {
      attributes: true,
      characterData: true,
      childList: true
    };
    const observer = new MutationObserver(callback);
    if (beesenderchat) {
      clearInterval(r);
      // setTimeout(() => {
        observer.observe(beesenderchat, observerOptions);
      // }, 200);
    }
  })

}
export default function beesenderNewWindow() {
  callback();
  observeBeesender();
}
