<template lang="pug">
  .property-calculator__row.margin
    p.property-calculator__row-label Стоимость недвижимости, ₽
    .property-calculator__input-field.js--number-cost(@click="inputFocus")
      input.range-input__value(inputmode="numeric")(
        v-model="dataField"
        type="text"
        ref="realtyInput"
        @keydown="inputField"
        @keyup="keyUp"
        @paste="inputPast"
        @change ="inputValue"
      )
      .range-input__slider(ref="mortgagePrice")
    .calculator_s__cost-flat
      .property-calculator__wr-range
        p.property-calculator__range {{String(stgMin).slice(0,3)}} тыс.
        p.property-calculator__range {{String(stgMax).slice(0,2)/2}} млн
        p.property-calculator__range {{String(stgMax).slice(0,2)}} млн

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import noUiSlider from 'nouislider';
import Storage from '../development-tools/state.vue';
import IMask from 'imask';
export default {
  name: 'v-apartment-price',
  data(){
    return {
      realtySlider: '', // Слайдер "Стоимость недвижимости"
      dataField: 0, // Стоимость недвижимости
      dataFieldForCalculation: 0,
      subsidies: 0,
      stepApartment: 1, // Шаг для range инпутов
      stgMin: 625000, // Минимальное значение поля стоимости
      stgMiddle: 27000000, // Значение по середине (стоимость)
      stgMax: 56000000, // Максимальное значение поля стоимости
      input_salary:false
    }
  },
  methods:{
    initRealtySlider() {
      this.realtySlider = noUiSlider.create(this.$refs.mortgagePrice, {
        start: [this.stgMin],
        connect: 'lower',
        step: this.stepApartment,
        initial: this.stgMin,
        range: {
          min: this.stgMin,
          max: this.stgMax
        },
      });

      this.realtySlider.on('update', (val,handle) => {
        this.dataField = parseInt(val[handle]).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        this.dataFieldForCalculation = parseInt(val[handle]).toFixed(0)
      });
      this.realtySlider.on('end', (val,handle) => {
      });

    },

    inputFocus(el){
      const element = el.currentTarget
      element.querySelector('input').focus()
    },
    //Ввод значения пользователем
    inputField(event){
      const element = event.currentTarget
      let value = element.value

      value = parseInt(value.replace(/\s/g, ''));

      if(event.keyCode == 13){
        const parent = element.closest('.js--number-cost')
        let value = parent.querySelector('input').value
        value = parseInt(value.replace(/\s/g, ''));
        this.realtySlider.set(value);
      }
      if(value>this.stgMax){
        event.preventDefault();
      }
    },

    keyUp(e) {
      const element = e.currentTarget
      if(element.value!==''&&(parseInt(element.value.replace(/\s/g, ''))>=this.stgMin)&&parseInt(element.value.replace(/\s/g, ''))<=this.stgMax){
        this.realtySlider.set(parseInt(element.value.replace(/\s/g, '')));
      }

      else if(parseInt(element.value.replace(/\s/g, ''))>this.stgMax)  {
        this.realtySlider.set(this.stgMax);
      }
      else if(parseInt(element.value.replace(/\s/g, ''))<this.stgMin)  {

      }

      if(parseInt(element.value.replace(/\s/g, ''))>=this.stgMax){

      }
    },

    // расчет ндфл стоимости квартиры и отправка данных о квартире в компоненту с итоговой суммой
    calculationPageLoad(){
      //цена квартиры минус сумма субсидий
      let data_calculation = parseInt(this.dataFieldForCalculation) - parseInt(this.subsidies)
      if (data_calculation<0){
        data_calculation=0
      }
      const ndfl_cost_apartment = parseInt(data_calculation.toFixed(0))
      Storage.dispatch('ActionRealPriceAppartment',parseInt(this.dataFieldForCalculation))
      Storage.dispatch('ActionApartmentPrice',ndfl_cost_apartment)
      Storage.dispatch('ActionApartmentPriceForMarried',ndfl_cost_apartment)

    },
    inputValue(el){
      const element = el.currentTarget;
      let value = element.value
      value = parseInt(value.replace(/\s/g, ''));

      if(value<this.stgMin)  {
        this.dataFieldForCalculation = this.stgMin
        this.realtySlider.set(this.stgMin);
      }
    },
    inputPast(el){
      const element = el.currentTarget;
      let element_val = (el.clipboardData || window.clipboardData).getData('text');
      if ( element_val.search(/[^0-9]/g) != -1 ) {
        el.preventDefault();
      }
    },
  },
  mounted(){
    this.initRealtySlider()
    // this.inputCost()
  },
  computed:{

  },
  watch:{
    //как только стоимость квартиры изменилась, вызываю функцию
    dataField(){
      this.calculationPageLoad()
    }

  },
  created(){
    eventBus.$on('event_subsidies',(param)=>{
      this.subsidies = parseInt(param)
      this.calculationPageLoad()
    })
  },

  components:{}
};
</script>
<style scoped>
</style>
