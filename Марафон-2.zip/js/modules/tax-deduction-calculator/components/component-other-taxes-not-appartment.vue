<template lang="pug">
  .property-calculator__row.margin
    p.property-calculator__row-label Размер других вычетов, полученных ранее (за обучение, лечение и прочее), ₽
    .property-calculator__input-field.js--number-appartment(@click="inputFocus")
      input.property-calculator__value(inputmode="numeric")(
        v-model="dataField"
        type="text"
        ref="realtyInput"
        @keydown="inputField"
        @keyup="keyUp"
        @paste="inputPast"
        @change ="inputValue"
      )
      .range-input__slider(ref="mortgagePrice")
    .property-calculator__wr-range
      p.property-calculator__range {{stgMin}}
      p.property-calculator__range {{String(stgMax).slice(0,3)}} тыс.


</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import IMask from 'imask';
import Storage from '../development-tools/state.vue';
import noUiSlider from 'nouislider';
export default {
  name: 'v-container-other-tax',
  data(){
    return {
      realtySlider: '', // Слайдер "Стоимость недвижимости"
      dataField: 0, // Стоимость недвижимости
      dataFieldForCalculation: 0,
      subsidies: 0,
      stepApartment: 1, // Шаг для range инпутов
      stgMin: 0, // Минимальное значение поля стоимости
      stgMax: 900000, // Максимальное значение поля стоимости
      input_salary:false,
      start:0
    }
  },
  methods:{
    initRealtySlider() {
      this.realtySlider = noUiSlider.create(this.$refs.mortgagePrice, {
        start: [this.start],
        connect: 'lower',
        step: this.stepApartment,
        initial: this.stgMin,
        range: {
          min: this.stgMin,
          max: this.stgMax
        },
      });
      this.realtySlider.on('update', (val,handle) => {
        this.dataField = parseInt(val[handle]).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        this.dataFieldForCalculation = parseInt(val[handle]).toFixed(0)
      });

      this.realtySlider.on('end', (val,handle) => {
        // this.dataFieldForCalculation = parseInt(val[handle]).toFixed(0)
        // Storage.dispatch('ActionDebtOldCredit',parseInt(val[handle]))
      });

    },

    inputField(event){
      const element = event.currentTarget
      let value = element.value

      value = parseInt(value.replace(/\s/g, ''));

      if(event.keyCode == 13){
        const parent = element.closest('.js--number-cost')
        let value = parent.querySelector('input').value
        value = parseInt(value.replace(/\s/g, ''));
        this.realtySlider.set(value);
      }
      if(value>this.stgMax){
        event.preventDefault();
      }
    },
    keyUp(e) {
      const element = e.currentTarget


      if(element.value!==''&&(parseInt(element.value.replace(/\s/g, ''))>=this.stgMin)&&parseInt(element.value.replace(/\s/g, ''))<=this.stgMax){
        this.realtySlider.set(parseInt(element.value.replace(/\s/g, '')));
      }

      else if(parseInt(element.value.replace(/\s/g, ''))>this.stgMax)  {
        this.realtySlider.set(this.stgMax);
      }
      else if(parseInt(element.value.replace(/\s/g, ''))<this.stgMin)  {
      }

      if(parseInt(element.value.replace(/\s/g, ''))>=this.stgMax){

      }
    },
    inputValue(el){
      const element = el.currentTarget;
      let value = element.value
      value = parseInt(value.replace(/\s/g, ''));

      if(value<this.stgMin)  {
        this.dataFieldForCalculation = this.stgMin
        this.realtySlider.set(this.stgMin);
      }
    },
    inputPast(el){
      const element = el.currentTarget;
      let element_val = (el.clipboardData || window.clipboardData).getData('text');
      if ( element_val.search(/[^0-9]/g) != -1 ) {
        el.preventDefault();
      }
    },
    calculationPageLoad(){
      Storage.dispatch('ActionOtherDeductionsNotAppartment',parseInt(this.dataFieldForCalculation))
    },
    inputFocus(el){
      const element = el.currentTarget
      element.querySelector('input').focus()
    },
  },
  mounted(){
    this.initRealtySlider()
  },
  computed:{},
  watch:{
    dataField(){
      this.calculationPageLoad()
    }
  },
  components:{}
};
</script>
<style scoped>
</style>
