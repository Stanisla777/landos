const PLACEMARK_STATUS_CLASSES_BY_CARD = {
  'card-housing-cooperative_places_few': 'places_few',
  'card-housing-cooperative_places_enough': 'places_enough',
  'card-housing-cooperative_places_lot': 'places_lot',
};

/**
 * Соаздаёт шаблон метки
 * @param {HTMLElement} cardEl - карточка ЖСК
 * @returns {String} - шаблон
 */
function makePlacemarkLayout(cardEl) {
  let addedClass = '';
  Object.keys(PLACEMARK_STATUS_CLASSES_BY_CARD).forEach((placesClass) => {
    if (cardEl.classList.contains(placesClass)) {
      addedClass = PLACEMARK_STATUS_CLASSES_BY_CARD[placesClass];
    }
  });
  // eslint-disable-next-line no-undef
  return ymaps.templateLayoutFactory.createClass(
    `<div class="housing-cooperative-map-point ${addedClass}"></div>`
  );
}

/**
 * Соаздаёт шаблон балуна
 * @param {HTMLElement} cardEl - карточка ЖСК
 * @returns {String} - шаблон
 */
function makeBalloonLayout(cardEl) {
  const balloonCard = cardEl.cloneNode(true);
  balloonCard.classList.remove('card-housing-cooperative_map-list');
  balloonCard.classList.add('card-housing-cooperative_map');
  balloonCard.classList.add('js--housing-cooperative-map-balloon');
  const button = balloonCard.querySelector('.btn');
  button.classList.add('full');
  if (balloonCard.querySelector('.js--content-note')) {
    const event = new Event('mouseover');
    balloonCard.querySelector('.js--content-note').dispatchEvent(event);
  }

  // eslint-disable-next-line no-undef
  return ymaps.templateLayoutFactory.createClass(balloonCard.outerHTML, {
    build() {
      this.constructor.superclass.build.call(this);
      this.setBalloonPosition();
      this.setButtonState();
    },
    setBalloonPosition() {
      const balloon = document.querySelector('.js--housing-cooperative-map-balloon');
      balloon.style.left = `-${balloon.offsetWidth / 2}px`;
      balloon.style.top = `-${balloon.offsetHeight + 48}px`;
    },
    setButtonState() {
      const cardButton = cardEl.querySelector('.js--housing-cooperative-adder');
      const balloon = document.querySelector('.js--housing-cooperative-map-balloon');
      const balloonButton = balloon.querySelector('.js--housing-cooperative-adder');
      if (cardButton.classList.contains('btn_selected')) balloonButton.classList.add('btn_selected');
    }
  });
}

function scrollListToCardIsVisible(cardEl) {
  const wrapList = document.querySelector('.js--housing-cooperative-map-list');
  const cardOffsetBottom = wrapList.scrollHeight - cardEl.offsetTop - cardEl.offsetHeight;
  const wrapListScrollBottom = wrapList.scrollHeight - wrapList.scrollTop - wrapList.offsetHeight;

  if (cardEl.offsetTop < wrapList.scrollTop) { // карточка заходит за верхнюю границу
    wrapList.scrollTop = cardEl.offsetTop;
  } else if (cardOffsetBottom < wrapListScrollBottom) { // карточка заходит за нижнюю границу
    wrapList.scrollTop = cardEl.offsetTop + cardEl.offsetHeight - wrapList.offsetHeight;
  }
}

const ICON_PATHS = {
  default: '/dist/img/housing-cooperative/map-pin.svg',
  active: '/dist/img/housing-cooperative/map-pin-active.svg'
};

/**
 * Создаёт на карте метку, привязывая её к конкретной карточке ЖСК
 * @param {Array} coordinates - координаты
 * @param {Object} map - экземпляр карты
 */
function makeAndSetPlacemarkRelatedWithCard(coordinates, map) {
  const cardEl = document.querySelector(`[data-coordinates="[${coordinates}]"]`);

  // eslint-disable-next-line no-undef
  const myPlacemark = new ymaps.Placemark(coordinates, {}, {
    iconLayout: 'default#imageWithContent',
    iconImageHref: ICON_PATHS.default,
    iconImageSize: [38, 38],
    iconImageOffset: [-19, -44],
    iconContentLayout: makePlacemarkLayout(cardEl),
    balloonPanelMaxMapArea: 0,
    balloonLayout: makeBalloonLayout(cardEl),
    hideIconOnBalloonOpen: false,
  });

  myPlacemark.events.add('balloonopen', () => {
    cardEl.classList.add('active');
    myPlacemark.options.set({ iconImageHref: ICON_PATHS.active });
    if (document.documentElement.clientWidth > 1243) scrollListToCardIsVisible(cardEl);
    if (document.documentElement.clientWidth < 768) {
      const mobileCoordinates = [...coordinates];
      mobileCoordinates[0] += 5;
      map.setCenter(mobileCoordinates, map.getZoom(), { duration: 400 });
    }
  });

  myPlacemark.events.add('balloonclose', () => {
    cardEl.classList.remove('active');
    myPlacemark.options.set({ iconImageHref: ICON_PATHS.default });
  });

  cardEl.addEventListener('click', () => {
    myPlacemark.balloon.open();
    map.setCenter(coordinates, 4, { duration: 400 });
  });

  map.geoObjects.add(myPlacemark);
}

/**
 * Пример данных:
 * [
 *   [58.753301, 32.606263],
 *   [56.753301, 34.606263],
 *   [60.753301, 37.606263],
 *   [45.753301, 37.606263],
 *   [55.753301, 41.606263]
 * ];
 * @param {Array} dataCoordinates
 */
export function housingCooperativeMapList(dataCoordinates) {
  if (!dataCoordinates) return;
  const mapContainer = document.getElementById('housing-cooperative-map-list');
  if (!mapContainer) return;

  let myMap;
  // eslint-disable-next-line no-undef
  ymaps.ready(() => {
    // eslint-disable-next-line no-undef
    myMap = new ymaps.Map(mapContainer, {
      center: [55.753301, 37.606263],
      zoom: 4, // от 0 до 19
      controls: []
    }, {
      restrictMapArea: [[85.23618, -178.9], [-73.87011, 181]]
    });

    dataCoordinates.forEach((coordinates) => {
      makeAndSetPlacemarkRelatedWithCard(coordinates, myMap);
    });

    myMap.events.add('click', () => {
      myMap.balloon.close();
    });
  });
}

const PLACEMARK_STATUS_CLASSES = {
  'few-places': 'places_few',
  'enough-places': 'places_enough',
  'lot-of-places': 'places_lot',
};

/**
 * Создаёт на карте метку
 * @param {Array} data.coordinates - координаты
 * @param {String} data.status - статус
 * @param {Object} map - экземпляр карты
 */
function makeAndSetPlacemark({ coordinates, status }, map) {
  let statusClass = '';
  if (PLACEMARK_STATUS_CLASSES[status]) statusClass = PLACEMARK_STATUS_CLASSES[status];

  // eslint-disable-next-line no-undef
  const myPlacemark = new ymaps.Placemark(coordinates, {}, {
    iconLayout: 'default#imageWithContent',
    iconImageHref: ICON_PATHS.default,
    iconImageSize: [38, 38],
    iconImageOffset: [-19, -44],
    // eslint-disable-next-line no-undef
    iconContentLayout: ymaps.templateLayoutFactory.createClass(`<div class="housing-cooperative-map-point ${statusClass}"></div>`),
    hideIconOnBalloonOpen: false,
  });

  map.geoObjects.add(myPlacemark);
}

/**
 * {
 *   coordinates: [58.753301, 32.606263],
 *   status: 'lot-of-places' // 'few-places' || 'enough-places' || 'lot-of-places' || ''
 * };
 * @param {Object} dataDetail
 */
export function housingCooperativeMapDetail(dataDetail) {
  if (!dataDetail) return;
  const mapContainer = document.getElementById('housing-cooperative-map-detail');
  const mapContainerModal = document.getElementById('housing-cooperative-map-detail-modal');
  if (!mapContainer) return;

  const body = document.querySelector('body');
  const wrap = document.getElementsByClassName('js-p-wrap')[0];
  const modal = document.querySelector('.js--housing-cooperative-map-modal');
  const modalCloser = modal.querySelector('.housing-cooperative-detail__map-modal-closer');

  let myMap;
  // eslint-disable-next-line no-undef
  ymaps.ready(() => {
    // eslint-disable-next-line no-undef
    myMap = new ymaps.Map(mapContainer, {
      center: dataDetail.coordinates,
      zoom: 4, // от 0 до 19
      controls: []
    }, {
      restrictMapArea: [[85.23618, -178.9], [-73.87011, 181]]
    });

    makeAndSetPlacemark(dataDetail, myMap);

    if (document.documentElement.clientWidth < 768) {
      myMap.events.add('click', () => {
        modal.classList.add('is-open');
        wrap.classList.add('is-hidden');
        body.classList.add('menu-opened');
      });
    }
  });

  if (mapContainerModal && (document.documentElement.clientWidth < 768)) {
    let myMapModal;

    // eslint-disable-next-line no-undef
    ymaps.ready(() => {
      // eslint-disable-next-line no-undef
      myMapModal = new ymaps.Map(mapContainerModal, {
        center: dataDetail.coordinates,
        zoom: 4, // от 0 до 19
        controls: []
      });

      makeAndSetPlacemark(dataDetail, myMapModal);
    });

    modalCloser.addEventListener('click', () => {
      modal.classList.remove('is-open');
      wrap.classList.remove('is-hidden');
      body.classList.remove('menu-opened');
    });
  }
}
