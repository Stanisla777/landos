<template lang="pug">
  div
    template
      single-calculator(:array_kind_working="array_kind_working")

</template>
<script>
const SingleCalculator = () => import ("./SingleCalculator.vue");


export default {
  name: 'SingleCalculatorPointEntry',
  data(){
    return {
      array_kind_working:[]

    }
  },
  methods:{
  },
  mounted(){
    let professional_deductions = this.$attrs.array_kind_working
    if (professional_deductions!==undefined){
      this.array_kind_working = JSON.parse(professional_deductions);
    }
  },
  computed:{
  },
  watch:{
  },
  components:{
    SingleCalculator
  }
};
</script>
<style scoped>
</style>
