<template lang="pug">
  .calculator_s__calculator-row.calculator_s__two-columns_col.margin
    .calculator_s__period-input-wrapper
      p.calculator_s__calculator-label Передача объекта по факту
    .calculator_s__calculator-input.js--calendar-input
      input(type="text" placeholder="дд.мм.гггг" inputmode="numeric")(
        @input="changeDate"
      )
    p.ddu__error-green(v-if="delivery_date_fact&&appearance_error!==true") Дата передачи объекта ещё не наступила, расчёт может быть не точным
</template>
<script>
import IMask from 'imask';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import PopUp from '../components/v-component-pop-up.vue';
export default {
  name: 'v-date-actual-transfer',
  data(){
    return {
      error_count:0
    }
  },
  methods:{
    inputCalendar(){
      const input_status = document.querySelectorAll('.js--calendar-input input');
      const maskOptions = {
        mask: Date,
        min: new Date(1982, 0, 1),
        // max:new Date()
        // lazy:false
      };
      // eslint-disable-next-line no-restricted-syntax,camelcase,no-undef
      for (const item of input_status) {
        // eslint-disable-next-line no-new
        new IMask(item, maskOptions);
      }
    },
    changeDate(el) {
      const element = el.currentTarget;
      const container = element.closest('.js--tax-deduction_calculations');

      if (element.value.replace(/(_|\s)+/g, "").length===10) {
        const data = element.value.replace(/(_|\s)+/g, "").substr(6, 4)+'-'+element.value.replace(/(_|\s)+/g, "").substr(3, 2)+"-"+element.value.replace(/(_|\s)+/g, "").substr(0, 2);
        Storage.dispatch('ActionInputDateActual', [data, true ]);

      }
      else if(element.value.replace(/(_|\s)+/g, "").length < 10){
        Storage.dispatch('ActionInputDateActual', [null, false ]);
      }
    }
  },
  mounted(){
    this.inputCalendar()
  },
  computed:{
    appearance_error(){
      return Storage.getters.STATE_DIFFERENCE_DAYS
    },
    delivery_date_fact(){
      return Storage.getters.DELIVERY_DATE_FACT
    },
  },
  watch:{
  },
  components:{
    PopUp
  }
};
</script>
<style scoped>
</style>
