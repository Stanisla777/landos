<template lang="pug">
  .calculator_s__checkbox.ddu__checkbox
    .calculator_s__checkbox-item.checkbox-stylized
      input#checkbox_individual(type='radio' name="personal")(@change="checkboxChanged")
      label(for='checkbox_individual') Физическое лицо
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import ToolTip from '../components/v-component-tooltip.vue';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-checkbox-individual',
  data(){
    return {
      hint_text_1:"Вы получали ранее налоговый вычет за&#160;имущество, либо другие социальные налоговые вычеты",
      modal_text:'Вы не можете подать заявку на кредитные каникулы, если они уже действуют',
      paramName:null,
    }

  },
  methods:{
    checkboxChanged(el){
      const element = el.currentTarget
      if(!element.checked){
        const obj={
          state:false,
          text:this.modal_text
        }
        this.$emit('eventcheckboxChanged',obj)
        Storage.dispatch('ActionChecboxIndividual',false)
      }
      else{
        const obj={
          state:true,
          text:''
        }
        this.$emit('eventcheckboxChanged',obj)
        Storage.dispatch('ActionChecboxIndividual',true)
      }
    }


  },
  mounted(){

  },
  computed:{},
  watch:{
  },
  components:{
    ToolTip
  }
};
</script>
<style scoped>
</style>
