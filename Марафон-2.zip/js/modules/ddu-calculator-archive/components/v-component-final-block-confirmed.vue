<template lang="pug">
  .ddu__wrapper-detailed-result
    .ddu__footnote-up
      .ddu__footnote-sum
        p.ddu__footnote-title Сумма неустойки
        p.ddu__footnote-calculation {{parseFloat(calculate_result).toLocaleString('ru')}} ₽
      .ddu__footnote-wr-formula
        p.ddu__footnote-title Формула расчета

        p.ddu__footnote-formula(
          v-if="type_delay_show=='day_delivery_object' || type_delay_show=='start_date_delay'"
        ) {{parseFloat(apartment_price_show).toLocaleString('ru')}} × {{day_show}} × 1/{{checbox_individual_show === true ? '150' : checbox_individual_show === null ? '...' : '300'}} × {{applicable_rate}}%
        .ddu__footnote-formula-period(v-else)
          p.ddu__footnote-formula(
            v-for="item in formula_for_show"
          ) {{parseFloat(apartment_price_show).toLocaleString('ru')}} × {{item.count}} × 1/{{checbox_individual_show === true ? '150' : checbox_individual_show === null ? '...' : '300'}} × {{item.rate}}%

          //p.ddu__footnote-formula(
          //  v-for="item in rate_period"
          //) {{parseFloat(apartment_price_show).toLocaleString('ru')}} × {{item.count}} × 1/{{checbox_individual_show === true ? '150' : checbox_individual_show === null ? '...' : '300'}} × {{item.rate}}%




    .ddu__footnote-down.js-accordion-parent.active
      p.ddu__footnote-down-title Обращаем ваше внимание:
      ul.calculators__stylized-list.ddu__footnote-down-list.js-accordion-body(
        v-html="html_list"
      )



      p.ddu__footnote-hide.js--footnote-hide(
        @click="dropDownList"
      ) Скрыть



</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import ToolTip from '../components/v-component-tooltip.vue';
export default {
  name: 'v-component-final-block-confirmed',
  props:['html_list'],
  data(){
    return {

    }
  },
  methods:{
    dropDownList(el){
      const btn = el.currentTarget
      const parent = btn.closest('.js-accordion-parent');
      const container = parent.querySelector('.js-accordion-body ');
      container.style.maxHeight = `${container.scrollHeight}px`;
      if (parent.classList.contains('active')) {
        parent.classList.remove('active');
        // eslint-disable-next-line camelcase
        container.style.maxHeight = 0;
        btn.textContent = 'Показать'
      } else {
        // eslint-disable-next-line no-restricted-syntax,camelcase
        parent.classList.add('active');
        container.style.maxHeight = `${container.scrollHeight}px`;
        btn.textContent = 'Скрыть'
      }
    },
    maxHeightList(){
      const container = document.querySelector('.js-accordion-body')
      container.style.maxHeight = `1000px`;
    }

  },
  mounted(){
    // this.maxHeightList()
  },
  updated() {
    this.maxHeightList()
  },
  computed:{
    calculate_result(){
      return Storage.getters.CALCULATE_RESULT
    },
    apartment_price(){
      return Storage.getters.APARTMENT_PRICE
    },
    apartment_price_show(){
      return Storage.getters.APARTMENT_PRICE_SHOW
    },

    days_of_delay(){
      return Storage.getters.DAYS_OF_DELAY
    },
    minus_moratorium_days(){
      return Storage.getters.MINUS_MORATORIUM_DAYS
    },
    day_show(){
      return Storage.getters.DAY_SHOW
    },


    checbox_individual(){
      return Storage.getters.CHECBOX_INDIVIDUAL
    },
    checbox_individual_show(){
      return Storage.getters.CHECBOX_INDIVIDUAL_SHOW
    },

    check_entity(){
      return Storage.getters.CHECK_ENTITY
    },
    applicable_rate(){
      return Storage.getters.APPLICABLE_RATE
    },
    type_delay(){
      return Storage.getters.TYPE_DELAY
    },
    type_delay_show(){
      return Storage.getters.TYPE_DELAY_SHOW
    },

    formula_for_show(){
      return Storage.getters.FORMULA_FOR_SHOW
    },
    rate_period(){
      return Storage.getters.RATE_PERIOD
    },















  },

  watch:{

  },
  components:{
    ToolTip,
  },
  created(){
  //  Тут помещаюстя Шина событий
  }
};
</script>
<style scoped>
</style>
