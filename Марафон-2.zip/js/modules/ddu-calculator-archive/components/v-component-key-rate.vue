<template lang="pug">
  .calculator_s__calculator-row.margin

    .calculator_s__block-area.ddu__key-rate
      .ddu__key-rate-block
        svg(width='32', height='32', viewbox='0 0 32 32', fill='none', xmlns='http://www.w3.org/2000/svg')
          path(fill-rule='evenodd', clip-rule='evenodd', d='M1.33337 15.9999C1.33337 24.1001 7.89986 30.6666 16 30.6666C24.1002 30.6666 30.6667 24.1001 30.6667 15.9999C30.6667 7.89974 24.1002 1.33325 16 1.33325C7.89986 1.33325 1.33337 7.89974 1.33337 15.9999ZM28 15.9999C28 22.6274 22.6274 27.9999 16 27.9999C9.37261 27.9999 4.00003 22.6274 4.00003 15.9999C4.00003 9.37253 9.37261 3.99995 16 3.99995C22.6274 3.99995 28 9.37253 28 15.9999ZM14.6667 10.6666V15.9999C14.6667 16.7363 15.2637 17.3333 16.0001 17.3333C16.7364 17.3333 17.3334 16.7363 17.3334 15.9999V10.6666C17.3334 9.9302 16.7364 9.33325 16.0001 9.33325C15.2637 9.33325 14.6667 9.9302 14.6667 10.6666ZM16.9429 19.0571C17.4636 19.5778 17.4636 20.422 16.9429 20.9427C16.4222 21.4634 15.5779 21.4634 15.0572 20.9427C14.5365 20.422 14.5365 19.5778 15.0572 19.0571C15.5779 18.5364 16.4222 18.5364 16.9429 19.0571Z', fill='#F8D05F')
          mask#mask0_2240_44601(style='mask-type:alpha', maskunits='userSpaceOnUse', x='1', y='1', width='30', height='30')
            path(fill-rule='evenodd', clip-rule='evenodd', d='M1.33337 15.9999C1.33337 24.1001 7.89986 30.6666 16 30.6666C24.1002 30.6666 30.6667 24.1001 30.6667 15.9999C30.6667 7.89974 24.1002 1.33325 16 1.33325C7.89986 1.33325 1.33337 7.89974 1.33337 15.9999ZM28 15.9999C28 22.6274 22.6274 27.9999 16 27.9999C9.37261 27.9999 4.00003 22.6274 4.00003 15.9999C4.00003 9.37253 9.37261 3.99995 16 3.99995C22.6274 3.99995 28 9.37253 28 15.9999ZM14.6667 10.6666V15.9999C14.6667 16.7363 15.2637 17.3333 16.0001 17.3333C16.7364 17.3333 17.3334 16.7363 17.3334 15.9999V10.6666C17.3334 9.9302 16.7364 9.33325 16.0001 9.33325C15.2637 9.33325 14.6667 9.9302 14.6667 10.6666ZM16.9429 19.0571C17.4636 19.5778 17.4636 20.422 16.9429 20.9427C16.4222 21.4634 15.5779 21.4634 15.0572 20.9427C14.5365 20.422 14.5365 19.5778 15.0572 19.0571C15.5779 18.5364 16.4222 18.5364 16.9429 19.0571Z', fill='white')
          g(mask='url(#mask0_2240_44601)')
            rect(width='32', height='32', fill='#F8D05F')


        p С {{array_key_rate.date}} ключевая ставка ЦБ – {{array_key_rate.key}}%

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import PopUp from '../components/v-component-pop-up.vue';
export default {
  name: 'v-component-key-rate',
  data(){
    return {
      select_region:null
    }
  },
  methods:{


    sendKeyRate(){
      let value = '9.5'
      if(value.includes(',')){
        value = value.replace(',','.')
      }
      // Storage.dispatch('ActionKeyRate',value)
    },
  },
  mounted(){
    this.sendKeyRate()


  },
  computed:{
    array_key_rate(){
      return Storage.getters.LAST_CHANGE_KEY
    },
  },
  watch:{
  },
  components:{
    PopUp
  }
};
</script>
<style scoped>
</style>
