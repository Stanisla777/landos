<template lang="pug">
  div.calculator_s__calculator.ddu__calculator
    template(v-if="!pop_up")
      pop-up(
        :paramText="text_pop_up"
        v-on:eventClosePopUp="closePopUp($event)"
      )
    div.calculator_s__calculations.js--tax-deduction_calculations
      template
        component-key-rate
      .calculator_s__two-columns
        template
          component-apartment-price
      .ddu__date-transfer
        .calculator_s__two-columns
          template
            component-date-transfer(
              :first_period_date ="first_period_date"
            )
          template
            component-date-actual-transfer

      .calculator_s__calculator-row.margin
        p.calculator_s__calculator-label Кем вы являетесь?
          .ddu__row-checkbox
            template
              component-check-box-individual
            template
              component-check-box-entity
      template
        component-rate-application

      template
        component-button(
          v-on:eventCalculate="showCalculation"
        )

    //div.calculator_s__results.calculator_s__credir-holidays-results(
    //  :class="{zoomInD:final_result}"
    //)
    //  template(v-if="final_state_confirmed===true&&final_state_confirmed!=null")
    //    component-final-block-confirmed
    //  template(v-if="final_state_confirmed===false&&final_state_confirmed!=null")
    //    component-final-block-refusal

    div.calculator_s__results.dd__f-results(
      :class="{zoomInD:final_result}"
    )
      template
        component-final-block-confirmed(
          :html_list="html_list"
        )

</template>
<script>
import Vue from 'vue';
import eventBus from './development-tools/eventBus.vue';
import Storage from './development-tools/state.vue';
import ComponentKeyRate from './components/v-component-key-rate.vue';
import ComponentApartmentPrice from './components/v-component-apartment-price.vue';
import ComponentDateTransfer from './components/v-component-date-transfer.vue';
import ComponentDateActualTransfer from './components/v-component-date-actual-transfer.vue';
import ComponentCheckBoxIndividual from './components/v-component-checkbox-individual.vue';
import ComponentCheckBoxEntity from './components/v-component-checkbox-entity.vue';
import ComponentRateApplication from './components/v-component-rate-application.vue';
import ComponentButton from './components/v-component-button.vue';




import ComponentFinalBlockConfirmed from './components/v-component-final-block-confirmed.vue';
import PopUp from './components/v-component-pop-up.vue';






import ToolTip from './components/v-component-tooltip.vue';







export default {
  name: 'DduCalculator',
  data(){
    return {
      key_rates:null,
      first_period_date:null,

      pop_up:true,
      text_pop_up:null,
      hint_text:'Если дохода не было, укажите 0',


      final_state_confirmed:null,
      final_result:false,
      state_for_button:null,

      html_list:null,
      // final_result=false
    }
  },
  methods:{
    contentPopUp(ev){
      this.pop_up=ev.condition
      this.text_pop_up=ev.text
    },
    closePopUp(ev){
      this.pop_up=ev
    },
    callModal(ev){
      this.pop_up=ev.state
      this.text_pop_up=ev.text
      if(ev.state===false){
        this.state_for_button=false
      }
    },

    receivedData(){
      //получаю ключевые ставки
      let key_rates = this.$attrs.key_rates
      key_rates = JSON.parse(key_rates);
      this.first_period_date = new Date(String(Object.keys(key_rates[0])[0]).substr(6, 4)+"-"+String(Object.keys(key_rates[0])[0]).substr(3, 2)+"-"+String(Object.keys(key_rates[0])[0]).substr(0, 2))
      Storage.dispatch('ActionKeyRates',key_rates)

      let moratorium_dates = this.$attrs.moratorium_dates
      moratorium_dates = JSON.parse(moratorium_dates);
      Storage.dispatch('ActionMoratorium',moratorium_dates)

      let lower_rate = this.$attrs.lower_rate
      lower_rate = JSON.parse(lower_rate);
      Storage.dispatch('ActionLowerRate',lower_rate)
    },
    receivedHtml(){

      this.html_list = this.$attrs.html_list

    },

    startMoratoriumMethod(){
      // Storage.dispatch('ActionMoratorium')
    },

    showCalculation(){
      this.final_result=false
      setTimeout(()=>{
        this.final_result=true
      },100)
    },



  },
  mounted(){
    this.receivedData()
    this.receivedHtml()
    this.startMoratoriumMethod()

  },
  computed:{
    appearance_error(){
      return Storage.getters.STATE_DIFFERENCE_DAYS
    },
    show_final_block(){
      return Storage.getters.SHOW_FINAL_BLOCK
    },


  },
  watch:{
  },
  components:{
    ComponentFinalBlockConfirmed,
    ComponentDateTransfer,
    ComponentDateActualTransfer,
    ComponentCheckBoxIndividual,
    ComponentCheckBoxEntity,
    ComponentRateApplication,
    PopUp,
    ComponentKeyRate,
    ComponentApartmentPrice,
    ToolTip,
    ComponentButton,
  }
};
</script>
<style scoped>
</style>
