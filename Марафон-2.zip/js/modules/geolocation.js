// import throttle from './throttle';

export default function geolocation() {
    const geoWrap = document.querySelectorAll('.js--geolocation');

    for (let i = 0; i < geoWrap.length; i++) {
        const geoChoosen = geoWrap[i].querySelector('.geolocation__choosen');
        const geoBack = geoWrap[i].querySelector('.geolocation__back');
        let geoQuestion;
        let geoQuestionYes;
        let geoQuestionNo;

        if (document.documentElement.clientWidth >= 992) {
            geoQuestion = geoWrap[i].querySelector('.geolocation__question');

            if (geoQuestion) {
                geoQuestionYes = geoQuestion.querySelector('.js--geolocation-yes');
                geoQuestionNo = geoQuestion.querySelector('.js--geolocation-no');
            }
        } else {
            geoQuestion = document.querySelector('.geolocation__question_mobile');
            geoQuestionYes = geoQuestion.querySelector('.js--geolocation-yes');
            geoQuestionNo = geoQuestion.querySelector('.js--geolocation-no');
        }

        geoChoosen.addEventListener('click', () => {
            geoWrap[i].classList.toggle('open');

            if (geoWrap[i].querySelector('.geolocation__question')) {
                geoWrap[i].querySelector('.geolocation__question').classList.remove('open');
            }
        });

        geoBack.addEventListener('click', () => {
            geoWrap[i].classList.remove('open');
        });

        if (geoQuestion) {
            geoQuestionYes.addEventListener('click', (e) => {
                e.preventDefault();
                geoQuestion.classList.remove('open');
            });
            geoQuestionNo.addEventListener('click', (e) => {
                e.preventDefault();
                geoQuestion.classList.remove('open');
                if (document.documentElement.clientWidth < 992) {
                    document.getElementById('menu').classList.add('is-open');
                }
                geoWrap[i].classList.add('open');
            });
        }
    }
}
