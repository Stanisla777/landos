// eslint-disable-next-line import/no-named-as-default
import dropDown from './dropDown';

function birthdayListSprosi() {
  // eslint-disable-next-line camelcase
  const btn_list = document.querySelectorAll('.birthday__directions-most-popular-item-btn');
  // eslint-disable-next-line no-restricted-syntax,camelcase
  for (const item of btn_list) {
    item.onclick = () => {
      dropDown(item, 0);
    };
  }
}
function dropDownBirthdayMedia() {
  const btn = document.querySelector('.birthday__directions-tab-btn-media');
  if (btn) {
    btn.onclick = () => {
      dropDown(btn, 0);
    };
  }
}
function scrollSection() {
  // eslint-disable-next-line camelcase
  const scroll_btn = document.querySelector('.js--scroll-to-section');
  // eslint-disable-next-line camelcase
  if (scroll_btn) {
    scroll_btn.onclick = () => {
      const data = scroll_btn.getAttribute('data-scroll');
      const yOffset = -20;
      const element = document.querySelector(`.js-scroll[data-scroll=${data}]`);
      if (element) {
        const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
        window.scrollTo({ top: y, behavior: 'smooth' });
      }
    };
  }
}
// Функция нахождения элемента с наибольшей высотой и присваения высоты остальным требуемым блокам
// eslint-disable-next-line camelcase
function setEqualHeight(array_block) {
  let maxHeight = 0; // переменная для хранения максимальной высоты
  // eslint-disable-next-line camelcase
  for (let i = 0; i < array_block.length; i++) {
    // eslint-disable-next-line no-param-reassign
    array_block[i].style.height = 'auto'; // сбрасываем высоту каждого элемента
    // eslint-disable-next-line max-len
    if (array_block[i].offsetHeight > maxHeight) { // проверяем, является ли высота элемента максимальной
      maxHeight = array_block[i].offsetHeight; // обновляем значение максимальной высоты
    }
  }
  for (let i = 0; i < array_block.length; i++) {
    // eslint-disable-next-line no-param-reassign
    array_block[i].style.height = `${maxHeight}px`; // устанавливаем высоту каждого элемента равной максимальной высоте
  }
}
function sameHeightTaxDeduction() {
  // eslint-disable-next-line camelcase
  const array_block = document.querySelectorAll('.calculator_s__types-deductions .calculator_s__types-deductions-title');
  window.addEventListener('load', () => setEqualHeight(array_block)); // запуск при полной загрузке страницы
  window.addEventListener('resize', () => setEqualHeight(array_block)); /// запуск при изменении размеров страницы
}
// функция копирования содержимого при клике
function copyAble() {
  document.querySelectorAll('.js--copyable').forEach((element) => {
    element.addEventListener('click', async () => {
      if (element.classList.contains('js--what-copyable')) {
        try {
          await navigator.clipboard.writeText(element.textContent);
          if (element.closest('.js--wrapper-inserting-copied')) {
            if (element.closest('.js--wrapper-inserting-copied').querySelector('.js--successful-copying')) {
              // eslint-disable-next-line no-param-reassign
              element.closest('.js--wrapper-inserting-copied').querySelector('.js--successful-copying').textContent = 'Текст скопирован!';
            }
          }
        } catch (err) {
          if (element.closest('.js--wrapper-inserting-copied')) {
            element.closest('.js--wrapper-inserting-copied').classList.add('active');
          }
        }
      } else {
        const child = element.querySelector('.js--what-copyable');
        if (child) {
          try {
            await navigator.clipboard.writeText(child.textContent);
            // eslint-disable-next-line no-param-reassign
            element.closest('.js--wrapper-inserting-copied').querySelector('.js--successful-copying').textContent = 'Текст скопирован!';
          } catch (err) {
            if (element.closest('.js--wrapper-inserting-copied')) {
              element.closest('.js--wrapper-inserting-copied').classList.add('active');
            }
          }
        }
      }
    });
  });
}

function dropDownTags() {
  const btnTags = document.querySelectorAll('.js--dropDown-btn');
  // eslint-disable-next-line no-restricted-syntax
  for (const item of btnTags) {
    item.onclick = (el) => {
      // eslint-disable-next-line max-len
      // if (!el.target.classList.contains('js--footer-tags-link') && document.documentElement.clientWidth <= 480) {
        dropDown(el.target, 0);
      // }
    };
  }
}
export default function collectionSmallFunctions() {
  birthdayListSprosi();
  dropDownBirthdayMedia();
  scrollSection();
  sameHeightTaxDeduction();
  copyAble();
  dropDownTags();
}
