<script>
import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios';
import VueAxios from 'vue-axios';
Vue.use(VueAxios, axios);
Vue.use(Vuex);

export default new Vuex.Store({
  state:{
    btn_active:false,
    resultDaData:[], //что приходит от сервиса дадата
    resultDaDataCode:null, // код ответа от DaData
    request_result:null,//что приходит от результата попадает ли город в семейную ипотеку или нет
    error_not_found_town:false,
    timeout: null,
    preload_btn:false,



    "code": 200,
    "description": "",
  },
  getters:{
    RESULTDADATA(state){
      return state.resultDaData
    },
    RESULTDADATACODE(state){
      return state.resultDaDataCode
    },
    EERORNOTFOUNDTOWN(state){
      return state.error_not_found_town
    },
    REQUESTRESULT(state){
      return state.request_result
    },
    PRELOADBTN(state){
      return state.preload_btn
    },
    BTNACTIVE(state){
      return state.btn_active
    },
  },
  mutations:{
    mutationGetDaData(state,received_perem){
      if (!received_perem){
        return
      }
      let daData = {}
      daData.query = received_perem

      //это для тестирования
      //-------------------------------------------------

      // state.resultDaData=[
      //   {
      //     "name":"300000, Тульская обл, г Тула Кышты мылты кырты Скотопрогоньевск",
      //     "oktmo":"70701000001"
      //   },
      //   {
      //     "name":"665245, Иркутская обл, г Тулун",
      //     "oktmo":"25732000001"
      //   }
      // ]
      // //
      // setTimeout(() => {
      //   state.request_result = {
      //     'code': 400,
      //     'description': 'Всё плохо, ',
      //   };
      //   console.log(state.request_result);
      //   console.log(state.resultDaDataCode);
      // }, 2000);
      //
      // setTimeout(() => {
      //   state.resultDaDataCode = 200
      //   state.request_result = null
      //   console.log(state.request_result);
      //   console.log(state.resultDaDataCode);
      // }, 10000);



      //-------------------------------------------------------------------------

      axios({
        method:'post',
        url:'/api/local/check-city-for-family-mortgage/suggestions/',

        headers: {
          "Content-type": "application/json; charset=UTF-8",
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        },

        data:daData
      })
        .then((res) => {
          if (res.data.result) {
            state.resultDaData = res.data.result;
          }
          if (res.data.code) {
            state.resultDaDataCode = res.data.code;
            if (res.data.code === 200) {
              state.request_result = null;
            }
          }
        })

        //Если запрос с ошибкой
        .catch((error)=> {
          if(error.response){
            if (error.response.data!=undefined){
              console.log(error.response);
              state.request_result = error.response.data
            }
          }
          console.log(error);
        });
    },
    mutationGetResult(state,received_perem){

      //это для тестирования
      //-------------------------------------------------

      // state.request_result={
      //   "code": 200,
      //   "description": "Всё хорошо",
      // }

      //-------------------------------------------------------------------------

      axios({
        method:'post',
        url:'/api/local/check-city-for-family-mortgage/check/',

        headers: {
          "Content-type": "application/json; charset=UTF-8",
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        },

        data:{
          "oktmo":received_perem[0],
          "smart-token":received_perem[1]
        }
      })
        .then((res)=>{
          if(res.data.description){
            state.request_result = res.data
          }
          state.preload_btn=false

        })

        //Если запрос с ошибкой
        .catch((error)=> {
          if(error.response){
            if (error.response.data!=undefined){
              console.log(error.response);
              state.request_result = error.response.data
            }
          }
          state.preload_btn=false
          console.log(error);
        });
    },
    mutationRemoveError(state){
      if (state.request_result!==null&&state.request_result.code!==undefined) {
        if(state.request_result.code<=400) {
          state.request_result=null
        }

      }
      state.resultDaData=[]
    },
    mutationStandingButton(state){
      state.preload_btn = true
    },
    mutationButtonActive(state,received_perem){
      state.btn_active = received_perem
    },


  },
  actions:{

    //  Отправка данных на сервер
    ActionGetDaData({commit,state},param){
      commit('mutationGetDaData',param)
    },
    ActionGetResult({commit,state},param){
      commit('mutationGetResult',param)
    },
    ActionRemoveError({commit,state}){
      commit('mutationRemoveError')
    },
    ActionStandingButton({commit,state}){
      commit('mutationStandingButton')
    },
    ActionButtonActive({commit,state},param){
      commit('mutationButtonActive',param)
    },


  },
})
</script>
