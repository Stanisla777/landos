<template lang="pug">
  div
    template
      v-component-it-company
    <!--    template-->
    <!--      v-component-check-yourself-->
</template>
<script>
import Vue from 'vue';
import Storage from './development-tools/state.vue';
import vComponentItCompany from './components/v-component-search-family-mortgage.vue';
import vComponentCheckYourself from './components/v-component-check-yourself.vue';

export default {
  name: 'searchFamilyMortgage',
  components:{
    vComponentItCompany,
    vComponentCheckYourself
  },
};
</script>
<style scoped>
</style>
