<template lang="pug">
  .refinancing-calc__payment-list.js-accordion-parent
    h3.refinancing-calc__payment-list-title График платежей
    .mortgage-calculator__payment-table.refinancing-calc__payment-table
      table.iksweb
        thead
          tr
            td №
            td Месяц
            td Сумма платежа
            td Платеж по основному долгу, ₽
            td Платеж по процентам, ₽
            td Остаток долга, ₽

        tbody
          tr(
            v-for='(value,index) in payment_list'
          )
            td {{index+1}}
            td {{value.month}}
            td {{value.payment.toLocaleString('ru')}}
            td {{value.principal_payment.toLocaleString('ru')}}
            td {{value.monthly_interest_payment.toLocaleString('ru')}}
            td {{value.remainder.toLocaleString('ru')}}


</template>
<script>
import Vue from 'vue';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-component-payment-list',
  props:[],
  data(){
    return {
      data_type_payment:null,
      show_all_table:true
    }
  },
  methods:{
    dropDownList(el){
      const element = el.currentTarget
      this.show_all_table=!this.show_all_table
      if(this.show_all_table==true){
        element.textContent='показать все платежи'
        const yOffset = -20;
        const parent = element.closest('.js-scroll');
        const y = parent.getBoundingClientRect().top + window.pageYOffset + yOffset;
        window.scrollTo({ top: y, behavior: 'smooth' });
      }
      else {
        element.textContent='скрыть все платежи'
      }
    },
  },
  mounted(){

  },
  computed:{

    payment_list(){
      return Storage.getters.PAYMENTLIST
    },
  },
  watch:{
  },
  created(){
    eventBus.$on('receivePaymentType',(param)=>{
      this.data_type_payment=param
    })
  },
  components:{}
};
</script>
<style scoped>
</style>
