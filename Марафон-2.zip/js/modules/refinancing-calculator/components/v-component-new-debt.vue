<template lang="pug">
  .property-calculator__row.margin

    p.property-calculator__row-label Новая сумма, ₽
    .property-calculator__input-field.js--number-new-debt(@click="inputFocus")
      input.property-calculator__value(inputmode="numeric")(

        v-model="dataField"
        type="text"
        ref="realtyInput"
        @keydown="inputField"
        @keyup="keyUp"
        @change ="inputValue"
        @paste="inputPast"
        @blur="moveAnotherElement"
        @click="inpRemoveMark"
      )

      .range-input__slider(ref="mortgagePrice")
    .property-calculator__wr-range
      p.property-calculator__range {{String(stgMin).slice(0,1)}} тыс.
      p.property-calculator__range {{String(stgMax).slice(0,2)/2}} млн.
      p.property-calculator__range {{String(stgMax).slice(0,2)}} млн.
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import noUiSlider from 'nouislider';
import Storage from '../development-tools/state.vue';
import IMask from 'imask';
import onlyNumbers from '../custom-scripts/only-numbers.js'
export default {
  name: 'v-new-debt',
  data(){
    return {
      realtySlider: '', // Слайдер "Стоимость недвижимости"
      dataField: 0, // Стоимость недвижимости
      dataFieldForCalculation: 0,
      subsidies: 0,
      stepApartment: 1, // Шаг для range инпутов
      stgMin: 5000, // Минимальное значение поля стоимости
      stgMiddle: 27000000, // Значение по середине (стоимость)
      stgMax: 56000000, // Максимальное значение поля стоимости
      input_salary:false,
      start:1500000,
      count:0,
      amount_addition:500000
    }
  },
  methods:{
    initRealtySlider() {
      this.realtySlider = noUiSlider.create(this.$refs.mortgagePrice, {
        start: [this.old_debt_for_new + this.amount_addition],
        connect: 'lower',
        step: this.stepApartment,
        initial: this.stgMin,
        range: {
          min: this.stgMin,
          max: this.stgMax
        },
      });
      this.realtySlider.on('update', (val,handle) => {
        this.input_salary = false
        this.dataField = parseInt(val[handle]).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
      });

      this.realtySlider.on('end', (val,handle) => {
        this.dataFieldForCalculation = parseInt(val[handle]).toFixed(0)
        Storage.dispatch('ActionDebtNewCredit',parseInt(val[handle]))
        if(this.count===0&&this.count!==1){
          this.count+=1
        }
      });

    },
    inputCost(){
      const input_status = document.querySelectorAll('.js--number-new-debt input');
      const maskOptions = {
        mask: Number,
        thousandsSeparator: ' ',
        // max:this.stgMax
      };
      for (const item of input_status) {
        new IMask(item, maskOptions);
      }
    },


    //Ввод значения пользователем
    inputField(event){
      onlyNumbers(event)
      const element = event.currentTarget
      let value = element.value
      value = parseInt(value.replace(/\s/g, ''));
      if(event.keyCode == 13){
        const parent = element.closest('.js--number-new-debt')
        let value = parent.querySelector('input').value
        value = parseInt(value.replace(/\s/g, ''));
        // this.realtySlider.set(value);
      }
      if(value>this.stgMax){
        event.preventDefault();
      }
    },


    keyUp(e) {
      const element = e.currentTarget

      if(element.value!==''&&(parseInt(element.value.replace(/\s/g, ''))>=this.stgMin)&&parseInt(element.value.replace(/\s/g, ''))<=this.stgMax){
        Storage.dispatch('ActionDebtNewCredit',parseInt(element.value.replace(/\s/g, '')))
        this.realtySlider.set(parseInt(element.value.replace(/\s/g, '')));
      }

      else if(parseInt(element.value.replace(/\s/g, ''))>this.stgMax)  {
        Storage.dispatch('ActionDebtNewCredit',parseInt(this.stgMax))
        this.realtySlider.set(this.stgMax);
      }
      else if(parseInt(element.value.replace(/\s/g, ''))<this.stgMin)  {
        Storage.dispatch('ActionDebtNewCredit',parseInt(this.stgMin))
      }
    },
    inputValue(el){
      const element = el.currentTarget;
      let value = element.value
      value = parseInt(value.replace(/\s/g, ''));


      if(!isNaN(value)){
        // this.realtySlider.set(value);
      }

      if(value>this.stgMax)  {
        this.dataFieldForCalculation = this.stgMax
        // this.realtySlider.set(this.stgMax);
      }
      if(value<this.stgMin)  {
        this.dataFieldForCalculation = this.stgMin
        this.realtySlider.set(this.stgMin);
      }
    },
    inputPast(el){
      const element = el.currentTarget;
      let element_val = (el.clipboardData || window.clipboardData).getData('text');
      if ( element_val.search(/[^0-9]/g) != -1 ) {
        el.preventDefault();
      }
    },

    inputFocus(el){
      const element = el.currentTarget
      element.querySelector('input').focus()
    },

    inpRemoveMark(el){
      const element = el.currentTarget
      if(element.value==0||element.value=='0 %'){
        element.value=''
      }
    },
    moveAnotherElement(el) {
      const element = el.currentTarget;
      if (!element.value.includes('₽')) {
        element.value = this.dataField;
      }
      if (element.value==='') {
        element.value = this.stgMin;
        this.realtySlider.set(this.stgMin);
        Storage.dispatch('ActionDebtNewCredit',this.stgMin)

      }
    },

    calculationPageLoad(){
      Storage.dispatch('ActionDebtNewCredit',parseInt(this.dataFieldForCalculation))
    },

  },
  mounted(){
    this.initRealtySlider()
    // this.inputCost()
    Storage.dispatch('ActionDebtNewCredit',parseInt(this.dataField.replace(/\s/g, '')) - this.amount_addition)
  },

  computed:{
    old_debt_for_new(){
      return Storage.getters.OLDDEBTFORNEW
    },
    button_state(){
      return Storage.getters.BUTTON_STATE.parameter_debt
    }
  },
  watch:{
    button_state() {
      this.realtySlider.set(this.old_debt_for_new + this.amount_addition);
      if (this.button_state===true) {
        Storage.dispatch('ActionDebtNewCredit', parseInt(this.dataField.replace(/\s/g, '')));
      }
    }
  },
  created(){
  },
  components:{}
};
</script>
<style scoped>
</style>
