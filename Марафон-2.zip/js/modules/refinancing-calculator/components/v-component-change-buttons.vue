<template lang="pug">
  .property-calculator__row.margin
    p.property-calculator__sub-title Что изменится в вашем кредите?
    .refinancing-calc__row-buttons-change
      .swiper-container.js-button-slider
        .swiper-wrapper

          .swiper-slide
            .refinancing-calc__buttons-change(
              @click="stateChange($event,'parameter_rate')"
              :class="[button_state.parameter_rate===true?'active':'']"
            )
              p Ставка

          .swiper-slide
            .refinancing-calc__buttons-change(
              @click="stateChange($event,'parameter_debt')"
              :class="[button_state.parameter_debt===true?'active':'']"
            )
              p Сумма

          .swiper-slide
            .refinancing-calc__buttons-change(
              @click="stateChange($event,'parameter_time')"
              :class="[button_state.parameter_time ===true?'active':'']"
            )
              p Срок

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Swiper, { Navigation, Pagination } from 'swiper';
import Storage from '../development-tools/state.vue';
Swiper.use([Navigation, Pagination]);
let mySwiper;

export default {
  name: 'v-change-buttons',
  props:[''],
  data(){
    return {

    }
  },
  methods:{
    initSliderStoriesButton() {
      mySwiper = new Swiper('.js-button-slider', {
        loop: false,
        simulateTouch: true,
        allowTouchMove: false,
        centeredSlides: false,
        slidesPerView:3,
        slidesPerGroup:1,
        spaceBetween: 12,
        // autoHeight:false,
        // observer:true,
        // autoResize:false,
        // visibilityFullFit: true,
        // centeredSlides:true,

        navigation: false,
        pagination: false,
        breakpoints: {
          0: {
            slidesPerView:2,
            allowTouchMove: true,
            centeredSlides: true,
          },
          470: {
            slidesPerView:3,
            allowTouchMove: false,
            centeredSlides: false,
          }
        },
      });
      mySwiper.on('slideChange', () => {


      });
      // mySwiper.on('transitionEnd', function() {
      //   const slide_calculator = document.querySelectorAll('.test-slide-calculator')
      //   slide_calculator.forEach(function (item){
      //     item.querySelector('p:first-child').textContent = mySwiper.realIndex+1
      //   })
      // });
      // this.current_slide = current_slide
    },
    stateChange(el,parametr){
      const element = el.currentTarget
      Storage.dispatch('ActionStateChange',parametr)
    },
  },
  mounted(){
    this.initSliderStoriesButton()
  },
  computed:{
    button_state(){
      return  Storage.getters.BUTTON_STATE
    }
  },
  watch:{
  },
  components:{}
};
</script>
<style scoped>
</style>
