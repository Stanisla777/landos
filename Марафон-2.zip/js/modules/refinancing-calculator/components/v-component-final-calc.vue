<template lang="pug">
  .property-calculator__final-calc
    .refinancing-calc__final-item-block
      p.refinancing-calc__final-main-title Результаты расчета
      .property-calculator__final-item-row
        .refinancing-calc__final-item-col(
          v-bind:class="savings_overpayment>0 ? 'green': savings_overpayment<0 ? 'red' : ''"
        )
          p.refinancing-calc__final-item-value {{savings_overpayment_show.replace('-','')}} ₽
          p.refinancing-calc__final-item-key(
            v-if="savings_overpayment>=0"
          ) Экономия
          p.refinancing-calc__final-item-key(
            v-if="savings_overpayment<0"
          ) Переплата
        .refinancing-calc__final-item-col
          p.refinancing-calc__final-item-value {{annuity_debt_plus_interest_new_credit}} ₽
          p.refinancing-calc__final-item-key Долг + проценты

    .refinancing-calc__final-item-block
      p.property-calculator__final-sub-title Новые условия кредитования
      .property-calculator__final-item-row
        .refinancing-calc__final-item-col
          p.refinancing-calc__final-item-value {{annuity_monthly_payment_new_credid}} ₽
          p.refinancing-calc__final-item-key Ежемесячный платеж
        .refinancing-calc__final-item-col
          p.refinancing-calc__final-item-value {{annuity_overpayment_new_credit}} ₽
          p.refinancing-calc__final-item-key Переплата

    .refinancing-calc__final-item-block
      p.property-calculator__final-sub-title Старые условия кредитования
      .property-calculator__final-item-row
        .refinancing-calc__final-item-col
          p.refinancing-calc__final-item-value {{annuity_monthly_payment_old_credid}} ₽
          p.refinancing-calc__final-item-key Ежемесячный платеж
        .refinancing-calc__final-item-col
          p.refinancing-calc__final-item-value {{annuity_overpayment_old_credit}} ₽
          p.refinancing-calc__final-item-key Переплата

    button(type="button").property-calculator__final-btn-call-schedule(
     @click="callModal"
    ) График платежей

</template>
<script>
import Vue from 'vue';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-component-final-calc',
  props:[],
  data(){
    return {
      data_type_payment:null
    }
  },
  methods:{
    callModal(){
      Storage.dispatch('ActionModal',true)
      document.body.classList.add('body-modal')


    },

  },
  mounted(){

  },
  computed:{

    annuity_monthly_payment_old_credid(){
      return Storage.getters.ANNUITYMONTHLYPAYMENTOLDCREDIT.toLocaleString('ru')
    },
    annuity_overpayment_old_credit(){
      return Storage.getters.ANNUITYOVERPAYMENTOLDCREDIT.toLocaleString('ru')
    },

    //новый кредит
    annuity_monthly_payment_new_credid(){
      return Storage.getters.ANNUITYMONTHLYPAYMENTNEWCREDIT.toLocaleString('ru')
    },
    annuity_overpayment_new_credit(){
      return Storage.getters.ANNUITYOVERPAYMENTNEWCREDIT.toLocaleString('ru')
    },

    //переплата-экономия
    savings_overpayment(){
      return parseFloat(Storage.getters.SAVINGS_OVERPAYMENT)
    },
    savings_overpayment_show(){
      return Storage.getters.SAVINGS_OVERPAYMENT_SHOW.toLocaleString('ru')
    },
    annuity_debt_plus_interest_new_credit(){
      return Storage.getters.ANNUITYDEBTPLUSINTERESTNEWCREDIT.toLocaleString('ru')
    },

  },
  watch:{
  },
  created(){
    eventBus.$on('receivePaymentType',(param)=>{
      this.data_type_payment=param
    })
  },

  components:{}
};
</script>
<style scoped>
</style>
