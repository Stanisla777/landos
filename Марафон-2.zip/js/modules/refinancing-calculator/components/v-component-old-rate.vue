<template lang="pug">
  .property-calculator__row.property-calculator__several-columns_col.margin
    p.property-calculator__row-label Ставка, %
    .property-calculator__input-field.js--number-old-rate(@click="inputFocus")
      input.property-calculator__value(inputmode="decimal")(
        v-model="dataField"
        type="text"
        ref="realtyInput"
        @keyup="keyUp"
        @keydown="inputField"
        @change ="inputValue"
        @paste="inputPast"
        @blur="moveAnotherElement"
        @click="inpRemoveMark"
      )

      .range-input__slider(ref="mortgagePrice")
    .calculator_s__cost-flat
      p.property-calculator__range {{stgMin}}
      p.property-calculator__range {{stgMax}}
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import noUiSlider from 'nouislider';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-old-rate',
  data(){
    return {
      realtySlider: '', // Слайдер "Стоимость недвижимости"
      dataField: 0, // Стоимость недвижимости
      dataFieldForCalculation: 0,
      subsidies: 0,
      stepApartment: 0.1, // Шаг для range инпутов
      stgMin: 0.1, // Минимальное значение поля стоимости
      stgMax: 100, // Максимальное значение поля стоимости
      start:9.2, // с какого значения при загрузке должен стоять ползунок
      input_salary:false,
      slider:false,
    }
  },
  methods:{
    initRealtySlider() {
      this.realtySlider = noUiSlider.create(this.$refs.mortgagePrice, {
        start: [this.start],
        connect: 'lower',
        initial: this.stgMin,
        step:0.1,


        range: {
          min: this.stgMin,
          max: this.stgMax
        },
      });
      this.realtySlider.on('update', (val,handle) => {
        this.input_salary = false
        this.dataField = parseFloat(val[handle]).toFixed(1).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
      });
      this.realtySlider.on('end', (val,handle) => {
        this.dataFieldForCalculation = parseFloat(val[handle]).toFixed(1)
        Storage.dispatch('ActionRateOldCredit',parseFloat(val[handle]).toFixed(1))
      });
    },
    //Ввод значения пользователем
    inputFocus(el){
      const element = el.currentTarget
      element.querySelector('input').focus()
    },
    //Ввод значения пользователем
    inputField(event){
      const element = event.currentTarget
      let value = element.value
      // eslint-disable-next-line eqeqeq
      if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27
        // Разрешаем: Ctrl+A
        // eslint-disable-next-line eqeqeq
        || (event.keyCode == 65 && event.ctrlKey === true)
        // eslint-disable-next-line eqeqeq
        || (event.keyCode == 86 && event.ctrlKey === true)
        // Разрешаем: home, end, влево, вправо
        || (event.keyCode >= 35 && event.keyCode <= 39)) {
        // Ничего не делаем

      } else {
        // Запрещаем все, кроме цифр на основной клавиатуре, а так же Num-клавиатуре
        if ((event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105)
          && (event.keyCode != 110)&& (event.keyCode != 191)&& (event.keyCode != 190)&& (event.keyCode != 188)) {
          event.preventDefault();
        }
        if ((event.keyCode >= 48 || event.keyCode <= 57) && event.shiftKey === true) {
          event.preventDefault();
        }
      }

    },
    keyUp(e) {
      const element = e.currentTarget
      if (element.value.includes('ю')){
        element.value = element.value.replace(/%/g, "");
        element.value = element.value.replace(/ю/g, ".");
      }
      else if (element.value.includes('б')){
        element.value = element.value.replace(/%/g, "");
        element.value = element.value.replace(/б/g, ".");
      }
      else if (element.value.includes(',')){
        element.value = element.value.replace(/%/g, "");
        element.value = element.value.replace(/,/g, ".");
      }
      else if (element.value.includes('/')){
        element.value = element.value.replace(/%/g, "");
        element.value = element.value.replace(/\//g, ".");
      }


      if(element.value!==''&&(parseFloat(element.value)>=this.stgMin)&&parseFloat(element.value)<=this.stgMax){
        Storage.dispatch('ActionRateOldCredit',parseFloat(element.value).toFixed(1))
      }

      else if(parseFloat(element.value)>this.stgMax)  {
        Storage.dispatch('ActionRateOldCredit',parseFloat(this.stgMax).toFixed(1))
      }
      else if(parseFloat(element.value)<this.stgMin)  {
        Storage.dispatch('ActionRateOldCredit',parseFloat(this.stgMin).toFixed(1))
      }
    },
    inputValue(el){
      const element = el.currentTarget;
      let value = element.value
      value = parseFloat(value.replace(/\s/g, ''));
      if(value===''){

      }
      if(value!==''){
        this.realtySlider.set(value);
      }

      // if(value>this.stgMax)  {
      //   this.dataFieldForCalculation = this.stgMax
      // }
      // if(value<this.stgMin)  {
      //   this.dataFieldForCalculation = this.stgMin
      // }


    },
    changeInput(el){
      const element = el.currentTarget;
      let value = element.value
      value = parseFloat(value.replace(/\s/g, ''));
      if(value===''){

      }
      if(value!==''){
        Storage.dispatch('ActionRateOldCredit',parseFloat(value))
      }

      if(value>this.stgMax)  {
        Storage.dispatch('ActionRateOldCredit',parseFloat(this.stgMax))
      }
    },
    inputPast(el){
      const element = el.currentTarget;
      let element_val = (el.clipboardData || window.clipboardData).getData('text');
      if ( element_val.search(/[^0-9]/g) != -1 ) {
        el.preventDefault();
      }
    },
    inpRemoveMark(el) {
      const element = el.currentTarget;
      if(element.value==0||element.value=='0 %'){
        element.value=''
      }
      // if (element.value.includes(' %')) {
      //   element.value = parseFloat(element.value.replace(/\s/g, ''));
      // }
    },
    moveAnotherElement(el) {
      const element = el.currentTarget;
      if (!element.value.includes('%')) {
        element.value = this.dataField;
      }
      if (element.value==='') {
        element.value = 1;
        this.realtySlider.set(1);
        Storage.dispatch('ActionRateOldCredit',1)

      }
    },
    calculationPageLoad(){
      Storage.dispatch('ActionRateOldCredit',this.dataFieldForCalculation)
    },
  },
  mounted(){
    this.initRealtySlider()
    Storage.dispatch('ActionRateOldCredit',parseFloat(this.dataField))

  },
  computed:{
  },
  watch:{
    //как только стоимость квартиры изменилась, вызываю функцию
    dataField(){

    },
    dataFieldForCalculation(){
      if(this.dataFieldForCalculation==100.0){
        this.dataField = '100'
      }
      if(this.dataFieldForCalculation==0.0){
        // this.dataField = '0 %'
      }
    }
  },
  created(){
  },
  components:{}
};
</script>
<style scoped>
</style>
