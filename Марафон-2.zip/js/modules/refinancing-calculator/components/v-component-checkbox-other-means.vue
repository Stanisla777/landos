<template lang="pug">
  .calculator_s__checkbox.calculator_s__calculator-row.js--tax_checkbox
    .calculator_s__checkbox-item.checkbox-stylized
      input#checkbox_other-means(type='checkbox')(@change="checkboxChanged")
      label(for='checkbox_other-means') Использовать материнский капитал
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import ToolTip from '../components/v-component-tooltip.vue';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-checkbox-other-means',
  data(){
    return {

    }
  },
  methods:{
    checkboxChanged(el){
      const element = el.currentTarget
      if(!element.checked){
        Storage.dispatch('ActionMaternalCapitalCalculation',false)
        eventBus.$emit('eventcheckboxChanged',false)
      }
      else{
        Storage.dispatch('ActionMaternalCapitalCalculation',true)
        eventBus.$emit('eventcheckboxChanged',true)
      }
    }


  },
  mounted(){

  },
  computed:{},
  watch:{
  },
  components:{
    ToolTip
  }
};
</script>
<style scoped>
</style>
