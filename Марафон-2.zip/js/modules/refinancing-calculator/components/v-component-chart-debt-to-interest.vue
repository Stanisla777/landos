<template lang="pug">
  .mortgage-calculator__chart-debt-to-interest
    .mortgage-calculator__chart-interest-wrap
      apexcharts(width='230px' height='230px' :options='options' :series='list')
      .mortgage-calculator__chart-interest-info
        p.mortgage-calculator__chart-interest-accrued {{share_percent_small_chart}}%
        p.mortgage-calculator__chart-interest-mark начисленных процентов
    .mortgage-calculator__chart-interest
      .mortgage-calculator__chart-interest-item
        .mortgage-calculator__chart-interest-circle.white
        p Основной долг
      .mortgage-calculator__chart-interest-item
        .mortgage-calculator__chart-interest-circle.green
        p Начисленные проценты
</template>
<script>
import Vue from 'vue';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
// import VueApexCharts from "vue-apexcharts";
const VueApexCharts = () => import ("vue-apexcharts");
export default {
  name: 'v-component-small-chart',
  props:['list'],
  data(){
    return {
      data_type_payment: null,
      series: this.arr_data_small_debt,

      options: {
        chart: {
          type: 'donut',
          animations: {
            speed: 2000,
            animateGradually: {
              enabled: true,
              delay: 2000
            },
            dynamicAnimation: {
              enabled: true,
              speed: 1000
            },
          },
          width: '100%',
          zoom:{
            // enabled:false
          },
        },
        colors: ['#8BC540', '#CACCDF'],
        legend: { // названия графиков
          show: false,
          showForSingleSeries:true,
          showForNullSeries:true,
          position: 'bottom',
          // offsetY: 35,
          horizontalAlign: 'left',
          fontSize: '14px',
          fontFamily: 'Gilroy-SemiBold, Arial',
          color:'#fff',
          onItemClick: {
            toggleDataSeries: true
          },
          onItemHover: {
            highlightDataSeries: true
          },
          itemMargin: {
            horizontal: 5,
            vertical: 0
          },
          markers: {
            width: 9,
            height: 9,
            strokeWidth: 0,
            strokeColor: '#fff',
            fillColors: undefined,
            radius: 9,
            customHTML: undefined,
            onClick: undefined,
            offsetX: 0,
            offsetY: 0
          }
        },
        labels:['Основной долг','Начисленные проценты'],
        dataLabels: {
          enabled: false
        },
        tooltip: {
          enabled: false
        },
        stroke: {
          show: false
        },
        plotOptions: {
          pie: {
            donut: {
              size: '85%'
            }
          }
        }
      }
    };
  },
  methods:{

  },
  mounted(){

    // this.series = Storage.getters.ARRDATASMALLDEBT;
  },
  computed:{
    share_percent_small_chart(){
      return Storage.getters.SHAREPERCENTSMALLCHART
    },
  },
  watch:{
  },
  created(){
    eventBus.$on('receivePaymentType',(param)=>{
      this.data_type_payment=param
    })
  },

  components:{
    apexcharts: VueApexCharts
  }
};
</script>
<style scoped>
</style>
