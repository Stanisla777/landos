<template lang="pug">
  div.property-calculator__body.refinancing-calc__body.white
    template
      refinancing-calculator

</template>
<script>
// import DduCalculator from './DduCalculator.vue';
import Storage from './development-tools/state.vue';
const RefinancingCalculator = () => import ("./RefinancingCalculator.vue");


export default {
  name: 'RefinancingCalculatorPointEntry',
  data(){
    return {

    }
  },
  methods:{
  },
  mounted(){
  },
  computed:{
  },
  watch:{
  },
  components:{
    RefinancingCalculator
  }
};
</script>
<style scoped>
</style>
