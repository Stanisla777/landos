/* eslint-disable */
export function closeModal(id) {
  const modalWindow = document.getElementById(id);
  if (modalWindow && modalWindow.querySelector('.js--stories-body-video video')) {
    modalWindow.querySelector('.js--stories-body-video video').pause();
  }
  // eslint-disable-next-line no-unused-vars
  const promice = new Promise(((resolve) => {
    if (modalWindow && modalWindow.classList.contains('open')) {
      // modalWindow.classList.remove('open');
      if(modalWindow.querySelector('.select-list__selection-window')) {
        modalWindow.querySelector('.select-list__selection-window').classList.remove('opacity')
        setTimeout(() => {
          modalWindow.classList.remove('open');
        },200)

      }
      else {
        modalWindow.classList.remove('open');

      }
    }
    else if (modalWindow && modalWindow.classList.contains('show')) {
      modalWindow.classList.remove('show');
    }


    document.body.classList.remove('modal-opened');
    document.body.classList.remove('body-modal-modals');
    resolve();
  })).then(() => new Promise(((resolve) => {
    setTimeout(() => {
      document.body.classList.remove('body-modal');
      resolve();
    }, 500);
  })));
}

export function modals() {
    const modalWindows = document.querySelectorAll('.modal');
    const modalOpeners = document.querySelectorAll('.js--modal-opener');
    const modalOpenersOnLanding = document.querySelectorAll("[href$='modalcall']");

    for (let i = 0; i < modalOpeners.length; i++) {
        modalOpeners[i].addEventListener('click', () => {
            if (modalOpeners[i].getAttribute('data-program')) {
                document.querySelector('label.prog input').value = modalOpeners[i].getAttribute('data-program');
            }

            //основная часть открытия модалок
            if (document.querySelector(modalOpeners[i].dataset.modal)) {
              document.querySelector(modalOpeners[i].dataset.modal).classList.add('open');
              if(document.querySelector(modalOpeners[i].dataset.modal).querySelector('.select-list__selection-window')){
                setTimeout(() => {
                  document.querySelector(modalOpeners[i].dataset.modal).querySelector('.select-list__selection-window').classList.add('opacity')
                },400)
              }
              document.body.classList.add('modal-opened');
              // eslint-disable-next-line no-unused-vars
              document.body.classList.add('body-modal');
              document.body.classList.add('body-modal-modals');
            }
        });
    }

  for (let i = 0; i < modalOpenersOnLanding.length; i++) {
    modalOpenersOnLanding[i].addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      if (modalOpenersOnLanding[i].getAttribute('data-program')) {
        document.querySelector('label.prog input').value = modalOpeners[i].getAttribute('data-program');
      }
      document.querySelector('#modalcall').classList.add('open');
      document.body.classList.add('modal-opened');
      return false;
    });
  }

  for (let j = 0; j < modalWindows.length; j++) {
    // eslint-disable-next-line func-names
    const modalWindowCloser = modalWindows[j].querySelectorAll('.js--modal-closer');
    // eslint-disable-next-line no-restricted-syntax
    for (const item of modalWindowCloser) {
      // eslint-disable-next-line func-names
      item.onclick = function () {
        closeModal(modalWindows[j].id);
      };
    }
    const modalWindowWrapper = modalWindows[j].querySelector('.modal__wrapper');
    if (modalWindowWrapper) {
        modalWindowWrapper.onclick = function (w) {
        w.stopPropagation();
      };
    }
    modalWindows[j].onclick = function () {
      closeModal(modalWindows[j].id);
    };
  }
}

export function catalogModal() {
    const catalogWrapper = document.querySelector('.js--ct-modal');
    if (!catalogWrapper) return;

    catalogWrapper.addEventListener('click', (e) => {
        if (e.target.closest('.js--ct-modal-opener')) {
            if (e.target.getAttribute('data-program')) {
                document.querySelector('label.prog input').value = e.target.getAttribute('data-program');
                document.querySelector('#modalcall').classList.add('open');
                document.body.classList.add('modal-opened');
            } else {
                document.querySelector('#modalcall').classList.add('open');
                document.body.classList.add('modal-opened');
            }
        }
    });
}
