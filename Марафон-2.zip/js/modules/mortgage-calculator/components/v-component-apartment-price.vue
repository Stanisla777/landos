<template lang="pug">
  .property-calculator__row
    p.property-calculator__row-label Стоимость недвижимости, ₽
    .property-calculator__input-field.js--number-cost-pr(@click="inputFocus")
      input.property-calculator__value(inputmode="numeric" placeholder="Введите сумму")(
        v-model="dataField"
        type="text"
        ref="realtyInput"
        @keydown="inputField"
        @keyup="keyUp"
        @change ="inputValue"
        @paste="inputPast"
        @blur="lossFocus"
      )

      .range-input__slider(ref="mortgagePrice")
    .calculator_s__cost-flat
      .property-calculator__wr-range
        p.property-calculator__range {{String(stgMin).slice(0,3)}} тыс.
        p.property-calculator__range {{String(stgMax).slice(0,2)/2}} млн
        p.property-calculator__range {{String(stgMax).slice(0,2)}} млн
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import noUiSlider from 'nouislider';
import Storage from '../development-tools/state.vue';
export default {
  name: 'v-apartment-price',
  data(){
    return {
      realtySlider: '', // Слайдер "Стоимость недвижимости"
      dataField: 0, // Стоимость недвижимости
      dataFieldForCalculation: 0,
      subsidies: 0,
      stepApartment: 1, // Шаг для range инпутов
      stgMin: 625000, // Минимальное значение поля стоимости
      stgMiddle: 27000000, // Значение по середине (стоимость)
      stgMax: 56000000, // Максимальное значение поля стоимости
      input_salary:false
    }
  },
  methods:{
    initRealtySlider() {
      this.realtySlider = noUiSlider.create(this.$refs.mortgagePrice, {
        start: [this.stgMin],
        connect: 'lower',
        step: this.stepApartment,
        initial: this.stgMin,
        range: {
          min: this.stgMin,
          max: this.stgMax
        },
      });

      this.realtySlider.on('update', (val,handle) => {
        this.dataField = parseInt(val[handle]).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        this.dataFieldForCalculation = parseInt(val[handle]).toFixed(0)
      });
      this.realtySlider.on('end', (val,handle) => {
        // this.dataField = parseInt(val[handle]).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        // this.dataFieldForCalculation = parseInt(val[handle]).toFixed(0)
      });

    },
    //Ввод значения пользователем
    inputField(event){
      const element = event.currentTarget
      let value = element.value

      value = parseInt(value.replace(/\s/g, ''));
      if ( event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 ||
        // Разрешаем: Ctrl+A
        (event.keyCode == 65 && event.ctrlKey === true) ||
        // Разрешаем: home, end, влево, вправо
        (event.keyCode >= 35 && event.keyCode <= 39)) {

        // Ничего не делаем
        return;
      } else {
        // Запрещаем все, кроме цифр на основной клавиатуре, а так же Num-клавиатуре
        if ((event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105 )) {
          event.preventDefault();
        }
      }

      if(event.keyCode == 13){
        const parent = element.closest('.js--number-cost')
        let value = parent.querySelector('input').value
        value = parseInt(value.replace(/\s/g, ''));
        this.realtySlider.set(value);
      }
      if(value>this.stgMax){
        event.preventDefault();
      }
    },
    keyUp(e) {
      const element = e.currentTarget
      if(element.value!==''&&(parseInt(element.value.replace(/\s/g, ''))>=this.stgMin)&&parseInt(element.value.replace(/\s/g, ''))<=this.stgMax){
        this.realtySlider.set(parseInt(element.value.replace(/\s/g, '')));
      }
      else if(parseInt(element.value.replace(/\s/g, ''))>this.stgMax)  {
        this.realtySlider.set(this.stgMax);
      }
    },
    inputValue(el){
      const element = el.currentTarget;
      let value = element.value
      value = parseInt(value.replace(/\s/g, ''));

      Storage.dispatch('ActionRealPriceAppartment',parseInt(value).toFixed(0))
      if(value<this.stgMin)  {
        this.dataFieldForCalculation = this.stgMin
        this.realtySlider.set(this.stgMin);
      }
    },
    inputPast(el){
      const element = el.currentTarget;
      let element_val = (el.clipboardData || window.clipboardData).getData('text');
      if ( element_val.search(/[^0-9]/g) != -1 ) {
        el.preventDefault();
      }
    },
    lossFocus(el){
      const element = el.currentTarget
      if(element.value===''){
        element.value=this.stgMin
        this.realtySlider.set(this.stgMin);
        Storage.dispatch('ActionRealPriceAppartment',[parseInt(this.stgMin),true])
      }
    },
    inputFocus(el){
      const element = el.currentTarget
      element.querySelector('input').focus()
    },

    // расчет ндфл стоимости квартиры и отправка данных о квартире в компоненту с итоговой суммой
    calculationPageLoad(){
      Storage.dispatch('ActionRealPriceAppartment',parseInt(this.dataFieldForCalculation))
    },
  },
  mounted(){
    this.initRealtySlider()
  },
  computed:{
  },
  watch:{
    //как только стоимость квартиры изменилась, вызываю функцию
    dataField(){
      this.calculationPageLoad()
    },
    realtyPriceForCalculation(){
      eventBus.$emit('realtyPrice',this.realtyPriceForCalculation)
    }
  },
  created(){
  },
  components:{}
};
</script>
<style scoped>
</style>
