<template lang="pug">
  .property-calculator__row
    p.property-calculator__sub-title Тип платежа
    .mortgage-calculator__swiper-type-person(
      ref="btnTypeCredit"
    )
      .swiper-container.swiper-container.js--type-person
        .swiper-wrapper
          .swiper-slide
            div(for-type="ann").property-calculator__button-view-checkbox.active(@click="checkboxChanged")
              p Аннуитетный
          .swiper-slide
            div(for-type="def").property-calculator__button-view-checkbox(@click="checkboxChanged")
              p Дифференцированный


</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import ToolTip from '../components/v-component-tooltip.vue';
import Storage from '../development-tools/state.vue';
import Swiper, { Navigation, Pagination } from 'swiper';
Swiper.use([Navigation, Pagination]);
let mySwiper;

export default {
  name: 'v-checkbox',
  data(){
    return {

    }

  },
  methods:{
    initSliderStoriesButton() {
      mySwiper = new Swiper('.js--type-person', {
        loop: false,
        simulateTouch: true,
        allowTouchMove: false,
        centeredSlides: false,
        slidesPerView:2,
        slidesPerGroup:1,
        spaceBetween: 12,


        navigation: false,
        pagination: false,
        breakpoints: {
          0: {
            slidesPerView:2,
            allowTouchMove: true,
            centeredSlides: true,
          },
          470: {
            slidesPerView:2,
            allowTouchMove: false,
            centeredSlides: false,
          }
        },
      });
      mySwiper.on('slideChange', () => {


      });
    },
    checkboxChanged(el) {
      const element = el.currentTarget;
      const type = element.getAttribute('for-type')
      const array = this.$refs.btnTypeCredit.querySelectorAll('.property-calculator__button-view-checkbox')
      if(!element.classList.contains('active')){
        Storage.dispatch('ActionTypeCredit', type);
      }
      for(let item of array){
        item.classList.remove('active')
      }
      element.classList.add('active')

    }

  },
  mounted(){
    this.initSliderStoriesButton()

  },
  computed:{},
  watch:{
  },
  components:{
    ToolTip,
  }
};
</script>
<style scoped>
</style>
