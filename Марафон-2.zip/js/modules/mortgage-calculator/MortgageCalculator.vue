<template lang="pug">
  div
    .property-calculator__body-row.refinancing-calc__body-row
      div.property-calculator__calculations
        template
          component-credit-amount
        template
          component-initial-fee
          .property-calculator__block
            template
              component-check-other-means

        .property-calculator__several-columns.two-columns.grow(
          v-show="other_means"
        )
          template
            component-maternal-capital(
              v-on:eventPopUp="callPopUp($event)"
              :tooltip="tooltip"
              :max_maternity_capital="max_maternity_capital"
            )
          template
            component-personal-funds

        .property-calculator__several-columns.two-columns.grow
          template
            component-interest-rate
          template
            component-loan-time


        .property-calculator__block
          template
            component-type-payment



      div.property-calculator__container-result.refinancing-calc__container-result.first-show

        template
          component-final-result
        p.refinancing-calc__footnote.
          Результат расчета предварительный, сформирован в ознакомительных целях на основе предоставленных сведений и
          не является официальным заключением, офертой, индивидуальной оценкой. Для получения подробной информации и
          индивидуальной оценки рекомендуем обратиться в кредитную организацию
    template
      pop-up(
        v-show="modal_state"
      )
</template>
<script>
import Vue from 'vue';
import eventBus from './development-tools/eventBus.vue';
import Storage from './development-tools/state.vue';
import ComponentCreditAmount from './components/v-component-apartment-price.vue';
import ComponentInitialFee from './components/v-component-initial-fee.vue';
import ComponentFinalBlockConfirmed from './components/v-component-block-final-result.vue';
import ComponentTypePayment from './components/v-component-type-payment.vue';
import ComponentCheckOtherMeans from './components/v-component-checkbox-other-means.vue';
import ToolTip from './components/v-component-tooltip.vue';
import ComponentMaternalCapital from './components/v-component-maternal-capital.vue';
import ComponentPersonalFunds from './components/v-component-personal-funds.vue';
import ComponentButton from './components/v-component-button.vue';
import ComponentInterestRate from './components/v-component-interest-rate.vue';
import ComponentLoanTime from './components/v-component-loan-time.vue';
import ComponentFinalResult from './components/v-component-block-final-result.vue';
import ComponentLoanAmount from './components/v-component-loan-amount.vue';
import PopUp from './components/v-component-pop-up.vue';

export default {
  name: 'MortgageCalculator',
  props:['tooltip','max_maternity_capital'],
  data(){
    return {
      other_means:false,
      final_result:false,
      final_state_confirmed:false,
      pop_up:false,
      text_pop_up:'',
    }
  },
  methods:{
    showCalculation(){
      this.final_state_confirmed=false
      this.final_result=false
      this.final_state_confirmed=true
      setTimeout(()=>{
        this.final_result=true
      },100)
    },
    callPopUp(param){
      this.text_pop_up=param
      this.pop_up=true
    },
    closePopUp(){
      this.pop_up=false
    }
  },
  mounted(){
  },
  computed:{
    modal_state(){
      return  Storage.getters.MODAL_STATE
    },
  },
  created(){
    eventBus.$on('eventcheckboxChanged',(param)=>{
      this.other_means=param
    })
  },
  watch:{
  },
  components:{
    ComponentFinalBlockConfirmed,
    ComponentCreditAmount,
    ComponentMaternalCapital,
    ComponentCheckOtherMeans,
    ToolTip,
    ComponentButton,
    ComponentInitialFee,
    ComponentPersonalFunds,
    ComponentInterestRate,
    ComponentLoanTime,
    ComponentTypePayment,
    ComponentFinalResult,
    ComponentLoanAmount,
    PopUp
  }
};
</script>
<style scoped>
</style>
