<template lang="pug">
  .v-mortgage__container-common-rate
    .v-mortgage__title-rate
      h2.v-mortgage__name-programm.v-mortgage__common_name
        p Рыночная ставка
      p.v-mortgage__title-rate-des Средневзвешенные ставки банков, % годовых
      p.v-mortgage__count Данные по Топ-20 банкам
    .v-mortgage__average-rate.v-mortgage__block-rate
      template(v-if="loaded")
        v-component-schedule-common(
          :props_calendar ="obj_rate_calendar"
        )

      //template
      //  v-component-banks(
      //    :props_data_banks="obj_rate_common.banks_rates"
      //  )
    p.v-mortgage__footnote Банк России, Frank RG, оценки и расчеты ДОМ.РФ

</template>
<script>
import vComponentScheduleCommon from './v-component-schedule-common.vue';
import vComponentBanks from './v-component-banks.vue';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-container-common-rate',
  props:[''],
  data(){
    return {}
  },
  methods:{
    axiosGetObjectRateCommon(){
      Storage.dispatch('axiosGetObjectRateCommon')
    },

  },
  mounted(){
    this.axiosGetObjectRateCommon()
  },
  computed:{
    obj_rate_calendar(){
      return Storage.getters.CALENDAR_RATE_COMMON
    },
    loaded(){
      return Storage.state.loaded
    }
  },
  watch:{
  },
  components:{
    vComponentScheduleCommon,
    vComponentBanks
  }
};
</script>
<style scoped>
</style>
