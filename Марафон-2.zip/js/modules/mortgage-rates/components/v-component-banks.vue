<template lang="pug">
  .v-mortgage__banks
    .v-mortgage__die-actual-rate
      p Актуальная ставка
    ol(type="1").v-mortgage__list-banks(

    )
      li.v-mortgage__bank-item(
        v-for="value in props_data_banks"
      )
        <a target="_blank" v-bind:href=value.link>{{value.name}}</a> - {{value.rate}}%
        //a(v-bind:href="value.link")(target="_blank") {{value.rate}}

    .v-mortgage__all-banks(
      @click ="openListBanks"
      v-if="props_data_banks.length>3"
    )
      p все банки
      .v-mortgage__all-banks-icon
        svg(width='18' height='10' viewbox='0 0 18 10' fill='none' xmlns='http://www.w3.org/2000/svg')
          path(d='M1 1L8.29289 8.29289C8.68342 8.68342 9.31658 8.68342 9.7071 8.29289L17 1' stroke='#1C1B28' stroke-width='2' stroke-linecap='round' stroke-linejoin='round')


</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
export default {
  name: 'v-component-banks',
  props:['props_data_banks'],
  data(){
    return {
      banks:null,
      count_banks:true

    }
  },
  methods:{
    openListBanks(el){
      const element = el.currentTarget
      const parent = element.closest('.v-mortgage__banks')
      const list_banks = parent.querySelector('.v-mortgage__list-banks')
      const list_banks_count = list_banks.querySelectorAll('.v-mortgage__bank-item').length

      if (list_banks.classList.contains('active')) {
        list_banks.classList.remove('active');
        list_banks.scrollTo(0, 0);
        list_banks.setAttribute('style','max-height:137px;overflow: hidden;')
        element.classList.remove('active');
        // document.body.classList.remove('body-modal')
      } else {
        // document.body.classList.add('body-modal')
        element.classList.add('active');
        list_banks.classList.add('active');
        if(list_banks_count>9){
          list_banks.setAttribute('style','max-height:300px;overflow: auto;')
        }
        else {
          list_banks.style.maxHeight = `${list_banks.scrollHeight}px`;
        }
      }
    },
    eventBusFunctionExample(){ // сработает например по клике на кнопке
      eventBus.$emit("pass_someFunction");
    }
  },
  mounted(){

  },
  computed:{

  },
  watch:{
  },
  created () {
  },
  components:{},


};
</script>
<style scoped>
</style>
