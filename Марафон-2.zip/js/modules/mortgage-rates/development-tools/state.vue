<script>
import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios';
import VueAxios from 'vue-axios';
Vue.use(VueAxios, axios);
Vue.use(Vuex);

export default new Vuex.Store({
  state:{
    config_header: {
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      }
    },
    loaded:false,
    count_programm:null,
    object_rate_common: {

    },
    object_rate_separate: [],
    id_programs:[],

    db_json:{
      "PARAM_COMMON": {
        "mortgage_programs": [
          {
            "id": "1",
            "name": "Семейная ипотека",
            "with_state_support": 1,
            "rates":{
              "2021.01": 8.933333,
              "2021.02": 6.94,
              "2021.03": 6.89,
              "2021.04": 7.02,
              "2021.05": 7.10,
              "2021.06": 7.26,
              "2021.07": 7.32,
              "2021.08": 7.24,
              "2021.09": 7.36,
              "2021.10": 7.53,
              "2021.11": 7.90,
              "2021.12": 8.12
            }
          },
          {
            "id": "3",
            "name": "рефинансирование",
            "with_state_support": 1,
            "rates": {
              "2021.01": 7.93,
              "2021.02": 8.94,
              "2021.03": 6.3,
              "2021.04": 7.6,
              "2021.05": 7.7,
              "2021.06": 7.4,
              "2021.07": 8.32,
              "2021.08": 7.8,
              "2021.09": 7.3,
              "2021.10": 6.53,
              "2021.11": 7.3,
              "2021.12": 8.5
            }
          },
          {
            "id": "4",
            "name": "новостройка",
            "with_state_support": 1,
            "rates": {
              "2021.01": 7.93,
              "2021.02": 6.1,
              "2021.03": 6.34,
              "2021.04": 6.02,
              "2021.05": 8.10,
              "2021.06": 6.26,
              "2021.07": 8.32,
              "2021.08": 6.24,
              "2021.09": 8.36,
              "2021.10": 6.53,
              "2021.11": 8.90,
              "2021.12": 7.12
            }
          },
          {
            "id": "6",
            "name": "льготная «7»",
            "with_state_support": 0,
            "rates": {
              "2021.01": 6.01,
              "2021.02": 7.94,
              "2021.03": 6.89,
              "2021.04": 8.02,
              "2021.05": 8.10,
              "2021.06": 6.26,
              "2021.07": 8.32,
              "2021.08": 6.24,
              "2021.09": 8.36,
              "2021.10": 6.53,
              "2021.11": 7.4,
              "2021.12": 7.12
            }
          },
          {
            "id": "8",
            "name": "льготная «7»",
            "with_state_support": 0,
            "rates": {
              "2021.01": 6.01,
              "2021.02": 7.94,
              "2021.03": 6.89,
              "2021.04": 8.02,
              "2021.05": 8.10,
              "2021.06": 6.26,
              "2021.07": 8.32,
              "2021.08": 6.24,
              "2021.09": 8.36,
              "2021.10": 6.53,
              "2021.11": 7.4,
              "2021.12": 7.12
            }
          },
          {
            "id": "3",
            "name": "рефинансирование",
            "with_state_support": 1,
            "rates": {
              "2021.01": 7.93,
              "2021.02": 8.94,
              "2021.03": 6.3,
              "2021.04": 7.6,
              "2021.05": 7.7,
              "2021.06": 7.4,
              "2021.07": 8.32,
              "2021.08": 7.8,
              "2021.09": 7.3,
              "2021.10": 6.53,
              "2021.11": 7.3,
              "2021.12": 8.5
            }
          },
          {
            "id": "4",
            "name": "новостройка",
            "with_state_support": 1,
            "rates": {
              "2021.01": 7.93,
              "2021.02": 6.1,
              "2021.03": 6.34,
              "2021.04": 6.02,
              "2021.05": 8.10,
              "2021.06": 6.26,
              "2021.07": 8.32,
              "2021.08": 6.24,
              "2021.09": 8.36,
              "2021.10": 6.53,
              "2021.11": 8.90,
              "2021.12": 7.12
            }
          },
          {
            "id": "6",
            "name": "льготная «7»",
            "with_state_support": 0,
            "rates": {
              "2021.01": 6.01,
              "2021.02": 7.94,
              "2021.03": 6.89,
              "2021.04": 8.02,
              "2021.05": 8.10,
              "2021.06": 6.26,
              "2021.07": 8.32,
              "2021.08": 6.24,
              "2021.09": 8.36,
              "2021.10": 6.53,
              "2021.11": 7.4,
              "2021.12": 7.12
            }
          },
          {
            "id": "8",
            "name": "льготная «7»",
            "with_state_support": 0,
            "rates": {
              "2021.01": 6.01,
              "2021.02": 7.94,
              "2021.03": 6.89,
              "2021.04": 8.02,
              "2021.05": 8.10,
              "2021.06": 6.26,
              "2021.07": 8.32,
              "2021.08": 6.24,
              "2021.09": 8.36,
              "2021.10": 6.53,
              "2021.11": 7.4,
              "2021.12": 7.12
            }
          },
          {
            "id": "4",
            "name": "новостройка",
            "with_state_support": 1,
            "rates": {
              "2021.01": 7.93,
              "2021.02": 6.1,
              "2021.03": 6.34,
              "2021.04": 6.02,
              "2021.05": 8.10,
              "2021.06": 6.26,
              "2021.07": 8.32,
              "2021.08": 6.24,
              "2021.09": 8.36,
              "2021.10": 6.53,
              "2021.11": 8.90,
              "2021.12": 7.12
            }
          },
          {
            "id": "6",
            "name": "льготная «7»",
            "with_state_support": 0,
            "rates": {
              "2021.01": 6.01,
              "2021.02": 7.94,
              "2021.03": 6.89,
              "2021.04": 8.02,
              "2021.05": 8.10,
              "2021.06": 6.26,
              "2021.07": 8.32,
              "2021.08": 6.24,
              "2021.09": 8.36,
              "2021.10": 6.53,
              "2021.11": 7.4,
              "2021.12": 7.12
            }
          },
          {
            "id": "8",
            "name": "льготная «7»",
            "with_state_support": 0,
            "rates": {
              "2021.01": 6.01,
              "2021.02": 7.94,
              "2021.03": 6.89,
              "2021.04": 8.02,
              "2021.05": 8.10,
              "2021.06": 6.26,
              "2021.07": 8.32,
              "2021.08": 6.24,
              "2021.09": 8.36,
              "2021.10": 6.53,
              "2021.11": 7.4,
              "2021.12": 7.12
            }
          }


        ]
      },
      "RATE": {
        "mortgage_programs": [
          {
            "name": "Семейная ипотека",
            "description": "Налог на доходы физических лиц (НДФЛ) — основной вид прямых налогов. Исчисляется в процентах от совокупного дохода физических лиц за вычетом документально подтверждённых расходов, в соответствии с действующим законодательством.",
            "link": "/semeynaya-ipteka-kakaya-to/",
            "with_state_support": 1,
            "rates": {
              "2021.01": 7.933333333,
              "2021.02": 6.1,
              "2021.03": 6.34,
              "2021.04": 6.02,
              "2021.05": 8.10,
              "2021.06": 6.26,
              "2021.07": 8.32,
              "2021.08": 6.24,
              "2021.09": 8.36,
              "2021.10": 6.53,
              "2021.11": 8.90,
              "2021.12": 7.12
            }
          }
        ],
        "banks_rates": [
          {
            "name": "Московский кредитный банк",
            "link": "https://aaaaa.ru/",
            "rate": "6.9"
          },
          {
            "name": "АК Барс",
            "link": "https://bank-kakoyto.ru/",
            "rate": "6.53"
          },
          {
            "name": "Санкт-Петербург",
            "link": "https://bank-kakoyto.ru/",
            "rate": "6.73"
          },
          {
            "name": "Группа ВТБ",
            "link": "https://bank-kakoyto.ru/",
            "rate": "6.43"
          },
          {
            "name": "ааааа",
            "link": "https://aaaaa.ru/",
            "rate": "6.93"
          },
          {
            "name": "АК Барс",
            "link": "https://bank-kakoyto.ru/",
            "rate": "6.53"
          },
          {
            "name": "Санкт-Петербург",
            "link": "https://bank-kakoyto.ru/",
            "rate": "6.73"
          },
          {
            "name": "Группа ВТБ",
            "link": "https://bank-kakoyto.ru/",
            "rate": "6.43"
          },
          {
            "name": "ааааа",
            "link": "https://aaaaa.ru/",
            "rate": "6.93"
          },
          {
            "name": "АК Барс",
            "link": "https://bank-kakoyto.ru/",
            "rate": "6.53"
          },
          {
            "name": "Санкт-Петербург",
            "link": "https://bank-kakoyto.ru/",
            "rate": "6.73"
          },
          {
            "name": "Группа ВТБ",
            "link": "https://bank-kakoyto.ru/",
            "rate": "6.43"
          },
          {
            "name": "ааааа",
            "link": "https://aaaaa.ru/",
            "rate": "6.93"
          },
          {
            "name": "АК Барс",
            "link": "https://bank-kakoyto.ru/",
            "rate": "6.53"
          },
          {
            "name": "Санкт-Петербург",
            "link": "https://bank-kakoyto.ru/",
            "rate": "6.73"
          },
          {
            "name": "Группа ВТБ",
            "link": "https://bank-kakoyto.ru/",
            "rate": "6.43"
          }
        ]
      },

    }
  },
  getters:{
    //объект с данными по банкам и ставкам по месяцам для окна со средними показателями
    NAME_PROGRAMM_RATE_COMMON(state){
      return state.object_rate_common.series_sheduls
    },
    CALENDAR_RATE_COMMON(state){
      return state.object_rate_common.calendar
    },
    CHANGE_CALENDAR_RATE_COMMON(state){
      return state.object_rate_common.change_calendar
    },





    COUNT_PROGRAMM(state){
      return state.count_programm
    },
    RATE_SEPARATE(state){
      return state.object_rate_separate
    },
  },
  mutations:{
    //Формирую банки со ставками (для общего графика)
    mutationObjAverageRate_Common(state,received_perem){
      //-----для графика содаю переменные для  series разных линий------
      const series_sheduls = []
      const series_sheduls_double = []
      // console.log(received_perem.mortgage_programs);
      for (let item of received_perem.mortgage_programs){
        state.id_programs.push(item.id)
        const series_object = {}
        //название программы
        series_object.name = item.name
        //формирую ставки для data они прихадят так "2021.01": 6.93 и я беру только 6.93
        series_object.data = Object.values(item.rates)
        series_object.programm_support = item.with_state_support
        //запушил в массив
        series_sheduls.push(series_object)
      }
      Vue.set(state.object_rate_common,'series_sheduls',series_sheduls)
      Vue.set(state.object_rate_common,'series_sheduls_double',series_sheduls)
      const calendar_recive = Object.keys(received_perem.mortgage_programs[0].rates)
      const calendar = calendar_recive.map((num)=> {
        let name_month = num.substring(5,num.lenth);
        name_month == '01' ? name_month = 'январь' : name_month == '02' ? name_month = 'февраль' : name_month == '03' ? name_month = 'март' : name_month == '04' ?
          name_month = 'апрель' : name_month == '05' ? name_month = 'май' : name_month == '06' ? name_month = 'июнь' : name_month == '07' ? name_month = 'июль' :
            name_month == '08' ? name_month = 'август' :name_month == '09' ? name_month = 'сентябрь' : name_month == '10' ? name_month = 'октябрь' : name_month == '11' ?
              name_month = 'ноябрь' : name_month == '12' ? name_month = 'декабрь' : false;
        let year =num.slice(0,4)
        let month = num.slice(Math.max(num.length - 2, 0))
        return `${month}.${year}, ${name_month}`
      })
      // console.log(calendar);
      const new_month = calendar_recive.map(function (num){
        num = num.substring(5,num.lenth);
        num == '01' ? num = 'Январь' : num == '02' ? num = 'Февраль' : num == '03' ? num = 'Март' : num == '04' ?
          num = 'Апрель' : num == '05' ? num = 'Май' : num == '06' ? num = 'Июнь' : num == '07' ? num = 'Июль' :
            num == '08' ? num = 'Август' :num == '09' ? num = 'Сентябрь' : num == '10' ? num = 'Октябрь' : num == '11' ?
              num = 'Ноябрь' : num == '12' ? num = 'Декабрь' : false;
        return num
      })
      Vue.set(state.object_rate_common,'calendar',calendar)
      Vue.set(state.object_rate_common,'change_calendar',new_month)
      state.loaded=true
    },

    //Формирую ставки (для окон различных программ)
    mutationObjBankWhithRate_Separate(state,received_perem){
      // const obj_separate_rate = {}

      let banks_with_state_and_programm=[]


      const promice = new Promise((resolve,reject)=> {

        //Формирую названия банков со ставкакми
        banks_with_state_and_programm.push(received_perem.banks_rates)

        //Формирую программы со ставкакми
        const object_programm = received_perem.mortgage_programs[0]
        const massive_data = Object.keys(received_perem.mortgage_programs[0].rates)
        //Сформировал новый формат дат - июль 20221 вместо 2021.01
        const new_massive_data = massive_data.map((num)=> {
          let year =num.slice(0,4)
          num = num.slice(Math.max(num.length - 2, 0))
          num == '01' ? num = 'Январь' : num == '02' ? num = 'Февраль' : num == '03' ? num = 'Март' : num == '04' ?
            num = 'Апрель' : num == '05' ? num = 'Май' : num == '06' ? num = 'Июнь' : num == '07' ? num = 'Июль' :
              num == '08' ? num = 'Август' :num == '09' ? num = 'Сентябрь' : num == '10' ? num = 'Октябрь' : num == '11' ?
                num = 'Ноябрь' : num == '12' ? num = 'Декабрь' : false;
          return `${num} ${year}`
        })

        Vue.set(object_programm,'new_date',new_massive_data)
        Vue.set(object_programm,'support_button_data',2)





        banks_with_state_and_programm.push(object_programm)

        resolve()
      }).then(()=>{
        return new Promise((resolve,reject)=> {
          state.object_rate_separate.push(banks_with_state_and_programm)
          // state.object_rate_separate.push(mortgage_programs)
          state.loaded=true
          resolve()
        })
      })
      // console.log(state);
    },


  //изменяю в state.object_rate_separate отображение программ show_obj_rate
    mutationProgramDisplay(state,param){
      for (let item of state.object_rate_separate){
          Vue.set(item[1],'support_button_data',parseFloat(param))
      }
      state.object_rate_common.series_sheduls=state.object_rate_common.series_sheduls_double.slice()
      // state.object_rate_common.series_sheduls.splice(0, state.object_rate_common.series_sheduls.length)

      const massive_pr = []
      if(parseInt(param)!=2){
        for (let item of state.object_rate_common.series_sheduls_double) {
          if (item.programm_support == parseInt(param)) {
            massive_pr.push(item);
          }
        }
        state.object_rate_common.series_sheduls.splice(0, state.object_rate_common.series_sheduls.length, ...massive_pr)
      }


      // for (let item of state.object_rate_common.series_sheduls){
      //
      //   if(item.programm_support !=parseInt(param)){
      //     delete state.object_rate_common.series_sheduls[i]
      //     console.log(state.object_rate_common.series_sheduls_double);
      //   }
      // }

    },
  },
  actions:{
    // --------Получаю данные для окна для общего графика---------

    // Получаю данные по ставкам и месяцам
    axiosGetObjectRateCommon({commit,state}){

      //это для локалки
      // const param = state.db_json.PARAM_COMMON
      // commit('mutationObjAverageRate_Common',param)
      // const promice = new Promise((resolve,reject)=> {
      //   //тут вызываю action который по циклу начинает вызывать метод для формирования блоков различных программ
      //   this.dispatch('callingServerThroughLoop')
      //   resolve()
      // }).then(()=>{
      //   return new Promise((resolve,reject)=> {
      //     setTimeout(()=>{
      //       //тут вызываю action который по после отработки предыдущего, вызывает метод по добавлению баннера
      //       this.dispatch('actionBunner')
      //       resolve()
      //     },1500)
      //
      //   })
      // })


      //---------------------------------------------------------------------------Это бой
      const config_header = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        }
      }
      // return axios.get(`http://localhost:3000/PARAM_COMMON`,config_header)
      return axios.get(`/local/api/analitics-mortagage-rates/`,config_header)
        .then((res)=>{
          // console.log(res);
          commit('mutationObjAverageRate_Common',res.data)

          const promice = new Promise((resolve,reject)=> {
            //тут вызываю action который по циклу начинает вызывать метод для формирования блоков различных программ
            this.dispatch('callingServerThroughLoop')
            resolve()
          }).then(()=>{
            return new Promise((resolve,reject)=> {
              setTimeout(()=>{
                //тут вызываю action который по после отработки предыдущего, вызывает метод по добавлению баннера
                this.dispatch('actionBunner')
                resolve()
              },1500)

            })
          })
        }).catch((error) => {
          console.log(error);
        });

      //  --------------------------------------
    },



    //------- Получаю данные для окон по отдельным программам-------

    // Получаю данные по ставкам и месяцам
    axiosGetObjectRateSeparate({commit,state},param){

      //Это для локалки
      // const param_2 = state.db_json.RATE
      // commit('mutationObjBankWhithRate_Separate',param_2)


      //------------------------это для боя
      const config_header = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        }
      }
      // return axios.get(`http://localhost:3000/RATE=${param}`,config_header)
      return axios.get(`/local/api/analitics-mortagage-rates/?programNumber=${param}`,config_header)
        .then((res)=>{

          // console.log(res.data);
          commit('mutationObjBankWhithRate_Separate',res.data)

        }).catch((error) => {
        console.log('error'); //тут надо продумать!
      });
    //  -----------------------------------------------------------------

    },
    callingServerThroughLoop({commit,state}){
      for(let item of state.id_programs){
        this.dispatch('axiosGetObjectRateSeparate',item)
      }
    },
  // //
    actionProgramDisplay({commit},param){
      commit('mutationProgramDisplay',param)
    },
  //
    actionBunner({commit}){
      const bunner = document.querySelector('.v-mortgage__wrap-bunner')
      const wrapper = document.querySelector('.v-mortgage__container-separate-rate')
      if(bunner&&wrapper){
        wrapper.append(bunner)
        bunner.querySelector('.v-mortgage__bunner').setAttribute('style','display:block')
      }
    }
  },
})
</script>
