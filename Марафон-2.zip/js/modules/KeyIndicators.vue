<template lang="pug">
  .block-container.block-appKi(v-cloak)
    .headline-row.headline-row_key-indicators
      h2.headline-row__title(v-html="title")
      .key-indicators-select(:class="{active: subjects.isOpen}" v-if="showRegionSelect")
        .key-indicators-select__choosen(@click.prevent="handlerSelect()") {{ selectTitle }}
        .key-indicators-select__back(@click.prevent="closeSelect()")
        .key-indicators-select__list-wrapper
          .key-indicators-select__list
            .key-indicators-select__search
              input(type="search", name="", placeholder="Поиск субъекта" v-model="subjects.search" @keyup="handlerSearch()")
              button(
                @click.prevent="handlerSearch()"
              )
                svg(width='24' height='24' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg')
                  path(fill-rule='evenodd' clip-rule='evenodd' d='M16.4973 4.48737C13.1808 1.17088 7.8038 1.17088 4.48734 4.48737C1.17089 7.80386 1.17089 13.181 4.48734 16.4975C7.51258 19.5227 12.2524 19.7884 15.5788 17.2944L19.929 21.6447C20.4027 22.1184 21.1709 22.1184 21.6447 21.6447C22.1184 21.1709 22.1184 20.4027 21.6447 19.9289L17.2944 15.5787C19.7882 12.2523 19.5225 7.51256 16.4973 4.48737ZM6.20305 6.2031C8.57195 3.83417 12.4127 3.83417 14.7816 6.2031C17.1505 8.57202 17.1505 12.4128 14.7816 14.7817C12.4127 17.1507 8.57195 17.1507 6.20305 14.7817C3.83415 12.4128 3.83415 8.57202 6.20305 6.2031Z' fill='#1C1B28')
            .key-indicators-select__item-wrapper
              .key-indicators-select__item.key-indicators-select__item_main(@click.prevent="handlerChoose('all')") Все субъекты РФ
            template(v-for="(item, idx) in searchList")
              .key-indicators-select__item-wrapper(
                v-if="item.UF_NAME"
                @click="toggleSubMenu(idx)"
                :key="idx"
              )
                .key-indicators-select__item(:class="{'active': (idx === openSubMenu)}") {{ item.UF_NAME }}
                .key-indicators-select__sublist
                  .key-indicators-select__subitem(
                    v-for="(subItem, idx) in item.UF_SUB_REGION"
                    :key="idx"
                    @click.prevent="handlerChoose(subItem)"
                  ) {{ subItem }}

              template(v-else)
                .key-indicators-select__subitem(@click.prevent="handlerChoose(item)") {{ item }}
    .round-cards
      button.round-cards__item(
        v-for="tab in tabs"
        :key="tab.key"
        :class="{active: tab.isActive}"
        @click.prevent="handlerTab(tab.id)") {{ tab.name }}
    .key-indicators
      .preloader.preloader_cntr(v-if="showPreloader")
      template(v-else)
        key-tab(
          v-for="tab in tabs"
          :tab="tab"
          :imgPath="path"
          :key="tab.key"
          )

</template>

<script>
import Vue from 'vue';
import VueAxios from 'vue-axios';
import axios from 'axios';
import KeyTab from './components/KeyTab.vue';

Vue.use(VueAxios, axios);
const api = '/api/local/ki/';
const apiRegion = '/api/local/region/';

export default {
  name: 'KeyIndicators',
  components: {
    'key-tab': KeyTab
  },
  props: {
    title: {
      type: String,
      default: ''
    },
    tabsAdmin: {
      type: Array,
      default() {
        return []
      }
    },
    path: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      subjects: {
        isOpen: false,
        plh: 'Все субъекты',
        search: '',
        regions: []
      },
      region: 'all',
      program: 'all',
      tabs: [
        {
          id: 0,
          name: 'Все программы',
          isActive: true,
          color: 'blue',
          picture: 'key-indicators-family',
          key: 'all',
          showRegion: true, // селект с регионами
          creditorCnt: 0, // КРЕДИТОРА
          loanCnt: 0, // УЧАСТНИКОВ
          loanCntOrder: '', // тыс - для участников
          loanCntFull: 0, // Полное число участников
          loanAmt: 0, // сумма выплат
          loanOrder: '', // млрд - для суммы выплат
          link_btn:'/gosudarstvennye-programmy/'
        },
        {
          id: 1,
          name: 'Помощь многодетным семьям',
          isActive: false,
          color: 'purple',
          picture: 'key-indicators-toys',
          key: 'slf',
          showRegion: true, // селект с регионами
          creditorCnt: 0, // КРЕДИТОРА
          loanCnt: 0, // УЧАСТНИКОВ
          loanCntOrder: '', // тыс - для участников
          loanCntFull: 0, // Полное число участников
          loanAmt: 0, // сумма выплат
          loanOrder: '', // млрд - для суммы выплат
          sumLess450Cnt: 0, // полностью погасили
          sumLess450CntOrder: '', // тыс - для полностью погасили
          link_btn:'/catalog/gosudarstvennaya-programma-podderzhki-semey-s-detmi/'
        },
        {
          id: 2,
          // name: 'ИПОТЕКА 6,5%',
          name: 'Льготная ипотека',
          isActive: false,
          color: 'orange',
          picture: 'key-indicators-building',
          key: 'psm',
          showRegion: true, // селект с регионами
          creditorCnt: 0, // КРЕДИТОРА
          loanCnt: 0, // УЧАСТНИКОВ
          loanCntOrder: '', // тыс - для участников
          loanCntFull: 0, // Полное число участников
          loanAmt: 0, // сумма выплат
          loanOrder: '', // млрд - для суммы выплат
          link_btn:'/catalog/lgotnaya-ipoteka/'
        },
        {
          id: 3,
          name: 'Семейная ипотека',
          isActive: false,
          color: 'white',
          picture: 'key-indicators-family-mortgage',
          key: 'family',
          showRegion: false, // селект с регионами
          loanCnt: 0, // УЧАСТНИКОВ
          loanCntOrder: '', // тыс - для участников
          loanCntFull: 0, // Полное число участников
          loanAmt: 0, // сумма выплат
          loanOrder: '', // млрд - для суммы выплат
          link_btn:'/catalog/semeynaya-ipoteka-/'
        },
        {
          id: 4,
          name: 'Дальневосточная ипотека',
          isActive: false,
          color: 'blue',
          picture: 'key-indicators-mountain',
          key: 'dfo',
          showRegion: false, // селект с регионами
          creditorCnt: 0, // КРЕДИТОРА
          loanCnt: 0, // УЧАСТНИКОВ
          loanCntOrder: '', // тыс - для участников
          loanCntFull: 0, // Полное число участников
          loanAmt: 0, // сумма выплат
          loanOrder: '', // млрд - для суммы выплат
          link_btn:'/catalog/dalnevostochnaya-ipoteka/'
        },
        {
          id: 5,
          name: 'IT ипотека',
          isActive: false,
          color: 'purple',
          picture: 'key-indicators-man',
          key: 'iti',
          showRegion: false, // селект с регионами
          creditorCnt: 0, // КРЕДИТОРА
          loanCnt: 0, // УЧАСТНИКОВ
          loanCntOrder: 'тыс.', // тыс - для участников
          loanCntFull: 0, // Полное число участников
          loanAmt: 0, // сумма выплат
          loanOrder: 'млрд.', // млрд - для суммы выплат
          link_btn:'/catalog/lgotnaya-ipoteka-dlya-it-spetsialistov/'
        }
      ],
      regionSearch: [],
      showPreloader: false,
      openSubMenu: null
    }
  },
  computed: {
    selectTitle() {
      return this.region === 'all'
        ? this.subjects.plh
        : this.region;
    },
    searchList() {
      return (this.regionSearch.length && this.subjects.search !== '')
        ? this.regionSearch
        : this.subjects.regions;
    },
    allRegion() {
      const arr = [];
      this.subjects.regions.forEach((el) => {
        const regions = el.UF_SUB_REGION;
        regions.forEach((region) => {
          arr.push(region);
        });
      });
      return arr;
    },
    showRegionSelect() {
      for (let i = 0; i < this.tabs.length; i += 1) {
        if (this.tabs[i].isActive && this.tabs[i].showRegion) {
          return true
        }
      }
    }
  },
  watch: {
    region(newVal) {
      if (newVal === 'all') {
        this.getData();
      } else {
        this.getDataFromApi(this.program);
      }
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.getRegion();
      this.getData();
    });
  },
  methods: {
    /**
     * получение данных о регионах
     */
    getRegion() {
      axios.get(apiRegion, {
        params:{
          get_region:'all'
        },
        headers: {
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        }
      })
        .then((res) => {
          this.subjects.regions = res.data.result;
        })
        .catch((err) => {
          console.log(err);
        });
    },
    /**
     * получение данных
     */
    getData() {
      this.togglePreloader(true);
      this.testTabToAdmin();
      if (this.program === 'all') {
        //TODO: костыль для суммирования, надо поправить
        setTimeout(() => {
          this.setAllProgram();
        }, 800);

      }
    },
    setAllProgram() {
      let curObj;
      curObj = {
        creditorCnt: this.findValue(this.tabs, 'all', 'creditorCnt'),
        loanCnt: this.sumAllTabs('loanCnt', 'тыс'),
        loanCntOrder: 'тыс.',
        loanAmt: (Math.round(this.sumAllTabs('loanAmt', 'трлн. ') / 100) / 10),
        loanOrder: 'трлн. '
      };
      this.setData(curObj, this.program);
    },
    /**
     * проверка есть ли данные из админки
     **/
    testTabToAdmin() {
      let curObj;
      this.tabs.forEach(el => {
        if (!this.findTabFromAdmin(el.key)) {
          this.getDataFromApi(el.key);
        } else {
          const program = this.tabsAdmin.find((tab) => tab.key === el.key);
          curObj = {
            creditorCnt: this.findValue(program.indicators, 'creditorCnt', 'value'),
            loanCnt: this.findValue(program.indicators, 'loanCnt', 'value'),
            loanCntOrder: this.findValue(program.indicators, 'loanCnt', 'unit'),
            loanAmt: this.findValue(program.indicators, 'loanAmt', 'value'),
            loanOrder: this.findValue(program.indicators, 'loanAmt', 'unit'),
          };
          this.setData(curObj, el.key);
        }
      })
    },
    /**
     * получение данных из api
     * @param {String} program - название программы
     */
    getDataFromApi (program) {
      const bodyFormData = new FormData();
      bodyFormData.append('region', this.region);
      bodyFormData.append('program', program);
      const params = {
        region:this.region,
        program:program
      };
      axios.get(api, {
        params: params,
        headers: {
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        }
      })
        .then((res) => {
          this.setData(res.data.result.data, program);
        })
        .catch((error) => {
          console.log(error);
        });
    },
    /**
     * расставляет принятые данные
     * @param {Object} data
     * @param {String} program - ключ программы
     */
    setData(data, program) {
      this.resetSearch();
      const obj = this.tabs.find((el) => el.key === program);
      obj.creditorCnt = data.creditorCnt;
      obj.loanCnt = data.loanCnt;
      obj.loanCntOrder = data.loanCntOrder;
      obj.loanCntFull = this.fullValue(data.loanCntOrder, data.loanCnt);
      obj.loanAmt = data.loanAmt;
      obj.loanOrder = data.loanOrder;

      if (this.program === 'slf') {
        obj.sumLess450Cnt = data.sumLess450Cnt;
        obj.sumLess450CntOrder = data.sumLess450CntOrder;
      }
      setTimeout(this.togglePreloader(false), 100);
    },
    fullValue(value, number) {
      let result = 0;
      let paramValue = value.toString().replace(/ /g, '');
      paramValue = paramValue.replace('.', '');
      let paramNumber = number.toString().replace(/ /g, '');
      paramNumber = Number(paramNumber.replace(',', '.'));

      switch(paramValue) {
        case 'трлн':
          result = paramNumber*1000000000000.0;
          break;
        case 'млрд':
          result = paramNumber*1000000000.0;
          break;
        case 'млн':
          result = paramNumber*1000000.0;
          break;
        case 'тыс':
          result = paramNumber*1000.0;
          break;
      }

      return result
    },
    /**
     * сумма всех показателей для таба 'all'
     * @param {String} param - название показателя
     * @param {String} paramUnit - единицы измерения
     * @return {Number} - сумма показателя по всем программам
     */
    sumAllTabs(param, paramUnit) {
      let sum = 0;
      this.tabs.forEach(el => {
        if (el.key !== 'all') {
          if (param === 'loanAmt') {
            const trillion = this.findTrillion('трлн', el);
            sum += trillion;
          } else {
            sum += el[param];
          }
        }
      })
      return Math.round(sum * 10) / 10;
    },
    /**
     * поиск трлн
     * @param {String} paramUnit - название сокращения для показатлея
     * @param {Object} el - таб с показателем
     */
    findTrillion(paramUnit, el) {
      let trln = el.loanAmt;
      const unitTrim = el.loanOrder.replace(/ /g, '');
      const unit = unitTrim.replace('.', '');
      if (paramUnit === unit) {
        return trln * 1000;
      } return trln
    },
    /**
     * поиск объекта с показателем в  массиве по ключу
     * @param {Array} arr - массив, по которому будет поиск
     * @param {String} key - ключ для поиска нужного объекта
     * @param {String} value - значение, которое необходимо от объекта
     * @return {String, Number} значение искомого ключа
     */
    findValue(arr, key, value) {
      const elem = arr.find(el => el.key === key);
      if (elem) {
        return elem[value]
      }
    },
    /**
     * склонение для периода
     * @param  {Number} count quantity for word
     * @param  {Array} words Array of words. Example:
     * ['депутат', 'депутата', 'депутатов'], ['коментарий', 'коментария', 'комментариев']
     * @return {String} Count + plural form for word
     */
    pluralize(count, words) {
      const cases = [2, 0, 1, 1, 1, 2];
      return words[(count % 100 > 4 && count % 100 < 20)
        ? 2
        : cases[Math.min(count % 10, 5)]];
    },
    /**
     * поиск таба в табах из админки
     * @param {String} program - название программы
     */
    findTabFromAdmin(program) {
      const allAdminTabPrograms = [];
      this.tabsAdmin.forEach(el => allAdminTabPrograms.push(el.key));
      for (let i = 0; i < allAdminTabPrograms.length; i += 1) {
        if (program === allAdminTabPrograms[i]) {
          return true
        }
      }
    },
    /**
     * обработка селекта
     */
    handlerSelect() {
      if (this.subjects.isOpen) {
        this.closeSelect();
      } else {
        this.openSubMenu = null;
        this.subjects.isOpen = true;
      }
    },
    /**
     * закрытие селекта
     */
    closeSelect() {
      this.subjects.isOpen = false;
    },
    /**
     * обработка выбора
     * @param {String} data - название выбора
     */
    handlerChoose(data) {
      this.region = data;
      this.closeSelect();
    },
    /**
     * меняет активный таб, устанавливает выбранную программу гос. поддержки,
     * запускает метод запроса
     * @param {Number} id - id таба, по которому кликнули
     */
    handlerTab(id) {
      const activeTab = this.findToID(id, this.tabs);
      if (activeTab.isActive) {
        return false;
      }
      for (let i = 0; i < this.tabs.length; i += 1) {
        this.tabs[i].isActive = false;
      }
      activeTab.isActive = true;
      this.program = activeTab.key;
      this.region = 'all';
    },
    /**
     * поиск в массиве по id
     * @param {Number} id
     * @param {Array} arr
     * @returns {*}
     */
    findToID(id, arr) {
      return arr.find((el) => el.id === id);
    },
    /**
     * обработка поиска
     */
    handlerSearch() {
      this.regionSearch = [];
      const query = this.subjects.search;
      if (query === '') {
        return false;
      }
      if (query.length >= 3) {
        const arr = this.allRegion;
        for (let i = 0; i < arr.length; i += 1) {
          if (new RegExp(query, 'i').test(arr[i])) {
            this.regionSearch.push(arr[i]);
          }
        }
      }
      return false;
    },
    /**
     * сброс поиска
     */
    resetSearch() {
      this.regionSearch = [];
      this.subjects.search = '';
    },
    /**
     * смена состояния прелоадера
     * @param {Boolean} data - показывать/скрывать прелоадер
     */
    togglePreloader(data) {
      this.showPreloader = data;
    },
    /**
     * открытие/закрытие под меню
     * @param {Number} idx - порядок
     */
    toggleSubMenu(idx) {
      if (idx === this.openSubMenu) {
        this.openSubMenu = null;
      } else {
        this.openSubMenu = idx;
      }
    }
  }
};

</script>

