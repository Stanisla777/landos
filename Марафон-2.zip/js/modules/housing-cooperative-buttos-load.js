/* eslint-disable */
// возвращает куки с указанным name,
function getCookie(name) {
  const matches = document.cookie.match(new RegExp(
    // eslint-disable-next-line no-useless-escape
    `(?:^|; )${name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1')}=([^;]*)`
  ));
  return matches ? decodeURIComponent(matches[1]) : undefined;
}
export default function housingCooperativeButtosLoad() {
  const codeButtons = getCookie('BITRIX_SM_housing_cooperative_chosen');
  const massiveCodeButtons = codeButtons.split('|');
  console.log('Привет Мир');
  const elementButton = document.querySelectorAll('.js--housing-cooperative-add-buttons .card-housing-cooperative__adder');
  for (let item of elementButton) {
    const dataCode = item.getAttribute('data-code')
    if (massiveCodeButtons.includes(dataCode) && !item.classList.contains('btn_selected')&&!item.disabled) {
      item.classList.add('btn_selected')
    }
  }
}
