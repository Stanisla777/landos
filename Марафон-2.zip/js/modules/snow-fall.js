export default function snowFall() {
  const snow = document.querySelector('.js--snowfall');
  if (snow) {
    for (let i = 0; i < 70; i++) {
      const div = document.createElement('div');
      const img = document.createElement('img');
      div.classList.add('snowflake', 'js--snowflake');
      img.setAttribute('src', '/dist/img/snowflake.png');
      div.append(img);
      snow.append(div);
    }
  }
}
