/* eslint-disable */
import Vue from 'vue';
import axios from 'axios-jsonp-pro';
import localaxios from 'axios';
import VueAxios from 'vue-axios';
import Swiper, { Navigation, Pagination } from 'swiper';
import scrollIt from './scroll-it';

Swiper.use([Navigation, Pagination]);

let map = null;
const centerPos = [55.7558, 37.6173];
let myCollection;
let multiRoute;
let myPlacemark

export default function ocenkaInit() {
  // const BX = window.BX;
  Vue.use(VueAxios, axios, localaxios);

  // const api = 'https://api.ocenka.mobi/v1/';
  // const apiKeyProd = 'dhy1jTGBLd25mz2SS792EaTNTgl1D4ac5Rdqrpu3';
  // const localApiUrl = '/local/api/ocenka-mobi/';
  const localApiUrl = '/api/local/ocenka-mobi/';
  // const headers = {
  //   'Content-Type': 'application/json',
  //   Accept: 'application/json',
  // };

  // localaxios.get('/local/api/config/?get=ocenka-mobi', headers)
  //   .then((res) => {
  //     axios.defaults.baseURL = res.data.data.api_url;
  //     axios.defaults.headers['X-Api-Key'] = res.data.data.api_key_prod;
  //   })
  //   .catch((error) => {
  //     console.log(error);
  //   });
  // axios.defaults.baseURL = api;
  // axios.defaults.headers['X-Api-Key'] = apiKeyProd;

  // eslint-disable-next-line no-unused-vars
  const app = new Vue({
    el: '#app',
    data: {
      streetApi: 'https://kladr-api.ru/api.php?oneString=1&limit=8&query=',
      API_KEY: 'c998c65b39bb6bc3a3cd2d8b070f04bc3410b62f',
      apiUrl: '/api/local/suggestions/address/',
      config: {
        headers: {
          'Content-Type': 'application/json',
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
          Accept: 'application/json',
        }
      },
      inputs: [
        {
          id: 0,
          plh: 'Введите адрес',
          type: 'text',
          value: '',
          isNotValid: false,
          validate: true,
          mark:'adress',
          label:'Адрес здания',
        },
        {
          id: 1,
          type: 'text',
          plh: 'Введите площадь',
          value: '',
          isNotValid: false,
          validate: true,
          mark:'area',
          label:'Площадь, м2',
        },
        {
          id: 2,
          plh: 'Студия',
          value: '',
          type: 'select',
          lists: [
            {
              id: 0,
              title: 'Студия',
              value: '1'
            },
            {
              id: 1,
              title: '1 комнатная',
              value: '1'
            },
            {
              id: 2,
              title: '2 комнатная',
              value: '2'
            },
            {
              id: 3,
              title: '3 комнатная',
              value: '3'
            },
            {
              id: 4,
              title: '4 комнатная',
              value: '4'
            }
          ],
          mark:'type',
          label:'Количество комнат',
        },
      ],
      openSelect: false,
      btnSendPress: false,
      bullet: {
        showBullet: false,
        address: '',
        priceMin: 0,
        price: 0,
        price_range:[0,0],
        stations: 0
      },
      bldPos: {},
      bldPhotos: null,
      flat: null,
      showBuildInfo: false,
      showPreloader: false,
      showSocial:false,
      isShowError: false,
      ocenkaMobiErrorText: '',
      ocenkaMobiErrorTextDefault: 'Произошла неизвестная ошибка, попробуйте изменить запрос',
      tabs: [
        {
          id: 0,
          title: 'О доме',
          isActive: false,
          content: [
            {
              id: 0,
              desc: 'Кадастровый номер',
              data: '',
              link: true,
              linkUrl: '',
              additionalClass: 'appraisal__icon_download'
            },
            {
              id: 1,
              desc: 'Цена',
              data: '',
              isCost: true
            },
            {
              id: 2,
              desc: 'Цена за м²',
              data: '',
              isCost: true
            },
            {
              id: 3,
              desc: 'Минимальная цена за м²',
              data: '',
              isCost: true
            },
            {
              id: 4,
              desc: 'Год постройки',
              data: ''
            },
            {
              id: 5,
              desc: 'Этажность дома',
              data: ''
            },
            {
              id: 6,
              desc: 'Количество подъездов',
              data: ''
            },
            {
              id: 7,
              desc: 'Количество лифтов',
              data: ''
            },
            {
              id: 8,
              desc: 'Количество подземных этажей',
              data: ''
            },
            {
              id: 9,
              desc: 'Тип здания',
              data: ''
            },
            {
              id: 10,
              desc: 'Материалы стен',
              data: ''
            },
            {
              id: 11,
              desc: 'Индекс износа здания',
              data: '',
              isWearIndex: true
            },
            {
              id: 12,
              desc: 'Проект здания',
              data: ''
            },
            {
              id: 13,
              desc: 'Материал перекрытий',
              data: ''
            },
            {
              id: 14,
              desc: 'Наличие газоснабжения',
              data: ''
            },
          ]
        },
        {
          id: 1,
          title: 'О квартире',
          isActive: true,
          content: [
            {
              id: 0,
              desc: 'Идентификатор записи в&nbsp;ЕГРН',
              data: ''
            },
            {
              id: 1,
              desc: 'Идентификатор записи в&nbsp;ГКН',
              data: ''
            },
            {
              id: 2,
              desc: 'Кадастровый номер',
              data: ''
            },
            {
              id: 3,
              desc: 'Кадастровая стоимость',
              data: '',
              isCost: true
            },
            {
              id: 4,
              desc: 'Дата установления кадастровой стоимости',
              data: '',
              isDateCost:true
            },
            {
              id: 5,
              desc: 'Площадь',
              data: '',
              isArea: true
            },
            {
              id: 6,
              desc: 'Этаж',
              data: ''
            },
            {
              id: 7,
              desc: 'Количество комнат',
              data: ''
            },
            {
              id: 8,
              desc: 'Информация о&nbsp;зарегистрированных правах',
              data: ''
            },
            {
              id: 9,
              desc: 'Информация об&nbsp;обременении права',
              data: ''
            },
          ]
        }
      ],
      activeTab: 0,
      social: [],
      idActiveFilter: 0,
      bulletInfraShow: false,
      bulletInfra: {},
      searchList: [],
      showSearchList: false,
      showErrorSearch:false,
      captcha_id:null,
      send_argument:null,
      timeout: null,
    },
    filters: {
      // format: (val) => `${val}`.replace(/(\d)(?=(\d{3})+([^\d]|$))/g, '$1 '),
      format: (val) => {
        const sign = Math.sign(Number(val));
        // Nine Zeroes for Billions
        return Math.abs(Number(val)) >= 1.0e9
          ? (sign * (Math.abs(Number(val)) / 1.0e9).toFixed(3) + " блн").replace('.', ',')
          : // Six Zeroes for Millions
          Math.abs(Number(val)) >= 1.0e6
            ? (sign * (Math.abs(Number(val)) / 1.0e6).toFixed(3) + " млн").replace('.', ',')
            : // Three Zeroes for Thousands
            Math.abs(Number(val)) >= 1.0e3
              ? (sign * (Math.abs(Number(val)) / 1.0e3).toFixed(1) + " тыс").replace('.', ',')
              : Math.abs(Number(val));
      },
      format_spase:(val) => {//правка
        return `${val}`.replace(/(\d)(?=(\d{3})+([^\d]|$))/g, '$1 ').replace('.', ',')
      },
      format_date:(val) => { //правка
        return `${val}`.split('-').reverse().join('.');
      },
      format_point_comma:(val) => { //правка
        return `${val}`.replace('.', ',');
      },
    },
    computed: {
      isValid() {
        for (let i = 0; i < this.inputs.length; i += 1) {
          if (this.inputs[i].validate && this.inputs[i].isNotValid) {
            return false;
          }
        }
        return true;
      },
      showFilter() {
        return !!this.social.length;
      }
    },
    watch: {
      inputs: {
        handler() {
          if (this.btnSendPress) {
            this.validateAllInputs();
          }
        },
        deep: true
      },
      searchList(newVal) {
        this.showSearchList = !!newVal.length;
      },
    },
    mounted() {
      this.$nextTick(() => {
        setTimeout(this.initMap, 1000);
      });
      // this.captchaInit();


    },
    methods: {
      //яндекс капча
      captchaInit() {
        this.captcha_id = window.smartCaptcha.render('yandex-captcha-housing-appraisal', {
          sitekey: conf.smartcaptcha_key,
            invisible: true,
            callback: (token) => {
              if (!this.send_argument){
                this.apiConnect(token);
                this.handlerBuildInfo(false);
              }
              else {
                this.handlerBuildInfo(true,token);
              }
            },
          });
      },

      handlerSendForm(argument) {
        this.captchaInit();
        this.send_argument=argument
        this.btnSendPress = true;
        this.validateAllInputs();
        if (this.isValid) {
          // this.apiConnect();
          const grecaptchaInput = document.getElementById('mobi-ocenka-subscribe');
          let recaptchaKey = null;
          if(typeof conf !== 'undefined'){
            recaptchaKey = conf.smartcaptcha_key
          }

          if ((typeof recaptchaKey !== 'undefined') && recaptchaKey!==null) {
            window.smartCaptcha.execute(this.captcha_id,argument);

          }

          // this.handlerBuildInfo(false);
        }
      },
      apiConnect(token) {
        this.showPreloader = true;

        const grecaptchaInput = document.getElementById('mobi-ocenka-subscribe');
        // if (grecaptchaInput && grecaptchaInput.dataset.key) {
        //   window.smartCaptcha.execute(this.captcha_id);
        //   console.log('сработала рекапчка');


          // window.grecaptcha.ready(() => {
          //   window.grecaptcha.execute(grecaptchaInput.dataset.key).then((token) => {
              // grecaptchaInput.value = token;
              localaxios.get(localApiUrl, {
                params: {
                  method: 'appraise/flat',
                  address: this.inputs[0].value,
                  area: this.inputs[1].value,
                  rooms: this.inputs[2].value,
                  forceFlat: true,
                  'smart-token': token
                },
                headers: {
                  'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
                }
              })
                .then((response) => {

                  if (response.data !== null && response.status === 200 && response.data.result === null) {
                    this.ocenkaMobiErrorText = 'Недостаточно данных, попробуйте изменить запрос';
                    this.showError();
                    return false;
                  }
                  if (response.data === null || response.status !== 200) {
                    if (response.data.description) {
                      this.ocenkaMobiErrorText = response.data.description;
                    }
                    this.showError();
                    return false;
                  }
                  if (response.data !== null && response.status === 200 && response.data.result !== null) {
                    if (!(Object.prototype.hasOwnProperty.call(response.data, 'result') && Object.prototype.hasOwnProperty.call(response.data.result, 'address'))) {
                      if (response.data.description) {
                        this.ocenkaMobiErrorText = response.data.description;
                      }
                      this.showError();

                      return false;
                    }
                  }
                  if (response.data !== null && response.status === 200 && response.data.result !== null){
                    this.resetData();
                    this.bullet.address = response.data.result.address;

                    if (response.data.result.stats.min) {
                      this.bullet.priceMin = response.data.result.stats.min;
                    }
                    if (response.data.result.stats.price) {
                      this.bullet.price = response.data.result.stats.price;
                    }
                    if (response.data.result.stats.priceRange) {
                      this.bullet.price_range = response.data.result.stats.priceRange;
                    }

                    if (!response.data.result.stats.min || !response.data.result.stats.price || !response.data.result.stats.priceRange) {
                      this.ocenkaMobiErrorText = 'Недостаточно данных. Попробуйте изменить запрос';
                      this.showError();
                    }

                    if (response.data.result.bld.stations) {
                      this.bullet.stations = response.data.result.bld.stations;
                    }
                    this.bullet.showBullet = true;
                    this.setData(response.data.result);
                  }

                })
                .catch((error) => {
                  console.log(error);
                  if(error&&(error.request.status===403 || error.request.status===405)){
                    this.ocenkaMobiErrorText = 'Сервер не отвечает, попробуйте перезагрузить страницу';
                    this.showErrorSearch=false
                    setTimeout(()=>{
                      this.showError();
                    },500)

                  }
                  // else {
                    this.ocenkaMobiErrorText = this.ocenkaMobiErrorTextDefault;
                    this.showError();
                  // }
                  // handle error
                })
                .then(() => {
                  this.showPreloader = false;
                });
            // });
          // });
        // } else {
        //   // console.log(grecaptchaInput);
        //   // console.log(grecaptchaInput.dataset.key);
        //   // console.log(window.grecaptcha);
        // }
      },

      handlerBuildInfo(data,token) {
        this.showBuildInfo = data;
        this.showSocial = data;
        if (data) {
          setTimeout(this.appraisalSlider, 300);
          // запрос к инфраструктуре
          this.getInfraApi(token);
          this.closeBullet();
          scrollIt(document.querySelector('#form'), 400, 'linear');
        }
      },

      getInfraApi(token) {
        this.showPreloader = true;
        this.ocenkaMobiErrorText = this.ocenkaMobiErrorTextDefault;
        const grecaptchaInput = document.getElementById('mobi-ocenka-subscribe');
        // if (grecaptchaInput && grecaptchaInput.dataset.key && typeof window.grecaptcha !== 'undefined') {
        //   window.grecaptcha.ready(() => {
        //     window.grecaptcha.execute(grecaptchaInput.dataset.key).then((token) => {
        grecaptchaInput.value = token;
        localaxios.get(localApiUrl, {
          params: {
            method: 'search/infra',
            lat: this.bldPos.lat,
            lng: this.bldPos.lng,
            'smart-token': token
          },
          headers: {
            'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
          }
        })
          .then((response) => {
            // console.log(response);
            // handle success
            // if (response.data === null || response.data.bld.quality === 'warning') {
            if ((response.data === null) || (response.status !== 200) || (!(Object.prototype.hasOwnProperty.call(response.data, 'result') && Object.prototype.hasOwnProperty.call(response.data.result, 'social')))) {
              if (response.data.description) {
                this.ocenkaMobiErrorText = response.data.description;
              }
              this.showError();
              return false;
            }
            this.social = response.data.result.social;
            this.setInfraBulletData(response.data.result.social[0].items[0]);
            this.handlerInfraBullet(true);
            this.setObjectToMap();
          })
          .catch((error) => {
            this.ocenkaMobiErrorText = this.ocenkaMobiErrorTextDefault;
            this.showError();
            // handle error
            console.log(error);
          })
          .then(() => {
            this.showPreloader = false;
          });
        // });
        // });
        // } else {
        //   // console.log(grecaptchaInput);
        //   // console.log(grecaptchaInput.dataset.key);
        //   // console.log(window.grecaptcha);
        // }
      },

      setData(data) {
        this.bldPos = data.bld.pos;
        this.initMap([data.bld.pos.lat, data.bld.pos.lng]);
        this.bldPhotos = data.bld.photos;
        this.tabs[0].content[0].data = data.bld.cadNum;
        this.tabs[0].content[0].linkUrl = data.bld.linkPKK;
        this.tabs[0].content[1].data = data.stats.price;
        this.tabs[0].content[2].data = data.stats.min;
        this.tabs[0].content[3].data = data.stats.min;
        this.tabs[0].content[4].data = data.bld.bldYear;
        this.tabs[0].content[5].data = data.bld.maxFloor;
        this.tabs[0].content[6].data = data.bld.entranceCount;
        this.tabs[0].content[7].data = data.bld.elevatorCount;
        this.tabs[0].content[8].data = data.bld.uFloors;
        this.tabs[0].content[9].data = data.bld.bldType;
        this.tabs[0].content[10].data = data.bld.wallMaterial;
        this.tabs[0].content[11].data = data.bld.wearout;
        this.tabs[0].content[12].data = data.bld.bldProject;
        this.tabs[0].content[13].data = data.bld.floorMaterial;
        this.tabs[0].content[14].data = data.bld.supplyTypeGas;
        if (data.flat) {
          this.flat = true;
          this.tabs[1].content[0].data = data.flat.premisesId;
          this.tabs[1].content[1].data = data.flat.parcelId;
          this.tabs[1].content[2].data = data.flat.cadNum;
          this.tabs[1].content[3].data = data.flat.cadCost;
          this.tabs[1].content[4].data = data.flat.dateCost;
          this.tabs[1].content[5].data = data.flat.area;
          this.tabs[1].content[6].data = data.flat.floor;
          this.tabs[1].content[7].data = data.flat.rooms;
          if (data.flat.rights) {
            this.tabs[1].content[8].data = data.flat.rights[0].desc;
          }
          if (data.flat.rights&&data.flat.rights!=null&&data.flat.rights[0].encum) {
            this.tabs[1].content[9].data = data.flat.rights[0].encum[0].desc;
          }
        }
      },
      handlerToggleSelect(data) {
        this.openSelect = data;
      },
      setSelectItem(val, title) {
        this.inputs[2].value = val;
        this.inputs[2].plh = title;
        this.handlerToggleSelect(false);
      },
      validateAllInputs() {
        for (let i = 0; i < this.inputs.length; i += 1) {
          if (this.inputs[i].validate) {
            this.validInput(this.inputs[i]);
          }
        }
      },
      validInput(curInp) {
        // eslint-disable-next-line no-param-reassign,no-unused-expressions
        curInp.value !== '' ? curInp.isNotValid = false : curInp.isNotValid = true;
      },

      closeBullet() {
        this.bullet.showBullet = false;
      },

      handlerTab(activeId) {
        for (let i = 0; i < this.tabs.length; i += 1) {
          this.tabs[i].isActive = false;
        }
        this.tabs[activeId].isActive = true;
        this.activeTab = activeId;
      },

      appraisalSlider() {
        // eslint-disable-next-line no-unused-vars
        const mySwiper = new Swiper('#swiper-appraisal', {
          slidesPerView: 1,
          spaceBetween: 80,
          loop: true,
          observer: true,
          observeParents: true,
          pagination: {
            el: '.swiper-pagination',
            clickable: true,
          },
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          }
        });
      },
      resetData() {
        if (map !== null) {
          map.destroy();
        }
        this.bullet.showBullet = false;
        this.bullet.address = '';
        this.bullet.priceMin = '';
        this.bullet.price = '';
        this.bullet.stations = [];
        this.bldPos = {};
        this.bldPhotos = null;
        this.handlerTab(0);
        for (let i = 0; i < this.tabs.length; i += 1) {
          const contentArr = this.tabs[i].content;
          for (let j = 0; j < contentArr.length; j += 1) {
            contentArr[j].data = '';
            if (contentArr[j].link) {
              contentArr[j].linkUrl = '';
            }
          }
        }
        this.social = [];
        this.isShowError = false;
        this.idActiveFilter = 0;
        this.flat = null;
        this.bulletInfra = {};
        this.bulletInfraShow = false;
        this.showSearchList = false;
      },
      getNewAdress(elem) {
        this.inputs[0].value = elem;
      },
      initMap(dataPos) {
        // eslint-disable-next-line no-unused-vars
        const newAdress = this.getNewAdress;
        // eslint-disable-next-line no-undef
        let pos = dataPos;
        let zoomData = 16;
        let showObj = true;
        if (!pos) {
          pos = centerPos;
          zoomData = 12;
          showObj = false;
        }
        // eslint-disable-next-line no-unused-vars
        const newBullet = this.bullet;
        // eslint-disable-next-line no-undef,no-unused-vars
        const socialE = this.social;
        const ActiveFilter = this.idActiveFilter;
        // eslint-disable-next-line no-undef,no-unused-vars
        let inputValue = this.inputs[0].value;
        // eslint-disable-next-line no-undef
        ymaps.ready(function () {
          // eslint-disable-next-line no-undef,no-unused-vars
          myPlacemark = {
            geometry: {
              type: 'Point',
              coordinates: pos
            },
            properties: {
              // iconContent: this.bullet.address
              iconContent: newBullet.address
            }
          }, {
            preset: 'islands#blackStretchyIcon',
            iconColor: 'green'
          }
          // eslint-disable-next-line no-shadow,no-undef,no-const-assign
          map = new ymaps.Map('map', {
            center: pos,
            controls: ['smallMapDefaultSet'],
            zoom: zoomData
          });
          if (showObj) {
            // eslint-disable-next-line no-undef
            map.geoObjects.add(new ymaps.GeoObject({
              geometry: {
                type: 'Point',
                coordinates: pos
              },
              properties: {
                // iconContent: this.bullet.address
                iconContent: newBullet.address
              }
            }, {
              preset: 'islands#blackStretchyIcon',
              iconColor: 'green'
            }));
          }
          map.container.fitToViewport();
          // map.behaviors.disable('scrollZoom');
          // это потом исправить и вернуть функцию clickToBullet()
          map.geoObjects.events.add('click', (e) => {
            if (typeof socialE[ActiveFilter] !== 'undefined') {
              const objectsArr = socialE[ActiveFilter].items;
              const thisPlacemark = e.get('target');
              // eslint-disable-next-line no-underscore-dangle
              let ballonNumber = thisPlacemark.properties._data.balloonContentHeader;
              if (!ballonNumber) {
                ballonNumber = 0;
              }
              const bulletContent = objectsArr[ballonNumber];
              this.bulletInfra = bulletContent;
              this.setRoute(objectsArr[ballonNumber].pos);
            }
          });
          // this.clickToBullet();
          // eslint-disable-next-line no-unused-vars
          map.events.add('click', (e) => {
            const coords = e.get('coords');
            map.geoObjects.removeAll();
            // eslint-disable-next-line no-undef
            ymaps.geocode(coords)
              .then((res) => {
                // eslint-disable-next-line no-unused-vars
                const firstGeoObject = res.geoObjects.get(0);
                // eslint-disable-next-line no-undef
                map.geoObjects.add(new ymaps.GeoObject({
                  geometry: {
                    type: 'Point',
                    coordinates: coords
                  },
                  properties: {
                    // iconContent: this.bullet.address
                    iconContent: firstGeoObject.getAddressLine()
                  }
                }, {
                  preset: 'islands#blackStretchyIcon',
                  iconColor: 'green'
                }));
                newAdress(firstGeoObject.getAddressLine());
                // eslint-disable-next-line no-const-assign
                inputValue = firstGeoObject.getAddressLine();
              });
          });
        });
      },

      handlerFilter(id,el) {
        const element = el.currentTarget;
        if(!element.classList.contains('is-active')){
          this.idActiveFilter = id;
          this.setObjectToMap();
        }
      },
      clearFilter(){
        this.idActiveFilter=null
        this.bulletInfraShow=false
        this.removingBullets()
      },
      removingBullets(){
        map.geoObjects.remove(myCollection);
        map.geoObjects.remove(multiRoute);
      },
      handlerInfraBullet(data) {
        this.bulletInfraShow = data;
      },
      setInfraBulletData(data) {
        this.bulletInfra = data;
      },
      setObjectToMap() {
        this.bulletInfraShow = false;
        if (myCollection) {
          myCollection.removeAll();
        }
        const objectsArr = this.social[this.idActiveFilter].items;

        // eslint-disable-next-line no-undef
        myCollection = new ymaps.GeoObjectCollection();

        for (let i = 0; i < objectsArr.length; i += 1) {
          // eslint-disable-next-line no-undef
          myCollection.add(new ymaps.Placemark([objectsArr[i].pos.lat,
            objectsArr[i].pos.lng], {
            balloonContentHeader: i
          }, {
            preset: 'islands#darkBlueCircleDotIcon',
            openBalloonOnClick: false
          }));
        }
        this.setRoute(objectsArr[0].pos);
        // eslint-disable-next-line prefer-destructuring
        this.bulletInfra = objectsArr[0];
        map.geoObjects.add(myCollection);
      },
      clickToBullet() {
        map.geoObjects.events.add('click', (e) => {
          const objectsArr = this.social[this.idActiveFilter].items;
          const thisPlacemark = e.get('target');
          // eslint-disable-next-line no-underscore-dangle
          let ballonNumber = thisPlacemark.properties._data.balloonContentHeader;
          if (!ballonNumber) {
            ballonNumber = 0;
          }
          const bulletContent = objectsArr[ballonNumber];
          this.bulletInfra = bulletContent;
          this.setRoute(objectsArr[ballonNumber].pos);
        });
      },
      async setRoute(objectsPos) {
        this.bulletInfraShow = false;
        map.geoObjects.remove(multiRoute);
        // eslint-disable-next-line no-undef
        multiRoute = new ymaps.multiRouter.MultiRoute({
          referencePoints: [
            [this.bldPos.lat, this.bldPos.lng],
            [objectsPos.lat, objectsPos.lng]
          ],
          params: {
            routingMode: 'pedestrian',
            reverseGeocoding: false
          }
        }, {
          wayPointVisible: false,
          routeActiveStrokeWidth: 6,
          routeActiveStrokeStyle: 'dot',
          routeActiveStrokeColor: '#FED141'
          // boundsAutoApply: true
        });
        map.geoObjects.add(multiRoute);
        this.bulletInfra.link = `https://yandex.ru/maps/?ll=${objectsPos.lng},${objectsPos.lat}&z=16&l=map`;
        this.getRouteData();
        setTimeout(this.getRouteData, 600);
      },
      getRouteData() {
        const activeRoute = multiRoute.getActiveRoute();
        if (activeRoute) {
          this.bulletInfra.duration = activeRoute.properties.get('duration').text;
          this.bulletInfraShow = true;
        } else {
          setTimeout(this.getRouteData, 400);
        }
      },
      showError() {
        this.isShowError = true;
      },
      compare(a, b) {
        if (a.type === b.type) {
          return 0;
        }
        if (b.type === 'Город') {
          return 1;
        }
        if (a.type === 'Город') {
          return -1;
        }
        return 0;
      },
      handlerAddress() {
        if (this.inputs[0].value.length > 2) {
          axios.jsonp(this.streetApi + this.inputs[0].value)
            .then((res) => {
              this.searchList = [];
              if (res.result) {
                res.result.sort(this.compare);
                for (let i = 0; i < res.result.length; i += 1) {
                  let { fullName } = res.result[i];
                  if (fullName) {
                    fullName = fullName.split(',');
                    fullName.shift();
                    for (let j = 0; j < fullName.length; j += 1) {
                      fullName[j] = fullName[j].trim();
                    }
                    this.searchList.push(fullName.join(', '));
                    if (this.searchList.length) {
                      this.handlerSelectAddress(true);
                    }
                  }
                }
              }
            })
            .catch((error) => {
              console.log(error);
            });
        }
      },

      set() {
        if (this.timeout) clearTimeout(this.timeout)
        this.timeout = setTimeout(() => {
          this.dadaTa()
        }, 500)
      },
      dadaTa() {
        if (this.inputs[0].value.length > 2) {
          this.isShowError = false;
          // eslint-disable-next-line no-undef
          axios.post(this.apiUrl, {
            query: `${this.inputs[0].value}`, count: 8
            // eslint-disable-next-line no-undef
          }, this.config)
            .then((response) => {
              this.searchList = [];
              if (response.data.result.suggestions) {
                for (let i = 0; i < response.data.result.suggestions.length; i += 1) {
                  const fullName = response.data.result.suggestions[i].value;
                  if (fullName) {
                    this.searchList.push(fullName);
                    if (this.searchList.length) {
                      this.handlerSelectAddress(true);
                    }
                  }
                }
              }
            })
            .then((response) => {
              this.searchError()
            })
            .catch((error) => {
              console.log(error);
              if(error&&(error.request.status===403 || error.request.status===405)){
                this.ocenkaMobiErrorText = 'Сервер не отвечает. Попробуйте перезагрузите страницу';
                this.showErrorSearch=false
                this.showError();
              }
            });
        }
      },
      setAddress(data) {
        this.inputs[0].value = data;
        this.handlerSelectAddress(false);
      },
      handlerSelectAddress(data) {
        this.showSearchList = data;
      },
      clearField(el){ //по нажатию на кнопку Очистить всё
        this.inputs[0].value=''
        this.inputs[1].value=''
        this.$refs.SelectList[0].querySelector('.select__list-item:first-child').click()
        this.bullet.showBullet=false
        this.bulletInfraShow=false
        this.showBuildInfo=false
        this.showSocial=false
        this.inputs[0].isNotValid=false
        this.inputs[1].isNotValid=false
        map.geoObjects.removeAll();

      },
      goBack(){//по нажатию на кнопку вернуться
        this.bulletInfraShow=false
        this.showBuildInfo=false
        this.bullet.showBullet=true
        this.showSocial=false
        this.removingBullets()
      },
      firstZero(el){
        this.inputs[1].value = this.inputs[1].value.replace(/^0+/gi, '1').replace(',', '.').replace(/[^\d\.]/g, "").replace(/\./, "x").replace(/\./g, "").replace(/x/, ".")
      },
      searchError(el){
        if(this.inputs[0].value.length>8){
          if(this.$refs.searchResults[0].querySelectorAll('ul li').length===0 && this.isShowError !== true){
            this.showErrorSearch=true
          }
          else {
            this.showErrorSearch=false
          }
        }
        else{
          this.showErrorSearch=false
        }
      },
    },

  });
}
