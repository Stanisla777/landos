<template lang="pug">
  div

</template>

<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';


export default {
  name: 'RegistrationLoginViaVK',

  props: {

  },
  data() {
    return {

    }
  },
  computed: {

  },
  methods: {


  },
  created(){


  },
  updated() {

  }

}
</script>
