export default function svgHandWriting() {
    const elements = document.querySelectorAll('.js--svg-hand-writing');
    const windowHeight = document.documentElement.clientHeight;
    const halfWindowHeight = windowHeight / 2;
    const rootMargin = halfWindowHeight ? halfWindowHeight - 10 : 0;

    const options = {
        root: null,
        rootMargin: `-${rootMargin}px`,
        threshold: 0
    };

    // eslint-disable-next-line func-names
    const callback = function (entries) {
        entries.forEach((entry) => {
            if (entry.boundingClientRect.top < halfWindowHeight) {
                entry.target.classList.add('active');
            }
        });
    };

    const observer = new IntersectionObserver(callback, options);

    if (elements) {
        for (let i = 0; i < elements.length; i++) {
            observer.observe(elements[i]);
        }
    }
}
