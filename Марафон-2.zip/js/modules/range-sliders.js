import noUiSlider from 'nouislider';

function numberWithSpaces(x) {
    return x.toString()
        .replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
}

export default function rangeSliders() {
    const rangeInitialProperty = document.querySelector('.js--range-slider-initial-payment');

    if (rangeInitialProperty) {
        const inputSlider = rangeInitialProperty;
        const wrapper = inputSlider.closest('.range-input');
        const inputValue = wrapper.querySelector('.range-input__value');
        const perValue = wrapper.querySelector('.range-input__value-per');
        const onePer = 400000;

        noUiSlider.create(rangeInitialProperty, {
            start: 0,
            step: 1,
            behaviour: 'drag',
            connect: [true, false],
            range: {
                min: 1000000,
                max: 40000000
            },
        });

        inputSlider.noUiSlider.on('update', (values, handle) => {
            const value = Math.round(values[handle]);
            const valueWithSpaces = numberWithSpaces(value);
            let pers = (value / onePer).toFixed(1);
            if (pers.endsWith('.0')) {
                if (pers.length === 3) {
                    pers = pers.substr(0, 1);
                } else if (pers.length === 4) {
                    pers = pers.substr(0, 2);
                } else {
                    pers = pers.substr(0, 3);
                }
            }
            inputValue.innerHTML = `${valueWithSpaces} &#8381;`;
            perValue.innerHTML = `${pers}%`;
        });
    }

    const rangeCreditTerm = document.querySelector('.js--range-slider-credit-term');

    if (rangeCreditTerm) {
        const inputSlider = rangeCreditTerm;
        const wrapper = inputSlider.closest('.range-input');
        const inputValue = wrapper.querySelector('.range-input__value');

        noUiSlider.create(rangeCreditTerm, {
            start: 0,
            step: 1,
            behaviour: 'drag',
            connect: [true, false],
            range: {
                min: 3,
                max: 30
            },
        });

        inputSlider.noUiSlider.on('update', (values, handle) => {
            const value = Math.round(values[handle]);
            let year;
            if (value === 1) {
                year = 'год';
            } else if (value === 2 || value === 3 || value === 4) {
                year = 'года';
            } else {
                year = 'лет';
            }
            inputValue.innerHTML = `${value} ${year}`;
        });
    }
}
