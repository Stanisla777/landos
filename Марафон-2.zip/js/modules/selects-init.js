export default function selectsInit() {
    const selects = document.querySelectorAll('.js--select');

    function checkFreePlaceForList(select) {
        const { top, height } = select.getBoundingClientRect();
        const bottom = document.documentElement.clientHeight - (top + height);
        const listWrap = select.querySelector('.select__list-wrapper');
        if (top > bottom) {
            listWrap.classList.add('select__list-wrapper_to-up');
        } else {
            listWrap.classList.remove('select__list-wrapper_to-up');
        }
    }

    if (selects) {
        for (let i = 0; i < selects.length; i++) {
            // eslint-disable-next-line no-continue
            if (selects[i].classList.contains('js--select-initialized')) continue;
            selects[i].classList.add('js--select-initialized');
            const selectBackground = selects[i].querySelector('.js--select-background');
            const selectPlace = selects[i].querySelector('.js--select-place');
            const selectPlaceWrap = selects[i].querySelector('.select__choosen-wrap');
            if (!selectPlace) return false;
            const selectInput = selects[i].querySelector('input');
            const selectItems = selects[i].querySelectorAll('.js--select-item');

            selectPlace.addEventListener('click', () => {
                selects[i].classList.add('open');
            });

            selectBackground.addEventListener('click', () => {
                selects[i].classList.remove('open');
            });

            for (let j = 0; j < selectItems.length; j++) {
                selectItems[j].addEventListener('click', () => {
                  const container = selectItems[j].closest('.js--universal-form');
                  if (container && container.querySelector('.js--feedback-bottom .input__error.visible')) {
                    container.querySelector('.js--feedback-bottom .input__error.visible').remove();
                  }
                  if (selectItems[j].closest('.js--select').classList.contains('input_error')) {
                    selectItems[j].closest('.js--select').classList.remove('input_error');
                  }
                    if (selectPlaceWrap) {
                      // selectPlaceWrap.textContent = selectItems[j].dataset.value;
                      selectPlaceWrap.textContent = selectItems[j].textContent;
                    } else {
                      // selectPlace.textContent = selectItems[j].dataset.value;
                      selectPlace.textContent = selectItems[j].textContent;
                      if (selectPlace.classList.contains('select__choosen-grey')) {
                        selectPlace.classList.remove('select__choosen-grey');
                      }
                    }
                    selectInput.value = selectItems[j].dataset.value;
                    selects[i].classList.remove('open');
                });
            }
        }
    }

    const selectsMultiple = document.querySelectorAll('.js--select-multiple');

    if (selectsMultiple) {
        for (let i = 0; i < selectsMultiple.length; i++) {
            // eslint-disable-next-line no-continue
            if (selectsMultiple[i].classList.contains('js--select-initialized')) continue;
            selectsMultiple[i].classList.add('js--select-initialized');
            const selectBackground = selectsMultiple[i].querySelector('.js--select-background');
            const selectPlace = selectsMultiple[i].querySelector('.js--select-place');
            if (!selectPlace) return false;
            const selectItems = selectsMultiple[i].querySelectorAll('.js--select-item');
            const selectSearch = selectsMultiple[i].querySelector('.js--select-search');
            const checkForFreePlaceForList = selectsMultiple[i].classList.contains('js--check-free-place-for-list');

            selectPlace.addEventListener('click', () => {
                if (checkForFreePlaceForList) checkFreePlaceForList(selectsMultiple[i]);
                selectsMultiple[i].classList.add('open');
                if (selectSearch) selectSearch.focus();
            });

            selectBackground.addEventListener('click', () => {
                selectsMultiple[i].classList.remove('open');
            });

            for (let j = 0; j < selectItems.length; j++) {
                selectItems[j].addEventListener('click', () => {
                    if (selectItems[j].querySelector('input')) selectItems[j].querySelector('input').toggleAttribute('checked');
                });
            }
        }
    }

    const selectChosenLists = document.querySelectorAll('.js--select-with-chosen-list');

    if (selectChosenLists) {
        for (let i = 0; i < selectChosenLists.length; i++) {
            const list = selectChosenLists[i];
            // eslint-disable-next-line no-continue
            if (list.classList.contains('js--chosen-list-initialized')) continue;
            list.classList.add('js--chosen-list-initialized');

            list.addEventListener('click', (e) => {
                const listItem = e.target.closest('.select-chosen-list__item');
                if (listItem) {
                    const { value } = listItem.dataset;
                    const selectItem = list.querySelector(`.js--select-item[data-value='${value}']`);
                    const selectItemCheckbox = selectItem.querySelector('input');
                    selectItemCheckbox.removeAttribute('checked');
                    listItem.remove();
                }
            });
        }
    }
}
