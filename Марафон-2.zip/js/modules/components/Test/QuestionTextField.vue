<template lang="pug">
  .test-cotainer-answer(
    v-bind:class="{mandatory:req}"
  )
    .test-window__number(
      v-if="circle_number"
      v-bind:data-color="[`${item_key}`]"
    )
      p <span>{{item_key}}</span>/<span>{{count_answers}}</span>
    p.test-window__question(
      v-html="question"
    )

    .test-item
      .test-window__item.test-window__textarea
        textarea(
          v-for ="(answer,key,ind) in variants"
          @change="pass_inputAnswer($event,answer.NAME_INPUT,answer.VALUE_INPUT)"
          @input="limitInput"
          v-model="input"
        )(name="",maxlength="1001")
        p.test-window__textarea-error.
          Превышено допустимое количество в 1000 символов
    button.test-window__btn.btn.btn-slide-sub(type="button")(
      v-bind:class="{unact:req}"
      v-if="btn_answer"
      @click="pass_clickButtonAnswer"
    ) Отправить
</template>

<script>
export default {
  name: "QuestionTextField",
  props:['question','variants','item_key','btn_answer','circle_number','count_answers','required','current_answer'],
  data(){
    return{
      input:"",
      req:null,
    }
  },

  methods:{
    pass_inputAnswer(elem,param_1,param_2){
      const element = elem.currentTarget
      this.$emit('event_inputAnswer',[element,elem,param_1,param_2,this.input])
    },
    pass_clickButtonAnswer(elem){
      const element = elem.currentTarget
      this.$emit('event_clickButtonAnswer',[element])
    },
    requiredButton(){
      if(this.required==="Y"){
        this.req=true
      }
      else if(this.required==="N"){
        this.req=false
      }
    },
    requiredButton_2(){
      if(this.input.length!==0){
        this.req=false
      }
      else if(this.input.length===0||this.required==="Y"){
        this.req=true
      }

    },
    limitInput(el) {
      const max = 1001
      const field=el.currentTarget
      // field.value = field.value.substring(0, max);
      const parent = field.closest('.test-window__item')
      const item = parent.querySelectorAll('.test-window__textarea-error')
      if (field.value.length === max) {
        item.forEach(function (item){
          item.setAttribute('style','display:block')
        })
      }
      else
      {
        item.forEach(function (item){
          item.setAttribute('style','display:none')
        })
      }
    }

  },
  watch: {
    input(){
      this.requiredButton_2()
    }
  },
  mounted() {
    this.requiredButton()
  },

}
</script>

<style scoped>

</style>
