<template lang="pug">
  .key-indicators-select(:class="{active: isOpen}")
    .key-indicators-select__choosen(@click.prevent="handlerSelect()") {{ selectTitle }}
    .key-indicators-select__back(@click.prevent="closeSelect()")
    .key-indicators-select__list-wrapper
      .key-indicators-select__list
        .key-indicators-select__search
          input(type="search", name="", placeholder="Поиск субъекта" v-model="subjects.search" @keyup="handlerSearch()")
          button(
            @click.prevent="handlerSearch()"
          )
            svg(width='24' height='24' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg')
              path(fill-rule='evenodd' clip-rule='evenodd' d='M16.4973 4.48737C13.1808 1.17088 7.8038 1.17088 4.48734 4.48737C1.17089 7.80386 1.17089 13.181 4.48734 16.4975C7.51258 19.5227 12.2524 19.7884 15.5788 17.2944L19.929 21.6447C20.4027 22.1184 21.1709 22.1184 21.6447 21.6447C22.1184 21.1709 22.1184 20.4027 21.6447 19.9289L17.2944 15.5787C19.7882 12.2523 19.5225 7.51256 16.4973 4.48737ZM6.20305 6.2031C8.57195 3.83417 12.4127 3.83417 14.7816 6.2031C17.1505 8.57202 17.1505 12.4128 14.7816 14.7817C12.4127 17.1507 8.57195 17.1507 6.20305 14.7817C3.83415 12.4128 3.83415 8.57202 6.20305 6.2031Z' fill='#1C1B28')
        .key-indicators-select__item-wrapper
          .key-indicators-select__item.key-indicators-select__item_main(@click.prevent="handlerChoose('all')") Все субъекты РФ
        template(v-for="(item, idx) in searchList")
          .key-indicators-select__item-wrapper(
            v-if="item.UF_NAME"
            @click="toggleSubMenu(idx)"
          )
            .key-indicators-select__item(:class="{'active': (idx === openSubMenu)}") {{ item.UF_NAME }}
            .key-indicators-select__sublist
              .key-indicators-select__subitem(
                v-for="(subItem, idx) in item.UF_SUB_REGION"
                :key="idx"
                @click.prevent="handlerChoose(subItem)"
              ) {{ subItem }}

          template(v-else)
            .key-indicators-select__subitem(@click.prevent="handlerChoose(item)") {{ item }}
</template>

<script>
export default {
  name: 'KeySelect',
  props: {
    isOpen: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {

    }
  },
  methods: {
    /**
     * обработка селекта
     */
    handlerSelect() {
      if (this.subjects.isOpen) {
        this.closeSelect();
      } else {
        this.openSubMenu = null;
        this.subjects.isOpen = true;
      }
    },
  }
};
</script>
