// import throttle from './throttle';

export default function searchGlobal() {
    // const data = [
    //     {
    //         name: 'Инструкция 1',
    //         url: '123',
    //         type: 'Инструкции',
    //     },
    //     {
    //         name: 'Инструкция 2',
    //         url: '123',
    //         type: 'Инструкции',
    //     },
    //     {
    //         name: 'Документ 1',
    //         url: '123',
    //         type: 'Документы',
    //     },
    //     {
    //         name: 'Документ 2',
    //         url: '123',
    //         type: 'Документы',
    //     },
    //     {
    //         name: 'Вопрос',
    //         url: '123',
    //         type: 'Вопросы и ответы',
    //     },
    //     {
    //         name: 'Ответ',
    //         url: '123',
    //         type: 'Вопросы и ответы',
    //     },
    //     {
    //         name: 'Сервис 1',
    //         url: '123',
    //         type: 'Сервисы',
    //     },
    //     {
    //         name: 'Сервис 2',
    //         url: '123',
    //         type: 'Сервисы',
    //     },
    //     {
    //         name: 'Сервис',
    //         url: '123',
    //         type: 'Инструкции',
    //     },
    //     {
    //         name: 'Вопрос',
    //         url: '123',
    //         type: 'Инструкции',
    //     },
    //     {
    //         name: 'Вопрос',
    //         url: '123',
    //         type: 'Сервисы',
    //     },
    //     {
    //         name: 'Вопрос',
    //         url: '123',
    //         type: 'Документы',
    //     },
    // ];

    const search = document.querySelector('.js--search-global');
    let searchWrapper;
    let searchForOpen;
    let searchForm;
    let searchInput;
    let searchCloser;
    let searchList;
    let searchNothing;
    let searchCleaner;
    let startWidthSearch;
    if (search) {
        searchWrapper = search.querySelector('.search-global__wrapper');
        searchForOpen = search.querySelector('.search-global__for-open');
        searchForm = search.querySelector('.search-global__form');
        searchInput = search.querySelector('.search-global__input');
        searchCloser = search.querySelector('.search-global__closer');
        searchList = search.querySelector('.search-global__list');
        searchNothing = search.querySelector('.search-global__nothing');
        searchCleaner = search.querySelector('.search-global__cleaner');
        if (searchWrapper) {
          startWidthSearch = searchWrapper.offsetWidth;
        }
    }

    if (searchForm) {
        searchForm.style.width = `${startWidthSearch}px`;
    }

    if (searchForOpen) {
        searchForOpen.addEventListener('click', () => {
            search.classList.add('open');
            searchForm.style.width = `${searchWrapper.offsetWidth}px`;
            document.body.classList.add('modal-opened');
            searchInput.focus();
        });
    }

    function inputCleaner() {
        searchNothing.classList.remove('show');
        searchList.classList.remove('show');
        searchCleaner.classList.remove('show');
        searchInput.value = '';
        searchInput.focus();
    }

    if (searchCloser) {
        searchCloser.addEventListener('click', () => {
            search.classList.remove('open');
            searchForm.style.width = `${startWidthSearch}px`;
            document.body.classList.remove('modal-opened');
            inputCleaner();
        });

        searchCleaner.addEventListener('click', inputCleaner);
    }

    // function filterF(e) {
    //     return e.name.toLowerCase().startsWith(searchInput.value.toLowerCase());
    // }

    // function createCategory(item, fragment) {
    //     const category = document.createElement('div');
    //     category.classList.add('search-global__list-category');
    //     category.dataset.type = item.type;
    //     const categoryName = document.createElement('span');
    //     categoryName.classList.add('search-global__list-name');
    //     categoryName.innerHTML = item.type;
    //     category.appendChild(categoryName);
    //     fragment.appendChild(category);
    //
    //     return category;
    // }

    // function createLink(item) {
    //     const link = document.createElement('a');
    //     link.href = item.url;
    //     link.innerHTML = item.name;
    //     link.classList.add('search-global__list-link');
    //
    //     return link;
    // }

    // function spaceValidator() {
    //     if (searchInput.value[0] === ' ') {
    //         searchInput.value = '';
    //     }
    // }

    // function lettersLighter(link, value) {
    //     const l = link;
    //     l.innerHTML = l.innerHTML.toLowerCase();
// l.innerHTML = l.innerHTML.replace(value.toLowerCase(), `<span>${value.toLowerCase()}</span>`);
    //     return l;
    // }
  function searching() {
        if (searchInput.value.length === 0) {
            searchNothing.classList.remove('show');
            searchList.classList.remove('show');
            searchCleaner.classList.remove('show');
        } else {
          searchCleaner.classList.add('show');
        }
  }
    // function searching() {
    //     spaceValidator();
    //
    //     if (searchInput.value.length === 0) {
    //         searchNothing.classList.remove('show');
    //         searchList.classList.remove('show');
    //         searchCleaner.classList.remove('show');
    //         return;
    //     }
    //
    //     searchCleaner.classList.add('show');
    //     const filteredData = data.filter(filterF);
    //
    //     if (filteredData.length === 0) {
    //         searchList.classList.remove('show');
    //         searchNothing.classList.add('show');
    //         return;
    //     }
    //
    //     searchNothing.classList.remove('show');
    //     searchList.classList.add('show');
    //     const fragment = new DocumentFragment();
    //
    //     filteredData.forEach((item) => {
// const category = fragment.
// querySelector(`.search-global__list-category[data-type='${item.type}']`);
    //         if (!(category)) {
    //             const categoryNew = createCategory(item, fragment);
    //             const link = createLink(item);
    //             const lightedLink = lettersLighter(link, searchInput.value);
    //             categoryNew.append(lightedLink);
    //         } else {
    //             const link = createLink(item);
    //             const lightedLink = lettersLighter(link, searchInput.value);
    //             category.append(lightedLink);
    //         }
    //     });
    //
    //     searchList.innerHTML = '';
    //     searchList.append(fragment);
    // }

    if (searchInput) {
        searchInput.addEventListener('input', searching);
    }
}
