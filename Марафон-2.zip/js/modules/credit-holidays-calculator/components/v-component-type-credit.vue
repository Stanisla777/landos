<template lang="pug">
  .calculator_s__calculator-row
    .calculator_s__period-input-wrapper
      p.calculator_s__calculator-label Тип кредита
    .calculator_s__period-selection.calculator_s__wrapper-select.js--wrapper-select
      .calculator_s__select-choosen(@click="openList")
        p.calculator_s__selected-value.js--selected-value {{type_credit[0].output_name}}
        .calculator_s__selected-arrow
          svg(width='18' height='10' viewbox='0 0 18 10' fill='none' xmlns='http://www.w3.org/2000/svg')
            path(d='M1 1L8.29289 8.29289C8.68342 8.68342 9.31658 8.68342 9.7071 8.29289L17 1' stroke='#6B7081' stroke-width='2' stroke-linecap='round' stroke-linejoin='round')
      .calculator_s__list-wrapper.credit-holiday__list-wrapper.js--list-wrapper
        ul.select__list
          li.select__list-item.js--select-item(
            v-for="item in type_credit"
            @click="periodSelection"
            v-bind:for-type="item.type"
          ) {{item.output_name}}


</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import PopUp from '../components/v-component-pop-up.vue';
export default {
  name: 'v-component-type-credit',
  data(){
    return {

    }
  },
  methods:{
//  Раскрываю список с выбором периода зарплаты
    openList(el){
      const item = el.currentTarget;
      const parent = item.closest('.js--wrapper-select');
      const container = parent.querySelector('.js--list-wrapper');

      if (parent.classList.contains('active')) {
        parent.classList.remove('active');
        container.style.maxHeight = 0;
      } else {
        parent.classList.add('active');
        container.style.maxHeight = `${container.scrollHeight}px`;
      }

    },
    //  Выбор тип кредита списка
    periodSelection(el){
      const element = el.currentTarget
      const type = element.getAttribute('for-type')
      const value = element.textContent
      const parent = element.closest('.js--wrapper-select')
      const container = parent.querySelector('.js--list-wrapper');
      const main_container = element.closest('.calculator_s__wrapper-salary');
      parent.querySelector('.js--selected-value').textContent = value;
      parent.classList.remove('active');
      container.style.maxHeight = 0;
      const type_credit = {}
      type_credit.name=value
      type_credit.symbolic_name = type
      this.sendInputChange(type_credit)


    },
    sendInputChange(value){
      Storage.dispatch('ActionTypeCredit',value)
    },
  },
  mounted(){
//При загрузке страницы отправил тип кредита
    const type_credit = {}
    type_credit.name=this.type_credit[0].output_name
    type_credit.symbolic_name = this.type_credit[0].type
    this.sendInputChange(type_credit)
  },
  computed:{
    type_credit(){
      return Storage.getters.TYPE_CREDIT
    },
  },
  watch:{
  },
  components:{
    PopUp
  }
};
</script>
<style scoped>
</style>
