<template lang="pug">
  div
    template(v-if="!pop_up")
      pop-up(
        :paramText="text_pop_up"
        v-on:eventClosePopUp="closePopUp($event)"
      )
    div.calculator_s__calculations.js--tax-deduction_calculations
      template
        component-region
      template
        component-type-credit
      template
        component-credit-amount
      template
        component-date-signing
      template
        component-check-box-not-work(
          v-on:eventcheckboxChanged="callModal($event)"
        )
      .credit-holiday__wrap
        .calculator_s__period-input-wrapper
          h2.calculator_s__second-level-title Информация о доходах за 2021 год
          .calculator_s__period-input-wrap-icon
            svg(width='6' height='9' viewbox='0 0 6 9' fill='none' xmlns='http://www.w3.org/2000/svg')
              path(d='M2.29615 5.82809V5.87809H2.34615H3.38128H3.43128V5.82809C3.43128 5.17718 3.88001 4.74316 4.37092 4.26834C4.3939 4.24612 4.41697 4.2238 4.44009 4.20137C4.95161 3.70514 5.47928 3.15761 5.47928 2.27748C5.47928 1.56616 5.1798 1.02591 4.72144 0.664646C4.26438 0.304406 3.65179 0.123828 3.0251 0.123828C1.94115 0.123828 0.916704 0.644209 0.518245 1.74851L0.503822 1.78848L0.540948 1.80916L1.42025 2.2989L1.47368 2.32866L1.49223 2.27038C1.60592 1.91305 1.80522 1.65293 2.06481 1.48165C2.32489 1.31005 2.64868 1.22557 3.01397 1.22557C3.39653 1.22557 3.72964 1.31585 3.96588 1.49634C4.20027 1.67543 4.34415 1.94688 4.34415 2.322C4.34415 2.63879 4.22214 2.90106 4.03445 3.14622C3.87409 3.35566 3.66836 3.5496 3.45209 3.75346C3.41356 3.78978 3.37469 3.82642 3.33569 3.86351C2.82303 4.3511 2.29615 4.90943 2.29615 5.82809ZM2.85815 8.28226C3.29809 8.28226 3.63162 7.93659 3.63162 7.50879C3.63162 7.08098 3.29809 6.73531 2.85815 6.73531C2.42984 6.73531 2.08467 7.08048 2.08467 7.50879C2.08467 7.9371 2.42984 8.28226 2.85815 8.28226Z' fill='#1C1B28' stroke='#1C1B28' stroke-width='0.1')
          template
            tool-tip(
              :hint_text="hint_text"
            )
      .calculator_s__wrap-borrower
        template
          component-check-box-same-salary(
            :param_label="label_for_borrower"
            :param_id="id_borrower"
            v-on:eventcheckboxChanged="blockSalaryMonthly($event)"
          )
        template
          component-salary-per-year
        template
          component-salary-monthly
        template
          component-before-going-bank

      .calculator_s__co-borrower.calculator_s__wrap-borrower(
        v-for="item in co_borrower"
      )
        .credit-holiday__co-borrower-same_salary
          template
            component-check-box-same-salary(
              :param_label="label_for_co_borrower"
              :param_id="item"
              v-on:eventcheckboxChanged="blockSalaryMonthly($event)"
            )
        template
          component-salary-per-year
        template
          component-salary-monthly
        template
          component-before-going-bank

      template
        component-button(
          v-on:eventAddCoBorrower="addCoBorrower($event)"
          v-on:eventCalculateSalary="calculateSalary($event)"
          :param_for_btn="check_not_work"
        )

    div.calculator_s__results.calculator_s__credir-holidays-results(
      :class="{zoomInD:final_result}"
    )
      template(v-if="final_state_confirmed===true&&final_state_confirmed!=null")
        component-final-block-confirmed
      template(v-if="final_state_confirmed===false&&final_state_confirmed!=null")
        component-final-block-refusal

</template>
<script>
import Vue from 'vue';
import eventBus from './development-tools/eventBus.vue';
import Storage from './development-tools/state.vue';
import ComponentDateSigning from './components/v-component-date-signing.vue';
import ComponentCreditAmount from './components/v-component-credit-amount.vue';
import ComponentFinalBlockRefusal from './components/v-component-final-block-refusal.vue';
import ComponentFinalBlockConfirmed from './components/v-component-final-block-confirmed.vue';
import PopUp from './components/v-component-pop-up.vue';

import ComponentRegion from './components/v-component-region.vue';
import ComponentTypeCredit from './components/v-component-type-credit.vue';
import ComponentCheckBoxNotWork from './components/v-component-checkbox-not-work.vue';
import ToolTip from './components/v-component-tooltip.vue';
import ComponentCheckBoxSameSalary from './components/v-component-checkbox-same-salary.vue';
import ComponentSalaryPerYear from './components/v-component-salary-per-year.vue';
import ComponentBeforeGoingBank from './components/v-component-salary-before-going-bank.vue';
import ComponentSalaryMonthly from './components/v-component-salary-monthly.vue';
import ComponentButton from './components/calculate-and-co-borrower.vue';





export default {
  name: 'CreditHolidaysCalculator',
  data(){
    return {
      data_detailed_calculator:false,
      pop_up:true,
      text_pop_up:null,
      hint_text:'Если дохода не было, укажите 0',
      salary_per_year:true,
      salary_monthly:false,
      label_for_borrower:'Я получал одинаковую заработную плату на протяжении 2021 года',
      label_for_co_borrower:'Созаемщик получал одинаковую заработную плату на протяжении 2021 года',
      co_borrower:[],
      id_checkbox:0,
      id_borrower:'co_borrower', //id для чекбокса непосредственного заёмщика,
      final_state_confirmed:null,
      final_result:false,
      state_for_button:null
    }
  },
  methods:{
    contentPopUp(ev){
      this.pop_up=ev.condition
      this.text_pop_up=ev.text
    },
    closePopUp(ev){
      this.pop_up=ev
    },
    addCoBorrower(ev){
      this.co_borrower.push(ev)
    },
    callModal(ev){
      this.pop_up=ev.state
      this.text_pop_up=ev.text
      if(ev.state===false){
        this.state_for_button=false
      }
    },

    blockSalaryMonthly(el){
      // this.salary_per_year=el
      if(el[1]==false){

        el[0].closest('.calculator_s__wrap-borrower').classList.add('salary-option')
        el[0].closest('.calculator_s__wrap-borrower').querySelector('.calculator_s__per-year-salary input').value=''
        el[0].closest('.calculator_s__wrap-borrower').querySelector('.calculator_s__per-year-salary input').setAttribute('placeholder',"Введите сумму")
        el[0].closest('.calculator_s__wrap-borrower').querySelector('.calculator_s__per-year-salary input').setAttribute('style','width:100%;')
        // el[0].closest('.calculator_s__wrap-borrower').querySelector('.calculator_s__per-year-salary input').setAttribute('placeholder','Введите сумму')
      }
      else {
        el[0].closest('.calculator_s__wrap-borrower').classList.remove('salary-option')
        const array_month = el[0].closest('.calculator_s__wrap-borrower').querySelectorAll('.credit-holiday__salary-item')
        for (let item of array_month){
          if(item.querySelector('input').value!==''){
            item.querySelector('input').value=''
            item.querySelector('.currency-salary').setAttribute('style','display:none;')
            item.querySelector('input').setAttribute('placeholder',"Введите сумму")
            item.querySelector('input').setAttribute('style','width:100%;')
          }

        }
      }

    },
    calculateSalary(){
      this.final_result=false
      const array_borrower = document.querySelectorAll('.calculator_s__wrap-borrower')
      const state_borrower=[]
      for (let item of array_borrower) {
        let arr_salary = [];
        let array_input_salary = item.querySelectorAll('.js--salary-per-year input');

        for (let elem of array_input_salary) {

          let input_salary = elem.value;
          if (input_salary == '') {
            input_salary = 0;
          } else {
            input_salary = parseInt(input_salary.replace(/\s/g, ''));
          }
          arr_salary.push(input_salary);
          if(!elem.closest('.calculator_s__wrap-borrower').classList.contains('salary-option')){
            arr_salary.splice(1);
          }
        }

        let sum_arr_salary = 0;
        let calc_average_salary=0
        //Когда одно поле с зарплатой


        if(arr_salary.length===1){
          for (let i = 0; i < arr_salary.length; i++) {
            sum_arr_salary = sum_arr_salary + arr_salary[i];
          }
          calc_average_salary =parseFloat((((sum_arr_salary * 12) - (sum_arr_salary * 4)) / 8).toFixed(1))

        }
        //Когда много полей с зарплатой
        else {
          arr_salary = arr_salary.filter(function(f) { return f !== 0 })

          for (let i = 0; i < arr_salary.length; i++) {
            sum_arr_salary = sum_arr_salary + arr_salary[i];
          }
          //Если заполнено больше 6 полей
          if(arr_salary.length<6){
            calc_average_salary = (sum_arr_salary/arr_salary.length).toFixed(1)

          }
          else{
            const minimum_salary = arr_salary.sort((a,b) => a - b).slice(0, 2);
            let sum_minimum_salary=0
            for (let i = 0; i < minimum_salary.length; i++) {
              sum_minimum_salary = sum_minimum_salary + minimum_salary[i];
            }


            const maximum_salary = arr_salary.sort((a,b) => b - a).slice(0, 2);
            let sum_maximum_salary=0
            for (let i = 0; i < maximum_salary.length; i++) {
              sum_maximum_salary = sum_maximum_salary + maximum_salary[i];
            }


            calc_average_salary = ((sum_arr_salary - (sum_minimum_salary + sum_maximum_salary))/(arr_salary.length-4)).toFixed(1)

          }
        }

        // obj_salary.salary_per_year = calc_average_salary
        //
        let input_salary_before = item.querySelector('.js--salary-before-going input').value
        if (input_salary_before == '') {
          input_salary_before = 0;
        } else {
          input_salary_before = parseInt(input_salary_before.replace(/\s/g, ''));
        }
        // input_salary_before = parseInt(input_salary_before.replace(/\s/g, ''))
        calc_average_salary = parseFloat(calc_average_salary)
        const final_state = ((input_salary_before - calc_average_salary)/calc_average_salary)*100
        state_borrower.push(final_state)

      }


      let sum = 0;
      for (let i = 0; i < state_borrower.length; i++) {
        sum = sum + state_borrower[i];
      }

      const final_state_all_borrower = sum/state_borrower.length

      if(final_state_all_borrower<-30){
        this.final_state_confirmed=true
      }
      else {
        this.final_state_confirmed=false
      }
      setTimeout(()=>{
        this.final_result=true
      },100)

    }


  },
  mounted(){
  },
  computed:{
    check_not_work(){
      return Storage.getters.STATE_APPROVAL_CHECK_NOT_WORK
    },
  },
  watch:{
  },
  components:{
    ComponentFinalBlockRefusal,
    ComponentFinalBlockConfirmed,
    ComponentDateSigning,
    ComponentCreditAmount,
    ComponentSalaryPerYear,
    PopUp,

    //Новое
    ComponentRegion,
    ComponentTypeCredit,
    ComponentCheckBoxNotWork,
    ToolTip,
    ComponentCheckBoxSameSalary,
    ComponentBeforeGoingBank,
    ComponentSalaryMonthly,
    ComponentButton,
  }
};
</script>
<style scoped>
</style>
