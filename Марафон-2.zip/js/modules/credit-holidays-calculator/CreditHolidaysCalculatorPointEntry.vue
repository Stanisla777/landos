<template lang="pug">
  div.calculator_s__calculator
    template
      credit-holidays-calculator

</template>
<script>
// import DduCalculator from './DduCalculator.vue';
import Storage from './development-tools/state.vue';
const CreditHolidaysCalculator = () => import ("./CreditHolidaysCalculator.vue");


export default {
  name: 'CreditHolidaysCalculatorPointEntry',
  data(){
    return {

    }
  },
  methods:{
  },
  mounted(){
  },
  computed:{
  },
  watch:{
  },
  components:{
    CreditHolidaysCalculator
  }
};
</script>
<style scoped>
</style>
