/* eslint-disable */
import Swiper from 'swiper';
let swiper
let count=0
function tagsCut() {
  const bread_crumbs = document.querySelectorAll('.js--list-tag')
  for(let item of bread_crumbs){
    const parent = item.closest('.js--material-header')
    let elementWidth = item.clientWidth;
    let pageWidth = parent.clientWidth;
    if (elementWidth > pageWidth){
      item.closest('.js--wrapper-list-tag').classList.add('active')
    }
    else if(elementWidth < pageWidth) {
      item.closest('.js--wrapper-list-tag').classList.remove('active')
    }
    window.onresize = function() {
      let pageWidth = parent.clientWidth;
      let elementWidth = item.clientWidth;
      if (elementWidth > pageWidth){
        item.closest('.js--wrapper-list-tag').classList.add('active')
      }
      else if(elementWidth < pageWidth) {
        item.closest('.js--wrapper-list-tag').classList.remove('active')
      }
    };
  }
}
function tagsDropDownMobile() {
  const array_btn = document.querySelectorAll('.js--tag-mob-btn')
  for(let item of array_btn){

    item.onclick=()=>{
      if(item.closest('.js--parent-material').querySelector('.js--mobile-list-tag').classList.contains('active')){
        item.closest('.js--parent-material').querySelector('.js--mobile-list-tag').classList.remove('active')
      }
      else{
        item.closest('.js--parent-material').querySelector('.js--mobile-list-tag').classList.add('active')
      }

    }
    const parent = item.closest('.js--parent-material')
    const btn = item.closest('.js--parent-material').querySelector('.js--tag-mob-btn')
    const mob = item.closest('.js--parent-material').querySelector('.js--mobile-list-tag')
    parent.onclick=(e)=>{
      const element = e.currentTarget

      if ((e.target === parent||e.target.closest('.js--parent-material'))&&e.target!==btn&&e.target!==mob) {
        element.querySelector('.js--mobile-list-tag').classList.remove('active')
      }

    }

  }
}
function materialDropDown() {
  const btn = document.querySelectorAll('.js--izhs-accordion-btn')
  let parent_height
  let max_height
  for(let item of btn){
    item.onclick=()=>{
      const parent_container = item.closest('.js--container-block-info')
      const parent = item.closest('.js-accordion-parent');
      const container = parent.querySelector('.js-accordion-body');
      if (parent.classList.contains('active')) {

        parent.classList.remove('active');
        const max_height=container.scrollHeight;
        // container.setAttribute('style', `max-height:${max_height}px;`);
        // parent_container.style.height='auto'
        // setTimeout(()=>{
        //   container.setAttribute('style', `max-height:0;`);
        // },300)

      } else {
        parent_height = parent_container.clientHeight
        // parent_container.style.height='auto'
        parent.classList.add('active');


        // setTimeout(()=>{

        //   container.setAttribute('style', `max-height:4000px;`);
        // // },100)
        // setTimeout(()=>{
        //   container.setAttribute('style', `max-height:max-content;`);
        // },600)

      }



    }

  }
}
function infoBlockOpen() {
  let win_width
  win_width= window.screen.width
  window.addEventListener('resize', ()=>{
    win_width= window.screen.width
  });
  const info_block = document.querySelectorAll('.js--categories-preview')
  const container = document.querySelector('.js--container-block-info')
  for (let item=0;item<info_block.length;item++){
    info_block[item].onclick=()=>{
      info_block[item].style.pointerEvents='none'
      const data = info_block[item].getAttribute('data-material');
      const array_material = document.querySelectorAll('.js--block-info')
      const swiper_item = info_block[item].closest('.swiper-slide')
      if(info_block[item].classList.contains('active')){
        info_block[item].classList.remove('active')
        info_block[item].closest('.js--izhs-wrapper-categories').classList.remove('active');
        info_block[item].closest('.js--izhs-wrapper-categories').querySelector('.js--izhs-swiper-categories-pag').classList.remove('unactive');
        if(container){
          const promice = new Promise(function (resolve,reject) {
            setTimeout(()=>{
              const computed_style = parseInt(window.getComputedStyle(container).height);
              container.style.height=`${computed_style}px`
              container.style.overflow='hidden';
              resolve()
            },200)
          }).then(()=>{
            return new Promise(function (resolve,reject) {
              setTimeout(()=>{
                container.style.height='0'
                resolve()
              },100)

            })
          }).then(()=>{
            return new Promise(function (resolve,reject) {
              setTimeout(()=>{
                container.querySelector('.js--block-info[data-material="' + data + '"]').classList.remove('active');
                resolve()
              },500)

            })
          }).then(()=>{
            return new Promise((resolve,reject)=> {
              // setTimeout(()=>{
                info_block[item].style.pointerEvents='auto'
                resolve()
              // },200)
            })
          })
          container.classList.remove('active');
          // setTimeout(()=>{
          //   container.querySelector('.js--block-info[data-material="' + data + '"]').classList.remove('active');
          //   },500)
        }
      }
      else{
        for(let i=0;i<info_block.length;i++){
          info_block[i].classList.remove('active')
        }
        info_block[item].classList.add('active');
        info_block[item].closest('.js--izhs-wrapper-categories').classList.add('active');
        info_block[item].closest('.js--izhs-wrapper-categories').classList.add('active_additional');
        info_block[item].closest('.js--izhs-wrapper-categories')
          .querySelector('.js--izhs-swiper-categories-pag').classList.add('unactive');
        if (container) {
          for(let i=0;i<array_material.length;i++){
            array_material[i].classList.remove('active')
          }


          const promice = new Promise((resolve,reject)=> {
            container.style.overflow='hidden';
            const height_elem =  container.querySelector('.js--block-info[data-material="' + data + '"]').clientHeight
            container.classList.add('active');
            container.querySelector('.js--block-info[data-material="' + data + '"]').classList.add('active');
            const wrap = container.querySelector('.js--block-info[data-material="' + data + '"]')
            wrap.querySelector('.js--info-block-close').style.pointerEvents='none'
            resolve(height_elem)
          }).then((height_elem)=>{
            return new Promise((resolve,reject)=> {
              setTimeout(()=>{
                container.style.height=`${height_elem}px`
                resolve()
              },100)

            })
          }).then(()=>{
            return new Promise((resolve,reject)=> {
              setTimeout(()=>{
                container.style.overflow='visible';
                resolve()
              },600)
            })
          })
            .then(() => {
              return new Promise((resolve, reject) => {
                info_block[item].style.pointerEvents = 'auto';
                const wrap = container.querySelector('.js--block-info[data-material="' + data + '"]');
                wrap.querySelector('.js--info-block-close').style.pointerEvents = 'auto';
                resolve();
              });
            })
            .then(() => {
              return new Promise((resolve, reject) => {
                container.setAttribute('style', `height:max-content;`);
                resolve();
              });
            })
        }
        if (win_width<=865){
          swiper.slideTo(item)
        }
        setTimeout(()=>{
          info_block[item].closest('.js--izhs-wrapper-categories').classList.remove('active_additional');
        },600)
      }
      setTimeout(()=>{
        // info_block[item].style.pointerEvents='auto'
      },1000)

    }
  }
}
function infoBlockClose (){
  const btn = document.querySelectorAll('.js--info-block-close')
  const container = document.querySelector('.js--izhs-wrapper-categories')
  for(let item of btn){
    item.onclick=()=>{
      if(container){
        const parent = item.closest('.js--container-block-info')
        const array_categories = container.querySelectorAll('.js--categories-preview')
        const computed_style = parseInt(window.getComputedStyle(parent).height);
        parent.style.height=`${computed_style}px`
        container.classList.remove('active')
        const promice = new Promise(function (resolve,reject) {
          parent.style.overflow='hidden';
          resolve()
        }).then(()=>{
          return new Promise(function (resolve,reject) {
            setTimeout(()=>{
              parent.style.height='0'
              resolve()
            },100)
          })
        })
        container.querySelector('.js--izhs-swiper-categories-pag').classList.remove('unactive');
        for(let i=0;i<array_categories.length;i++){
          array_categories[i].classList.remove('active')
        }
      }
      if(item.closest('.js--container-block-info')){
        item.closest('.js--container-block-info').classList.remove('active')
        setTimeout(()=>{
          item.closest('.js--block-info').classList.remove('active');
        },500)
      }
    }
  }
}
function izhsCategoriesSlider() {
  let win_width
  win_width= window.screen.width
  window.addEventListener('resize', ()=>{
    win_width= window.screen.width
  });
  swiper = new Swiper('.js--izhs-swiper-categories', {
    slidesPerView: 4,
    spaceBetween: 20,
    simulateTouch: false,
    loop: true,
    rewind:true,
    autoHeight: false,
    preventClicks:true,
    pagination: {
      el: '.js--izhs-swiper-categories-pag',
      clickable: true
    },
    navigation: {
      nextEl: '.js-izhs-category-button-next',
      prevEl: '.js-izhs-category-button-prev',
    },
    breakpoints: {
      0: {
        loop: false,
        slidesPerView: 2.1,
        spaceBetween: 12,
      },
      615: {
        loop: false,
        slidesPerView: 3,
        spaceBetween:12,
      },
      865: {
        loop: false,
        slidesPerView: 4,
        spaceBetween: 20,
      }
    },
    on:{
      beforeInit: (param) => {
        if(win_width>865){
          const count = param.$el[0].querySelectorAll('.swiper-slide').length;
          if(count<5){
            param.$el[0].closest('.js--izhs-wrapper-categories')
              .querySelector('.js--izhs-swiper-categories-pag').classList.add('un-active');
            param.params.allowTouchMove=false
          }
        }
      },
      slideNextTransitionEnd:(el)=>{
        count===0
        const element_parent = el.$el[0].querySelector('.izhs__categories-preview.active')
        if(element_parent){
          let element;
          if(element_parent.closest('.js--izhs-wrapper-categories').classList.contains('active_additional')){
            element = element_parent.closest('.swiper-slide');
          }
          else {
            element = element_parent.closest('.swiper-slide').nextElementSibling;
          }

          if (el.$el[0].closest('.js--izhs-wrapper-categories').classList.contains('active')) {
            const container = document.querySelector('.js--container-block-info')
            const data = element.querySelector('.js--categories-preview').getAttribute('data-material');
            const array_material = document.querySelectorAll('.js--block-info')
            const info_block = document.querySelectorAll('.js--categories-preview')
            for(let i=0;i<info_block.length;i++){
              info_block[i].classList.remove('active')
            }
            for(let i=0;i<array_material.length;i++){
              array_material[i].classList.remove('active')
            }

            const promice = new Promise((resolve,reject)=> {
              element.querySelector('.js--categories-preview').classList.add('active');
              element.querySelector('.js--categories-preview').closest('.js--izhs-wrapper-categories').classList.add('active');
              element.querySelector('.js--categories-preview').closest('.js--izhs-wrapper-categories')
              container.style.overflow='hidden';
              const height_elem =  container.querySelector('.js--block-info[data-material="' + data + '"]').clientHeight
              container.querySelector('.js--block-info[data-material="' + data + '"]').classList.add('active');
              const wrap = container.querySelector('.js--block-info[data-material="' + data + '"]')
              wrap.querySelector('.js--info-block-close').style.pointerEvents='none'
              resolve(height_elem)
            }).then((height_elem)=>{
              return new Promise((resolve,reject)=> {
                setTimeout(()=>{
                  container.style.height=`${height_elem}px`
                  resolve()
                },100)

              })
            }).then(()=>{
              return new Promise((resolve,reject)=> {
                setTimeout(()=>{
                  container.style.overflow='visible';
                  resolve()
                },600)
              })
            }).then(()=>{

              return new Promise((resolve, reject) => {
                const wrap = container.querySelector('.js--block-info[data-material="' + data + '"]');
                wrap.querySelector('.js--info-block-close').style.pointerEvents = 'auto';
                resolve();
              });
            })
          }
        }
      },
      slidePrevTransitionEnd:(el)=>{
        count===0
        const element_parent = el.$el[0].querySelector('.izhs__categories-preview.active')
        if(element_parent){
          let element;
          if(element_parent.closest('.js--izhs-wrapper-categories').classList.contains('active_additional')){
            element = element_parent.closest('.swiper-slide');
          }
          else {
            element = element_parent.closest('.swiper-slide').previousElementSibling;
          }

          if (el.$el[0].closest('.js--izhs-wrapper-categories').classList.contains('active')) {
            const container = document.querySelector('.js--container-block-info')
            const data = element.querySelector('.js--categories-preview').getAttribute('data-material');
            const array_material = document.querySelectorAll('.js--block-info')
            const info_block = document.querySelectorAll('.js--categories-preview')
            for(let i=0;i<info_block.length;i++){
              info_block[i].classList.remove('active')
            }
            for(let i=0;i<array_material.length;i++){
              array_material[i].classList.remove('active')
            }

            const promice = new Promise((resolve,reject)=> {
              element.querySelector('.js--categories-preview').classList.add('active');
              element.querySelector('.js--categories-preview').closest('.js--izhs-wrapper-categories').classList.add('active');
              element.querySelector('.js--categories-preview').closest('.js--izhs-wrapper-categories')
              container.style.overflow='hidden';
              const height_elem =  container.querySelector('.js--block-info[data-material="' + data + '"]').clientHeight
              container.querySelector('.js--block-info[data-material="' + data + '"]').classList.add('active');
              const wrap = container.querySelector('.js--block-info[data-material="' + data + '"]')
              wrap.querySelector('.js--info-block-close').style.pointerEvents='none'
              resolve(height_elem)
            }).then((height_elem)=>{
              return new Promise((resolve,reject)=> {
                setTimeout(()=>{
                  container.style.height=`${height_elem}px`
                  resolve()
                },100)

              })
            }).then(()=>{
              return new Promise(function (resolve,reject) {
                setTimeout(()=>{
                  container.style.overflow='visible';
                  resolve()
                },600)
              })
            }).then(()=>{
              return new Promise((resolve, reject) => {
                const wrap = container.querySelector('.js--block-info[data-material="' + data + '"]');
                wrap.querySelector('.js--info-block-close').style.pointerEvents = 'auto';
                resolve();
              });
            })
          }
        }
      }
    }
  });
}
function changeWindow(){
  const parent = document.querySelector('.js--container-block-info')
  if(parent){
    const child = parent.querySelector('.js--block-info.active')
    if(child&&parent&&parent.classList.contains('active')){
      const promice = new Promise(function (resolve,reject) {
        const array_body = child.querySelectorAll('.js-accordion-body')
        for(let item of array_body){
          if(item.closest('.js-accordion-parent').classList.contains('active')){
            item.setAttribute('style', `height:${item.scrollHeight}px;`);
          }
        }
        resolve()
      }).then(()=>{
        return new Promise(function (resolve,reject) {
          setTimeout(()=>{
            const height_child = child.clientHeight
            parent.style.height=`${height_child}px`
            resolve()
          },500)
        })
      })
        .then(()=>{
          return new Promise(function (resolve,reject) {
            setTimeout(()=>{
              parent.style.height=`max-content`
              resolve()
            },500)
          })
        })
    }
  }
}
export default function izhsPage() {
  tagsCut();
  tagsDropDownMobile();
  materialDropDown();
  infoBlockClose();
  infoBlockOpen();
  izhsCategoriesSlider();
  // window.addEventListener('resize', changeWindow);
}
