export default function openListInfo() {
  const arrayActiveList = document.querySelectorAll('.block-additional-info__list-wrapper');

  arrayActiveList.forEach((item) => {
    item.addEventListener('click', (e) => {
      const activeList = e.currentTarget;
      const btn = activeList.querySelector('.block-additional-info__list-header-icon');
      const list = activeList.querySelector('.block-additional-info__list-block-hidden');
      btn.classList.toggle('btn-open');
      list.classList.toggle('open');
      });
  });
}
