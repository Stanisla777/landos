/* eslint-disable */
import Vue from 'vue';
import noUiSlider from 'nouislider';
import IMask from 'imask';
import catalogNew from '../catalog-new';
let count_first_child=1
let count_second_child=1
let count = 0;
let count_price = 0;
let mask_array = []
let mask_array_year = []
let mask_array_child = []
let maskOptions = {
  mask: Number,
  thousandsSeparator: ' ',
  min:1,
  max:100000000,
  scale: 0
};
let maskOptions_year = {
  mask: Number,
  max:100,
  min:0,
  scale: 0
};
export default function taxDeductionNew() {
  const app = new Vue({
    el: '#tax-deduction-new',
    data: {
      realtySlider:'',
      realtySlider_2:'',
      dataField: 0,
      dataField_2:0,
      array_year:[],
      selected_year:null,
      placeholder:'Размер выплаты',
      // array_child_first:['Первый'],


      array_child_first:[],
      array_child_first_delete:0,
      array_child_second_delete:0,
      array_child_second:[0],


      array_child_name:['Первый','Второй','Третий','Четвёртый','Пятый','Шестой','Седьмой','Восьмой','Девятый','Десятый','Одиннадцатый','Двенадцатый','Тренадцатый','Четырнадцатый','Пятнадцатый','Шестнадцатый','Семндцатый','Восемнадцатый','Девятнадцатый','Двадцатый'],
      array_kind_working:[ // для селекта выберите сферу вашей деятельности
        {
          name: 'Декоративное искусство',
          ratio: 0.6
        },
        {
          name: 'Другие музыкальные произведения',
          ratio: 0.25
        },
        {
          name: 'Фильмы',
          ratio: 0.3
        },
      ],
      array_personal_information_myself:[// для селекта уточните информацию о себе (на себя)
        {
          name: 'Донор костного мозга',
          ratio: 500
        },
        {
          name: 'Инвалил с детства (I или II группы)',
          ratio: 500
        },
        {
          name: 'Инвалиды в результате военной службы',
          ratio: 3000
        },
        {
          name: 'Инвалиды ВОВ',
          ratio: 3000
        },
        {
          name: 'Участник ВОВ',
          ratio: 500
        },
        {
          name: 'Участники испытаний ядерного оружия',
          ratio: 3000
        },
        {
          name: 'Чернобыльцы',
          ratio: 3000
        },

      ],
      array_personal_information_child:[ // // для селекта уточните информацию о себе (на ребёнка)
        {
          name: 'Родитель',
          ratio: 12000
        },
        {
          name: 'Опекун',
          ratio: 6000
        }
      ],

      stgMin: 0, // Минимальное значение поля стоимости
      stgMinPadding: -2550000, // Минимальное значение поля стоимости
      stgMinPadding_2: -2200000, // Минимальное значение поля стоимости
      stgMax: 10000000, // Максимальное значение поля стоимости


      stgMinPadding_update:-6000000,
      stgMinPadding_2_update:-5250000,

      stgMinPadding_update_2:-9000000,
      stgMinPadding_2_update_2:-7850000,




      stepApartment: 1,
      start:0,
      limit_2023:15600,
      limit_2024:19500,
      limit_2023_child:6500,
      limit_2024_child:14300,
      check_documents_costs:false, //Я могу подтвердить свои расходы документами
      array_child_category:[], // категория ребёнка инвалид или нет
      array_studies_category:[], // категория студент или нет
      ratio_areas_activity:0, // коэффициент сферы деятельности
      information_yourself_child:0, //уточните информацию о себе На ребёнка
      total_calculate:0,
      dataField_deduction:0, //Максимально возможная сумма к возврату
      error_message:false,
      screenWidth : window.innerWidth,
    },
    filters: {
    },
    computed: {

    },
    watch: {
      screenWidth() {
        this.screenWidthSider()
        if (this.screenWidth > 480 && this.error_message === true) {
          document.body.classList.remove('body-modal')
          if (document.querySelector('.js--layer-overlay')) {
            document.querySelector('.js--layer-overlay').classList.remove('active')
          }
        }
        else if (this.screenWidth <= 480 && this.error_message === true) {
          document.body.classList.add('body-modal')
          if (document.querySelector('.js--layer-overlay')) {
            document.querySelector('.js--layer-overlay').classList.add('active')
          }
        }
      },
      error_message() {
        if (this.screenWidth <= 480 && this.error_message === true) {
          document.body.classList.add('body-modal')
          if (document.querySelector('.js--layer-overlay')) {
            document.querySelector('.js--layer-overlay').classList.add('active')
          }

        }
        else if (this.screenWidth <= 480 && this.error_message === false) {
          document.body.classList.remove('body-modal')
          if (document.querySelector('.js--layer-overlay')) {
            document.querySelector('.js--layer-overlay').classList.remove('active')
          }
        }

      },
      dataField() {

        const input_charity = document.querySelector('.js--tax-deduc-row[data-kind="limitatcharity"]')
        if (input_charity) {
          const input = input_charity.querySelector('input')
          const input_val = parseInt(input.value.replace(/\s/g, '')) * 0.13;
          input_charity.querySelector('.js--wr-col-input').classList.remove('active_2')

          if (input.value !== '' && input_val >= parseInt(this.dataField.replace(/\s/g, '')) * 0.25) {
            input_charity.querySelector('.js--result-calc').textContent = (parseInt(this.dataField.replace(/\s/g, '')) * 0.25).toFixed(0).toString()
              .replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
            this.totalCalc();
          }
          if (input.value !== '' && input_val < parseInt(this.dataField.replace(/\s/g, '')) * 0.25) {
            this.incomeSubstitution(input_charity.querySelector('.js--calc-row-input'),input_val)
          }
        }
        const input_investmentdeductions = document.querySelectorAll('.js--tax-deduc-row[data-kind="limitatinvestmentdeductions"]')
        for (let item of input_investmentdeductions) {

          const input = item.querySelector('input')
          const input_val = parseInt(input.value.replace(/\s/g, '')) * 0.13;
          let value_val = parseInt(input.value.replace(/\s/g, ''));
          item.querySelector('.js--wr-col-input').classList.remove('active_2')
          if (parseInt(this.dataField.replace(/\s/g, '')) *0.13 < 52000 && value_val*0.13>=parseInt(this.dataField.replace(/\s/g, '')) *0.13) {
            item.querySelector('.js--result-calc').textContent = (parseInt(this.dataField.replace(/\s/g, '')) *0.13).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
            this.totalCalc();
          }
          else if (parseInt(this.dataField.replace(/\s/g, '')) *0.13 < 52000 && value_val * 0.13<parseInt(this.dataField.replace(/\s/g, '')) *0.13) {
            item.querySelector('.js--result-calc').textContent = (value_val * 0.13).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
            this.totalCalc();
          }
          else if (parseInt(this.dataField.replace(/\s/g, '')) *0.13 >= 52000 && value_val *0.13>=52000) {
            item.querySelector('.js--result-calc').textContent = (52000).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
            this.totalCalc();
          }
          else{
            if(input.value !== ''){
              this.incomeSubstitution(item.querySelector('.js--calc-row-input'),input_val)
            }
          }
        }
        if (this.dataField!=='') {
          this.dataField_deduction = (parseInt(this.dataField.replace(/\s/g, '')) *0.13).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        }
        else {
          this.dataField_deduction=0
        }
        this.errorMessage()
      },
      ratio_areas_activity() {
        const element_value = (this.$refs.areasActivityIncome.value).replace(/\s/g, '')
        this.fieldCalculationAreasActivityIncomeGeneral(element_value)
      },
      check_documents_costs(){
        const parent = document.querySelector('.js--calc-row-input-profy')
        if (this.check_documents_costs===false) {
          const element_value = (this.$refs.areasActivityIncome.value).replace(/\s/g, '')
          this.fieldCalculationAreasActivityIncomeGeneral(element_value)
        }
        else {
          const element = this.$refs.InputAreasActivityExpenses
          const parent = this.$refs.InputAreasActivityExpenses.closest('.js--calc-row-input')

          this.fieldCalculationAreasActivityExpensesGeneral(element,parent)

        }
      },
      array_child_category(){
        this.methodsWatchCheckChild()
      },
      array_studies_category(){
        this.methodsWatchCheckChild()
      },
      information_yourself_child() {
        const array_input = document.querySelectorAll('.js--tax-deduc-row[data-kind="childdeductions"]')
        for(let item of array_input) {
          let element = item.querySelector('input')
          let data = parseInt(element.getAttribute('data-index'))
          this.calcStandardDeductionsChild(item,element,data)
          if (item.querySelector('.js--tex-deduc-input').value!=='' && item.querySelector('.js--category-checkbox') && item.querySelector('.js--category-checkbox').checked) {
          }
        }
      },
      //сдедит изменился ли массив с количеством детей в Стандартные вычеты На детей
      array_child_second() {
        const array_input = document.querySelectorAll('.js--tax-deduc-row[data-kind="childdeductions"]')
        for(let item of array_input) {
          let element = item.querySelector('input')
          let data = parseInt(element.getAttribute('data-index'))
          this.calcStandardDeductionsChild(item,element,data)
        }
      }
    },

    methods: {
      //метод для watch оторый вызывается при смене в Стандартные вычеты На ребенка чекбоксов Ребенок инвалид и Студент
      methodsWatchCheckChild(){
        const array_input = document.querySelectorAll('.js--tax-deduc-row[data-kind="childdeductions"]')
        for(let item of array_input) {
          let element = item.querySelector('input')
          let data = parseInt(element.getAttribute('data-index'))
          this.calcStandardDeductionsChild(item,element,data)
        }
      },
      updateScreenWidth() {
        this.screenWidth = window.innerWidth;
      },
      calcStandardDeductionsChildInput(){
        const array_input = document.querySelectorAll('.js--tax-deduc-row[data-kind="childdeductions"]')
        for(let item of array_input) {
          let element = item.querySelector('input')
          let data = parseInt(element.getAttribute('data-index'))
          this.calcStandardDeductionsChild(item,element,data)
        }
      },
      totalCalc(){
        const array_input = document.querySelectorAll('.js--wr-col-input.active');
        let result = 0;
        for (let item of array_input) {
          if (item.querySelector('.js--result-calc')) {
            result += parseInt(item.querySelector('.js--result-calc').textContent.replace(/\s/g, ''))
            if (!isNaN(result)){
              this.total_calculate = result.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
            }

          }
        }
        if (array_input.length === 0) {
          this.total_calculate = 0
        }
        this.errorMessage()

      },
      closeErrorMessage() {
        this.error_message=false
      },
      errorMessage() {
        if(parseInt(this.dataField_deduction)!==0&&parseInt(this.total_calculate)!==0){
          if (parseInt(this.total_calculate.replace(/\s/g, ''))>parseInt(this.dataField_deduction.replace(/\s/g, ''))) {
            this.error_message=true
          }
          else {
            this.error_message=false
          }
        }
        else if(parseInt(this.dataField_deduction)===0 && parseInt(this.total_calculate)!==0){
          this.error_message=true
        }
        else if(parseInt(this.dataField_deduction)===0 && parseInt(this.total_calculate)===0){
          this.error_message=false
        }

      },
      //метод для расчёта в блоке Стандартные вычеты На ребенка
      calcStandardDeductionsChild(parent,element,data) {
        let coefficient = parent.getAttribute('data-yourself')
        coefficient = parseInt(coefficient)
        const checkbox_el = parent.querySelector('.js--studies-checkbox')
        const checkbox_el_category = parent.querySelector('.js--category-checkbox')
        const array_input = this.$refs.ChildParent.querySelectorAll('.js--tax-deduc-row[data-kind="childdeductions"] .js--tex-deduc-input input.active')
        const foundNumber = this.array_child_category.find((element) => element === data);
        if ((parseInt(element.value) < 18 && !checkbox_el.checked) || (parseInt(element.value) > 0&&parseInt(element.value) <= 23 && checkbox_el.checked)) {

          if (checkbox_el_category.checked){
            parent.querySelector('.js--result-calc').textContent = (coefficient * 0.13 * 12).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
          }

          if (checkbox_el_category.checked && coefficient===0){
            parent.querySelector('.js--wr-col-input').classList.add('active_2')
            parent.querySelector('.js--result-calc').textContent = "Уточните информацию о себе"
          }
          if(checkbox_el_category.checked && coefficient!==0) {
            parent.querySelector('.js--wr-col-input').classList.remove('active_2')
          }

          if (!checkbox_el_category.checked){
            parent.querySelector('.js--wr-col-input').classList.remove('active_2')
            if(array_input.length < 3 || this.array_child_second.length <3 ) {
              console.log(1);
              parent.querySelector('.js--result-calc').textContent = (1400 * 0.13 * 12).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
            }

            else if (array_input.length >=3) {
              console.log(2);
              parent.querySelector('.js--result-calc').textContent = (3000 * 0.13 * 12).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
            }

          }

        }
        if (!checkbox_el_category.checked&& parseInt(element.value) >= 18 && !checkbox_el.checked) {
          parent.querySelector('.js--result-calc').textContent = 0
        }
        if (checkbox_el_category.checked && parseInt(element.value) >= 18 && !checkbox_el.checked){

          parent.querySelector('.js--result-calc').textContent = 0
        }

        if (parent.querySelector('.js--wr-col-input') && !parent.querySelector('.js--wr-col-input').classList.contains('active_2')){
          setTimeout(()=>{
            this.totalCalc();
          },200)
        }
      },

      //Профессиональные вычеты Расходы
      fieldCalculationAreasActivityExpensesGeneral(element,parent){
        if (element.value.length > 0) {
          if (parent.querySelector('.js--wr-col-input')) {
            parent.querySelector('.js--wr-col-input').classList.add('active')
          }
          parent.querySelector('.js--result-calc').textContent = (parseInt(element.value.replace(/\s/g, '')) * 0.13).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        }
        else {
          if (parent.querySelector('.js--wr-col-input')) {
            parent.querySelector('.js--wr-col-input').classList.remove('active')
          }
          parent.querySelector('.js--result-calc').textContent = this.placeholder
        }
        this.totalCalc()
      },
      fieldCalculationAreasActivityExpenses(e){
        const element = e.currentTarget;
        const parent = element.closest('.js--calc-row-input')
        if (parent) {
          if (element.value.length > 0) {
            parent.querySelector('.js--clear-calc-tax').classList.add('active')
          }
          else {
            parent.querySelector('.js--clear-calc-tax').classList.remove('active')
          }
          if (this.check_documents_costs === true) {
            this.fieldCalculationAreasActivityExpensesGeneral(element,parent)

          }
        }
      },

      //Профессиональные вычеты Доходы
      fieldCalculationAreasActivityIncomeGeneral(value_inp) {
        const parent = document.querySelector('.js--tax-deduc-container-row');
        if (parent) {
          if (this.check_documents_costs === false) {
            if (value_inp !== '' && this.ratio_areas_activity!==0) {
              if (parent.querySelector('.js--wr-col-input')) {
                parent.querySelector('.js--wr-col-input').classList.add('active')
              }
              parent.querySelector('.js--result-calc').textContent = (value_inp * 0.13 * this.ratio_areas_activity).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
              this.totalCalc()
            }
            else {
              if (parent.querySelector('.js--wr-col-input')) {
                parent.querySelector('.js--wr-col-input').classList.remove('active')
              }
              parent.querySelector('.js--result-calc').textContent = this.placeholder
              this.totalCalc()
            }
          }
        }
      },
      fieldCalculationAreasActivityIncome(e) {
        const element = e.currentTarget;
        const element_value = (this.$refs.areasActivityIncome.value).replace(/\s/g, '')

        const parent = element.closest('.js--calc-row-input')
        if (parent) {
          if (element.value.length > 0) {
            parent.querySelector('.js--clear-calc-tax').classList.add('active')
          }
          else {
            parent.querySelector('.js--clear-calc-tax').classList.remove('active')
          }
          if (this.check_documents_costs === false) {
            this.fieldCalculationAreasActivityIncomeGeneral(element_value)

          }
        }
      },

      fieldCalculation(e){
        const element = e.currentTarget;
        const main_container = element.closest('.js--tax-deduc-cont-prof')
        const container = element.closest('.js--tax-deduc-row')
        const parent = element.closest('.js--calc-row-input')

        if (element.value.length > 0) {
          element.classList.add('active')
          parent.querySelector('.js--clear-calc-tax').classList.add('active')
        } else {
          element.classList.remove('active')
          parent.querySelector('.js--clear-calc-tax').classList.remove('active')
        }
        if (element.closest('.js--child-parent') && parseInt(element.value) >=18
          && !element.closest('.js--tax-deduc-row').querySelector('.js--studies-checkbox').checked ) {
          element.classList.remove('active')
        }

        if (parent && parent.querySelector('.js--result-calc')) {
          let value = parseInt(element.value.replace(/\s/g, '')) * 0.13;
          let clear_value = parseInt(element.value.replace(/\s/g, ''));
          value = value.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')

          if (element.value.length > 0) {
            if (parent.querySelector('.js--wr-col-input')) {
              parent.querySelector('.js--wr-col-input').classList.add('active')
            }
            if (container && container.hasAttribute('data-kind') && container.getAttribute('data-kind')!=='professionaldeductions') {
              const data = container.getAttribute('data-kind');
              this.calculateField(data,parent,value);
            }

            if(container && !container.hasAttribute('data-kind')) {
              const data = 'none';
              this.calculateField(data,parent,value);
            }
          }
          else {
            parent.querySelector('.js--result-calc').textContent = this.placeholder
            if (parent.querySelector('.js--wr-col-input')) {
              parent.querySelector('.js--wr-col-input').classList.remove('active')
            }
          }
          //подсчёт для поля Стандартные вычеты На ребенка
          if (container && container.hasAttribute('data-kind') && container.getAttribute('data-kind') === 'childdeductions') {
            const data = parseInt(element.getAttribute('data-index'));
            this.calcStandardDeductionsChildInput(parent,element,data)
          }
        }
        if (element.closest('.js--tax-deduc-row')
          && element.closest('.js--tax-deduc-row').classList.contains('js--first-child')
          && element.closest('.js--child-parent')) {
          this.firstChild(element)
        }
      },

      //изменение селекта Выберите количество детей в Стандартные вычеты На ребенка когда в блоке с первым ребёнком меняем какую-либо инфрмацию
      firstChild(element){
        if (element.closest('.js--child-parent').querySelector('.js--select-child .select__substituted-text')&&this.array_child_second.length===1) {
          element.closest('.js--child-parent').querySelector('.js--select-child .select__substituted-text').classList.remove('input-emty')
          element.closest('.js--child-parent').querySelector('.js--select-child .select__substituted-text').textContent='1'
        }

      },
      screenWidthSider() {
        if (this.screenWidth <= 768) {
          this.realtySlider.updateOptions(
            {
              range: {
                min: this.stgMinPadding_update,
                max: this.stgMax
              },
              padding:[Math.abs(this.stgMinPadding_update),0]
            }
          );
          this.realtySlider_2.updateOptions(
            {
              range: {
                min: this.stgMinPadding_2_update,
                max: this.stgMax * 0.87
              },
              padding:[Math.abs(this.stgMinPadding_2_update),0]
            }
          );
        }
        if (this.screenWidth <= 540) {
          this.realtySlider.updateOptions(
            {
              range: {
                min: this.stgMinPadding_update_2,
                max: this.stgMax
              },
              padding:[Math.abs(this.stgMinPadding_update_2),0]
            }
          );
          this.realtySlider_2.updateOptions(
            {
              range: {
                min: this.stgMinPadding_2_update_2,
                max: this.stgMax * 0.87
              },
              padding:[Math.abs(this.stgMinPadding_2_update_2),0]
            }
          );
        }
        if(this.screenWidth > 768){
          this.realtySlider.updateOptions(
            {
              range: {
                min: this.stgMinPadding,
                max: this.stgMax
              },
              padding:[Math.abs(this.stgMinPadding),0]
            }
          );
          this.realtySlider_2.updateOptions(
            {
              range: {
                min: this.stgMinPadding_2,
                max: this.stgMax * 0.87
              },
              padding:[Math.abs(this.stgMinPadding_2),0]
            }
          );
        }
      },
      initRealtySlider() {
        const hoverSlider = document.querySelector('.range-input__wr-toddler');
        this.realtySlider = noUiSlider.create(hoverSlider, {
          start: [this.start],
          connect: 'lower',
          step: this.stepApartment,
          range: {
            min: this.stgMinPadding,
            max: this.stgMax
          },
          padding:[Math.abs(this.stgMinPadding),0]
        });
        this.realtySlider.on('update', (val,handle) => {
          this.dataField = parseInt(val[handle]).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        });
        this.realtySlider.on('end', (val,handle) => {
          this.calculationNDFL(parseInt(val[handle]).toFixed(0));
        });
      },
      initRealtySlider_2() {
        const hoverSlider = document.querySelector('.range-input__wr-toddler_2');
        this.realtySlider_2 = noUiSlider.create(hoverSlider, {
          start: [this.start],
          connect: 'lower',
          step: this.stepApartment,
          // initial: this.stgMin,
          range: {
            min: this.stgMinPadding_2,
            max: this.stgMax * 0.87
          },
          padding:[Math.abs(this.stgMinPadding_2),0]
        });
        this.realtySlider_2.on('update', (val,handle) => {
          this.dataField_2 = parseInt(val[handle]).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        });

        this.realtySlider_2.on('end', (val,handle) => {
          this.amountIncome(parseInt(val[handle]).toFixed(0));
        });
      },
      //смена чекбокса категория ребёнка(инвалид или нет)
      childCategory(e){
        const element = e.currentTarget
        if (element.checked) {
          this.array_child_category.push(parseInt(element.getAttribute('data-index')))
        }
        else {
          this.array_child_category = this.array_child_category.filter((number) => number !== parseInt(element.getAttribute('data-index')));
        }
        if (element.closest('.js--tax-deduc-row')
          && element.closest('.js--tax-deduc-row').classList.contains('js--first-child')
          && element.closest('.js--child-parent')) {
          this.firstChild(element)
        }
      },

      //смена чекбокса категория ребёнка(инвалид или нет)
      studiesCategory(e){
        const element = e.currentTarget
        const parent = element.closest('.js--tax-deduc-row')
        if (element.checked) {
          this.array_studies_category.push(parseInt(element.getAttribute('data-index')))
        }
        else {
          this.array_studies_category = this.array_studies_category.filter((number) => number !== parseInt(element.getAttribute('data-index')));
        }
        if (parent && parent.querySelector('.js--tex-deduc-input input')
          && element.checked && parent.querySelector('.js--tex-deduc-input input').value >=18) {
          parent.querySelector('.js--tex-deduc-input input').classList.add('active')
        }
        else {
          parent.querySelector('.js--tex-deduc-input input').classList.remove('active')
        }
        if (element.closest('.js--tax-deduc-row')
          && element.closest('.js--tax-deduc-row').classList.contains('js--first-child')
          && element.closest('.js--child-parent')) {
          this.firstChild(element)
        }
      },

      //что выбрал пользователь в поле селект Уточните информация о себе На ребёнка
      informationYourselfChild(e){
        const element = e.currentTarget
        if (element.closest('.js--tax-deduc-row[data-kind="childdeductions"]') &&  element.closest('.js--tax-deduc-row[data-kind="childdeductions"]').hasAttribute('data-yourself')){
          element.closest('.js--tax-deduc-row[data-kind="childdeductions"]').setAttribute('data-yourself',parseInt(element.getAttribute('data-ratio')))
        }
        if (this.information_yourself_child === 0) {
          this.information_yourself_child = 1
        }
        else {
          this.information_yourself_child = 0
        }

        if (element.closest('.js--tax-deduc-row')
          && element.closest('.js--tax-deduc-row').classList.contains('js--first-child')
          && element.closest('.js--child-parent')) {
          this.firstChild(element)
        }

      },
      //добавить детей при клике в секте Уточните информация о себе На ребёнка
      addChildSelect(e) {
        const element = e.currentTarget
        const data = parseInt(element.getAttribute('data-ratio'))

        const array_block = document.querySelectorAll('.js--tax-deduc-child-second')
        for (let i=0;i<array_block.length;i++){
          if (i>=data && data<array_block.length){
            array_block[i].remove()
          }
        }
        if (data>array_block.length) {
          for (let i=0;i<(data - array_block.length);i++){
            this.array_child_second.push(count_second_child)
            count_second_child+=1
          }
        }
        this.counSecondChild()
        this.recalculationNumberChildren()
      },
      //расчёт стандартных вычетов на себя при выборе селекта Стандартные вычеты На ребенка
      calculationAmountPayment(e) {
        const element = e.currentTarget
        const ratio = parseFloat(element.getAttribute('data-ratio'))
        const parent = element.closest('.js--tax-deduc-row')
        if (parent) {
          const final_field = parent.querySelector('.js--result-calc')
          if (final_field && final_field.closest('.js--wr-col-input')) {
            final_field.textContent = (ratio * 12 * 0.13).toFixed(0).toString()
              .replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
            final_field.closest('.js--wr-col-input').classList.add('active')
          }
        }
        this.totalCalc();
      },
      coefficientAreasActivity(e) {
        const element = e.currentTarget
        this.ratio_areas_activity = parseFloat(element.getAttribute('data-ratio'))
      },
      changeCheckboxDocuments(e){
        const element = e.currentTarget
        if (element.checked) {
          this.check_documents_costs=true
        } else {this.check_documents_costs=false}
      },
      selectedYear(e){
        const element = e.currentTarget
        this.selected_year=parseInt(element.getAttribute('for-year'))
        this.recalculationFields();
        this.totalCalc();
        const parent = element.closest('.js--select')
        if (parent && parent.classList.contains('open') && parent.querySelector('.js--openlist-background')) {
          element.closest('.js--select').classList.remove('open')
          parent.querySelector('.js--openlist-background').style.display='none'
        }

      },
      recalculationFields() {
        const array_field = document.querySelectorAll('.js--tax-deduc-row[data-kind="limitat"]')
        for (let item of array_field){
          const input = item.querySelector('input')
          const input_val = parseInt(input.value.replace(/\s/g, '')) * 0.13;
          if (input.value !== '' && this.selected_year <= 2023 && input_val >= this.limit_2023) {
            item.querySelector('.js--result-calc').textContent = parseInt(this.limit_2023)
              .toFixed(0).toString()
              .replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
          }
          else if (input.value !== '' && this.selected_year <= 2023 && input_val < this.limit_2023) {
            item.querySelector('.js--result-calc').textContent = input_val
              .toFixed(0).toString()
              .replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
          }
          if (input.value !== '' && this.selected_year >= 2024 && input_val >= this.limit_2024) {
            item.querySelector('.js--result-calc').textContent = parseInt(this.limit_2024)
              .toFixed(0).toString()
              .replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
          }
          else if (input.value !== '' && this.selected_year >= 2024 && input_val < this.limit_2024) {
            item.querySelector('.js--result-calc').textContent = input_val
              .toFixed(0).toString()
              .replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
          }
        }
        const array_field_child = document.querySelectorAll('.js--tax-deduc-row[data-kind="limitatchild"]')
        for (let item of array_field_child){
          const input = item.querySelector('input')
          const input_val = parseInt(input.value.replace(/\s/g, '')) * 0.13;
          if (input.value !== '' && this.selected_year <= 2023 && input_val >= this.limit_2023_child) {
            item.querySelector('.js--result-calc').textContent = parseInt(this.limit_2023_child)
              .toFixed(0).toString()
              .replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
          }
          if (input.value !== '' && this.selected_year >= 2024 && input_val >= this.limit_2024_child) {
            item.querySelector('.js--result-calc').textContent = parseInt(this.limit_2024_child)
              .toFixed(0).toString()
              .replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
          }
        }
      },
      amountIncome(val){
        this.dataField = parseInt(val / 0.87).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        this.realtySlider.set(val / 0.87);
      },
      calculationNDFL(val){
        this.dataField_2 = parseInt(val * 0.87).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        this.realtySlider_2.set(val * 0.87);
      },
      calculateField(data,parent,value){

        let value_val = parseInt(value.replace(/\s/g, ''))
        if (data === 'limitat') {

          if (this.selected_year <= 2023 && value_val >=this.limit_2023) {

            value_val = this.limit_2023
          }
          if (this.selected_year >= 2024 && value_val >=this.limit_2024) {

            value_val = this.limit_2024
          }
          this.incomeSubstitution(parent,value_val)
        }
        else if (data === 'limitatinvestmentdeductions') {
          if(parseInt(this.dataField.replace(/\s/g, '')) === 0 && parent.querySelector('.js--result-calc')) {
            parent.querySelector('.js--result-calc').textContent = 'Укажите доход'
            parent.querySelector('.js--wr-col-input').classList.add('active_2')
          }
          else {
            parent.querySelector('.js--wr-col-input').classList.remove('active_2')
          }

          if (parseInt(this.dataField.replace(/\s/g, '')) *0.13 < 52000 && value_val>=parseInt(this.dataField.replace(/\s/g, '')) *0.13) {
            value_val = parseInt(this.dataField.replace(/\s/g, '')) *0.13
          }
          else if (parseInt(this.dataField.replace(/\s/g, '')) *0.13 >= 52000 && value_val>=52000) {
            value_val = 52000
          }
          if (parseInt(this.dataField.replace(/\s/g, '')) !== 0) {
            this.incomeSubstitution(parent,value_val)
          }
        }
        else if (data === 'limitatchild') {
          if (this.selected_year <= 2023 && value_val >=this.limit_2023_child) {
            value_val = this.limit_2023_child
          }
          if (this.selected_year >= 2024 && value_val >=this.limit_2024_child) {
            value_val = this.limit_2024_child
          }
          this.incomeSubstitution(parent,value_val)
        }
        else if (data === 'limitatcharity') {
          if(parseInt(this.dataField.replace(/\s/g, '')) === 0 && parent.querySelector('.js--result-calc')) {
            parent.querySelector('.js--result-calc').textContent = 'Укажите доход'
            parent.querySelector('.js--wr-col-input').classList.add('active_2')
          }
          else {
            parent.querySelector('.js--wr-col-input').classList.remove('active_2')
          }

          if (parseInt(this.dataField.replace(/\s/g, '')) !== 0 &&value_val >= parseInt(this.dataField.replace(/\s/g, '')) * 0.25) {
            value_val = parseInt(this.dataField.replace(/\s/g, '')) * 0.25
          }
          if (parseInt(this.dataField.replace(/\s/g, '')) !== 0) {
            this.incomeSubstitution(parent,value_val)
          }
        }
        else if (data === 'limitathousingcost') {
          if (value_val >= 260000) {
            value_val = 260000
          }
          this.incomeSubstitution(parent,value_val)
        }
        else if (data === 'limitathousinginterest') {
          if (value_val >= 390000) {
            value_val = 390000
          }
          this.incomeSubstitution(parent,value_val)
        }
        else if (!parent.closest('.js--tax-deduc-row').hasAttribute('data-kind')) {
          parent.querySelector('.js--result-calc').textContent = value
          this.totalCalc();
        }
      },
      //в поле подставляю результат расчётов
      incomeSubstitution (parent,value_val) {
        if (parent.querySelector('.js--result-calc')) {
          parent.querySelector('.js--result-calc').textContent = value_val.toFixed(0)
            .toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
          this.totalCalc(value_val);
        }
      },
      fieldInput(e){
      },
      inputCost(){
        mask_array=[]
        const input_status = document.querySelectorAll('.js--number-debt input');
        for (let i=0; i<input_status.length;i++) {
          mask_array.push(IMask(input_status[i], maskOptions));
        }
      },
      inputCostChild(){
        mask_array_child=[]
        const input_status = document.querySelectorAll('.js--number-child input');
        for (let i=0; i<input_status.length;i++) {
          mask_array_child.push(IMask(input_status[i], maskOptions));
        }
      },
      inputCostNumber(){
        // mask_array_year=[]
        // const input_status = document.querySelectorAll('.js--number-simply input');
        // for (let i=0; i<input_status.length;i++) {
        //   mask_array_year.push(IMask(input_status[i], maskOptions_year));
        // }
      },
      inputFieldChild(e){
        const element = e.currentTarget
        element.value = element.value.replace(/[^\d]/g, '');
        if (element.closest('.js--child-parent') && parseInt(element.value)>25){
          element.value=25
        }
      },
      keyUpRange(e) {
        const element = e.currentTarget
        if(element.value!==''&&(parseInt(element.value.replace(/\s/g, ''))>=this.stgMin)&&parseInt(element.value.replace(/\s/g, ''))<=this.stgMax){
          this.realtySlider.set(parseInt(element.value.replace(/\s/g, '')));
        }
        else if(parseInt(element.value.replace(/\s/g, ''))>this.stgMax)  {
          this.realtySlider.set(this.stgMax);
        }
        if(parseInt(element.value.replace(/\s/g, ''))>=this.stgMax){
          this.dataField = this.stgMax.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        }
        if(parseInt(element.value.replace(/\s/g, ''))!==NaN || element.value!=='') {
          this.calculationNDFL(parseInt(element.value.replace(/\s/g, '')))
        }

      },
      keyUpRange_2(e) {
        const element = e.currentTarget
        if(element.value!==''&&(parseInt(element.value.replace(/\s/g, ''))>=this.stgMin)&&parseInt(element.value.replace(/\s/g, ''))<=this.stgMax  * 0.87){
          this.realtySlider_2.set(parseInt(element.value.replace(/\s/g, '')));
        }
        else if(parseInt(element.value.replace(/\s/g, ''))>this.stgMax * 0.87)  {
          this.realtySlider_2.set(this.stgMax * 0.87);
        }
        if(parseInt(element.value.replace(/\s/g, ''))>=this.stgMax * 0.87){
          this.dataField_2 = (this.stgMax * 0.87).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
        }
        this.amountIncome(parseInt(element.value.replace(/\s/g, '')))
      },
      inputFocus(el) {
        const element = el.currentTarget

      },
      focusRange(e){

      },








      inputField(event){

      },
      inputValue(el){

      },
      inputPast(el){
        const element = el.currentTarget;
        let element_val = (el.clipboardData || window.clipboardData).getData('text');
        if ( element_val.search(/[^0-9]/g) != -1 ) {
          el.preventDefault();
        }
      },
      moveAnotherElement(el) {
        const element = el.currentTarget;
        if (element.value==='') {
          element.value = this.stgMin;
          this.realtySlider.set(this.stgMin);
        }
      },
      moveAnotherElement_2(el) {
        const element = el.currentTarget;
        if (element.value==='') {
          element.value = this.stgMin;
          this.realtySlider_2.set(this.stgMin);
          this.realtySlider.set(this.stgMin);
        }
      },

      focusInput(evt){
        const element = evt.currentTarget;
        var theEvent = evt || window.event
        // Handle key press
        var key = theEvent.keyCode || theEvent.which;
        key = String.fromCharCode(key);
        var regex = /[0-9]/;
        if( !regex.test(key) ) {
          theEvent.returnValue = false;
          if(theEvent.preventDefault) theEvent.preventDefault();
        }
      },

      clearInput(e){
        const element = e.currentTarget;
        const parent = element.closest('.js--tex-deduc-input');
        const container = element.closest('.js--calc-row-input');
        const wr_container = element.closest('.js--tax-deduc-container-row');
        if (parent) {
          let data = parent.getAttribute('data-input-index');
          data=parseInt(data)

          if (parent.classList.contains('js--number-debt')){
            mask_array[data].value='';
          }
          else if (parent.classList.contains('js--number-simply')){
            for(let i = 0;i<mask_array_year.length;i++){
              let data_mask = mask_array_year[i].el.input.closest('.js--tex-deduc-input')
                .getAttribute('data-input-index')
              data_mask = parseInt(data_mask)
              if (data_mask ===data) {
                mask_array_year[i].value=''
              }
            }
          }
          else if (parent.classList.contains('js--number-child')){
            for(let i = 0;i<mask_array_child.length;i++){
              let data_mask = mask_array_child[i].el.input.closest('.js--tex-deduc-input')
                .getAttribute('data-input-index')
              data_mask = parseInt(data_mask)
              if (data_mask ===data) {
                mask_array_child[i].value=''
              }

            }
          }
          if (container && container.querySelector('.js--result-calc') && container.querySelector('.js--wr-col-input')
            && !element.classList.contains('js--clear-calc-tax-special')
            && !element.classList.contains('js--clear-calc-tax-expenses') ){
            container.querySelector('.js--wr-col-input').classList.remove('active')
            container.querySelector('.js--result-calc').textContent = this.placeholder

          }
          if (element.classList.contains('js--clear-calc-tax-special')
            && element.closest('.js--row-container')
            && wr_container && !wr_container.querySelector('.js--checkbox_wrapper input[type="checkbox"]').checked){
            element.closest('.js--row-container').querySelector('.js--wr-col-input').classList.remove('active')
            element.closest('.js--row-container').querySelector('.js--result-calc').textContent = this.placeholder
          }
          if (element.classList.contains('js--clear-calc-tax-expenses')
            && element.closest('.js--row-container')
            && wr_container && wr_container.querySelector('.js--checkbox_wrapper input[type="checkbox"]').checked){

            element.closest('.js--row-container').querySelector('.js--wr-col-input').classList.remove('active')
            element.closest('.js--row-container').querySelector('.js--result-calc').textContent = this.placeholder
          }
          if (!element.classList.contains('js--clear-calc-tax-special')) {
            parent.querySelector('input').value='';
          }

          parent.querySelector('input').classList.remove('active')
          element.classList.remove('active')
        }
        this.calcStandardDeductionsChildInput()
        this.totalCalc();
      },

      addField() {
        if(this.array_child_first_delete < 20) {
          this.array_child_first.push(count_first_child)
          count_first_child+=1
        }
      },
      removeChild(e){
        const element = e.currentTarget;
        const parent = element.closest('.js--tax-deduc-child-first')
        const parent_second = element.closest('.js--tax-deduc-child-second')
        const parent_child = element.closest('.js--child-parent')
        if (parent){
          parent.remove()
          this.array_child_first_delete-=1
        }
        if (parent_second){
          parent_second.remove()
          this.counSecondChild()

          if (parent_child){
            parent_child.querySelector('.js--select-child .js--openlist-btn p').textContent = this.array_child_second_delete
            parent_child.querySelector('.js--select-child .js--openlist-btn p').classList.remove('input-emty')
            const array_select = parent_child.querySelectorAll('.js--select-child .js--openlist-item')
            for (let item of array_select) {
              item.classList.remove('active')
              if (parseInt(item.getAttribute('data-ratio')) === this.array_child_second_delete) {
                item.classList.add('active')
              }
            }
          }
          this.recalculationNumberChildren()
        }
        this.totalCalc();
      },
      recalculationNumberChildren() {
        const array_input = document.querySelectorAll('.js--tax-deduc-row[data-kind="childdeductions"]')
        for(let item of array_input) {
          let element = item.querySelector('input')
          let data = parseInt(element.getAttribute('data-index'))
          this.calcStandardDeductionsChild(item,element,data)
        }
      },

      // добавление детей стандартные вычеты
      addFieldSecond(e) {
        const element = e.currentTarget;
        const parent = element.closest('.js--child-parent')
        if(this.array_child_second_delete < 20) {
          this.array_child_second.push(count_second_child)
          count_second_child+=1
        }
        if (parent) {
          this.addCountSelect(parent)
        }
      },
      //в селекте подставляю количество детей
      addCountSelect(parent){
        parent.querySelector('.js--select-child .js--openlist-btn p').textContent = this.array_child_second_delete+1
        parent.querySelector('.js--select-child .js--openlist-btn p').classList.remove('input-emty')
        const array_select = parent.querySelectorAll('.js--select-child .js--openlist-item')
        for (let item of array_select) {
          item.classList.remove('active')
          if (parseInt(item.getAttribute('data-ratio')) === this.array_child_second_delete+1) {
            item.classList.add('active')
          }
        }
      },
      dropdownArea(e){
        const element = e.currentTarget;
        const parent = element.closest('.js-accordion-parent-calc');
        if (parent){
          parent.classList.toggle('active')
          if (parent.classList.contains('js-accordion-parent-calc-standard')){
            if(!parent.classList.contains('active_2')) {
              setTimeout(()=>{
                parent.classList.add('active_2')
              },700)
            }
            else{
              parent.classList.remove('active_2')
            }
          }

        }
      },

      //задаю блокам с .js--number-debt data-input-index
      dataInputIndex(){
        const array_input=document.querySelectorAll('.js--number-debt')
        for (let i=0;i<array_input.length;i++){
          array_input[i].setAttribute('data-input-index',i)
        }
      },

      counSecondChild() {
        this.array_child_second_delete = document.querySelectorAll('.js--tax-deduc-child-second').length;
      }
    },
    updated(){
      if(this.array_child_second.length>count){
        catalogNew();
        count+=1
      }

      this.counSecondChild()
      this.inputCostNumber()
      if(this.array_child_first.length>count_price){
        this.array_child_first_delete+=1
        count_price+=1
        this.inputCostChild();
      }
    },
    mounted() {
      this.initRealtySlider()
      this.initRealtySlider_2()
      setTimeout(()=>{
        this.screenWidthSider()
      },500)
      this.inputCost();
      this.inputCostChild();
      catalogNew();
      window.addEventListener('resize', this.updateScreenWidth);
      const this_year = new Date().getFullYear()
      this.selected_year = this_year - 1
      let year = this_year
      this.array_year.push(year)
      for (let i = 0;i <= 2;i++) {
        year-=1
        this.array_year.push(year)
      }
      this.dataInputIndex()
      setTimeout(()=>{
        this.$refs.BtnChildFirst.click()
      },500)
    },

  });
}
