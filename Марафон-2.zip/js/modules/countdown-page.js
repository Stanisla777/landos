/* eslint-disable */
export default function countdownPage(counter) {
  let obratniyOtschet;
  const coundown = document.querySelector('.js--coundown-page');
  if(coundown){
    let time;
    if (coundown.hasAttribute('data-time')) {
      time = coundown.getAttribute('data-time')
    }
    else {
      if(counter!==undefined) {
        time =counter
      } else {
        time=0
      }

    }

    time = parseInt(time)
    let kolichestvoMinut = time/60;  // желаемое время таймера в минутах (5 минут)
    let tekuscheyeVremya = new Date(); // получаем сегодняшнюю дату и время
    // let deadlineTime = tekuscheyeVremya.setMinutes(tekuscheyeVremya.getMinutes() + 5); // устанавливаем таймер на 5 минут
    let deadlineTime = new Date( new Date().getTime() + (kolichestvoMinut * 60 * 1000) ); // можно и так установить таймер на 5 минут
    // обновляем скрипт каждую секунду - так мы получаем обратный отсчет
    obratniyOtschet = setInterval(()=> {
      let seychas = new Date().getTime(); // текущее время
      let ostatokVremeni = deadlineTime - seychas; // находим различие между текущим моментом и временем дедлайна
      // преобразовываем значение миллисекунд в минуты и секунды
      let hour = Math.floor( (ostatokVremeni % (1000 * 60 * 60 * 60)) / (1000 * 60 *60) );
      let minuti = Math.floor( (ostatokVremeni % (1000 * 60 * 60)) / (1000 * 60) );
      let secundi = Math.floor( (ostatokVremeni % (1000 * 60)) / 1000 );
      // если значение текущей минуты или секунды меньше 10, добавляем вначале ведущий ноль
      hour = hour < 10 ? "0" +  hour : hour;
      minuti = minuti < 10 ? "0" +  minuti : minuti;
      secundi = secundi < 10 ? "0" + secundi : secundi;
      // отображаем результат таймера в элементе с id="deadline-timer"
      coundown.querySelector('.js--hour').textContent = hour;
      coundown.querySelector('.js--minutes').textContent = minuti;
      coundown.querySelector('.js--seconds').textContent = secundi;
      // если в таймере остались только секунды, меняем слово "минуты" на "секунды"

      // когда обратный отсчет закончился, отображаем соответствующее уведомление
      if (ostatokVremeni <= 0) {
        clearInterval(obratniyOtschet);
        coundown.querySelector('.js--hour').textContent = '00';
        coundown.querySelector('.js--minutes').textContent = '00';
        coundown.querySelector('.js--seconds').textContent = '00';
      }
    }, 1000);
  }
}
