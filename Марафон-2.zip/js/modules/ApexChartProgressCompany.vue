<template lang="pug">
  div(
    ref="apexChart"
  )
    apexcharts(width='75%' :options='chartOptions' :series='chartSeries')
</template>

<script>
const VueApexCharts = () => import ("vue-apexcharts");

export default {
  name: 'ApexChartProgressCompany',
  data() {
    return {
      chartSeries:null,
      chartOptions: {
        chart: {
          // width: '75%',
          type: 'pie',
          animations:{
            enabled: false,
          },
          // offsetX: -26
        },
        states: {
          normal: {
            filter: {
              type: 'none',
              value: 0,
            }
          },
          click:{
            filter: {
              type: 'none',
              value: 0,
            }
          },
          hover: {
            filter: {
              type: 'none',
              value: 0,
            }
          },
          active: {
            allowMultipleDataPointsSelection: false,
            filter: {
              type: 'none',
              value: 0,
            }
          },
        },
        dataLabels:{
          enabled: false,
        },
        labels: ['Мобильные', 'ПК'],
        fill: {
          colors: ['#A3D562', '#FFC9B5']
        },
        legend:{
          show: false,
          position: 'right',
          horizontalAlign:'right',
          fontSize: '14px',
          fontFamily: 'Gilroy-Medium,sans-serif',
          formatter: function(seriesName, opts) {
            // return [opts.w.globals.series[opts.seriesIndex],'%','<br>','<i>',seriesName,'</i>']
            // const legend = document.querySelector('.schedule-circle-legend')
            // console.log(legend);
          },
          offsetX:5,
          offsetY:-18,
          labels: {
            // colors: ['#A3D562', '#FFC9B5'],
            // useSeriesColors: true
          },
          markers:{
            width: 0,
            height: 0,
          },
          onItemClick: {
            toggleDataSeries: false
          },
          onItemHover: {
            highlightDataSeries: false
          },
          height: 90
        },
        tooltip:{
          enabled: false
        },
        stroke:{
          show: false
        },
        responsive: [{
          breakpoint: 640,
          options: {
            chart: {
              // width: '75%',
              // offsetX: -35
              // height:260
            },
            legend: {
              // position: 'bottom'
            }
          }
        }]
      }

    }
  },
  mounted() {
    const element_chart = this.$refs.apexChart.closest('.js--schedule-circle')
    if(element_chart) {
      let data = element_chart.getAttribute('data-circle-chart')
      this.chartSeries = JSON.parse(data);
    }
  },
  components: {
    apexcharts: VueApexCharts
  }
}
</script>
