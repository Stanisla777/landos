export default function instructionDocuments() {
    const docsBlock = document.querySelector('.js--instruction-documents');
    if (docsBlock) {
        const docsList = docsBlock.querySelector('.instruction-documents__list');
        const docs = docsList.querySelectorAll('.instruction-documents__list-item');
        const openerWrap = docsBlock.querySelector('.instruction-documents__opener-wrap');
        const opener = docsBlock.querySelector('.instruction-documents__opener');
        const fullOpener = docsBlock.querySelector('.instruction-documents__fullopener');
        const fullWrap = docsBlock.querySelector('.instruction-documents__wrapper');
        let contentIsOpen = false;

        if (docs.length < 4) {
            openerWrap.style.display = 'none';
            return;
        }
        let startListLength = 0;
        const windowWidth = document.documentElement.clientWidth;
        const startAmountOfCards = windowWidth > 1243 || windowWidth < 768 ? 3 : 1;

        for (let i = 0; i < startAmountOfCards; i++) {
            startListLength += docs[i].offsetHeight;
        }

        docsList.style.height = `${startListLength}px`;

        const heightContent = docsBlock.querySelector('.instruction-documents__list-wrap')
    .offsetHeight + docsBlock.querySelector('.instruction-documents__opener-wrap').offsetHeight;

        opener.addEventListener('click', () => {
            opener.classList.toggle('active');

            if (!(docsList.classList.contains('show'))) {
                docsList.classList.add('show');
                fullWrap.style.height = 'auto';

                let listHeight = 0;

                if (windowWidth > 1243 || windowWidth < 768) {
                    for (let j = 0; j < docs.length; j++) {
                        listHeight += docs[j].offsetHeight;
                    }
                } else {
                    for (let j = 0; j < docs.length; j++) {
                        if ((j + 1) % 2) {
                            listHeight += docs[j].offsetHeight;
                        }
                    }
                }

                docsList.style.height = `${listHeight}px`;
                setTimeout(() => {
                    fullWrap.style.height = `${fullWrap.offsetHeight}px`;
                }, 500);
                contentIsOpen = true;
            } else {
                docsList.classList.remove('show');
                docsList.style.height = `${startListLength}px`;

                contentIsOpen = false;
                fullWrap.style.height = `${heightContent}px`;
            }
        });

        if (windowWidth > 1243 || windowWidth < 768) {
            window.addEventListener('scroll', () => {
                if (!(contentIsOpen)) {
                    if (docsBlock.getBoundingClientRect().top <= 20) {
                        fullWrap.style.height = '0px';
                        fullOpener.classList.add('active');
                    }
                }
            });
        }

        fullWrap.style.height = `${heightContent}px`;

        fullOpener.addEventListener('click', () => {
            fullWrap.style.height = `${heightContent}px`;
            fullOpener.classList.remove('active');
        });
    }
}
