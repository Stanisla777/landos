<script>
import Vue from 'vue';
import Vuex from 'vuex';


Vue.use(Vuex);

export default new Vuex.Store({
  state:{
    state_bunner:true
  },
  getters:{

    STATEBUNNER(state){
      return state.state_bunner
    },




  },
  mutations:{

    mutationStateBunner(state,received_perem){
      state.state_bunner=received_perem
    },




  },
  actions:{
    //Время закончилось активировать кнопку Следующий вопрос
    ActionStateBunner({commit,state},param){
      commit('mutationStateBunner',param)
    },
  },
})
</script>
