/* eslint-disable */
import Vue from 'vue';
import state from '../marathon-2024-test/development-tools/state.vue'
import Storage from './development-tools/state.vue';

export default function marathon2024TestInn() {
  const app = new Vue({
    el: '#marathon-new-last--wr-countdown',
    data: {
      nick_name:'',
      state_button:null,
      // state_bunner:true

    },
    methods: {
      modals(e) {
        const element = e.currentTarget
        const modalWindows = document.querySelectorAll('.modal');
        const modalOpeners = document.querySelectorAll('.js--modal-opener');
        const modalOpenersOnLanding = document.querySelectorAll("[href$='modalcall']");
          if (document.querySelector(element.dataset.modal)) {
            document.querySelector(element.dataset.modal).classList.add('open');
            document.body.classList.add('modal-opened');
            // eslint-disable-next-line no-unused-vars
            document.body.classList.add('body-modal');
          }


        for (let i = 0; i < modalOpenersOnLanding.length; i++) {
          modalOpenersOnLanding[i].addEventListener('click', (e) => {
            e.stopPropagation();
            e.preventDefault();
            if (modalOpenersOnLanding[i].getAttribute('data-program')) {
              document.querySelector('label.prog input').value = modalOpeners[i].getAttribute('data-program');
            }
            document.querySelector('#modalcall').classList.add('open');
            document.body.classList.add('modal-opened');
            return false;
          });
        }
        for (let j = 0; j < modalWindows.length; j++) {
          // eslint-disable-next-line func-names
          const modalWindowCloser = modalWindows[j].querySelectorAll('.js--modal-closer');
          // if (modalWindowCloser) {
          //     modalWindowCloser.onclick = function () {
          //     closeModal(modalWindows[j].id);
          //   };
          // }
          // eslint-disable-next-line no-restricted-syntax
          for (const item of modalWindowCloser) {
            // eslint-disable-next-line func-names
            item.onclick = function () {
              closeModal(modalWindows[j].id);
            };
          }
          const modalWindowWrapper = modalWindows[j].querySelector('.modal__wrapper');
          if (modalWindowWrapper) {
            modalWindowWrapper.onclick = function (w) {
              w.stopPropagation();
            };
          }
          modalWindows[j].onclick = function () {
            // if (e.target.closest('.js--modal-closer')) {
            //       closeModal(modalWindows[j].id);
            //   }
            closeModal(modalWindows[j].id);
          };
        }
      },
      callTest(e) {
        state.state.data_open=1
        state.state.nickname=this.nick_name
        // this.state_bunner = false
        Storage.dispatch('ActionStateBunner',false)
      }
    },
    filters: {

    },
    computed: {
      state_bunner(){
        return Storage.getters.STATEBUNNER
      },

    },
    watch: {

    },
    mounted() {
      if (this.$refs.TestButton!==undefined){
        if (this.$refs.TestButton.hasAttribute('data-state-button')) {

          if (parseInt(this.$refs.TestButton.getAttribute('data-state-button'))===0) {
            // this.state_bunner=false
            Storage.dispatch('ActionStateBunner',false)
          }
          else {
            // this.state_bunner=true
            Storage.dispatch('ActionStateBunner',true)
          }
        }


        if (this.$refs.TestButton.hasAttribute('data-nickname')) {
          this.nick_name = this.$refs.TestButton.getAttribute('data-nickname');
        }
        if (this.nick_name==='') {
          this.state_button = 0
        }
        else {
          this.state_button = 1
          state.state.nickname=this.nick_name
        }
      }

    },


  });
}
