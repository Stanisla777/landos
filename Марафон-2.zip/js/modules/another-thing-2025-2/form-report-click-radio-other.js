/* eslint-disable */

export default function formReportRadioOther(el) {
  const checkbox_other_items = document.querySelectorAll('.js--feedback-check[data-show-other-option-block]')
  for (let checkbox_other_item of checkbox_other_items) {
    checkbox_other_item.addEventListener('change', function () {
      const field_code = this.getAttribute('data-show-other-option-block')
      if (field_code) {
        const other_option_block = document.querySelector(`.feed_back__block[data-field-code="${field_code}"]`)
        if (other_option_block) {
          if (this.checked) {
            other_option_block.classList.remove('hide')
          } else {
            other_option_block.classList.add('hide')
          }
        }
      }
    })
  }
}
