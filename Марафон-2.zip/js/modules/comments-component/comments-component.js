// eslint-disable-next-line camelcase
function commentsAnswer() {
  // eslint-disable-next-line no-unused-vars,camelcase
  // eslint-disable-next-line no-restricted-syntax
  const buttons = document.querySelectorAll('.comments__item');
  if (buttons) {
    buttons.forEach((item) => {
      if (item.querySelector('.comments__item-button-answer')) {
        item.querySelector('.comments__item-button-answer').addEventListener('click', (e) => {
          e.preventDefault();
          buttons.forEach((element) => {
            if (element.querySelector('.comments__item-button-answer')) {
              if (element.querySelector('.comments__item-form-answer').classList.contains('comments__item-form-answer_active')) {
                element.querySelector('.comments__item-form-answer').classList.remove('comments__item-form-answer_active');
              }
            }
          });
          item.querySelector('.comments__item-form-answer').classList.add('comments__item-form-answer_active');
        });
      }
    });
  }
}
function commentsEdit() {
  // eslint-disable-next-line no-unused-vars,camelcase
  // eslint-disable-next-line no-restricted-syntax
  const buttons = document.querySelectorAll('.comments__item');
  if (buttons) {
    buttons.forEach((item) => {
      if (item.querySelector('.comments__item-button-edit')) {
        item.querySelector('.comments__item-button-edit').addEventListener('click', (e) => {
          e.preventDefault();
          buttons.forEach((element) => {
            if (element.querySelector('.comments__item-form-edit')) {
              if (element.querySelector('.comments__item-form-edit').classList.contains('comments__item-form-edit_active')) {
                element.querySelector('.comments__item-form-edit').classList.remove('comments__item-form-edit_active');
              }
            }
          });
          item.querySelector('.comments__item-form-edit').classList.add('comments__item-form-edit_active');
        });
      }
    });
  }
}
function commentsMore() {
  // eslint-disable-next-line no-unused-vars,camelcase
  // eslint-disable-next-line no-restricted-syntax
  const buttons = document.querySelectorAll('.comments__item');
  if (buttons) {
    buttons.forEach((item) => {
      item.querySelector('.comments__item-button-more').addEventListener('click', (e) => {
        e.preventDefault();
        if (item.querySelector('.comments__item-more').classList.contains('comments__item-more_active')) {
          buttons.forEach((element) => {
            if (element.querySelector('.comments__item-more')) {
              if (element.querySelector('.comments__item-more').classList.contains('comments__item-more_active')) {
                element.querySelector('.comments__item-more').classList.remove('comments__item-more_active');
              }
            }
          });
          item.querySelector('.comments__item-more').classList.remove('comments__item-more_active');
        } else {
          buttons.forEach((element) => {
            if (element.querySelector('.comments__item-more')) {
              if (element.querySelector('.comments__item-more').classList.contains('comments__item-more_active')) {
                element.querySelector('.comments__item-more').classList.remove('comments__item-more_active');
              }
            }
          });
          item.querySelector('.comments__item-more').classList.add('comments__item-more_active');
        }
      });
    });
  }
}
function commentsTabSelect() {
  const complainSelect = document.querySelector('.comments__tab-select-title');
  const complainInput = document.querySelector('.comments__tab-select-input');
  if (complainSelect) {
    const complainSelectBlock = document.querySelector('.comments__tab-select-container');
    complainSelect.addEventListener('click', () => {
      complainSelectBlock.classList.toggle('comments__tab-select-container_active');
    });
    complainSelectBlock.querySelectorAll('.comments__tab-select-option').forEach((item) => {
      item.addEventListener('click', () => {
        complainSelectBlock.classList.remove('comments__tab-select-container_active');
        complainSelect.textContent = item.textContent;
        complainInput.value = item.textContent;
      });
    });
  }
}
function CommentsCheck() {
  const items = document.querySelectorAll('.comments__item');
  if (items) {
    items.forEach((item, index) => {
      if (index > 9) {
        item.classList.add('comments__item_hidden');
      }
    });
    const button = document.querySelector('.comments__other-button');
    button.addEventListener('click', (event) => {
      event.preventDefault();
      items.forEach((item) => {
        if (item.classList.contains('comments__item_hidden')) {
          item.classList.remove('comments__item_hidden');
        }
      });
      button.style.display = 'none';
    });
  }
}
// eslint-disable-next-line camelcase
export default function commentsInit() {
  commentsAnswer();
  commentsEdit();
  commentsTabSelect();
  commentsMore();
  CommentsCheck();
}
