/* eslint-disable */

export default {
  props: {
  },
  data() {
    return {
    };
  },
  watch: {
  },
  created() {
  },
  methods: {
    removeAllCheckboxes(el) {
      const element = el.currentTarget;
      const parent = element.closest('.js--checkbox-remove');
      if (parent && parent.querySelector('.js--select-list-remove-checkbox')) {
        const array_chekcbox = parent.querySelector('.js--select-list-remove-checkbox').querySelectorAll('input[type="checkbox"]:checked');
        for (let item of array_chekcbox) {
          item.checked = false;
        }
        if (parent.querySelector('.js--select-list') && parent.querySelector('.js--select-list').hasAttribute('data-input')) {
          let data_input
          data_input = parent.querySelector('.js--select-list').getAttribute('data-input');
          data_input=parseInt(data_input);
          this.input[data_input].input=[]
          this.substitutingDataFromArray(parent,data_input);
        }
      }
    }

  },
  mounted() {

  }
};
