/* eslint-disable */
import universalForm from '../../universal-form/universal-form';
import { catalogModal, modals } from '../../modals';

export default {

  data() {
    return {
      step_1:true,
      error_step_1:true,
      error_step_2:true,
      fullness_input:0,
      fullness_input_name:0,
      fullness_input_mail:0,
      fullness_input_tel:0,

      fullness_texarea_program:0,
      fullness_texarea_doc:0,

      hiddenInput:'',
      InputSearhPlace:'',
    };
  },

  methods: {
    nextSlide(){
      this.step_1=false
    },
    prevSlaide(){
      this.step_1=true
    },

    buttonActivationName(element){
      if (element.value.length > 0&&this.fullness_input_name!==1) {
        this.fullness_input_name = 1;
      }
      if (element.value.length < 1) {
        this.fullness_input_name = 0;
      }
      this.fullness_input = this.fullness_input_name+this.fullness_input_tel+this.fullness_input_mail+
        this.fullness_input_radio+this.fullness_select+this.fullness_texarea_program+this.fullness_texarea_doc

    },

    buttonActivationEmail(element){
      if(element.value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)&&element.value.length>0){
        if(this.fullness_input_mail!==1) {
          this.fullness_input_mail=1
        }
      }
      if (!element.value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)) {
        this.fullness_input_mail=0
      }
      if (element.value.length<1) {
        this.fullness_input_mail=0
      }
      this.fullness_input = this.fullness_input_name+this.fullness_input_tel+this.fullness_input_mail+
        this.fullness_input_radio+this.fullness_select+this.fullness_texarea_program+this.fullness_texarea_doc

    },

    buttonActivationTel(element){
      if(element.value.length>=16&&this.fullness_input_tel!==1){
        this.fullness_input_tel=1
      }
      if (element.value.length < 16) {
        this.fullness_input_tel=0
      }
      this.fullness_input = this.fullness_input_name+this.fullness_input_tel+this.fullness_input_mail+
        this.fullness_input_radio+this.fullness_select+this.fullness_texarea_program+this.fullness_texarea_doc

    },

    buttonActivation(element){
      const parent = element.closest('.js--housing-cooperative-request')
      if(parent){
        const array = parent.querySelectorAll('.js--validate-mask')
        const array_length = array.length
        for (let item of array){
          const inp_val = element.value.length
          if(item.classList.contains('js--validate-mask-name')&&item.value.length>0){
          }
          if(item.classList.contains('js--validate-mask-email')&&item.value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)&&item.value.length>0){
          }
          if(item.classList.contains('js--validate-mask-tel')&&item.value.length>=16){
          }
        }
      }
    },

    buttonActivationNameProgram(element) {
      if (element.value.length > 0&&this.fullness_texarea_program!==1) {
        this.fullness_texarea_program = 1;
      }
      if (element.value.length < 1) {
        this.fullness_texarea_program = 0;
      }

      this.fullness_input = this.fullness_input_name+this.fullness_input_tel+this.fullness_input_mail+
        this.fullness_input_radio+this.fullness_select+this.fullness_texarea_program+this.fullness_texarea_doc
    },

    buttonActivationNameDoc(element) {
      if (element.value.length > 0&&this.fullness_texarea_doc!==1) {
        this.fullness_texarea_doc = 1;
      }
      if (element.value.length < 1) {
        this.fullness_texarea_doc = 0;
      }

      this.fullness_input = this.fullness_input_name+this.fullness_input_tel+this.fullness_input_mail+
        this.fullness_input_radio+this.fullness_select+this.fullness_texarea_program+this.fullness_texarea_doc
    },

    sendingRequestFirstStep(el){
      const element = el.currentTarget
      const parent = element.closest('.js--step-1')
      const array_input = parent.querySelectorAll('.js--validate-mask')
      for(let item of array_input){
        if(item.classList.contains('js--validate-mask-select')){
          if(item.value===''){
            item.closest('.js--izhs-select').classList.add('input_error')
          }
        }
        else if (item.classList.contains('js--validate-mask')) {
          if(item.value===''){
            item.closest('label').classList.add('input_error')
            const array_error = item.closest('label').querySelectorAll('.js--input__error_required')
            if(array_error.length===0){
              const element_error = document.createElement('p');
              element_error.classList.add('input__error','js--input__error_required');
              element_error.innerHTML += 'Поле обязательно для заполнения'
              item.closest('label').append(element_error);
            }
          }
        }
      }
    },

    closeItemList(el){
      if(el.target.classList.contains('js--select-input')!==true){
        const array_search = el.currentTarget.querySelectorAll('.js--container-select.open');
        for(let item of array_search){
          if (item.querySelector('.js--select-input')
            .hasAttribute('data-search') && item.querySelector('.js--select-input')
            .getAttribute('data-search').length > 0) {
            item.querySelector('.js--select-input').value = item.querySelector('.js--select-input')
              .getAttribute('data-search');
          }
          if ((!item.querySelector('.js--select-input')
            .hasAttribute('data-search') || item.querySelector('.js--select-input')
            .getAttribute('data-search').length === 0)) {
            item.querySelector('.js--select-input').value = '';
          }
          item.classList.remove('open')
        }
      }
    },

  },

  watch: {
    fullness_input(){
      const parent = document.querySelector('.js--housing-cooperative-request .js--step-1');
      if(parent){
        const array = parent.querySelectorAll('.js--validate-mask')
        const array_length = array.length
        if(array_length===this.fullness_input){
          this.error_step_1 = false
        }
        else {
          this.error_step_1 = true
        }
      }
    },
  },
  created() {

  },
  mounted() {
    modals();
    catalogModal();
    universalForm();
  }
};
