/* eslint-disable */
import Vue from 'vue';
import VueSlider from 'vue-slider-component';

export default function atEndForm() {
  const app = new Vue({
    el: '#at-form-end',
    data: {
      value: 5,
      place_holder:'Поделитесь своими эмоциями',
      formatter:(v)=>{
        v===1?v='Катастрофа!':v===2?v='Монотонно и без изюминки':v===3?v='Вполне удовлетворительно':v===4?v='Хорошо':v===5?v='Великолепно!':v=''
        return v
      },
    },
    methods: {
      changeVal(value, index){
        const parent = this.$refs.formSlider.$el
        if(parent){
          parent.querySelector('.vue-slider-dot-tooltip').classList.add('tooltip_start')
          if (value===1){
            parent.querySelector('.vue-slider-dot').setAttribute('data-img','status-1')
            this.place_holder='Что разочаровало?'
          }
          else if (value===2){
            parent.querySelector('.vue-slider-dot').setAttribute('data-img','status-2')
            this.place_holder='Что бы вы предложили?'
          }
          else if (value===3){
            parent.querySelector('.vue-slider-dot').setAttribute('data-img','status-3')
            this.place_holder='Чем дополнить курс?'
            parent.querySelector('.vue-slider-dot-tooltip').classList.add('tooltip-pre-3')
          }
          else if (value===4){
            parent.querySelector('.vue-slider-dot').setAttribute('data-img','status-4')
            this.place_holder='Что показалось сложным?'
            parent.querySelector('.vue-slider-dot-tooltip').classList.add('tooltip-pre-end')
          }
          else if (value===5){
            parent.querySelector('.vue-slider-dot').setAttribute('data-img','status-5')
            parent.querySelector('.vue-slider-dot-tooltip').classList.add('tooltip-end')
            this.place_holder='Поделитесь своими эмоциями'
          }
          if(value!==5){
            parent.querySelector('.vue-slider-dot-tooltip').classList.remove('tooltip-end')
          }
          if(value!==4){
            parent.querySelector('.vue-slider-dot-tooltip').classList.remove('tooltip-pre-end')
          }
          if(value!==3){
            parent.querySelector('.vue-slider-dot-tooltip').classList.remove('tooltip-pre-3')
          }
        }
      }
    },
    computed: {
    },
    watch: {
    },
    mounted() {
    },
    components: {
      VueSlider,
    },
  })
}
