<template lang="pug">
  .personal-office__end-wr-donut-chart
    .personal-office__end-donut-chart
      div(
        ref="apexChart"
      )
        apexcharts(width='140%' :options='chartOptions' :series='chartSeries')
    .personal-office__end-donut-wr-legend
      .personal-office__end-donut-legend-row
        p.personal-office__end-legend-general Показатели
        p.personal-office__end-legend-general Ваш результат
        p.personal-office__end-legend-total Всего
      .personal-office__end-donut-legend-row
        p.personal-office__end-legend-general.personal-office__end-donut-legend-key.green Очки рейтинга
        p.personal-office__end-legend-general {{point.user | format}}
        p.personal-office__end-legend-total {{point.total | format}}
      .personal-office__end-donut-legend-row
        p.personal-office__end-legend-general.personal-office__end-donut-legend-key.orange Задания
        p.personal-office__end-legend-general {{task.user | format}}
        p.personal-office__end-legend-total {{task.total | format}}
      .personal-office__end-donut-legend-row
        p.personal-office__end-legend-general.personal-office__end-donut-legend-key.white Финансовая цель
        p.personal-office__end-legend-general {{target.user | format}}
        p.personal-office__end-legend-total {{target.total | format}}

</template>

<script>
const VueApexCharts = () => import ("vue-apexcharts");


export default {
  name: 'ApexChartAtRing',
  data() {
    return {
      chartSeries:[0, 0, 0],
      chartOptions: {
        chart: {
          type: 'radialBar',
          animations:{
            enabled: false,
          },
        },
        plotOptions: {
          radialBar:{
            track:{
              margin: 10,
              strokeWidth: '100%',
              background: '#2E2E30'
            },
            hollow: {
              size: '24%',
              background: 'transparent',
            }
          },
          dataLabels: {
            name: {
              show: false,
            },
            value: {
              show: false,
            }
          },
        },
        states: {
          normal: {
            filter: {
              type: 'none',
              value: 0,
            }
          },
          click:{
            filter: {
              type: 'none',
              value: 0,
            }
          },
          hover: {
            filter: {
              type: 'none',
              value: 0,
            }
          },
          active: {
            allowMultipleDataPointsSelection: false,
            filter: {
              type: 'none',
              value: 0,
            }
          },
        },
        dataLabels: {
          enabled: false,
          name: {
            show: false,
          },
          value: {
            show: false,
          }
        },
        labels: ['Очки рейтинга', 'Задания','Финансовая цель'],
        fill: {
          colors: ['#82BF00', '#FB9C0F','#ffffff']
        },
        legend:{
          show: false,
          position: 'right',
          horizontalAlign:'right',
          fontSize: '14px',
          fontFamily: 'Gilroy-Medium,sans-serif',
          formatter: function(seriesName, opts) {
            // return [opts.w.globals.series[opts.seriesIndex],'%','<br>','<i>',seriesName,'</i>']
            // const legend = document.querySelector('.schedule-circle-legend')
            // console.log(legend);
          },
          offsetX:5,
          offsetY:-18,
          labels: {
            // colors: ['#A3D562', '#FFC9B5'],
            // useSeriesColors: true
          },
          markers:{
            width: 0,
            height: 0,
          },
          onItemClick: {
            toggleDataSeries: false
          },
          onItemHover: {
            highlightDataSeries: false
          },
          height: 90
        },
        tooltip:{
          enabled: false
        },
        stroke:{
          lineCap: 'round'
        },
        responsive: [{
          breakpoint: 640,
          options: {
            chart: {
              // width: '75%',
              // offsetX: -35
              // height:260
            },
            legend: {
              // position: 'bottom'
            }
          }
        }]
      },

      point:{user:0,total:0},
      task:{user:0,total:0},
      target:{user:0,total:0}
    }
  },
  filters: {
    format: (val) => `${val}`.replace(/(\d)(?=(\d{3})+([^\d]|$))/g, '$1 '),
  },
  mounted() {
    const element_chart = this.$refs.apexChart.closest('.js--at-end-schedule')
    if(element_chart&&element_chart.hasAttribute('data-chart')) {
      let data = element_chart.getAttribute('data-chart')
      const regex = /,(?=\s*?[}\]])/g;
      data = data.replace(regex, '');
      data = JSON.parse(data)
      if(data.totalTasks){
        this.point.user = data.totalTasks.userPoints
        this.point.total = data.totalTasks.maxPoints

        this.task.user = data.totalTasks.userTasks
        this.task.total = data.totalTasks.maxTasks

        this.target.user = data.totalTasks.financialAdded
        this.target.total = data.totalTasks.financialPlanned

        const maxPoints = data.totalTasks.maxPoints
        const userPoints = data.totalTasks.userPoints
        const pointsPercentage = (parseInt(userPoints) * 100)/parseInt(maxPoints)

        const maxTasks = data.totalTasks.maxTasks
        const userTasks = data.totalTasks.userTasks
        const tasksPercentage = (parseInt(userTasks) * 100)/parseInt(maxTasks)

        const financialPlanned = data.totalTasks.financialPlanned
        const financialAdded = data.totalTasks.financialAdded
        const financialPercentage = (parseInt(financialAdded) * 100)/parseInt(financialPlanned)

        this.chartSeries = [pointsPercentage,tasksPercentage,financialPercentage];
      }

    }
  },
  components: {
    apexcharts: VueApexCharts
  }
}
</script>
