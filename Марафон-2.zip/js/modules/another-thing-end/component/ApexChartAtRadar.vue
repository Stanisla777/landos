<template lang="pug">
  .personal-office__end-radar-chart
    div(
      ref="apexChartRadar"
    )
      apexcharts(:width='chartOptions.chart.width' :options='chartOptions' :series="series")

    .personal-office__end-wr-radar-legend
      .personal-office__end-row-radar-legend(v-for="item in blocks")
        p.personal-office__end-radar-legend {{item[0]}} - <span>{{item[1]}}</span>


</template>

<script>
import Vue from 'vue';

const VueApexCharts = () => import ("vue-apexcharts");


export default {
  name: 'ApexChartAtRadar',
  data() {
    return {
      series: [
        {
          name: 'Всего',
          data: [100,100,100,100,100,100,100],
        },
        {
          name: 'Выполнено',
          data: [10,90,10,20,15,5,20],
        },
      ],
      chartOptions: {
        chart: {
          type: 'radar',
          width: '130%',
          animations:{
            enabled: false,
          },
          toolbar:{
            show: false,
          }
        },
        labels: ['Блок 1', 'Блок 2', 'Блок 3', 'Блок 4', 'Блок 5', 'Блок 6', 'Блок 7'],
        fill: {
          colors: ['transparent','rgba(130, 191, 0, 0.28)'],
          opacity: 0.8,
        },
        stroke: {
          show: true,
          width: 1,
          colors: ['#ffffff','#82BF00'],
          dashArray: 0
        },
        markers: {
          size: 3,
          colors: ['#ffffff','#82BF00'],
          strokeWidth: 0,
          hover: {
            size: 4
          }
        },
        tooltip:{
          enabled: true,
          y: {
            formatter: function(value, { series, seriesIndex, dataPointIndex, w }) {
              return value.toFixed(1) + '%';
            }
          }
        },
        yaxis: {
          show: false
        },
        plotOptions: {
          radar: {
            size: undefined,
            offsetX: 0,
            offsetY: 0,
            polygons: {
              strokeColors: '#2E2E30',
              strokeWidth: 1,
              connectorColors: '#2E2E30',
              fill: {
                colors: undefined
              }
            }
          }
        },
        legend: {
          show:false
        },
        responsive: [{
          breakpoint: 640,
          options: {
            chart:{
              width:'150%'
            }

          },
        },
          {
            breakpoint: 471,
            options: {
              chart:{
                width:'160%'
              }

            },
          }]
      },

      blocks:[]


    }
  },

  mounted() {
    const element_chart = this.$refs.apexChartRadar.closest('.js--at-end-schedule')
    if(element_chart&&element_chart.hasAttribute('data-chart')) {
      let data = element_chart.getAttribute('data-chart')
      const regex = /,(?=\s*?[}\]])/g;
      data = data.replace(regex, '');
      data = JSON.parse(data)

      let label = []
      const series_data = []
      const series_data_empty = []
      let blocks_task = []
      if(data.blocks){
        for(let item of data.blocks){
          label.push(item.name)
          const percent = (parseInt(item.userTasks) * 100)/parseInt(item.maxTasks)
          series_data.push(percent)
          series_data_empty.push(100)

          blocks_task.push(item.name)
          blocks_task.push(item.description)
          this.blocks.push(blocks_task)
          blocks_task=[]

        }
        label = label.map(function (num) {
          return num.replace('№', '');
        })
        this.chartOptions.labels=label
        this.series[1].data=series_data
        this.series[0].data=series_data_empty
      }

    }
  },
  components: {
    apexcharts: VueApexCharts
  }
}
</script>
