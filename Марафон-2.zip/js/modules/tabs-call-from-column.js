// eslint-disable-next-line import/no-named-as-default
import dropDown from './dropDown';

export default function callTab() {
  // Основная часть
  // eslint-disable-next-line camelcase
  const tabs_btn = document.querySelectorAll('.js--tabs-btn');
  // eslint-disable-next-line no-restricted-syntax,no-shadow,camelcase
  for (const item of tabs_btn) {
    item.onclick = () => {
      // eslint-disable-next-line no-unused-vars,no-use-before-define
      TabsCallFromColumn(item);

      // ---------- Подключаемые функции по необходимости страниц ----------
      // eslint-disable-next-line camelcase
      const wrap_birthday = document.querySelector('.birthday__directions-wrap-description');
      // eslint-disable-next-line camelcase
      if (wrap_birthday) {
        // eslint-disable-next-line no-use-before-define
        borderBirthdayWrap(item);
      }
      // eslint-disable-next-line camelcase
      const wrap_birthday_media = document.querySelector('.birthday__directions-tab-btn-wrap-media');
      // eslint-disable-next-line camelcase
      if (wrap_birthday_media) {
        // eslint-disable-next-line no-use-before-define
        birthdayTabsMedia(item);
      }

    //  ------------------- окончание подключения необходимых методов
    };
  }
}
function TabsCallFromColumn(element) {
  const attr = element.getAttribute('data-type');
  if (!element.classList.contains('active')) {
    const parent = element.closest('.js-tabs-container');
    // eslint-disable-next-line camelcase
    const tab_btn = parent.querySelectorAll('.js--tabs-btn');
    // eslint-disable-next-line camelcase,no-restricted-syntax
    for (const elem of tab_btn) {
      elem.classList.remove('active');
    }
    element.classList.add('active');
    // eslint-disable-next-line camelcase
    const tabs_block = parent.querySelectorAll('.js-tabs-item');
    // eslint-disable-next-line no-restricted-syntax,camelcase
    for (const item of tabs_block) {
      const data = item.getAttribute('data-type');
      // eslint-disable-next-line eqeqeq
      if (data == attr) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    }
  } else return false;
}
// eslint-disable-next-line no-unused-vars
function borderBirthdayWrap(element) {
  const attr = element.getAttribute('data-type');
  const parent = element.closest('.js-tabs-container');
  // eslint-disable-next-line eqeqeq
  if (attr != 1) {
    parent.querySelector('.birthday__directions-wrap-description').setAttribute('style', 'border-top-left-radius:20px;');
  } else {
    parent.querySelector('.birthday__directions-wrap-description').setAttribute('style', 'border-top-left-radius:0;');
  }
}
// eslint-disable-next-line no-unused-vars
function birthdayTabsMedia(param) {
  // eslint-disable-next-line no-restricted-syntax,camelcase
  const text = param.textContent;
  const parent = param.closest('.js-accordion-parent');
  parent.querySelector('.js-accordion-btn p').textContent = text;
  dropDown(param, 0);
}
