import Vue from 'vue';
import GameddTask from './modules/another-thing/TestNEntry.vue';
import anotherThing from './modules/anotherThing';
import callGameTest from './modules/another-thing/custom-scripts/call-game-test';
import GameddRegistration from './modules/another-thing-registration/AnotherThingRegistration.vue';
import substituteStepChange from './modules/another-thing-registration/custom-scripts/substitute-step-change';
import countdownPage from './modules/countdown-page';
import progressBarNew from './modules/progress-bar-new';
import GameddNotifications from './modules/another-thing-notifications/GameddNotifications.vue';
import jsCallModal from './modules/js--call-modal';
import atBeesender from './modules/at-beesender';
import {
  atAdvantageSwiper, atBecomeSwiper, atSliderPartners
} from './modules/swiper-sliders';
import anchors from './modules/anchors';
import {
  subcategoryAccordion, documentAccordion, catalogAsideAccordion, coursesAccordion,
  housingCooperativeChoosenAccordion
} from './modules/accordions';
import cookies from './modules/cookies';
import {
  chatValidation, feedbackValidation, coursesFeedbackValidation, subscriptionValidation,
  callValidation, housingCooperativeRequestValidation, phoneMask
} from './modules/validations';

Vue.config.productionTip = false;

document.addEventListener('DOMContentLoaded', () => {
    anotherThing();
    callGameTest();
    substituteStepChange();
    countdownPage();
    progressBarNew();
    jsCallModal();
    atBeesender();
    atAdvantageSwiper();
    atBecomeSwiper();
    atSliderPartners();
    anchors();
    subcategoryAccordion();
    documentAccordion();
    catalogAsideAccordion();
    coursesAccordion();
    housingCooperativeChoosenAccordion();
    cookies();
    chatValidation();
    feedbackValidation();
    coursesFeedbackValidation();
    subscriptionValidation();
    callValidation();
    housingCooperativeRequestValidation();
    phoneMask();
    function initVueApp(obj) {
        const app = document.getElementById(obj.id);
        if (app) {
            obj.fn();
        }
    }

    // eslint-disable-next-line no-unused-vars
        function initGameddRegistration() {
              // eslint-disable-next-line no-new
              new Vue({
                el: '#v-gamedd-registration',
                components: {
                  'gamedd-registration': GameddRegistration
                }
              });
            }
    // eslint-disable-next-line no-unused-vars
        function initGameddNotifications() {
              // eslint-disable-next-line no-new
              new Vue({
                el: '#v-gamedd-notifications',
                components: {
                  'gamedd-notifications': GameddNotifications
                }
              });
            }

    const obj = [
        {
          id: 'v-gamedd-registration',
          fn: initGameddRegistration
        },
        {
          id: 'v-gamedd-notifications',
          fn: initGameddNotifications
        },

    ];

    for (let i = 0; i < obj.length; i += 1) {
        initVueApp(obj[i]);
    }

  // создание несколько экземпляров vue для вызова тестов в них
    const vueTestAnotherThing = document.querySelectorAll('.js-test-another-thing');

    if (vueTestAnotherThing.length) {
      for (let i = 0; i < vueTestAnotherThing.length; i += 1) {
        vueTestAnotherThing[i].id = `test-n-${i}`;

        // eslint-disable-next-line no-new
        new Vue({
          el: `#test-n-${i}`,
          components: {
            'gamedd-task': GameddTask,
          }
        });
      }
    }
});
