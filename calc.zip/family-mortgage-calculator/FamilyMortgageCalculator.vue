<template lang="pug">
  div
    .block-grid-area-big-small.mor-rep-calculators__block-grid-area.family-calculator
      .block-grid-area__col.js--block-grid-area
        .calc-tax-deduc-new__block.calc-tax-deduc-new__area.grey
          .calc-tax-deduc-new__container-title
            .calc-tax-deduc-new__row-title-container.not-margin
              h3.calc-tax-deduc-new__block-title.big Данные об ипотеке
          .mor-rep-calculators__body-block
            .calc-tax-deduc-new__row.small-margin
              .calc-tax-deduc-new__row-input.js--calc-row-input
                template
                  component-credit-amount
                template
                  component-initial-payment


            .calc-tax-deduc-new__row.small-margin
              .calc-tax-deduc-new__row-input.js--calc-row-input
                template
                  component-interest-rate
                template
                  component-credit-time
        template
          component-payment-list.desctop


      .block-grid-area__col
        .sticky-aside.calc-tax-deduc-new__sticky-aside
          template
            component-final-result
          .calc-tax-deduc-new__block.mobile-padding.grey
            .mor-rep-calculators__container-footnote.family-calculator
              .mor-rep-calculators__container-footnote-icon
                .mor-rep-calculators__wr-footnote-icon
              p.calc-tax-deduc-new__block-subtitle.
                Расчет носит справочный характер и не может быть основанием для совершения юридически значимых действий
    template
      component-payment-list.tablet
    template
      component-payment-list-mobile.mobile
    template
      component-modal-tooltip
    template
      component-modal-send-mail

    #yandex-captcha-family-calculator.captcha-element



</template>
<script>
import Vue from 'vue';
import eventBus from './development-tools/eventBus.vue';
import Storage from './development-tools/state.vue';
import ComponentCreditAmount from './components/v-component-credit-amount.vue';
import ComponentInterestRate from './components/v-component-interest-rate.vue';
import ComponentCreditTime from './components/v-component-credit-time.vue';
import ComponentInitialPayment from './components/v-component-initial-payment.vue';

import ComponentFinalBlockConfirmed from './components/v-component-block-final-result.vue';
import ComponentModalTooltip from './components/v-component-modal-tooltip.vue';
import ComponentModalSendMail from './components/v-component-modal-send-mail.vue';
import ComponentFinalResult from './components/v-component-final-result.vue';
import ComponentPaymentList from './components/v-component-payment-list.vue';
import ComponentPaymentListMobile from './components/v-component-payment-list-mobile.vue';



export default {
  name: 'FamilyMortgageCalculator',
  data(){
    return {

    }
  },
  methods:{

  },
  mounted(){


  },
  computed:{

  },
  created(){

  },
  watch:{
  },
  components:{
    ComponentCreditAmount,
    ComponentInterestRate,
    ComponentCreditTime,
    ComponentInitialPayment,
    ComponentFinalBlockConfirmed,
    ComponentModalTooltip,
    ComponentModalSendMail,
    ComponentFinalResult,
    ComponentPaymentList,
    ComponentPaymentListMobile
  }
};
</script>
<style scoped>
</style>
