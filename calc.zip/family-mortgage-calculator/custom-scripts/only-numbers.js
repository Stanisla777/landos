export default function onlyNumbers(event) {
  // eslint-disable-next-line eqeqeq
  if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27
    // Разрешаем: Ctrl+A
    // eslint-disable-next-line eqeqeq
    || (event.keyCode == 65 && event.ctrlKey === true)
    // eslint-disable-next-line eqeqeq
    || (event.keyCode == 86 && event.ctrlKey === true)
    // Разрешаем: home, end, влево, вправо
    || (event.keyCode >= 35 && event.keyCode <= 39)) {
    // Ничего не делаем

  } else {
    // Запрещаем все, кроме цифр на основной клавиатуре, а так же Num-клавиатуре
    // eslint-disable-next-line max-len,no-lonely-if,eqeqeq
    if ((event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105)) {
      event.preventDefault();
    }
    // // eslint-disable-next-line eqeqeq,max-len
    // if (event.keyCode == 53 && event.shiftKey === true) {
    //   event.preventDefault();
    // }
    // eslint-disable-next-line eqeqeq
    if ((event.keyCode >= 48 || event.keyCode <= 57) && event.shiftKey === true) {
      event.preventDefault();
    }
  }
}
