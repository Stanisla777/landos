<template lang="pug">
  div.property-calculator__style-nouislider.white
    template
      credit-calculator

</template>
<script>
// import DduCalculator from './DduCalculator.vue';
import Storage from './development-tools/state.vue';
const CreditCalculator = () => import ("./FamilyMortgageCalculator.vue");


export default {
  name: 'FamilyMortgageCalculatorPointEntry',
  data(){
    return {
      transfer_parametr: [
        {'initial_payment_perc':20},
        {'max_tax_deduction_property':260000},
        {'max_tax_deduction_interest':390000},
      ],
      transfer_tooltip:null,
      answers: null,



    };
  },
  methods:{
  },
  mounted(){
    //обязательный процент от стоимости недвижимости для первоначального взноса
    let initial_payment_perc = this.$el.getAttribute('initial-payment')
    if (initial_payment_perc){
      try{
        this.transfer_parametr.initial_payment_perc=parseInt(initial_payment_perc)
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }

    //максимальный налоговый вычет за имущество
    let max_tax_deduction = this.$el.getAttribute('max-tax-deduction')
    if (max_tax_deduction){
      try{
        this.transfer_parametr.max_tax_deduction_property=parseInt(max_tax_deduction)
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }

    //максимальный налоговый вычет за проценты
    let max_tax_deduction_interest = this.$el.getAttribute('max-tax-deduction-interest')
    if (max_tax_deduction_interest){
      try{
        this.transfer_parametr.max_tax_deduction_interest=parseInt(max_tax_deduction_interest)
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }
    Storage.dispatch('ActionTransferParametr',this.transfer_parametr)



    //объект с тултипами
    const tooltips = {};
    const attributes = this.$el.attributes;

    // Перебираем все атрибуты элемента
    for (let i = 0; i < attributes.length; i++) {
      const attr = attributes[i];

      // Проверяем, начинается ли атрибут с 'tooltip-'
      if (attr.name.startsWith('tooltip-')) {
        try {
          // Парсим JSON из значения атрибута
          const value = JSON.parse(attr.value);

          // Извлекаем имя из названия атрибута (удаляем 'tooltip-')
          const name = attr.name.replace('tooltip-', '');

          // Добавляем свойство name, если его нет в объекте
          if (!value.name) {
            value.name = attr.name.replace('tooltip-', '');
          }

          // Добавляем в результирующий объект
          tooltips[name] = value;
        } catch (error) {
          console.error(`Ошибка парсинга атрибута ${attr.name}:`, error);
        }
      }
    }
    // на выходе получаем:
    // {
    //   initial_payment: {info: 'Какая-то информация', name: 'initial-payment', size: 'small'},
    //   ...
    // }

    // отправляю в state
    if (Object.keys(tooltips).length > 0) {
      Storage.dispatch('ActionTransferTooltip', tooltips);
    }

    // получаю данные, которыми делятся
    let html_answers = this.$el.getAttribute('answers')
    if (html_answers){
      try{
        this.answers=JSON.parse(html_answers);
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }
    Storage.dispatch('ActionAnswers',this.answers)

    //сегодняшний месяц и год для начала кредита для графика
    const now = new Date();
    const date_begin_credit = [now.getMonth(),now.getFullYear()];
    Storage.dispatch('ActionDateBeginCredit',date_begin_credit)

    //получаю ссылки на соцсети и страницу
    let html_answerLink = this.$el.getAttribute('answers-link')
    if (html_answerLink){
      try{
        Storage.dispatch('ActionAnswerLink',JSON.parse(html_answerLink))
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }
    //получаю флаг можно ли делиться
    let html_can_share = this.$el.getAttribute('answer-can-share')
    if (html_can_share){
      try{
        Storage.dispatch('ActionCanShare',parseInt(html_can_share))
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }
    //id калькулятра
    let html_calculatorId = this.$el.getAttribute('calculatorId')
    if (html_calculatorId){
      try{
        Storage.dispatch('ActionCalculatorId',parseInt(html_calculatorId))
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }

    //id вопроса
    let html_answersId = this.$el.getAttribute('answersId')
    if (html_answersId){
      try{
        Storage.dispatch('ActionAnswersId',parseInt(html_answersId))
      } catch (error) {
        console.log('Ошибка при парсинге');
      }
    }


  },
  computed:{
  },
  watch:{
  },
  components:{
    CreditCalculator
  }
};
</script>
<style scoped>
</style>
