<template lang="pug">
  .modal.mor-rep-calculators__modal-mail(
    ref="dataModalMail" @click="closeModalBody"
    :class="modal_mail_send_status?'open':''"
  )
      .modal__wrapper.new.js--modal
          button.modal__closer.outside(@click="closeModal")
              svg(width='17' height='18' viewBox='0 0 17 18' fill='none' xmlns='http://www.w3.org/2000/svg')
                  path(fill-rule='evenodd' clip-rule='evenodd' d='M0.357542 15.3637C-0.0329827 15.7543 -0.0329827 16.3874 0.357542 16.778C0.748066 17.1685 1.38123 17.1685 1.77176 16.778L8.13551 10.4142L14.4995 16.7782C14.89 17.1687 15.5232 17.1687 15.9137 16.7782C16.3042 16.3876 16.3042 15.7545 15.9137 15.364L9.54972 8.99999L15.9139 2.63582C16.3044 2.24529 16.3044 1.61213 15.9139 1.2216C15.5234 0.83108 14.8902 0.83108 14.4997 1.2216L8.13551 7.58577L1.77156 1.22182C1.38104 0.8313 0.747871 0.8313 0.357346 1.22182C-0.0331781 1.61235 -0.0331778 2.24551 0.357346 2.63604L6.7213 8.99999L0.357542 15.3637Z')

          .modal__main-content.js--modal-main-content
              form(action="" novalidate).feedback.js--universal-form
                  .modal__title Отправить на e-mail
                  .modal__desc Укажите адрес электронной почты на которую вы хотите отправить расчет
                  .feedback__form-sand
                    .feedback__row
                      label.feed_back__field.feed_back__input(:class="mail_error||error_mail_fill?'input_error':''")
                          input(
                            ref="inputMail"
                            type="text"
                            inputmode="email"
                            placeholder="E-mail",
                            @input="onInputMail"
                            @blur="onInputMail"
                          )
                      .mor-rep-calculators__input-error(v-if="mail_error") Недопустимый формат
                      .mor-rep-calculators__input-error(v-if="error_mail_fill") Введите полностью почту

                  .modal__bottom-sand
                    .feed_back__wr-checkbox.modal__bottom-form
                      .checkbox-stylized.feed_back__user-form-subscription.js--checkbox_wrapper(:class="chek_error?'input_error':''")
                        .personal-office__user-form-subscription-em
                        .feed_back__user-form-block
                          input#modal_subscription.js--feedback-check(
                            type="checkbox" name=""
                            required
                            @change="changePersonal"
                          )
                          label.feed_back__chek-label(for='modal_subscription')
                            p Согласен (-на) на обработку
                            a(href='/user-agreement/#user-agreement', target='_blank') персональных данных
                      .mor-rep-calculators__input-error(v-if="chek_error") Согласитесь с условиями
                      .checkbox-stylized.feed_back__user-form-subscription.js--checkbox_wrapper
                        .personal-office__user-form-subscription-em
                        .feed_back__user-form-block
                          input#modal_agree(type="checkbox" name="" @change="changeAgree")
                          label.feed_back__chek-label(for='modal_agree')
                            p Согласен (-на) на получение
                            a(href='/user-agreement/#user-personalized-communications', target='_blank') рекламных материалов
                    button(type="button").btn_s.black.disabled.disabled__can-check(
                      @click="sendingResultError"
                      v-if="!check_agree_personal||!mail_fill"
                    ) Отправить заявку
                    button(type="button").btn_s.black(
                      @click="sendingResult('mail',$event)"
                      v-if="check_agree_personal&&mail_fill"
                    ) Отправить заявку



          .modal__sending-result.success.js--modal-wr-success
            .modal__sending-result-icon
            p.modal__sending-result-title Готово!
            .modal__sending-result-wr-des
                p Ссылка отправлена

            button.btn_s.black.js--modal-closer(@click="closeModal") Закрыть


          //окно появляется после отправки добавлением класса .active
          .modal__sending-result.failed.js--modal-wr-failed
            .modal__sending-result-icon
            p.modal__sending-result-title <span class="highlighting">Ошибка</span>
            .modal__sending-result-wr-des
              p {{description_after_sand_mail}}
            button.btn_s.black.js--modal-closer(@click="closeModal") Закрыть



</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import numberFormatting from '../mixin/numberFormatting.js';
import IMask from 'imask';

export default {
  name: 'v-modal-send-mail',
  mixins: [numberFormatting],
  props:[],
  data(){
    return {
      mail_error:false,
      mail_fill:false,
      mask_mail:null,
      check_agree_advertisement:false,
      check_agree_personal:false,
      error_mail_fill:false,
      chek_error:false,

      //это нужно будет в state, сдю будет приходить сообщение после отправки
      description_after_sand_mail:'Сообщение после отправки'

    }
  },
  methods:{
    closeModal(){
      Storage.dispatch('ActionOpenModalMailStatus',false)
      this.RemoveClassBody()
    },
    closeModalBody(e){
      if(e.target===this.$refs.dataModalMail){
        Storage.dispatch('ActionOpenModalMailStatus',false)
        this.RemoveClassBody()
      }
    },
    onInputMail(e){
      const element = e.target
      let char = e.data
      const reg = e.inputType!=='deleteContentBackward'&&e.inputType!=='deleteContentForward'&&e.inputType!=='insertFromPaste'&&e.inputType!=='historyUndo'
      if (typeof char != 'undefined' && !/^[a-z0-9@!#$%&'.+-=?^_"\\`{|}~]*$/i.test(char) && reg) {
        this.mail_error=true
      }
      else if(((char&&char!=null)&&typeof char != 'undefined' && /^[a-z0-9@!#$%&'.+-=?^_"\\`{|}~]*$/i.test(char))||e.inputType==='deleteContentBackward'||e.inputType==='deleteContentForward'){
        this.mail_error=false
      }
      if(element.value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)) {
        this.mail_fill=true
      } else{
        this.mail_fill=false
      }
      this.error_mail_fill = false

    },
    changePersonal(el){
      const element = el.currentTarget
      this.chek_error=false
      if (element.checked) {
        this.check_agree_personal=true
      }
      else {
        this.check_agree_personal=false
      }
    },
    changeAgree(el){
      const element = el.currentTarget
      if (element.checked) {
        this.check_agree_advertisement=true
      }
      else {
        this.check_agree_advertisement=false
      }
    },
    inputMaskEarly() {
      this.mask_mail = IMask(this.$refs.inputMail, {
        mask: /^[a-z0-9@!#$%&'.+-=?^_"`{|}~]*$/i
      });
      this.mask_mail.on('accept', () => {


      })
      this.mask_mail.on('reject', () => {

      })
    },
    sendingResultError(){
      if (this.mail_fill===false) {
        this.error_mail_fill = true
      }
      this.mail_error=false
      if (this.check_agree_personal===false) {
        this.chek_error = true
      }


    },
  },
  mounted(){
    this.inputMaskEarly()
  },
  computed:{
    modal_mail_send_status(){
      return Storage.getters.MODALMAILSENDSTATUS
    },

  },
  watch:{

  },
  components:{}
};
</script>
<style scoped>
</style>
