/* eslint-disable */
import Vue from 'vue';
import Swiper, { Navigation, Pagination } from 'swiper';
import paginationSlider_s from '../redesign-site/paginationSlider';
Swiper.use([Navigation, Pagination]);



export default function speakerInit() {

  const app = new Vue({
    el: '#another-thing-speaker',
    data: {
      html_tooltip:null

    },

    computed: {

    },

    mounted() {
      this.appraisalSlider();

    },
    methods:{

      appraisalSlider() {
        // eslint-disable-next-line no-unused-vars
        const mySwiper = new Swiper('.js--another-thing-speaker', {
          init: true,
          loop: false,
          slidesPerView: 4,
          spaceBetween: 16,
          simulateTouch: true,
          autoHeight: true,
          resizeObserver:true,
          // observeParents:true,
          // observer:true,
          // observeSlideChildren:true,

          pagination: {
            el: '.js--pagination-speaker',
            clickable: true,
          },
          navigation: {
            nextEl: '.js--swiper-speaker-right',
            prevEl: '.js--swiper-speaker-left',
          },
          breakpoints: {
            0: {
              slidesPerView: 1,
            },
            690: {
              slidesPerView: 2,
            },
            1050: {
              slidesPerView: 3,
            },
            1375: {
              slidesPerView: 4,
            }
          },
          on: {
            beforeInit:(el)=>{

            },
            afterInit: function (el) {
              if(el.$el && el.$el[0].closest('.js--general-style-slider.before-init')) {
                el.$el[0].closest('.js--general-style-slider').classList.remove('before-init')
              }
              paginationSlider_s(el)
            },
            resize:function (el){
              paginationSlider_s(el)

            }
          },
        });
      },


      receiveHtml(el){
        const element = el.currentTarget
        let html_tooltip = element.getAttribute('html-tooltip')
        if (html_tooltip){
          try{
            this.html_tooltip = html_tooltip
            this.$refs.refModal.classList.add('open')
            this.AddClassBody()
          } catch (error) {
            console.log('Ошибка при парсинге');
          }
        }

      },
      closeModal(){
        this.$refs.refModal.classList.remove('open')
        this.RemoveClassBody()
      },
      closeModalBody(e){
        if(e.target===this.$refs.refModal){
          this.$refs.refModal.classList.remove('open')
          this.RemoveClassBody()
        }
      },
      AddClassBody() {
        document.body.classList.add('body-modal');
        document.body.classList.add('body-additional-class');
        document.body.setAttribute('style', `top:-${window.scrollY}px;position: fixed;`);
        document.ontouchmove = (e) => {
          e.preventDefault();
        };
      },
      RemoveClassBody() {
        if (!document.body.classList.contains('body-modal-modals')) {
          document.body.classList.remove('body-modal');
          document.body.classList.remove('body-additional-class');
        }
        const scrollY = document.body.style.top;
        document.body.style.position = '';
        document.body.style.top = '';
        window.scrollTo(0, parseInt(scrollY || '0') * -1);
      },
    },

  });
}
