<template lang="pug">
  .calc-tax-deduc-new__block.calc-tax-deduc-new__area.grey.js--container-block
    .calc-tax-deduc-new__container-title
      .calc-tax-deduc-new__row-title-container.not-margin
        h3.calc-tax-deduc-new__block-title.big Данные об ипотеке
    .calc-tax-deduc-new__wr-function-block.always-active
      .calc-tax-deduc-new__acc-wr
        .calc-tax-deduc-new__block-subtitle
          p Блок содержит исходные данные об ипотеке и является обязательным для заполнения


        .mor-rep-calculators__body-block
          .calc-tax-deduc-new__row.js--tax-deduc-row
            .calc-tax-deduc-new__row-input.js--calc-row-input
              .calc-tax-deduc-new__container-block.mor-rep-calculators__parent-tooltip-mobile.js--container-block.js--tooltip-parent
                .calc-tax-deduc-new__row-title-container
                  p.calc-tax-deduc-new__row-title Сумма кредита, ₽
                  span.content-note.desctop.content-note__center.js--content-note(v-if="tooltip_information['loan-amount']!==''")
                    span.content-note__text {{tooltip_information["loan-amount"]}}
                  span.content-note.mobile(
                    v-if="tooltip_information['loan-amount']!==''"
                    @click="openTooltipMobile"
                  )
                div(v-if="tooltip_information['loan-amount']!==''")
                  .select__background.modal-special-background(@click="closeTooltipMobile")
                  .select-list__selection-window.modal-special-styles.js--openlist-body
                    .select-list__head
                      p Сумма кредита
                      .select-list__head-close(@click="closeTooltipMobile")
                        svg(width='10', height='10', viewbox='0 0 10 10', fill='none', xmlns='http://www.w3.org/2000/svg')
                          path(fill-rule='evenodd', clip-rule='evenodd', d='M0.209209 0.209209C0.488155 -0.0697365 0.940416 -0.0697365 1.21936 0.209209L5 3.98985L8.78064 0.209209C9.05958 -0.0697365 9.51184 -0.0697365 9.79079 0.209209C10.0697 0.488155 10.0697 0.940416 9.79079 1.21936L6.01015 5L9.79079 8.78064C10.0697 9.05958 10.0697 9.51184 9.79079 9.79079C9.51184 10.0697 9.05958 10.0697 8.78064 9.79079L5 6.01015L1.21936 9.79079C0.940416 10.0697 0.488155 10.0697 0.209209 9.79079C-0.0697365 9.51184 -0.0697365 9.05958 0.209209 8.78064L3.98985 5L0.209209 1.21936C-0.0697365 0.940416 -0.0697365 0.488155 0.209209 0.209209Z', fill='#252628')
                    .select-list__wr-search.mor-rep-calculators__wr-search
                      p {{tooltip_information["loan-amount"]}}

                .calc-tax-deduc-new__col-input.js--number-debt.js--tex-deduc-input.js--loan-amount.js--for-clear-field
                  input.js--normal-field.js-mor-required(
                    ref="inputLoanAmount"
                    inputmode="numeric"
                    placeholder="Введите сумму"
                    @keyup="fieldNotEmpty"
                    @focus="inpFocus"
                    @blur="inpBlur"
                    @input="multiplyActionsInpuLoanAmount(1000000000,$event)"
                  )
                  .calc-tax-deduc-new__input-clear.js--clear-calc-tax(
                    @click="multiClickCloseLoanAmount"
                  )
                p.mor-rep-calculators__input-error.js--required-error.display-none Это поле обязательное для заполнения
              template
                component-calendar(
                  :tooltip_information="tooltip_information"
                  :answers="answers"
                  @sendDateLoanReceipt="receivedDateLoanReceipt"
                  @sendClearDateReceive="receivedClearDateReceive"
                  @sendTimeDataLoan="receivedTimeDataLoan"
                )


          .calc-tax-deduc-new__row.js--tax-deduc-row
            .calc-tax-deduc-new__row-input.js--calc-row-input
              .calc-tax-deduc-new__container-block.mor-rep-calculators__parent-tooltip-mobile.js--container-block.js--tooltip-parent
                .calc-tax-deduc-new__row-title-container
                  p.calc-tax-deduc-new__row-title Ставка, %
                  span.content-note.desctop.content-note__center.js--content-note(v-if="tooltip_information['bet']!==''")
                    span.content-note__text {{tooltip_information["bet"]}}
                  span.content-note.mobile(
                    v-if="tooltip_information['bet']!==''"
                    @click="openTooltipMobile"
                  )
                div(v-if="tooltip_information['bet']!==''")
                  .select__background.modal-special-background(@click="closeTooltipMobile")
                  .select-list__selection-window.modal-special-styles.js--openlist-body
                    .select-list__head
                      p Ставка
                      .select-list__head-close(@click="closeTooltipMobile")
                        svg(width='10', height='10', viewbox='0 0 10 10', fill='none', xmlns='http://www.w3.org/2000/svg')
                          path(fill-rule='evenodd', clip-rule='evenodd', d='M0.209209 0.209209C0.488155 -0.0697365 0.940416 -0.0697365 1.21936 0.209209L5 3.98985L8.78064 0.209209C9.05958 -0.0697365 9.51184 -0.0697365 9.79079 0.209209C10.0697 0.488155 10.0697 0.940416 9.79079 1.21936L6.01015 5L9.79079 8.78064C10.0697 9.05958 10.0697 9.51184 9.79079 9.79079C9.51184 10.0697 9.05958 10.0697 8.78064 9.79079L5 6.01015L1.21936 9.79079C0.940416 10.0697 0.488155 10.0697 0.209209 9.79079C-0.0697365 9.51184 -0.0697365 9.05958 0.209209 8.78064L3.98985 5L0.209209 1.21936C-0.0697365 0.940416 -0.0697365 0.488155 0.209209 0.209209Z', fill='#252628')
                    .select-list__wr-search.mor-rep-calculators__wr-search
                      p {{tooltip_information["bet"]}}

                .calc-tax-deduc-new__col-input.js--number-debt.js--tex-deduc-input.js--interest-rate-calc.js--for-clear-field
                  input.js--normal-field.js-mor-required(
                    ref="inputPersent"
                    inputmode="decimal"
                    placeholder="Введите процент"
                    @keyup="fieldNotEmpty"
                    @focus="inpFocus"
                    @blur="inpBlur"
                    @input="maxPercent"
                  )
                  .calc-tax-deduc-new__input-clear.js--clear-calc-tax(
                    @click="clearInputPercent"
                  )
                p.mor-rep-calculators__input-error.js--required-error.display-none Это поле обязательное для заполнения
              .calc-tax-deduc-new__container-block.mor-rep-calculators__parent-tooltip-mobile.js--calc-row-input.js--container-block.js--tooltip-parent
                .calc-tax-deduc-new__row-title-container
                  p.calc-tax-deduc-new__row-title Срок кредита
                  span.content-note.desctop.content-note__center.js--content-note(v-if="tooltip_information['loan-term']!==''")
                    span.content-note__text {{tooltip_information["loan-term"]}}
                  span.content-note.mobile(
                    v-if="tooltip_information['loan-term']!==''"
                    @click="openTooltipMobile"
                  )
                div(v-if="tooltip_information['loan-term']!==''")
                  .select__background.modal-special-background(@click="closeTooltipMobile")
                  .select-list__selection-window.modal-special-styles.js--openlist-body
                    .select-list__head
                      p Срок кредита
                      .select-list__head-close(@click="closeTooltipMobile")
                        svg(width='10', height='10', viewbox='0 0 10 10', fill='none', xmlns='http://www.w3.org/2000/svg')
                          path(fill-rule='evenodd', clip-rule='evenodd', d='M0.209209 0.209209C0.488155 -0.0697365 0.940416 -0.0697365 1.21936 0.209209L5 3.98985L8.78064 0.209209C9.05958 -0.0697365 9.51184 -0.0697365 9.79079 0.209209C10.0697 0.488155 10.0697 0.940416 9.79079 1.21936L6.01015 5L9.79079 8.78064C10.0697 9.05958 10.0697 9.51184 9.79079 9.79079C9.51184 10.0697 9.05958 10.0697 8.78064 9.79079L5 6.01015L1.21936 9.79079C0.940416 10.0697 0.488155 10.0697 0.209209 9.79079C-0.0697365 9.51184 -0.0697365 9.05958 0.209209 8.78064L3.98985 5L0.209209 1.21936C-0.0697365 0.940416 -0.0697365 0.488155 0.209209 0.209209Z', fill='#252628')
                    .select-list__wr-search.mor-rep-calculators__wr-search
                      p {{tooltip_information["loan-term"]}}

                .mor-rep-calculators__row-term
                  .calc-tax-deduc-new__col-input.js--number-debt.js--tex-deduc-input.js--for-clear-field.js-mor-required(ref="fieldTermWrapper")
                    input.js--normal-field.js--field-term(
                      ref="fieldTerm"
                      v-if="term==='year'"
                      inputmode="numeric"
                      placeholder="Введите количество"
                      @keyup="fieldNotEmpty"
                      @focus="inpFocus"
                      @blur="inpBlur"
                      @input="justNumber(40,$event)"
                    )
                    input.js--normal-field.js--field-term(
                      ref="fieldTerm"
                      v-if="term==='month'"
                      inputmode="numeric"
                      placeholder="Введите количество"
                      @keyup="fieldNotEmpty"
                      @focus="inpFocus"
                      @blur="inpBlur"
                      @input="justNumber(480,$event)"
                    )
                    .calc-tax-deduc-new__input-clear.js--clear-calc-tax(
                      @click="clearInputTermAmount"
                    )

                  .radio-button-switch.mor-rep-calculators__radio-button-switch.js--for-clear-field.js--for-clear-radio-term
                    .radio-button-switch__item
                      input.js--radio-term#fid-1(
                        ref="switchTermYear"
                        type='radio'
                        name='term'
                        value='year'
                        checked="checked"
                        @change="changeMortgageTerm"
                      )
                      label(for='fid-1') Годы
                    .radio-button-switch__item.mor-rep-calculators__switch
                      input.js--radio-term#fid-2(
                        ref="switchTermMonth"
                        type='radio'
                        name='term'
                        value='month'
                        @change="changeMortgageTerm"
                      )
                      label(for='fid-2') Месяцы
                p.mor-rep-calculators__input-error.js--required-error.display-none Это поле обязательное для заполнения

          .calc-tax-deduc-new__row.js--tax-deduc-row
              .calc-tax-deduc-new__container-block
                .calc-tax-deduc-new__row-title-container
                  p.calc-tax-deduc-new__row-title Тип платежа

                .mor-rep-calculators__row-flex.height
                  .mor-rep-calculators__radio-type.js--for-clear-field.js--for-clear-radio-type-payment
                    .checkbox-stylized.feed_back__user-form-subscription.mor-rep-calculators__parent-tooltip-mobile.js--checkbox_wrapper.js--tooltip-parent
                      .personal-office__user-form-subscription-em
                      .feed_back__user-form-block.calc-tax-deduc-new__row-title-container
                        input#ann(

                          type="radio"
                          value="annuity"
                          name="type"
                          checked="checked"
                          @change="paymentType"
                        )
                        label.feed_back__radio-label(for='ann')
                          p Аннуитетный
                        span.content-note.desctop.content-note__center.js--content-note(v-if="tooltip_information['annuity-payment']!==''")
                          span.content-note__text {{tooltip_information["annuity-payment"]}}
                        span.content-note.mobile(
                          v-if="tooltip_information['annuity-payment']!==''"
                          @click="openTooltipMobile"
                        )
                      div(v-if="tooltip_information['annuity-payment']!==''")
                        .select__background.modal-special-background(@click="closeTooltipMobile")
                        .select-list__selection-window.modal-special-styles.js--openlist-body
                          .select-list__head
                            p Тип платежа
                            .select-list__head-close(@click="closeTooltipMobile")
                              svg(width='10', height='10', viewbox='0 0 10 10', fill='none', xmlns='http://www.w3.org/2000/svg')
                                path(fill-rule='evenodd', clip-rule='evenodd', d='M0.209209 0.209209C0.488155 -0.0697365 0.940416 -0.0697365 1.21936 0.209209L5 3.98985L8.78064 0.209209C9.05958 -0.0697365 9.51184 -0.0697365 9.79079 0.209209C10.0697 0.488155 10.0697 0.940416 9.79079 1.21936L6.01015 5L9.79079 8.78064C10.0697 9.05958 10.0697 9.51184 9.79079 9.79079C9.51184 10.0697 9.05958 10.0697 8.78064 9.79079L5 6.01015L1.21936 9.79079C0.940416 10.0697 0.488155 10.0697 0.209209 9.79079C-0.0697365 9.51184 -0.0697365 9.05958 0.209209 8.78064L3.98985 5L0.209209 1.21936C-0.0697365 0.940416 -0.0697365 0.488155 0.209209 0.209209Z', fill='#252628')
                          .select-list__wr-search.mor-rep-calculators__wr-search
                            p {{tooltip_information["annuity-payment"]}}

                    .checkbox-stylized.feed_back__user-form-subscription.mor-rep-calculators__parent-tooltip-mobile.js--tooltip-parent.js--checkbox_wrapper
                      .personal-office__user-form-subscription-em
                      .feed_back__user-form-block.calc-tax-deduc-new__row-title-container
                        input#dif(
                          ref="differentiatedCheck"
                          type="radio"
                          value="differentiated"
                          name="type"
                          @change="paymentType"
                        )
                        label.feed_back__radio-label.calc-tax-deduc-new__row-title-container(for='dif')
                          p Дифференцированный
                        span.content-note.desctop.content-note__center.js--content-note(v-if="tooltip_information['differentiated-payment']!==''")
                          span.content-note__text {{tooltip_information["differentiated-payment"]}}
                        span.content-note.mobile(
                          v-if="tooltip_information['differentiated-payment']!==''"
                          @click="openTooltipMobile"
                        )
                      div(v-if="tooltip_information['differentiated-payment']!==''")
                        .select__background.modal-special-background(@click="closeTooltipMobile")
                        .select-list__selection-window.modal-special-styles.js--openlist-body
                          .select-list__head
                            p Тип платежа
                            .select-list__head-close(@click="closeTooltipMobile")
                              svg(width='10', height='10', viewbox='0 0 10 10', fill='none', xmlns='http://www.w3.org/2000/svg')
                                path(fill-rule='evenodd', clip-rule='evenodd', d='M0.209209 0.209209C0.488155 -0.0697365 0.940416 -0.0697365 1.21936 0.209209L5 3.98985L8.78064 0.209209C9.05958 -0.0697365 9.51184 -0.0697365 9.79079 0.209209C10.0697 0.488155 10.0697 0.940416 9.79079 1.21936L6.01015 5L9.79079 8.78064C10.0697 9.05958 10.0697 9.51184 9.79079 9.79079C9.51184 10.0697 9.05958 10.0697 8.78064 9.79079L5 6.01015L1.21936 9.79079C0.940416 10.0697 0.488155 10.0697 0.209209 9.79079C-0.0697365 9.51184 -0.0697365 9.05958 0.209209 8.78064L3.98985 5L0.209209 1.21936C-0.0697365 0.940416 -0.0697365 0.488155 0.209209 0.209209Z', fill='#252628')
                          .select-list__wr-search.mor-rep-calculators__wr-search
                            p {{tooltip_information["differentiated-payment"]}}
                  //кнопка очистить
                  .mor-rep-calculators__clear-block(
                    v-show="allFieldsFilled"
                    @click="multiClickClearAllLoanAmount"
                  )
                    .mor-rep-calculators__clear-block-icon

                    p Очистить


</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import componentCalendar from './v-2-component-calendar-mortgage-data.vue';
import numberFormatting from '../mixin/numberFormatting.js';
import IMask from 'imask';

let maskCalendarMortgageData

let mask_interest;
export default {
  name: 'v-component-information-mortgage',
  mixins: [numberFormatting],
  props:['answers','tooltip_information', 'screenWidth'],
  data(){
    return {
      mask_interest:null,
      term:'year',
      //поля
      payment_type:'annuity',
      a_calculation:null,// исходный ежемесячный платеж (нужно передавать в стейт)
      n_calculation:0, // количество платежей (возможно нужно передавать в общий стейт)

      date_receipt_mortgage:null, //дата получения ипотеки
      field_loan_term:null, //срок кредита
      field_loan_term_error:'',
      loan_amount:0, //сумма кредита
      i_calculation:0,//  ежемесячная процентная ставка (возможно не нужно передавать в стейт)



    }
  },
  methods:{
    //ВБИВАНИЯ В ПОЛЯ

    receivedTimeDataLoan(data){
      eventBus.$emit('emitTimeDataLoan',data)
    },


    //отправляю сумму кредита
    loanAmount(el) {
      let element;
      if (el instanceof Event) {
       element = el.currentTarget;
      }
      else if(el instanceof HTMLElement ) {
        element = el;
      }

      let parse_element = element.value.replace(/\s/g, '')
      this.loan_amount = parseInt(parse_element)
      if (element.value.length>0) {
        this.$emit('sendLoanAmountForHolidays',this.loan_amount)
        if (element.classList.contains('js-mor-required')) {
          element.classList.add('js-filled')
          this.$emit('sendButtonResult')
        }
        if (element.closest('.js--container-block')
          && element.closest('.js--container-block').querySelector('.js--required-error')) {
          element.closest('.js--container-block').querySelector('.js--required-error').classList.add('display-none')
        }
        if (element.closest('.js--for-clear-field')) {
          element.closest('.js--for-clear-field').classList.remove('input_error')
        }


      }
      else if (element.value.length===0) {
        this.loan_amount=0
        element.classList.remove('js-filled')
        this.$emit('sendButtonResult')

      }
    },

    ////ввод только цифр в строке
    justNumber(count,e){
      let element;
      if (e instanceof Event) {
        element = e.currentTarget;
      }
      else if(e instanceof HTMLElement ) {
        element = e;
      }
      element.value = element.value.replace(/[^\d]/g, '');

      if (element.value.length > 0 && element.value[0] === '0'){
        element.value = '1' +  element.value.slice(1)
      }

      // if (element.value.length>count){
      //   element.value = element.value.substring(0, count);
      // }


      if (parseInt(element.value) > count) {
        element.value = count
      }



      this.field_loan_term_error=element.value


      if (element.value.length===0) {
        this.field_loan_term=null
        if (element.closest('.js-mor-required')) {
          element.closest('.js-mor-required').classList.remove('js-filled')
          this.$emit('sendButtonResult')
        }
        if (element.closest('.js--for-clear-field')) {
          element.closest('.js--for-clear-field').classList.remove('input_error')
        }
        eventBus.$emit('emitMonthlyPayment',0)
      }
      else if(element.value.length>0) {
        this.field_loan_term = parseInt(element.value)
        if (this.term==='year') {
          this.n_calculation = this.field_loan_term * 12
        } else {
          this.n_calculation = this.field_loan_term
        }
        if (element.closest('.js-mor-required').classList.contains('js-mor-required')) {
          element.closest('.js-mor-required').classList.add('js-filled')
          this.$emit('sendButtonResult')
        }
        if (element.closest('.js--container-block')
          && element.closest('.js--container-block').querySelector('.js--required-error')) {
          element.closest('.js--container-block').querySelector('.js--required-error').classList.add('display-none')
        }
        if (element.closest('.js--for-clear-field')) {
          element.closest('.js--for-clear-field').classList.remove('input_error')
        }

        //передаю срок кредита в родитель и в компоненту Ипотечные каникулы и Досрочное погашение
        eventBus.$emit('emitMonthlyPayment',this.n_calculation)
      }




    },

    //СТИРАНИЯ ПОЛЕЙ

    //стирание в поле сумма ипотеки находится в файле nimbertFormattng.js
    receivedClearDateReceive(){

      this.date_receipt_mortgage=null
      //отправил стирание в календарь каникул и досрочки
      eventBus.$emit('emitClearCalendarHolidaysPayment')
      this.$emit('sendButtonResult')
    },

    //стираю срок кредита
    clearInputTermAmount(e){
      const element = e.currentTarget;
      const parent = element.closest('.js--tex-deduc-input');
      if (parent) {
        parent.querySelector('input').value='';
        parent.querySelector('input').classList.remove('active')
        parent.classList.remove('js-filled')
        element.classList.remove('active')
      }
      this.field_loan_term=null
      this.field_loan_term_error=''
      eventBus.$emit('emitMonthlyPayment',0)
      this.$emit('sendButtonResult')
    },

    //Очистка поля с процентами
    clearInputPercent(el) {
      const element = el.currentTarget
      const parent = element.closest('.js--tex-deduc-input');
      if (parent) {
        this.mask_interest.value='';
        parent.querySelector('input').classList.remove('active')
        element.classList.remove('active')
      }
      this.i_calculation=0
      if (element.closest('.js--for-clear-field')
        && element.closest('.js--for-clear-field').querySelector('.js-mor-required')) {
        element.closest('.js--for-clear-field').querySelector('.js-mor-required').classList.remove('js-filled')
      }
      this.$emit('sendButtonResult')

    },




    //именение радио-кнопок Годы - месяцы, в зависимости от данных формируется вввод в поле "Срок кредита"
    // возможность вбивать двух или трёхзначное число
    changeMortgageTerm(el) {
      const element = el.currentTarget
      this.term = element.getAttribute('value')

      if (this.field_loan_term!==null){
        if (this.term==='year') {
          this.n_calculation = this.field_loan_term * 12
        } else {
          this.n_calculation = this.field_loan_term
        }
      } else {
        this.n_calculation = 0
      }

      //передаю срок кредита в родитель и в компоненту Ипотечные каникулы
      eventBus.$emit('emitMonthlyPayment',this.n_calculation)


    },
    //маска для ввода процентов
    inputRate(){
      const input_status = document.querySelectorAll('.js--interest-rate-calc input');
      const maskOptions = {
        mask: Number,
        scale: 2,
        thousandsSeparator: '',
        padFractionalZeros:false,
        normalizeZeros:'trim',
        // padFractionalZeros: true,
        radix: ',',
        mapToRadix: ['.',','],
        min: 0.1,
        max: 100,
        autofix:true,
        // validate:function (value) {
        //   return value ===0 || value >=0.1
        // }

        // autofix:true
      };
      for (const item of input_status) {
        // eslint-disable-next-line no-new
        this.mask_interest = IMask(item, maskOptions);
      }
      this.mask_interest.on('accept',()=>{
        const parse_element = this.mask_interest.value.replace(',', '.')
        this.i_calculation = parseFloat(parse_element)
        if (this.mask_interest.value.length===0) {
          this.i_calculation=0
        }

      })
    },
    //ограничение ввода процентной ставки, число не больше 100
    maxPercent(el) {
      let element;
      if (el instanceof Event) {
        element = el.currentTarget;
      }
      else if(el instanceof HTMLElement ) {
        element = el;
      }
      if (parseInt(element.value)>100){
        element.value=100
      }
      if(element.value=='100,') {
        element.value=100
      }
      if (element.value.length>0) {
        if (element.classList.contains('js-mor-required')) {
          element.classList.add('js-filled')
          this.$emit('sendButtonResult')
        }
        if (element.closest('.js--container-block')
          && element.closest('.js--container-block').querySelector('.js--required-error')) {
          element.closest('.js--container-block').querySelector('.js--required-error').classList.add('display-none')
        }
        if (element.closest('.js--for-clear-field')) {
          element.closest('.js--for-clear-field').classList.remove('input_error')
        }

      }
      else if (element.value.length===0) {
        element.classList.remove('js-filled')
        this.$emit('sendButtonResult')
      }
    },


    // общая функция для методов при вводе в поле срок кредита
    multiplyActionsInputLoanTerm(perem,el) {
      this.justNumber(perem,el)
      this.totalCountPayments(el);
    },

    //передаю в родитель, что стёрли поле сумма кредита
    clearInputLoanAmount(e) {
      const element = e.currentTarget
      const container = element.closest('.js--container-block')

      if (element.closest('.js--for-clear-field')
        && element.closest('.js--for-clear-field').querySelector('.js-mor-required')) {
        element.closest('.js--for-clear-field').querySelector('.js-mor-required').classList.remove('js-filled')
      }

      this.$emit('sendClearInputLoanAmount')
      this.$emit('sendButtonResult')
    },
    clearInputLoanAmountAll(e) {
      const element = e.currentTarget
      const container = element.closest('.js--container-block')
      const array_requared = container.querySelectorAll('.js-mor-required')
      for (let item of array_requared) {
        item.classList.remove('js-filled')
      }
      this.$emit('sendButtonResult')

      this.mask_interest.value='';

      this.$emit('sendClearInputLoanAmount')
    },



    //---------------------------------------------------------------------------------------------

    //общая функция для клика по стереть все поля блока
    multiClickClearAllLoanAmount(e) {
      this.clearAllFieldBlock(e)
      this.clearInputLoanAmountAll(e)
    },

    //очистить все поля блока
    clearAllFieldBlock(el) {
      const element = el.currentTarget
      const parent = element.closest('.js--container-block');
      if (parent) {
        const array_block_input = parent.querySelectorAll('.js--for-clear-field')
        for (let item of array_block_input) {
          if (item.querySelector('input.js--normal-field')) {
            item.querySelector('input.js--normal-field').value = ''
          }
          //при клике очистить всё переключение в дефолтное состояние радиокнопки группы срок кредита в группе данные об ипотеке
          if (item.classList.contains('js--for-clear-radio-term')) {
            if(item.querySelector('input[type="radio"]').value==='year') {
              item.querySelector('input[type="radio"]').click();
            }
          }
          //при клике очистить всё переключение в дефолтное состояние радиокнопки группы тип платежав группе данные об ипотеке
          if (item.classList.contains('js--for-clear-radio-type-payment')) {
            if(item.querySelector('input[type="radio"]').value==='annuity') {
              item.querySelector('input[type="radio"]').click();
            }
          }

          //при клике очистить всё очищение поля инпут календаря
          if (item.querySelector('input.js--calendar-field')) {
            item.querySelector('input.js--calendar-field').value = ''
          }
          if (item.querySelector('.js--clear-calc-tax')) {
            item.querySelector('.js--clear-calc-tax').classList.remove('active')
          }
          //отправил в календарь что всё стёрли
          eventBus.$emit('emitClearCalendarHolidaysPaymentAll')

          //отправляю в календарь блока
          eventBus.$emit('emitClearCalendarHolidaysPayment')



        }
      }

      this.date_receipt_mortgage=null
      this.field_loan_term=null
      this.field_loan_term_error=''
      this.loan_amount=0
      this.i_calculation=0
      eventBus.$emit('emitMonthlyPayment',0)
    },


    //-----------------------------------------------------------------------------------

    //общая функция для клика по стереть поле Сумма кредита
    multiClickCloseLoanAmount(e) {
      this.clearInput(e)
      this.clearInputLoanAmount(e)
    },

    // общая функция для методов при вводе в поле сумма кредита
    multiplyActionsInpuLoanAmount(perem,el) {
      this.numberFormattingThousandths(perem,el)
      //сумма кредита
      this.loanAmount(el)
    },


    //формирую тип платежа
    paymentType(el){
      const element = el.currentTarget
      this.payment_type = element.value
    },


    //РАСЧЁТ И ОТПРАВКА ДАННЫХ РОДТЕЛЬСКОМУ КОМПОНЕНТУ

    //получил данные календаря "Дата получения кредита" записал в переменную для отправки потом родителю, следующей строкой в компонент Ипотечные каникулы и досрочное погашение
    receivedDateLoanReceipt(data) {
      this.date_receipt_mortgage=data
      eventBus.$emit('emitDateLoanReceipt',data)
      this.$emit('sendButtonResult')
    },

    //расчёт общего количества ежемесячных платежей - n_calculation
    totalCountPayments(el){
      // const element = el.currentTarget;
      // this.field_loan_term = parseInt(element.value)
      //
      // if (this.term==='year') {
      //   this.n_calculation = this.field_loan_term * 12
      // } else {
      //   this.n_calculation = this.field_loan_term
      // }
      // //передаю срок кредита в родитель и в компоненту Ипотечные каникулы и Досрочное погашение
      // eventBus.$emit('emitMonthlyPayment',this.n_calculation)
    },






  },
  watch:{
    allFieldsFilled() {
      if (this.allFieldsFilled) {

      }
    },



    //ошибка, если поле не заполнено воззвращает underfind
    term() {
      if (this.term==='year' && this.$refs.fieldTerm.value.length > 2) {
        this.$refs.fieldTerm.value = parseInt(parseInt(this.$refs.fieldTerm.value) / 12);
        this.field_loan_term = this.$refs.fieldTerm.value
      }
      if (this.term==='year' && this.field_loan_term!==null) {
        this.n_calculation = this.field_loan_term * 12
      }
      else if (this.term==='month' && this.field_loan_term!==null) {
        this.n_calculation = this.field_loan_term
      }
      //(возможно передавать и не нужно, нужна для расчётов тут, пока просто для тестирования)
      // this.$emit('sendMonthlyPayment',this.n_calculation)

    },






  },
  mounted(){
    this.inputRate();
    //когда страница только загрузилась передаю в компоненту Ипотечные каникулы срок кредита = нулю
    eventBus.$emit('emitMonthlyPayment',this.n_calculation)


    if(this.answers.length>0&&Object.keys(this.answers[0]).length!==0){
      //подставляю сумму кредита
      if (this.answers[0].loanAmount) {
        this.$refs.inputLoanAmount.value=new Intl.NumberFormat("ru-RU").format(this.answers[0].loanAmount);
        this.fieldNotEmpty(this.$refs.inputLoanAmount)
        this.loanAmount(this.$refs.inputLoanAmount)
      }
      //время года месяц - год




      //подставляю ставку
      if (this.answers[0].bet) {
        this.$refs.inputPersent.value=(this.answers[0].bet).toString().replace(/\./g, ',')
        this.mask_interest.value=(this.answers[0].bet).toString().replace(/\./g, ',')
        this.maxPercent(this.$refs.inputPersent)
        this.fieldNotEmpty(this.$refs.inputPersent)
        this.i_calculation = parseFloat(this.answers[0].bet)
      }


      //подставляю срок кредита
      if(this.answers[0].term && this.answers[0].term==='month') {
        this.$refs.switchTermMonth.click()
      }
      if (this.answers[0] && this.answers[0].loanTerm){
        if(this.answers[0].term==='month') {
          this.$refs.fieldTermWrapper.querySelector('.js--field-term').value = this.answers[0].loanTerm
          this.justNumber(480,this.$refs.fieldTerm)
        }
        else if (this.answers[0].term==='year') {
          this.$refs.fieldTermWrapper.querySelector('.js--field-term').value = parseInt(this.answers[0].loanTerm) / 12
          this.justNumber(40,this.$refs.fieldTerm)
        }

        this.fieldNotEmpty(this.$refs.fieldTermWrapper.querySelector('.js--field-term'))

      }

      //подставляю тип платежа
      if(this.answers[0].paymentType && this.answers[0].paymentType==='differentiated') {
        this.$refs.differentiatedCheck.click()
      }
      if(this.answers[0].dateReceipt) {
        const dateReceipt = JSON.parse(this.answers[0].dateReceipt);
        const time_data_loan = parseInt(dateReceipt[1]) *12 + parseInt(dateReceipt[0])+1
        eventBus.$emit('emitTimeDataLoan',time_data_loan)
        eventBus.$emit('emitDateLoanReceipt',dateReceipt)
      }


      // console.log('Ансвер');
      // console.log(this.answers[0]);

    }

  },
  computed:{
    allFieldsFilled() {
      if (
        this.date_receipt_mortgage !==null ||
        this.field_loan_term_error !=='' ||
        this.loan_amount !==0 ||
        this.i_calculation !==0
      ) {
        return true
      }
    }

  },


  components:{
    componentCalendar

  },
  created(){
    //была нажата кнопка рассчитать
    eventBus.$on('sendtotalCalculation', () => {
      this.$emit('sendDateLoanReceipt',this.date_receipt_mortgage)
      this.$emit('sendMonthlyPayment',this.n_calculation)
      this.$emit('sendMonthlyInterestRate',this.i_calculation)
      this.$emit('sendLoanAmount',this.loan_amount)
      this.$emit('sendPaymentType',this.payment_type)
      this.$emit('sendTermMonthOrYear',this.term)
    })
  }
};
</script>
<style scoped>
</style>
