<template lang="pug">
  .calc-tax-deduc-new__container-block.js--calc-row-input.js--container-block-required

    .calc-tax-deduc-new__col-input.js--credit-calendar-input.js--tex-deduc-input.js--for-clear-field.js--calendar-data
      //input.property-calculator__value.js--calendar-field.js--calendar-field-end.js-early-period-required(
        //type="text"
        //placeholder="ММ.ГГГГ"
        //inputmode="numeric"
        //@keyup="fieldNotEmpty"
        //@click ="showCalendar"
        //@blur="replaceMonthNew"
        //ref="inputEnd"
        //@focus="replaceMonthFocus"
        //:readonly="isReadonly"
        //@input = "handleInput"
      //)
      input.property-calculator__value.js--calendar-field.js--calendar-field-end.js-early-period-required(
        type="text"
        placeholder="ММ.ГГГГ"
        inputmode="numeric"
        ref="inputEnd"
        @focus="replaceMonthFocusNew"
        @blur="inputBlur"
        @keyup="fieldNotEmpty"
        @click="showCalendar"
        @input = "changeDate"
        @keydown="inputKeyDown"
      )


      .js__vanilla-calendar-calc.vanilla-calendar-style-new.property-calculator__vanilla-calendar(
        :class="calendarContainerId"
        @click.stop ="showCalendar"


      )
      .mor-rep-calculators__calendar-container-icon
        .calc-tax-deduc-new__input-clear.js--clear-calc-tax.js--clear-input-period-end(
            @click="clearInputCalendarEarlyRepayment"
          )
        .property-calculator__input-additional-elem(
          @click ="showCalendar"
        )
          svg(width='16', height='16', viewbox='0 0 16 16', fill='none', xmlns='http://www.w3.org/2000/svg')
            path(fill-rule='evenodd', clip-rule='evenodd', d='M4.66699 0.666687C5.03518 0.666687 5.33366 0.965164 5.33366 1.33335V2.00002H10.667V1.33335C10.667 0.965164 10.9655 0.666687 11.3337 0.666687C11.7018 0.666687 12.0003 0.965164 12.0003 1.33335V2.00002H14.0609C14.696 2.00002 15.3337 2.47837 15.3337 3.21214V14.1212C15.3337 14.855 14.696 15.3334 14.0609 15.3334H1.93972C1.30462 15.3334 0.666992 14.855 0.666992 14.1212V3.21214C0.666992 2.47837 1.30462 2.00002 1.93972 2.00002H4.00033V1.33335C4.00033 0.965164 4.2988 0.666687 4.66699 0.666687ZM4.00033 3.33335H2.00033V6.00002H14.0003V3.33335H12.0003V4.00002C12.0003 4.36821 11.7018 4.66669 11.3337 4.66669C10.9655 4.66669 10.667 4.36821 10.667 4.00002V3.33335H5.33366V4.00002C5.33366 4.36821 5.03518 4.66669 4.66699 4.66669C4.2988 4.66669 4.00033 4.36821 4.00033 4.00002V3.33335ZM14.0003 7.33335H2.00033V14H14.0003V7.33335Z', fill='#252628')
    p.mor-rep-calculators__input-error.js--required-error.display-none Это поле обязательное для заполнения
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
// import IMask from 'imask';
import VanillaCalendar from '../../vanilla-calendar2';
import numberFormatting from '../mixin/numberFormatting.js';
import IMask from 'imask';
let maskCalendarMortgageData
export default {
  name: 'v-2-component-calendar',
  mixins: [numberFormatting],
  props:['time_data_loan','answers','class_calendar','blockId','array_selected_dates', 'min_date_holidays_end','max_date','loan_term','array_block_early_repayment_end'],
  data(){
    return {
      calendarEarlyPeriodEnd:null,
      parent:null,
      index_block:null,

      calendarContainerId:`calendar-end-${this.blockId}`,
      imask:null,
      rawValue:'',
      formattedValue:'',
      isReadonly:true,
      lastValueOnFocus:'',
      month:['январь', 'февраль', 'март', 'апрель', 'май', 'июнь', 'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь'],

      minYear:new Date().getFullYear() - 30,
      maxYear:new Date().getFullYear() + 1,
      minMonth:1,
      maxMonth:12,

      minDate: {month:1,year:new Date().getFullYear() - 30,flag:0},
      maxDate: {month:12,year:new Date().getFullYear() + 1},
      time_holiday:0,

      //Дополнительно
      activeCalendar: null,
      viewportHandler: null,
      isMobile: false
    }
  },
  methods:{
    destroyCalendar(){
      if (this.calendarEarlyPeriodEnd!==null) {
        this.calendarEarlyPeriodEnd.destroy()
        this.calendarEarlyPeriodEnd=null
      }
    },

    updateCalendar(){
      if (this.min_date_holidays_end==='1995-01-01') {
        this.destroyCalendar()
        this.initPluginCalendarPeriodEnd()
      }
      else{
        this.destroyCalendar()
        this.initPluginCalendarPeriodEnd(this.formatYearMonthSelected(this.min_date_holidays_end)[1], this.formatYearMonthSelected(this.min_date_holidays_end)[0])
      }
    },

    initPluginCalendarPeriodEnd(month=new Date().getMonth(),year=new Date().getFullYear()){

      const key_word_this=this
      // let range={
      //   min: key_word_this.formatYearMonthMinDate(key_word_this.min_date_holidays_end),
      //   max: key_word_this.formatYearMonthMaxDate(key_word_this.min_date_holidays_end)
      // }

      let range={
        min: `${key_word_this.minDate.year}-${String(key_word_this.minDate.month).padStart(2,'0')}`,
        max: `${key_word_this.maxDate.year}-${String(key_word_this.maxDate.month).padStart(2,'0')}`
      }


      const element = document.querySelector(`.${this.calendarContainerId}`)
      if (element!==null) {
      //   this.parent = element.closest('.js--container-block')
      //   this.index_block=parseInt(this.parent.getAttribute('data-index'))
        this.calendarEarlyPeriodEnd = new VanillaCalendar(`.${this.calendarContainerId}`, {
          type: 'year',

          settings: {
            lang: 'ru',
            range: range,

            selected: {
              month: month,
              year:year
            },

            selection: {

            },
          },
          actions: {
            clickMonth(e, dates) {

              if (dates.length !== 0) {
                const parent = e.target.closest('.js--credit-calendar-input');
                const container = e.target.closest('.js__vanilla-calendar-calc')
                const array_month = [ 'январь', 'февраль', 'март', 'апрель', 'май', 'июнь', 'июль', 'август', 'сентябрь', 'октябрь', 'ноябрь', 'декабрь']
                let title_month;
                let title_year;
                if (container && container.querySelector('.vanilla-calendar-year')) {
                  title_year = container.querySelector('.vanilla-calendar-year').textContent
                }
                if(parent){
                  e.target.closest('.js__vanilla-calendar-calc').classList.remove('active');
                  parent.querySelector('input').value = `${array_month[dates.selectedMonth]}, ${dates.selectedYear}`;

                  if(parent.querySelector('input').classList.contains('js-early-period-required')) {
                    parent.querySelector('input').classList.add('js-filled')
                  }
                  if (parent.closest('.js--container-block-required')
                    && parent.closest('.js--container-block-required').querySelector('.js--required-error')) {
                    parent.closest('.js--container-block-required').querySelector('.js--required-error').classList.add('display-none')
                  }
                  if (parent.closest('.js--for-clear-field')) {
                    parent.closest('.js--for-clear-field').classList.remove('input_error')
                  }
                  key_word_this.time_holiday = (parseInt(dates.selectedYear) * 12) + (parseInt(dates.selectedMonth) + 1)
                  key_word_this.receivedEearlyRepaymentPeriodEnd([dates.selectedMonth,dates.selectedYear],e,parseInt(key_word_this.blockId))

                  if (e.target.closest('.js--calc-row-input')) {
                    e.target.closest('.js--calc-row-input').querySelector('.js--clear-calc-tax').classList.add('active')
                  }


                  const data = parseInt(e.target.closest('.js--container-block').getAttribute('data-index'))
                }
              }
              dates.type = 'year'
            },
            clickYear(event, self) {
              const selectedYear = self.selectedYear;
              self.type = 'month'
            }
          }
        })
        this.calendarEarlyPeriodEnd.init();
      }

    },
    CalendarVanillaClose() {
      let count = 0;
      const handler = () => {
        const array_parent = document.querySelectorAll('.js--credit-calendar-input');
        const array_element = document.querySelectorAll('.js__vanilla-calendar-calc.active');
        for (const item of array_parent) {
          item.onclick = function (w) {
            w.stopImmediatePropagation();
          };
        }
        if (count > 0) {
          for (let i = 0; i < array_element.length; i++) {
            array_element[i].classList.remove('active');
          }
        }
        if (count < 1) {
          count += 1;
        }
      };
      document.body.addEventListener('click', handler);
    },
    changeDate(e) {
      const target = e.target;

      if (target.value.length>0) {
        if(target.classList.contains('js-early-period-required')) {
          target.classList.add('js-filled')
        }
        if (target.closest('.js--container-block-required')
          && target.closest('.js--container-block-required').querySelector('.js--required-error')) {
          target.closest('.js--container-block-required').querySelector('.js--required-error').classList.add('display-none')
        }
        if (target.closest('.js--for-clear-field')) {
          target.closest('.js--for-clear-field').classList.remove('input_error')
        }
      }



      let value = target.value.replace(/[^\d.]/g, '');
      let parts = value.split('.')
      let monthPart = parts[0].substring(0,2);
      let yearPart = parts[1] ? parts[1].substring(0,4) : '';

      let newValue = monthPart;
      if (monthPart.length>=2 || (parts.length > 1 && yearPart.length > 0)) {
        newValue += '.' + yearPart
      }
      if (newValue !== target.value) {
        const cursorPos = target.selectionStart;
        target.value = newValue;
        target.setSelectionRange(cursorPos, cursorPos)
      }

      if (target.value.length === 3 && newValue[2] === '.') {
        target.setSelectionRange(3,3)
      }

      if (target.value.replace(/(_|\s)+/g, "").length===7) {
        let [monthStr, yearStr] = e.target.value.split('.')
        let month = parseInt(monthStr, 10) || 0;
        let year = parseInt(yearStr, 10) || 0;
        if (month < 1 || month >12) month = Math.min(Math.max(month, 1), 12);

        if (year < this.minDate.year) {
          year = this.minDate.year;
          month = this.minDate.month;
        } else if (year >this.maxDate.year) {
          year = this.maxDate.year;
          month = this.maxDate.month
        }
        if (year === this.minDate.year) month = Math.max(month, this.minDate.month);
        if (year === this.maxDate.year) month = Math.min(month, this.maxDate.month);
        const current = {month,year};
        if (this.dateToNumber(current) < this.dateToNumber(this.minDate)) {
          Object.assign(current,this.minDate);
        } else if (this.dateToNumber(current) > this.dateToNumber(this.maxDate)) {
          Object.assign(current,this.maxDate);
        }
        this.time_holiday = (parseInt(current.year) * 12) + parseInt(current.month)
        e.target.value = this.formatDate(current.month, current.year)
      }

      if (target.value.replace(/(_|\s)+/g, "").length===7 && target.value.replace(/(_|\s)+/g, "").substr(3, 6)<=new Date().getFullYear()) {
        const month = parseInt(target.value.replace(/(_|\s)+/g, "").substr(0, 2) -1);
        const year = target.value.replace(/(_|\s)+/g, "").substr(3, 6)

        if (this.calendarEarlyPeriodEnd!==null) {
          this.calendarEarlyPeriodEnd.destroy()
          this.calendarEarlyPeriodEnd=null
        }
        this.destroyCalendar()
        this.initPluginCalendarPeriodEnd(month,year)
        this.$emit('' +
          '', [[month,year],parseInt(this.blockId)]);
        setTimeout(()=>{
          target.closest('.js--credit-calendar-input').querySelector('.js__vanilla-calendar-calc').classList.remove('active')
        },300)

      }
    },
    formatDate(month, year){
      return `${String(month).padStart(2, '0')}.${String(year).padStart(4,'0')}`
    },
    dateToNumber(date){
      return date.year * 12 + (date.month - 1);
    },
    replaceMonthFocusNew(e){
      let element;
      if (e instanceof Event) {
        element = e.currentTarget;
      }
      else if(e instanceof HTMLElement ) {
        element = e;
      }
      const currentValue = element.value;
      const parts = currentValue.split(', ');

      if (parts.length === 2) {
        const [monthName, year] = parts;
        const monthIndex = this.month.indexOf(monthName)
        if (monthIndex !== -1 && year.length === 4) {
          element.value = `${String(monthIndex + 1).padStart(2, '0')}.${year}`;
        }
      }
    },
    formatCheckDateInputYear(inputValue) {
      const parts = inputValue.split(',');
      const yearhName = parts[1]
      return yearhName
    },
    inputKeyDown(e){
      const target = e.target;
      if (e.key === 'Backspace' && target.selectionStart === 3) {
        target.setSelectionRange(2,2)
      }
    },
    inputBlur(e){
      const target = e.target;
      let [monthStr, yearStr] = e.target.value.split('.')
      let month = parseInt(monthStr, 10) || 0;
      let year = parseInt(yearStr, 10) || 0;
      if (!monthStr || !yearStr || monthStr.length !==2 || yearStr.length!==4) {
        e.target.value = ''
        if (target.classList.contains('js-early-period-required')) {
          target.classList.remove('js-filled');
        }
        if (target.closest('.js--for-clear-field')) {
          target.closest('.js--for-clear-field').querySelector('.js--clear-calc-tax').classList.remove('active')
        }

      } else {

        if (target.closest('.js--container-block')
          && target.closest('.js--container-block').querySelector('.js--required-error')) {
          target.closest('.js--container-block').querySelector('.js--required-error').classList.add('display-none');
        }
        if (target.closest('.js--for-clear-field')) {
          target.closest('.js--for-clear-field').classList.remove('input_error');
        }

        if (target.classList.contains('js-early-period-required')) {
          target.classList.add('js-filled');
        }

        this.$emit('sendEearlyRepaymentEnd',[[parseInt(month)-1,year],parseInt(this.blockId),'maska'])
      }
      this.replaceMonthNewEarly(target)
    },
    replaceMonthNewEarly(e) {
      let element;
      if (e instanceof Event) {
        element = e.currentTarget;
      }
      else if(e instanceof HTMLElement ) {
        element = e;
      }

      const value = element.value.trim();
      const parts=value.split('.')
      if (parts.length!==2) return;
      const monthPart = parts[0].trim()
      const yearPart = parts[1].trim()
      const monthNumber = parseInt(monthPart,10)
      if (isNaN(monthNumber) || monthNumber < 1 ||monthNumber > 12) return;
      element.value = `${this.month[monthNumber - 1]}, ${yearPart}`;
    },




    //ДОПОЛНИТЕЛЬНО
    showCalendar(el) {
      const element = el.currentTarget;
      const calendars = document.querySelectorAll('.js__vanilla-calendar-calc');

      calendars.forEach(calendar => calendar.classList.remove('active'));

      const calendar = element.closest('.js--credit-calendar-input')
        .querySelector('.js__vanilla-calendar-calc');
      calendar.classList.add('active');
      this.activeCalendar = calendar;


      // Для мобильных: добавляем обработчик клавиатуры
      if (this.isMobile) {
        this.addViewportListener();
      }
    },
    addViewportListener() {
      // Убедимся, что обработчик только один
      this.removeViewportListener();

      this.viewportHandler = () => {
        if (!this.activeCalendar) return;
        this.$nextTick(() => {
          this.scrollCalendarIntoView();
        });
      };

      // Используем visualViewport для мобильных устройств
      if (window.visualViewport) {
        window.visualViewport.addEventListener('resize', this.viewportHandler);
      }
    },
    removeViewportListener() {
      if (this.viewportHandler && window.visualViewport) {
        window.visualViewport.removeEventListener('resize', this.viewportHandler);
        this.viewportHandler = null;
      }
    },
    scrollCalendarIntoView() {
      if (!this.activeCalendar || !window.visualViewport) return;

      const calendarRect = this.activeCalendar.getBoundingClientRect();
      const viewportHeight = window.visualViewport.height;
      const calendarBottom = calendarRect.bottom - window.visualViewport.offsetTop;

      // Если календарь скрыт клавиатурой
      if (calendarBottom > viewportHeight) {
        // Вычисляем необходимую величину скролла
        const scrollOffset = calendarBottom - viewportHeight + 10;
        window.scrollBy({
          top: scrollOffset,
          behavior: 'smooth'
        });
      }
    },
    handleDocumentClick(e) {
      // Закрытие календаря при клике вне его области
      if (
        this.activeCalendar &&
        !e.target.closest('.js__vanilla-calendar-calc') &&
        !e.target.closest('.js--calendar-field')
      ) {
        this.activeCalendar.classList.remove('active');
        this.activeCalendar = null;
        this.removeViewportListener();
      }
    },

    //ВРЕМЕННО ЗАКОМЕНТИРОВАЛ
    //очищаю поля

    clearInputCalendarEarlyRepayment(e){
      const element = e.currentTarget;
      const parent = element.closest('.js--tex-deduc-input');
      if (element.closest('.js--for-clear-field')
        && element.closest('.js--for-clear-field').querySelector('.js-early-period-required')) {
        element.closest('.js--for-clear-field').querySelector('.js-early-period-required').classList.remove('js-filled')
      }

      if (parent) {
        parent.querySelector('input').value='';
        parent.querySelector('input').classList.remove('active')
        element.classList.remove('active')
      }

      if (this.min_date_holidays_end=='1995-01-01') {
        this.resetCalendar()
      }
      else {
        // this.destroyCalendar()
        // this.initPluginCalendarPeriodEnd(this.formatYearMonthSelected(this.min_date_holidays_end)[1], this.formatYearMonthSelected(this.min_date_holidays_end)[0])

        this.destroyCalendar()
        this.initPluginCalendarPeriodEnd(parseInt(this.minDate.month)-1,this.minDate.year)
      }

      //родителю календаря сказал, что поле очищено
      this.$emit('sendClearReceiveEarlyEnd',this.blockId)
      this.time_holiday=0
    },
    //очистить все поля блока


    receivedEearlyRepaymentPeriodEnd(data,el,index) {

      const parent = el.currentTarget.closest('.js--container-block')
      const data_el = parent.getAttribute('data-index')

      //отправляю в соседний календарь начала периода
      this.$emit('sendEearlyRepaymentEnd',[data,index])

    },

    formatYearMonthMinDate(dateStr) {
      if(dateStr!==null) {
        let [year, month] = dateStr.split('-');
        month = parseInt(month) + 2
        if (month === 13) {
          month = 1
          year = parseInt(year) + 1
        }
        if (month === 14) {
          month = 2
          year = parseInt(year) + 1
        }

        month = month.toString()
        const formattedMonth = month.padStart(2, '0');
        return `${year}-${formattedMonth}`;
      }
    },
    formatYearMonthMaxDate(dateStr) {
      if(dateStr!==null) {
        if (this.loan_term !== 0) {
          let [year, month] = dateStr.split('-').map(Number);
          const date = new Date(year, month, 1);
          date.setMonth((date.getMonth()) + this.loan_term);
          const newYear = date.getFullYear()
          const newMonth = date.getMonth()
          const formattedMonth = String(newMonth + 1).padStart(2,'0')
          return `${newYear}-${formattedMonth}`



          // date.setMonth((date.getMonth() + 1) + this.loan_term);
          // month = (date.getMonth()).toString()
          // const formattedMonth = month.padStart(2, '0');
          // return `${date.getFullYear()}-${formattedMonth}`
        } else if (this.loan_term === 0) {
          return `${new Date().getFullYear() + 1}-12`
        }
      }
    },
    formatYearMonthSelected(dateStr) {

      if(dateStr!==null&&dateStr!==undefined) {
        let [year, month] = dateStr.split('-');

        month = parseInt(month) + 1

        if (month === 12) {
          month = 0
          year = parseInt(year) + 1
        }
        // if (month===13){
        //   month=2
        //   year=parseInt(year)+1
        // }

        month = month.toString()
        const formattedMonth = month.padStart(2, '0');
        // return `${year}-${formattedMonth}`;
        return [`${year}`, `${formattedMonth}`];
      }
    },
    resetCalendar(){
      this.destroyCalendar()
      this.initPluginCalendarPeriodEnd(new Date().getMonth(), new Date().getFullYear())

    },
    replaceMonth(e){
      const element = e.currentTarget
      const value = e.target.value.trim();
      const parts=value.split('.')
      if (parts.length!==2) return;
      const monthPart = parts[0].trim()
      const yearPart = parts[1].trim()
      const monthNumber = parseInt(monthPart,10)
      if (isNaN(monthNumber) || monthNumber < 1 ||monthNumber > 12) return;
      e.target.value = `${this.month[monthNumber - 1]}, ${yearPart}`;
      if (element.classList.contains('js-early-period-required')) {
        element.classList.add('js-filled')
      }
      if (element.closest('.js--container-block-required')
        && element.closest('.js--container-block-required').querySelector('.js--required-error')) {
        element.closest('.js--container-block-required').querySelector('.js--required-error').classList.add('display-none')
      }
      if (element.closest('.js--for-clear-field')) {
        element.closest('.js--for-clear-field').classList.remove('input_error')
      }
    },
    formatCheckDateInput(inputValue) {

      const parts = inputValue.split(',');

      if (parts.length !==2){

      }
      const monthName = parts[0].trim().toLowerCase();
      const monthNumber = this.month.indexOf(monthName) + 1

      if (monthName ===0) {
        throw new Error('некоректное название месяца')
      }
      return monthNumber

    },
    formattedDateInput(param, flag=0){
      if (flag===0) {
        const value = param
        const parts = value.split('-');
        if (parts.length !== 2) return;

        const year =parts[0];
        const monthNumber = parseInt(parts[1], 10)

        if (isNaN(monthNumber)) return;
        if (monthNumber < 0 || monthNumber > 11) return;

        return `${this.month[monthNumber]}, ${year}`
      }
      else if (flag===1) {
        const value = param
        const parts = value.split('-');
        if (parts.length !== 2) return;

        const year =parts[0];
        const monthNumber = parseInt(parts[1], 10)

        if (isNaN(monthNumber)) return;
        if (monthNumber < 0 || monthNumber > 11) return;

        return `${this.month[monthNumber +1]}, ${year}`
      }

    },

    inputMaskEarly() {
      const key = this
      if(this.imask) this.imask.destroy()
      this.imask = IMask(this.$refs.inputEnd, {
        mask: 'MM.YYYY',
        blocks: {
          MM: {
            mask: IMask.MaskedRange,
            from: 1,
            to: 12,
            // maxLength: 2,
            autofix:true
          },
          YYYY: {
            mask: IMask.MaskedRange,
            from: this.minYear,
            to: this.maxYear,
            autofix:true
            // maxLength: 4
          }
        }
      });
      this.imask.on('accept', () => {
        this.rawValue = this.imask.value
        this.correctDate()
      })
      this.imask.on('complete', () => {
        if (this.imask.value!==this.lastValueOnFocus){



          const month = parseInt(this.imask.value.replace(/(_|\s)+/g, "").substr(0, 2) -1);
          const year = this.imask.value.replace(/(_|\s)+/g, "").substr(3, 6)
          if (this.calendarEarlyPeriodEnd!==null) {
            this.calendarEarlyPeriodEnd.destroy()
            this.calendarEarlyPeriodEnd=null
          }
          this.destroyCalendar()
          this.initPluginCalendarPeriodEnd(month,year)
          // this.$emit('sendDateLoanReceipt', [[month,year],parseInt(this.blockId)]);
          this.$emit('sendEearlyRepaymentEnd',[[month,year],parseInt(this.blockId)])

          //наверное не нужно
          // this.$emit('sendDateLoanReceipt',[month,year])
          setTimeout(() => {
            this.$refs.inputEnd.closest('.js--credit-calendar-input')
              .querySelector('.js__vanilla-calendar-calc')
              .classList
              .remove('active')
          }, 400)
        }
      })
    },
    correctDate(){

      setTimeout(()=>{

        if (!this.imask.masked.isComplete) return
        let [month, year] = this.imask.value.split('.').map(Number)
        let newYear = Math.max(this.minYear, Math.min(this.maxYear, year))
        let newMonth = month;

        if (newYear ===this.minYear ) {
          newMonth = Math.max(this.minMonth, Math.min(12, newMonth))
        } else if (newYear ===this.maxYear) {
          newMonth = Math.max(1, Math.min(this.maxMonth, newMonth))
        } else {
          newMonth = Math.max(1, Math.min(12, newMonth))
        }

        if(newYear !== year || newMonth !==month) {
          const formattedDate = `${String(newMonth).padStart(2,'0')}.${String(newYear).padStart(4,'0')}`
          this.imask.value = formattedDate

          this.$nextTick(() => this.$emit('input',formattedDate))

        }
      },200)




    },
    handleInput(){

      this.$emit('input', this.imask.value)
    },
    replaceMonthNew(e) {
      const element = e.currentTarget;
      if (element.closest('.js--container-block-required')
        && element.closest('.js--container-block-required').querySelector('.js--required-error')) {
        element.closest('.js--container-block-required').querySelector('.js--required-error').classList.add('display-none')
      }
      if (element.closest('.js--for-clear-field')) {
        element.closest('.js--for-clear-field').classList.remove('input_error')
      }

      const [month,year] = this.rawValue.split('.')
      if(month && year && year.length === 4) {
        const monthNum = parseInt(month, 10);
        if (monthNum >=1 && monthNum <=12) {
          this.formattedValue = `${this.month[monthNum - 1]}, ${year}`;
          this.$refs.inputEnd.value = this.formattedValue;
        }
        if (element.classList.contains('js-early-period-required')) {
          element.classList.add('js-filled')
        }
      }
      if (this.rawValue.length!==7) {
        this.$refs.inputEnd.value = '';
        if (element.classList.contains('js-early-period-required')) {
          element.classList.remove('js-filled')
        }
        if (element.closest('.js--for-clear-field')) {
          element.closest('.js--for-clear-field').querySelector('.js--clear-calc-tax').classList.remove('active')
        }
      }

      this.isReadonly = true;
      // this.imask.destroy();
    },
    replaceMonthFocus(e){
      this.lastValueOnFocus = this.imask.value
      this.isReadonly = false;
      let raw = '';
      const currentValue = this.$refs.inputEnd.value;

      const parts = currentValue.split(', ');

      if (parts.length === 2) {
        const [monthName, year] = parts;
        const monthIndex = this.month.indexOf(monthName)
        if (monthIndex !== -1 && year.length === 4) {
          raw = `${String(monthIndex + 1).padStart(2, '0')}.${year}`;
        }

      }
      this.rawValue = raw;
      // this.inputMaskEarly();
      this.$nextTick(() => {
        this.imask.value = this.rawValue;
      })
    },
    getMonthName(month) {
      return this.month[month - 1] ||'...';
    },

    minDayHoliday(){
      if (this.min_date_holidays_end==='1995-01-01' && this.minDate.flag===0) {
        this.minDate.month = 1
        this.minDate.year = 1995
        this.maxDate.month = 12
        this.maxDate.year = new Date().getFullYear() + 1
      }
      else if(this.min_date_holidays_end!=='1995-01-01' && this.minDate.flag===0){
        let [year,month] = this.formatYearMonthMinDate(this.min_date_holidays_end).split('-');
        let [yearMax,monthMax] = this.formatYearMonthMaxDate(this.min_date_holidays_end).split('-');
        this.minDate.month = parseInt(month)
        this.minDate.year = parseInt(year)
        this.maxDate.month = parseInt(monthMax)
        this.maxDate.year = parseInt(yearMax)


        // const split_min_date_holidays = this.min_date_holidays_end.split('-');
        // const split_year = parseInt(split_min_date_holidays[0])
        // const split_month = parseInt(split_min_date_holidays[1])
        // if (split_month<11){
        //   this.minDate.month = split_month + 2
        //   this.minDate.year = split_year
        // }
        // else if (split_month===11) {
        //   this.minDate.month = 1
        //   this.minDate.year = split_year + 1
        // }
      }
      this.destroyCalendar()
      this.initPluginCalendarPeriodEnd()
    },

    calculateMaxDate(minDate,loan) {

      // let totalMonths;
      // if (loan!==0) {
      //   totalMonths = parseInt(minDate.month) + loan - 1
      //
      //   const year = minDate.year + Math.floor((totalMonths - 2) /12)
      //   const month = totalMonths % 12 || 12
      //   return {month,year}
      // }




      if (loan!==0 && this.min_date_holidays_end==='1995-01-01') {
        const startMonths = minDate.year * 12 + minDate.month -1
        const endMonths = startMonths + loan - 1
        const year = Math.floor(endMonths / 12)
        const month = (endMonths % 12) + 1;
        return {month,year}
      }
      if (loan!==0 && this.min_date_holidays_end!=='1995-01-01') {
        const [yearS,monthS] =  this.min_date_holidays_end.split('-');
        const startMonths = parseInt(yearS) * 12 + parseInt(monthS) + 1
        const endMonths = startMonths + loan - 1
        const year = Math.floor(endMonths / 12)
        const month = (endMonths % 12) + 1;
        return {month,year}
      }


      if (loan===0){
        return {month: 12,year: new Date().getFullYear() + 1}
      }

    },

    newMethods(perem){

      if (perem[0] === this.blockId) {
        let [year,month] = this.formatYearMonthMinDate(`${perem[1][1]}-${perem[1][0]}`).split('-');
        this.minDate.month = parseInt(month)
        this.minDate.year = parseInt(year)
        this.minDate.flag = 1
        this.maxDate = this.calculateMaxDate(this.minDate,this.loan_term)

        this.destroyCalendar()
        this.initPluginCalendarPeriodEnd()


        const inputValue =  this.$el.querySelector('input').value
        const inputParts =  inputValue.split(', ');

        if (inputParts.length !==2) {
          this.$el.querySelector('input').value = ''
        }

        const inputMonthName = inputParts[0].toLowerCase();
        const inputYear = parseInt(inputParts[1], 10)
        if (isNaN(inputYear)){
          this.$el.querySelector('input').value = ''
        }
        const monthIndex = this.month.findIndex(m => m.toLowerCase() === inputMonthName)
        if (monthIndex === -1) {
          this.$el.querySelector('input').value = ''
        }

        const inputMonth = monthIndex + 1;

        let minDateRealMonth, minDateRealYear;
        if (this.minDate.month === 1) {
          minDateRealMonth = 12;
          minDateRealYear = this.minDate.year - 1
        } else {
          minDateRealMonth = this.minDate.month - 1
          minDateRealYear = this.minDate.year
        }

        if (
          inputYear < minDateRealYear ||
          (inputYear === minDateRealYear && inputMonth <=minDateRealMonth)
        ) {
          this.$el.querySelector('input').value = ''
          this.$el.querySelector('input').classList.remove('js-filled')
          this.$el.querySelector('.js--clear-calc-tax').classList.remove('active')
          this.$el.querySelector('.js--required-error').classList.add('display-none')
          this.minDate.flag = 0


          this.$emit('sendFromCalendarEndClearBlockRequared',this.blockId)
        }



        this.destroyCalendar()

        if (parseInt(perem[1][0])<11){
          this.initPluginCalendarPeriodEnd(parseInt(perem[1][0])+1, perem[1][1])
        } else if (parseInt(perem[1][0])===11) {
          this.initPluginCalendarPeriodEnd(0, parseInt(perem[1][1])+1)
        }
      }
    }


  },
  beforeDestroy() {
    this.destroyCalendar()
    eventBus.$off('sendDataEarlyCalendar')
    eventBus.$off('sendDataBeginPeriodChangeField')

    document.removeEventListener('click', this.handleDocumentClick);
    this.removeViewportListener();
  },
  mounted(){
    //Дополнительно
    this.isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    // Обработчик закрытия календаря
    document.addEventListener('click', this.handleDocumentClick);
    this.parent = this.$el.closest('.js--container-block')
    const index_block =parseInt(this.$el.closest('.js--container-block').getAttribute('data-index'));
    this.minDayHoliday()
    if (this.answers[2]!==undefined && this.answers[2]!==null) {
      for (let item of this.answers[2]) {
        const id_block = item.id
        const parent = document.querySelector('#earlyRepayment')
        if(parent){
          const element_eray = parent.querySelector(`.js--container-block-early[data-index="${id_block}"] input.js--calendar-field-end`);
          if (element_eray && item.earlyAllPeriod.selected_value_end!==null){
            this.time_holiday = parseInt(item.dateEarly[item.earlyAllPeriod.selected_value_end[0]]+1)
            if (parseInt(item.earlyAllPeriod.selected_value_begin[0])<10){
              this.minDate.month = parseInt(item.earlyAllPeriod.selected_value_begin[0]) + 2
              this.minDate.year = parseInt(item.earlyAllPeriod.selected_value_begin[1])
              this.minDate.flag = 1
            }
            else if (parseInt(item.earlyAllPeriod.selected_value_begin[0])===10) {
              this.minDate.month = 2
              this.minDate.year = parseInt(item.earlyAllPeriod.selected_value_begin[1]) + 1
              this.minDate.flag = 1
            }
            element_eray.value = `${this.month[item.earlyAllPeriod.selected_value_end[0]]}, ${item.earlyAllPeriod.selected_value_end[1]}`;
            this.destroyCalendar()
            this.initPluginCalendarPeriodEnd(this.minDate.month,this.minDate.year)
            if (element_eray.closest('.js-early-period-required')
              && element_eray.closest('.js-early-period-required').querySelector('.js--required-error')) {
              element_eray.closest('.js-early-period-required').querySelector('.js--required-error').classList.add('display-none')
            }
            if (element_eray.closest('.js--for-clear-field')) {
              element_eray.closest('.js--for-clear-field').classList.remove('input_error')
            }
            if (element_eray.closest('.js--for-clear-field') && element_eray.closest('.js--for-clear-field').querySelector('.js--clear-calc-tax')) {
              element_eray.closest('.js--for-clear-field').querySelector('.js--clear-calc-tax').classList.add('active')
            }
            if (element_eray.classList.contains('js-early-period-required')) {
              element_eray.classList.add('js-filled')
              element_eray.classList.add('btn-active')
              element_eray.closest('.js--acc-wr').classList.add('calendar-full')
            }
          }
        }
      }

    }

    this.CalendarVanillaClose()

  },
  computed:{

  },

  watch:{
    min_date_holidays_end(){
      const split_min_date_holidays = this.min_date_holidays_end.split('-');
      const split_year = parseInt(split_min_date_holidays[0])
      const split_month = parseInt(split_min_date_holidays[1])
      const time_data_loanR = (split_year * 12) + split_month+1
      if(this.time_holiday!==0 && time_data_loanR>=parseInt(this.time_holiday)) {
        this.$refs.inputEnd.closest('.js--for-clear-field').querySelector('.js--clear-calc-tax').click()
      }


      //ПОКА УБРАЛ НЕМНОГО ПЕРЕДЕЛАЮ

      if(this.minDate.flag===0) {
        this.minDayHoliday()
      }
    },

    time_data_loan() {

    },

    loan_term() {
      const fountId = this.array_block_early_repayment_end.find(user => user.id === this.blockId)
      if (fountId){


        if(this.time_holiday!==0 && this.time_data_loan>=parseInt(this.time_holiday)) {
          this.$refs.inputEnd.closest('.js--for-clear-field').querySelector('.js--clear-calc-tax').click()
        }
        if(this.time_holiday!==0 && this.time_data_loan!==0 && this.time_holiday>parseInt(this.time_data_loan) + this.loan_term) {
          this.$refs.inputEnd.closest('.js--for-clear-field').querySelector('.js--clear-calc-tax').click()
        }


        if (this.min_date_holidays_end==='1995-01-01') {
          this.maxDate.month = 12
          this.maxDate.year = new Date().getFullYear() + 1
        }
        else{
          this.maxDate = this.calculateMaxDate(this.minDate,this.loan_term)
        }


        this.destroyCalendar()
        this.initPluginCalendarPeriodEnd()


      }


    }
  },
  components:{

  },
  created(){
    //что-то изменил в календарке начало
    eventBus.$on('sendDataEarlyCalendar', (data) => {
     this.newMethods(data)
    })


    eventBus.$on('sendDataBeginPeriodChangeField', (data) => {
      if (data[0] === this.blockId) {
        let [year,month] = this.formatYearMonthMinDate(`${data[1][1]}-${data[1][0]}`).split('-');
        this.minDate.month = parseInt(month)
        this.minDate.year = parseInt(year)
        this.minDate.flag = 1
        this.maxDate = this.calculateMaxDate(this.minDate,this.loan_term)

        this.destroyCalendar()
        if (parseInt(data[1][0])<11){
          this.initPluginCalendarPeriodEnd(parseInt(data[1][0])+1, data[1][1])
        } else if (parseInt(data[1][0])===11) {
          this.initPluginCalendarPeriodEnd(0, parseInt(data[1][1])+1)
        }
      }
    })
    eventBus.$on('emitClearCalendarAll', () => {

      if (this.min_date_holidays_end=='1995-01-01') {
        this.resetCalendar()
      }
      else {
        this.destroyCalendar()
        this.initPluginCalendarPeriodEnd(this.formatYearMonthSelected(this.min_date_holidays_end)[1], this.formatYearMonthSelected(this.min_date_holidays_end)[0],this.formatYearMonthMinDate(this.min_date_holidays_end),this.formatYearMonthMaxDate(this.min_date_holidays_end) )
      }
    })

    eventBus.$on('sendClearToEnd', (index) => {
      if (index === this.blockId) {
        this.minDate.flag = 0
        this.destroyCalendar()
        this.minDayHoliday()
      }


    })



  }
};
</script>
<style scoped>
</style>
