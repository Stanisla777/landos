export default function mainBannerParallax() {
    const imgs = document.querySelectorAll('.main-banner__img-item');
    const cofs = [0.25, 0.2, 0.15, 0.1, 0.1];

    function scroll() {
        const scrollPosition = window.pageYOffset;

        if (scrollPosition < 700) {
            for (let i = 0; i < imgs.length; i++) {
                const value = Math.round(scrollPosition * cofs[i]);
                const translate3d = ['translate3d(0, ', -value, 'px, 0)'].join('');
                imgs[i].style.transform = translate3d;
            }
        }
    }

    window.requestAnimationFrame(scroll);

    window.addEventListener('scroll', () => {
        window.requestAnimationFrame(scroll);
    });
}
