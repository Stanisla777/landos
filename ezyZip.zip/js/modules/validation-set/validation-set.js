/* eslint-disable */
function validationMail() {
  // eslint-disable-next-line camelcase
  const input_status = document.querySelectorAll('.js--validate-mask-email-form');
  // eslint-disable-next-line camelcase
  const maskOptions = {
    mask: /^[a-z0-9@!#$%&'.+-=?^_"`{|}~]*$/i
    // enum: ' '
  };
  // eslint-disable-next-line camelcase,no-restricted-syntax
  for (const item of input_status) {
    // eslint-disable-next-line no-undef
    IMask(item, maskOptions);
  }
}
function insertError() {
  // eslint-disable-next-line camelcase
  const input_status = document.querySelectorAll('.js--validate-mask-email-form');
  // eslint-disable-next-line camelcase,no-restricted-syntax
  for (const item of input_status) {
    // eslint-disable-next-line no-unused-vars
    item.oninput = (e) => {
      const element = e.target
      const parent = element.closest('.js--validate-mask-parent')
      const reg = e.inputType!=='deleteContentBackward'&&e.inputType!=='deleteContentForward'&&e.inputType!=='insertFromPaste'&&e.inputType!=='historyUndo'
      let char = e.data
      if (typeof char != 'undefined' && !/^[a-z0-9@!#$%&'.+-=?^_"\\`{|}~]*$/i.test(char) && reg) {
        if(parent&&parent.querySelector('.js--validate-mask-error')){
          parent.querySelector('.js--validate-mask-error').classList.add('active')
        }
      }
      else if(((char&&char!=null)&&typeof char != 'undefined' && /^[a-z0-9@!#$%&'.+-=?^_"\\`{|}~]*$/i.test(char))||e.inputType==='deleteContentBackward'||e.inputType==='deleteContentForward'){
        if(parent&&parent.querySelector('.js--validate-mask-error')){
          parent.querySelector('.js--validate-mask-error').classList.remove('active')
        }
      }
    };
    item.onpaste=(eh)=>{
      const element = eh.target
      const parent = element.closest('.js--validate-mask-parent')
      if (parent&&parent.querySelector('.js--validate-mask-error')) {
        let char = (eh.clipboardData || window.clipboardData).getData('text');
        if (!/^[a-z0-9@!#$%&'.+-=?^_"\\`{|}~]*$/i.test(char)) {
          parent.querySelector('.js--validate-mask-error').classList.add('active')
        } else {
          parent.querySelector('.js--validate-mask-error').classList.remove('active')
        }
      }
    };
    // item.onblur = (e) => {
    //   const element = e.target;
    //   const parent = element.closest('.js--validate-mask-parent')
    //   if (!element.value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)
    //     &&element.value.length!==0) {
    //     if(parent&&parent.querySelector('.js--validate-mask-error')){
    //       parent.querySelector('.js--validate-mask-error').classList.add('active')
    //     }
    //   }
    // }
  }
}
export default function validationSet() {
  validationMail();
  insertError();
}
