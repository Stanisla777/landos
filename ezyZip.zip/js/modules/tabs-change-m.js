export default function tabChange(element) {
  if (element) {
    const attr = element.getAttribute('data-type');
    if (!element.classList.contains('active')) {
      const parent = element.closest('.js-tabs');
      // eslint-disable-next-line camelcase
      const users_active = parent.querySelectorAll('.js-tabs-item');
      // eslint-disable-next-line no-unused-vars,no-restricted-syntax,camelcase,no-shadow
      for (const elem of users_active) {
        elem.classList.remove('active');
      }
      element.classList.add('active');
      const container = element.closest('.activation-certificates-crediting');
      // eslint-disable-next-line camelcase
      const block_users = container.querySelectorAll('.check-status__user-type');
      // eslint-disable-next-line no-restricted-syntax,camelcase,no-shadow
      for (const item of block_users) {
        const data = item.getAttribute('data-type');
        // eslint-disable-next-line eqeqeq
        if (data == attr) {
          item.classList.add('active');
        } else {
          item.classList.remove('active');
        }
      }
    } else return false;
  }
}
