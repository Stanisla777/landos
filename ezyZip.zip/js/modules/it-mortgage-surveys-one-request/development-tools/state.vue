<script>
import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios';
import VueAxios from 'vue-axios';
Vue.use(VueAxios, axios);
Vue.use(Vuex);

export default new Vuex.Store({
  state:{
    banks:[],
    company:[],
    documents:[],
    status_list:false,
    status_failure:false,
    status_success:false,
    status_failure_other_error:false,

    it_module:{
      it_companies:[
        {
          name: "АО РНИЦ ГОРОДА СЕВАСТОПОЛЯ ИНН 9201510872"
        }
      ],
      banks:[
        {name: "ПАО СБЕРБАНК", link: "https://www.sberbank.ru/ru/about/today", rate: "0"}
      ],
      documents:[
        {
          link: "https://docs.cntd.ru/document/350305162",
          name: "Постановление Правительства N 805 от 30.04.2022"
        }
      ]
    }



  },
  getters:{
    MASSIVE_COMPANY(state){
      return state.company
    },
    MASSIVE_BANK(state){
      return state.banks
    },
    MASSIVE_DOCUMENTS(state){
      return state.documents
    },
    STATUS_LIST(state){
      return state.status_list
    },
    STATUS_FAILURE(state){
      return state.status_failure
    },
    STATUS_SUCCESS(state){
      return state.status_success
    },
    STATUS_FAILURE_OTHER_ERROR(state){
      return state.status_failure_other_error
    },







  },
  mutations:{




    mutationObjCompany(state,received_perem){
      // console.log(received_perem.it_companies);
      state.company=[]
      // if(state.company.length===0){
        for( let item of received_perem.it_companies){
          state.company.push(item.name);
        }
      // }

      if (state.company.length > 0) {
        state.status_list = true;
        state.status_failure = false
      }

      // console.log(state);
    },
    mutationObjBank(state,received_perem){
      state.banks=[]
      for (let item of received_perem.banks){
        state.banks.push(item)
      }
    },
    mutationObjDocument(state,received_perem){
      state.documents=[]
      for (let item of received_perem.documents){
        state.documents.push(item)
      }
      // console.log(state);
    },
    mutationStatusSuccess(state){
      state.status_success=true
    },
    mutationStatusFailureNotFound(state){
      state.status_failure = true;
    },
    mutationStatusFailureOtherError(state){
      state.status_failure_other_error = true;
    },

    mutationListFalse(state){
      state.status_list=false
      state.status_success=false
      state.status_failure=false
      state.status_failure_other_error=false
      state.company =[]
      state.banks=[]
      state.documents=[]
    }



  },
  actions:{

    ActionFilledParameters({commit,state},parametr){


      // это для тестов заархивировать
      // commit('mutationObjCompany',state.it_module)
      // commit('mutationObjBank',state.it_module)
      // commit('mutationObjDocument',state.it_module)


      //------------------------это для боя разархивировать

      const config_header = {
        headers: {
          'Content-Type': 'application/json',
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
          Accept: 'application/json',
        }
      }

      return axios.get(`/api/local/it-mortgage/?search=${parametr}`,config_header)
        .then((res)=>{
          commit('mutationObjCompany',res.data.result)
          commit('mutationObjBank',res.data.result)
          commit('mutationObjDocument',res.data.result)

        }).catch((error) => {
          if (error.response) {
            if(error.response.status==404){
              commit('mutationStatusFailureNotFound')
            }
            else{
              commit('mutationStatusFailureOtherError')
            }
          }
        });
    },
    ActionListFalse({commit,state}){
      commit('mutationListFalse')
    },
    ActionStatusSuccess({commit}){
      commit('mutationStatusSuccess')
    },


















  },
})
</script>
