<template lang="pug">
  div
    p.mortgage-surveys__step-title Перечень аккредитованных IT-компаний
    .mortgage-surveys__wr-select
      .calculator_s__calculator-input.mortgage-surveys__input.js--inn-mask(
        @focusin="focusIn"
        @focusout="focusOut"
      )
        input(type="text" inputmode="numeric" placeholder="Введите  ИНН организации")(
          @input="liveSearch"
          @paste="liveSearchPaste"
          @keyup="onlyNumber"
        )
      .mortgage-surveys__wr-list(
        v-bind:class="status_list===true ? 'active' : ''"
      )
        ul.mortgage-surveys__list
          li(
            v-for="item in massive_company"
            @click="commonClickSelect"
          ) {{item}}


</template>
<script>
import Storage from '../development-tools/state.vue';
// import IMask from 'imask';

export default {
  name: 'v-component-it-company',
  data(){
    return {
      output:[]

    }
  },
  methods:{
    onlyNumber(el){
      const element = el.currentTarget
      let element_val = element.value;
      if(el.keyCode===13&&element.value.length===10){
        Storage.dispatch('ActionFilledParameters',element_val)
      }
      else if (el.keyCode===13&&element_val.length <10){
        Storage.dispatch('ActionListFalse')
      }
    },
    inputCost(){
      const input_status = document.querySelectorAll('.js--inn-mask input');
      const maskOptions = {
        mask: /^\d+$/,
      };
      for (const item of input_status) {
        new IMask(item, maskOptions);
      }
    },
    liveSearchPaste(el){
      const element = el.currentTarget
      let element_val = (el.clipboardData || window.clipboardData).getData('text');
      if ( element_val.search(/[^0-9]/g) != -1 ) {
        el.preventDefault();
      }
    },

    liveSearch(el){

      const element = el.currentTarget
      let element_val = element.value;
      element_val=element_val.trim()

      if(element.value.match(/^\d+$/)){
        element.closest('.js--inn-mask').classList.remove('error')
      }
      else if(!element.value.match(/^\d+$/)&&element.value.length!==0){
        element.closest('.js--inn-mask').classList.add('error')
      }


      element.value = element.value.substring(0, 10)
      if (element_val.length ===10&&!isNaN(element_val)){
        Storage.dispatch('ActionFilledParameters',element_val)
      }
        // if (element_val.length >9&&element_val.length<13){
        //   // alert()
        //   Storage.dispatch('ActionFilledParameters',element_val)
      // }
      else if (element_val.length <10){
        Storage.dispatch('ActionListFalse')
      }
      else if (element_val.length >15){
        element.value=''
        Storage.dispatch('ActionListFalse')
      }

    },

    focusIn(el){
      const element = el.currentTarget
      element.classList.add('active')
    },
    focusOut(el){
      const element = el.currentTarget
      element.classList.remove('active')
    },
    commonClickSelect(el){
      this.elementSelect(el)
      this.showFinalBlock(el)
    },
    elementSelect(el){
      const element = el.currentTarget
      element.closest('.mortgage-surveys__wr-select').querySelector('input').value = element.textContent
      element.closest('.mortgage-surveys__wr-list').classList.remove('active')
    },
    showFinalBlock(el){
      Storage.dispatch('ActionStatusSuccess')
    }
  },
  mounted(){
    this.inputCost();
  },
  computed:{
    massive_company(){
      return Storage.getters.MASSIVE_COMPANY
    },
    status_list(){
      return Storage.getters.STATUS_LIST
    },

  },
  watch:{
  },
  components:{

  },
  created() {

  }
};
</script>
<style scoped>
</style>
