function textValidator(fld) {
    const field = fld;

    field.addEventListener('input', () => {
        if (field.value[0] === ' ') {
            field.value = '';
        }
    });
}

function noNumbersValidator(fld) {
    const field = fld;

    field.addEventListener('input', () => {
        field.value = field.value.replace(/\d/g, '');
    });
}

export function feedbackValidation() {
    const form = document.querySelector('.js--feedback');

    if (form) {
        const email = form.querySelector('.js--feedback-email');
        const check = form.querySelector('.js--feedback-check');
        const text = form.querySelector('.js--feedback-text');
        const textInput = form.querySelector('.js--feedback-text-input');
        // check.addEventListener('change', (e) => {
        //   if (!e.target.checked) {
        //     alert();
        //   }
        // });

        if (text) {
          textValidator(text);
        }

        form.addEventListener('submit', (event) => {
            const errors = {
                email: false,
                check: false,
                text: false
            };

            if (email.value.length > 0 && email.value.match(/^.+@.+\..+$/igm)) {
                email.closest('.input').classList.remove('input_error');
            } else if (email.value.length === 0) {
                errors.email = true;
                email.closest('.input').querySelector('.input__error').innerHTML = 'Это поле обязательно для заполнения';
                email.closest('.input').classList.add('input_error');
            } else {
                errors.email = true;
                email.closest('.input').querySelector('.input__error').innerHTML = 'Введите корректный email';
                email.closest('.input').classList.add('input_error');
            }

            if (text.value.length > 300) {
                errors.text = true;
                text.closest('.textarea').querySelector('.textarea__error').innerHTML = 'Максимальное количество символов — 300';
                text.closest('.textarea').classList.add('textarea_error');
            } else if (text.value.length === 0) {
                errors.text = true;
                text.closest('.textarea').querySelector('.textarea__error').innerHTML = 'Это поле обязательно для заполнения';
                text.closest('.textarea').classList.add('textarea_error');
            } else {
                text.closest('.textarea').classList.remove('textarea_error');
            }

            if (textInput.value.length > 30) {
                errors.text = true;
                textInput.closest('.input-text').querySelector('.input-text__error').innerHTML = 'Максимальное количество символов — 30';
                textInput.closest('.input-text').classList.add('input-text_error');
            } else if (textInput.value.length === 0) {
                errors.text = true;
                textInput.closest('.input-text').querySelector('.input-text__error').innerHTML = 'Это поле обязательно для заполнения';
                textInput.closest('.input-text').classList.add('input-text_error');
            } else {
                textInput.closest('.input-text').classList.remove('input-text_error');
            }

            if (!(check.checked)) {
                errors.check = true;
                check.closest('.checkbox').classList.add('checkbox_error');
            } else {
                check.closest('.checkbox').classList.remove('checkbox_error');
            }

            if (errors.email || errors.check || errors.text) {
                event.preventDefault();
            }
        });
    }
}

export function coursesFeedbackValidation() {
    const form = document.querySelector('.js--courses');

    if (form) {
        const check = form.querySelector('.js--courses-check');
        const text = form.querySelector('.js--courses-text');
        const textInput = form.querySelectorAll('.js--courses-text-input');

        textValidator(text);

        form.addEventListener('submit', (event) => {
            const errors = {
                check: false,
                text: false
            };

            if (text.value.length > 300) {
                errors.text = true;
                text.closest('.textarea').querySelector('.textarea__error').innerHTML = 'Максимальное количество символов — 300';
                text.closest('.textarea').classList.add('textarea_error');
            } else if (text.value.length === 0) {
                errors.text = true;
                text.closest('.textarea').querySelector('.textarea__error').innerHTML = 'Это поле обязательно для заполнения';
                text.closest('.textarea').classList.add('textarea_error');
            } else {
                text.closest('.textarea').classList.remove('textarea_error');
            }

            for (let i = 0; i < textInput.length; i++) {
                if (textInput[i].value.length === 0) {
                    errors.text = true;
                    textInput[i].closest('.input').querySelector('.input__error').innerHTML = 'Это поле обязательно для заполнения';
                    textInput[i].closest('.input').classList.add('input-text_error');
                } else {
                    textInput[i].closest('.input').classList.remove('input-text_error');
                }
            }

            if (!(check.checked)) {
                errors.check = true;
                check.closest('.checkbox').classList.add('checkbox_error');
            } else {
                check.closest('.checkbox').classList.remove('checkbox_error');
            }

            if (errors.check || errors.text) {
                event.preventDefault();
            }
        });
    }
}

export function subscriptionValidation() {
    const form = document.querySelector('.js--subscription');

    if (form) {
        const email = form.querySelector('.js--subscription-email');
        const check = form.querySelector('.js--subscription-check');

        form.addEventListener('submit', (event) => {
            const errors = {
                email: false,
                check: false
            };

            if (email.value.length > 0 && email.value.match(/^.+@.+\..+$/igm)) {
                email.closest('.input').classList.remove('input_error');
            } else if (email.value.length === 0) {
                errors.email = true;
                email.closest('.input').querySelector('.input__error').innerHTML = 'Это поле обязательно для заполнения';
                email.closest('.input').classList.add('input_error');
            } else {
                errors.email = true;
                email.closest('.input').querySelector('.input__error').innerHTML = 'Введите корректный email';
                email.closest('.input').classList.add('input_error');
            }

            if (!(check.checked)) {
                errors.check = true;
                check.closest('.checkbox').classList.add('checkbox_error');
            } else {
                check.closest('.checkbox').classList.remove('checkbox_error');
            }

            if (errors.email || errors.check) {
                event.preventDefault();
            }
        });
    }
}

export function chatValidation() {
    const form = document.querySelector('.js--chat');

    if (form) {
        const email = form.querySelector('.js--chat-email');
        const text = form.querySelector('.js--chat-text');
        const check = form.querySelector('.js--chat-check');

        textValidator(text);

        form.addEventListener('submit', (event) => {
            const errors = {
                email: false,
                text: false,
                check: false
            };

            if (email.value.length > 0 && email.value.match(/^.+@.+\..+$/igm)) {
                email.closest('.input').classList.remove('input_error');
            } else if (email.value.length === 0) {
                errors.email = true;
                email.closest('.input').querySelector('.input__error').innerHTML = 'Это поле обязательно для заполнения';
                email.closest('.input').classList.add('input_error');
            } else {
                errors.email = true;
                email.closest('.input').querySelector('.input__error').innerHTML = 'Введите корректный email';
                email.closest('.input').classList.add('input_error');
            }

            if (text.value.length > 300) {
                errors.text = true;
                text.closest('.textarea').querySelector('.textarea__error').innerHTML = 'Максимальное количество символов — 300';
                text.closest('.textarea').classList.add('textarea_error');
            } else if (text.value.length === 0) {
                errors.text = true;
                text.closest('.textarea').querySelector('.textarea__error').innerHTML = 'Это поле обязательно для заполнения';
                text.closest('.textarea').classList.add('textarea_error');
            } else {
                text.closest('.textarea').classList.remove('textarea_error');
            }

            if (!(check.checked)) {
                errors.check = true;
                check.closest('.checkbox').classList.add('checkbox_error');
            } else {
                check.closest('.checkbox').classList.remove('checkbox_error');
            }

            if (errors.email || errors.text || errors.check) {
                event.preventDefault();
            }
        });
    }
}

export function callValidation() {
    const form = document.querySelector('.js--call');

    if (form) {
        const name = form.querySelector('.js--call-name');
        const phone = form.querySelector('.js--call-phone');
        const check = form.querySelector('.js--call-check');

        textValidator(name);

        name.addEventListener('input', () => {
            if (name.value[0] === ' ') {
                name.value = '';
            }
        });

        form.addEventListener('submit', (event) => {
            const errors = {
                name: false,
                phone: false,
                check: false
            };

            if (name.value.length === 0) {
                errors.name = true;
                name.closest('.input').querySelector('.input__error').innerHTML = 'Это поле обязательно для заполнения';
                name.closest('.input').classList.add('input_error');
            } else {
                name.closest('.input').classList.remove('input_error');
            }

            if (phone.value.length < 17) {
                errors.phone = true;
                phone.closest('.input').querySelector('.input__error').innerHTML = 'Это поле обязательно для заполнения';
                phone.closest('.input').classList.add('input_error');
            } else {
                phone.closest('.input').classList.remove('input_error');
            }

            if (!(check.checked)) {
                errors.check = true;
                check.closest('.checkbox').classList.add('checkbox_error');
            } else {
                check.closest('.checkbox').classList.remove('checkbox_error');
            }

            if (errors.name || errors.phone || errors.check) {
                event.preventDefault();
            }
        });
    }
}

export function housingCooperativeRequestValidation() {
    const form = document.querySelector('.js--housing-cooperative-request');

    if (form) {
        const name = form.querySelector('.js--housing-cooperative-request-name');
        const email = form.querySelector('.js--housing-cooperative-request-email');
        const phone = form.querySelector('.js--housing-cooperative-request-phone');
        const check = form.querySelector('.js--housing-cooperative-request-check');

        textValidator(name);
        noNumbersValidator(name);

        form.addEventListener('submit', (event) => {
            const errors = {
                name: false,
                email: false,
                phone: false,
                check: false
            };

            if (name.value.length === 0) {
                errors.name = true;
                name.closest('.input').querySelector('.input__error').innerHTML = 'Это поле обязательно для заполнения';
                name.closest('.input').classList.add('input_error');
            } else {
                name.closest('.input').classList.remove('input_error');
            }

            if (email.value.length > 0 && email.value.match(/^.+@.+\..+$/igm)) {
                email.closest('.input').classList.remove('input_error');
            } else if (email.value.length === 0) {
                errors.email = true;
                email.closest('.input').querySelector('.input__error').innerHTML = 'Это поле обязательно для заполнения';
                email.closest('.input').classList.add('input_error');
            } else {
                errors.email = true;
                email.closest('.input').querySelector('.input__error').innerHTML = 'Введите корректный email';
                email.closest('.input').classList.add('input_error');
            }

            if (phone.value.length < 17) {
                errors.phone = true;
                phone.closest('.input').querySelector('.input__error').innerHTML = 'Это поле обязательно для заполнения';
                phone.closest('.input').classList.add('input_error');
            } else {
                phone.closest('.input').classList.remove('input_error');
            }

            if (!(check.checked)) {
                errors.check = true;
                check.closest('.checkbox').classList.add('checkbox_error');
            } else {
                check.closest('.checkbox').classList.remove('checkbox_error');
            }

            if (errors.name || errors.email || errors.phone || errors.check) {
                event.preventDefault();
            }
        });
    }
}

export function phoneMask() {
    [].forEach.call(document.querySelectorAll('input.js--call-phone[type="tel"]'), (input) => {
        let keyCode;
        function mask(event) {
            if (!(event.keyCode)) {
                keyCode = event.keyCode;
            }
            const pos = this.selectionStart;
            if (pos < 3) event.preventDefault();
            const matrix = '+7 (___) ___ ____';
            let i = 0;
            const def = matrix.replace(/\D/g, '');
            const val = this.value.replace(/\D/g, '');
            let newValue = matrix.replace(/[_\d]/g, (a) => (i < val.length ? val.charAt(i++) || def.charAt(i) : a));
            i = newValue.indexOf('_');
            if (i !== -1) {
                // if (!(i < 5)) {
                //     i = 3;
                // }
                newValue = newValue.slice(0, i);
            }
            let reg = matrix.substr(0, this.value.length).replace(/_+/g,
                (a) => `\\d{1,${a.length}}`).replace(/[+()]/g, '\\$&');
            reg = new RegExp(`^${reg}$`);
            if (!reg.test(this.value) || this.value.length < 5 || (keyCode > 47 && keyCode < 58)) {
                this.value = newValue;
            }
            if (event.type === 'blur' && this.value.length < 5) this.value = '';
        }

        input.addEventListener('input', mask, false);
        input.addEventListener('focus', mask, false);
        input.addEventListener('blur', mask, false);
        input.addEventListener('keydown', mask, false);
    });
}
