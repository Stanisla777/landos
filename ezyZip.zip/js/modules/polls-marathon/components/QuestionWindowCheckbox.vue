<template lang="pug">
  .test-cotainer-answer(
    v-bind:class="{mandatory:req}"
  )
    .test-window__number(
      v-if="circle_number"
      v-bind:data-color="[`${item_key}`]"
    )
      p <span>{{item_key}}</span>/<span>{{count_answers}}</span>
    p.test-window__question(
      v-html="question"
    )
    .test-item
      .test-window__wrap-chec
        .test-window__checkbox.test-window__height-limitation
          .test-window__item.test-window__checkbox-item.choose(
            v-for ="(answer,key,ind) in variants"
            @click="pass_clickVariant($event,answer.FIELD_WIDTH,answer.FIELD_PARAM,answer.COLOR,answer.NAME_INPUT,answer.VALUE_INPUT)"
            v-bind:class="[(answer.FIELD_WIDTH==1)?'test-wintdow__item':(answer.FIELD_WIDTH==2)?'test-winadow__item':'test-winfdow__item' ]"
          )
            .test-window__item-container-answer
              input(
                v-bind:id="[`check-${item_key}-${key}`]"
                v-on:click.stop=""
              )(type="checkbox",name="test",value="")
              label.fs-1rem.test-window__possible-answer(
                v-bind:for="[`check-${item_key}-${key}`]"
                v-html="answer.MESSAGE"
              )
              .test-window__field-for-variant(
                v-if="answer.FIELD_WIDTH==2"
              )
                .test-window__item.test-window__textarea
                  textarea.check-for-variant(
                    @click.stop
                    @change="passInputCheckAnother($event)"
                    @input="limitInput"
                    v-bind:placeholder="answer.PLACEHOLDER"
                  )(name="",maxlength="1001")
                  p.test-window__textarea-error.
                    Превышено допустимое количество в 1000 символов
    button.test-window__btn.btn.btn-slide-sub(type="button")(
      v-bind:class="{unact:req}"
      v-if="btn_answer"
      @click="pass_clickButtonAnswer"
    ) {{button_text}}
</template>

<script>
export default {
  name: "QuestionWindowCheckbox",
  props:['question','variants','item_key','btn_answer','circle_number','count_answers','required','field_clearing','button_text'],
  data(){
    return{
      req:null,
      cor_answer:null,
      name_radio:null,
      inputs:null,
      field_clearings:null
    }
  },
  methods:{
    pass_clickVariant(elem,param_1,param_2,param_3,param_4,param_5){
      const element = elem.currentTarget
      this.name_radio=param_4
      this.$emit('event_clickVariant',[element,elem,param_1,param_2,param_3,param_4,param_5])
    },
    pass_clickButtonAnswer(elem){
      const element = elem.currentTarget
      this.$emit('event_clickButtonAnswer',[element,this.cor_answer])
    },
    requiredButton(){
      if(this.required==="Y"){
        this.req=true
        this.$emit('eventrequiredButton',this.req)

      }
      else if(this.required==="N"){
        this.req=false
        this.$emit('eventrequiredButton',this.req)
      }
    },
    correctCheck(){
      const massive = []
      const cor = this.variants
      const wit = Object.keys(cor);
      for (let i=0;i<wit.length;i++){
        if(cor[wit[i]].FIELD_WIDTH=="1"){
          massive.push(cor[wit[i]].FIELD_WIDTH=="1")
        }
      }
      this.cor_answer = massive.length
    },
    passInputCheckAnother(elem){
      const element = elem.currentTarget
      this.$emit('eventInputCheckAnother',[element,element.value,this.name_radio])
    },
    limitInput(el) {
      const max = 1001
      const field=el.currentTarget
      const parent = field.closest('.test-window__item')
      const item = parent.querySelectorAll('.test-window__textarea-error')
      if (field.value.length === max) {
        item.forEach(function (item){
          item.setAttribute('style','display:block')
        })
      }
      else
      {
        item.forEach(function (item){
          item.setAttribute('style','display:none')
        })
      }
    }
  },
  mounted() {
    this.requiredButton()
    this.correctCheck()
  },
  watch:{
    field_clearings(){

    }
  }

}
</script>

<style scoped>

</style>
