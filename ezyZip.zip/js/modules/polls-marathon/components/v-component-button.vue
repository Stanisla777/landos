<template lang="pug">
  .polls__wrapper-btn
    .polls__btn-chek.polls__btn(
      @click="verificationAnswers"
      :class="[massive_required.length!==0?'unactive':'active']"
    )
      button(type='button') {{button_text}}
    .polls__btn-repeat.polls__btn(
      @click="repeatPolls"
    )
      button(type='button') Повторить
</template>
<script>
import Storage from '../development-tools/state.vue';
import eventBus from '../development-tools/eventBus.vue';

export default {
  name: 'v-conponent-button',
  props:['button_text','massive_required'],
  data(){
    return {
      button_status:false
    }
  },
  methods:{
    verificationAnswers(el){
      const element = el.currentTarget
      this.$emit('event_verificationAnswers',element)
    },
    repeatPolls(el){
      const element = el.currentTarget
      this.$emit('event_repeatPolls',element)
    }
  },
  mounted(){
    const parent = document.querySelector('.modal-for-polls')
    if(parent){
      parent.querySelector('.polls__wrapper-btn .polls__btn-chek button').textContent='Отправить ответы'
    }
  },
  computed:{
  },
  created() {
    eventBus.$on('statusButton',(param)=>{
      this.button_status=param
    })

  },
  watch:{
  },
  components:{
  }
};
</script>
<style scoped>
</style>
