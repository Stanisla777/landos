<template lang="pug">
  button.test-window__btn.btn.btn-slide-sub(type="button")(
    @click="pass_clickButtonAnswer"
  ) Проверить
</template>

<script>
export default {
  name: 'AnswerButton',
  data(){
    return {

    }
  },
  props:['btn_result'],
  methods:{
    pass_clickButtonAnswer(elem){
      const element = elem.currentTarget
      this.$emit('event_clickButtonAnswer',[element])
    },

  }
};
</script>

<style scoped>

</style>
