<template lang="pug">
  .marathon-detail__answer-question
    p.marathon-detail__answer-question-title Ответ
    p.marathon-detail__answer-question-content Ипотечные кредиты обязательно выдаются под залог недвижимости.
</template>

<script>
export default {
  name: "AnswerQuestion",
  data(){
    return{

    }
  },

  props:['correct','description','win'],
  methods:{
  },
  watch:{

  },
  mounted() {
    // this.sameAnswers()
  }

}
</script>

<style scoped>

</style>
