<template lang="pug">
  .polls__component-question.js--polls-component-radio.js--polls-component-text-field(
    v-bind:class="[(required=='Y')?'required':'optional']"
  )

    p.polls__question(
      v-html="question"
    )

    .polls__list-answers
      .polls__textarea
        textarea(
          v-for ="(answer,key,ind) in variants"
          v-bind:placeholder="answer.PLACEHOLDER"
          @input="eventInput($event,answer.NAME_INPUT)"
          v-model="input"
        )(name="",maxlength="1001")
        p.test-window__textarea-error.
          Превышено допустимое количество в 1000 символов
</template>

<script>
export default {
  name: "v-conponent-text-field",
  props:['question','variants','item_key','required','current_answer','id_question'],
  data(){
    return{
      input:"",
      req:null,
    }
  },

  methods:{
    eventInput(elem,param_1){
      this.pass_inputAnswer(elem,param_1)
      this.limitInput(elem)
    },

    pass_inputAnswer(elem,param_1){
      const element = elem.currentTarget
      if(element.closest('.js--polls-component-radio').classList.contains('required')){
        this.$emit('event_SelectTextFieldForButton',element)
      }
      this.$emit('event_inputAnswer',[element,param_1,this.input])
    },


    limitInput(el) {
      const max = 1001
      const field=el.currentTarget
      // field.value = field.value.substring(0, max);
      const parent = field.closest('.js--polls-component-radio')
      const item = parent.querySelectorAll('.test-window__textarea-error')
      if (field.value.length === max) {
        item.forEach(function (item){
          item.setAttribute('style','display:block')
        })
      }
      else
      {
        item.forEach(function (item){
          item.setAttribute('style','display:none')
        })
      }
    }

  },
  watch: {

  },
  mounted() {

  },

}
</script>

<style scoped>

</style>
