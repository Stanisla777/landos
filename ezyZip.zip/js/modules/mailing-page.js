function dropdownTopic() {
  // eslint-disable-next-line camelcase
  const btn_col_right = document.querySelectorAll('.js--headers-col-right');
  // eslint-disable-next-line camelcase
  const btn_col_left = document.querySelectorAll('.js--headers-col-left');
  // eslint-disable-next-line camelcase,no-unused-vars
  const header_parent = document.querySelectorAll('.js--wr-mailing-headers');
  // eslint-disable-next-line no-restricted-syntax,camelcase
  for (const item_2 of btn_col_left) {
    const parent = item_2.closest('.js--wr-mailing-headers');
      item_2.onclick = () => {
        if (!parent.classList.contains('active')) {
          parent.classList.add('active');
        }
      };
  }
  // eslint-disable-next-line no-restricted-syntax,camelcase
  for (const item of btn_col_right) {
    const parent = item.closest('.js--wr-mailing-headers');
    item.onclick = () => {
      if (parent.classList.contains('active')) {
        parent.classList.remove('active');
      } else {
        parent.classList.add('active');
      }
    };
  }
}
function selectAllCheckboxes() {
  // eslint-disable-next-line camelcase
  const array_main_chek = document.querySelectorAll('.js--main-label');
  // eslint-disable-next-line no-unused-vars
  const cont = document.querySelector('.js--subscription');
  // eslint-disable-next-line no-restricted-syntax,camelcase
  for (const item of array_main_chek) {
    const parent = item.closest('.js--wr-mailing-headers');

    // eslint-disable-next-line camelcase
    const array_all_check = parent.querySelectorAll('.js--found-topics input[type="checkbox"]');

    item.querySelector('input').onchange = () => {
      if (item.querySelector('input').checked) {
        for (let i = 0; i < array_all_check.length; i++) {
          array_all_check[i].checked = true;
        }
        item.classList.remove('something-selected');
        parent.querySelector('.js--reset-check').classList.add('active');
      } else {
        for (let i = 0; i < array_all_check.length; i++) {
          array_all_check[i].checked = false;
        }
        parent.querySelector('.js--reset-check').classList.remove('active');
      }
      // eslint-disable-next-line no-use-before-define
      buttonActive();
    };

    for (let i = 0; i < array_all_check.length; i++) {
      array_all_check[i].onclick = () => {
        // eslint-disable-next-line camelcase
        const array_all_check_checked = parent.querySelectorAll('.js--found-topics input[type="checkbox"]:checked');
        // eslint-disable-next-line max-len
        if (array_all_check_checked.length > 0 && array_all_check_checked.length !== array_all_check.length) {
          item.classList.add('something-selected');
          // eslint-disable-next-line max-len,no-mixed-operators
        } else if (array_all_check_checked.length > 0 && array_all_check_checked.length === array_all_check.length || array_all_check_checked.length === 0) {
          item.classList.remove('something-selected');
        }
      };
    }
  }

//  Убрать - это будет делать Артём проставляю id
//   const a_ch = document.querySelectorAll('.js--main-label')
//   for (let i=0;i<a_ch.length;i++){
//     a_ch[i].querySelector('input').setAttribute('id',`subscription-header_${i}`)
//     a_ch[i].querySelector('label').setAttribute('for',`subscription-header_${i}`)
//   }
//
//   const a_ch_all = document.querySelectorAll('.mail-subscription__search-label')
//   for (let i=0;i<a_ch_all.length;i++){
//     a_ch_all[i].querySelector('input').setAttribute('id',`search-topic__${i}`)
//     a_ch_all[i].querySelector('label').setAttribute('for',`search-topic__${i}`)
//   }

// eslint-disable-next-line max-len
//------------------------------------------------------------------------------------------------------------
}
function resetButton() {
  // eslint-disable-next-line camelcase
  const main_container = document.querySelectorAll('.js--wr-mailing-headers');
  // eslint-disable-next-line camelcase,no-restricted-syntax
  for (const item of main_container) {
    // eslint-disable-next-line camelcase
    const array_chek = item.querySelectorAll('.js--found-topics input[type="checkbox"]');
    for (let i = 0; i < array_chek.length; i++) {
      array_chek[i].onchange = () => {
        // eslint-disable-next-line camelcase
        const array_checked = item.querySelectorAll('.js--found-topics input[type="checkbox"]:checked');

        if (array_checked.length > 0) {
          item.querySelector('.js--reset-check').classList.add('active');
        } else {
          item.querySelector('.js--reset-check').classList.remove('active');
        }
        if (array_checked.length === array_chek.length) {
          item.querySelector('.js--main-label input[type="checkbox"]').checked = true;
        } else {
          item.querySelector('.js--main-label input[type="checkbox"]').checked = false;
        }
        // eslint-disable-next-line no-use-before-define
        buttonActive();
      };
    }
    // eslint-disable-next-line camelcase
    const btn_reset = item.querySelector('.js--reset-check');
    // Кнопка сбросить
    btn_reset.onclick = () => {
      for (let i = 0; i < array_chek.length; i++) {
        array_chek[i].checked = false;
      }
      btn_reset.classList.remove('active');
      item.querySelector('.js--main-label input[type="checkbox"]').checked = false;
      // eslint-disable-next-line no-use-before-define
      buttonActive();
    };
  }
}
// когда выбрал хоть один чекбокс кнопка подписаться становиться активной
function buttonActive() {
  //  тут активной делаю кнопку отправить
  const cont = document.querySelector('.js--subscription');
  if (cont) {
    // eslint-disable-next-line camelcase
    const array_other_check = document.querySelectorAll('.js--other-label input');
    for (let i = 0; i < array_other_check.length; i++) {
      // debugger
      // eslint-disable-next-line camelcase
      const array_checked = cont.querySelectorAll('.js--other-label input[type="checkbox"]:checked');

      if (array_checked.length > 0) {
        cont.querySelector('.js--subscription-form').classList.remove('unactive');
      } else {
        cont.querySelector('.js--subscription-form').classList.add('unactive');
      }
    }
  }
}
// Общая функция
function generalTagFunction() {
  // eslint-disable-next-line camelcase
  const parent_search = document.querySelectorAll('.js--work-zone');
  // eslint-disable-next-line no-restricted-syntax,camelcase
  for (const item of parent_search) {
    // eslint-disable-next-line camelcase
    const input_search = item.querySelector('.mail-subscription__search-topic input');
    // eslint-disable-next-line camelcase
    const array_label = item.querySelectorAll('.mail-subscription__search-results-item');
    // eslint-disable-next-line no-use-before-define
    liveSearch(item, input_search, array_label);
    // eslint-disable-next-line no-use-before-define
    selectFoundTag(item, array_label, input_search);
  }
}
// Выбор найденного тэга для подписки в живом поиске
// eslint-disable-next-line camelcase
function selectFoundTag(item, array_label, input_search) {
  for (let t = 0; t < array_label.length; t++) {
    // eslint-disable-next-line no-param-reassign
    array_label[t].onclick = (e) => {
      const element = e.currentTarget;
      const attr = element.getAttribute('data-id');
      // eslint-disable-next-line no-param-reassign
      input_search.value = '';
      if (item.querySelector('.mail-subscription__search-results')) {
        item.querySelector('.mail-subscription__search-results').classList.remove('active');
      }
      if (item.querySelector(`.js--found-topics input#${attr}`)) {
        // eslint-disable-next-line no-param-reassign
        item.querySelector(`.js--found-topics input#${attr}`).checked = true;
      }
      if (item.querySelector('.js--reset-check')) {
        item.querySelector('.js--reset-check').classList.add('active');
      }
      buttonActive();
    };
  }
}
// Живой поиск
// eslint-disable-next-line camelcase
function liveSearch(item, input_search, array_label) {
  // eslint-disable-next-line no-param-reassign
    input_search.onkeyup = () => {
      item.querySelector('.mail-subscription__search-results').classList.add('active');
      const val = input_search.value;
      for (let i = 0; i < array_label.length; i++) {
        const reg = new RegExp(val, 'gi');
        const text = array_label[i].querySelector('p').textContent;

        const box = array_label[i].querySelector('p');
        // eslint-disable-next-line camelcase
        let text_box = box.innerHTML;
        // eslint-disable-next-line camelcase
        text_box = text.replace(/(<span class="highlight">|<\/span>)/gim, '');
        const newText = text_box.replace(reg, '<span class="highlight">$&</span>');
        box.innerHTML = newText;

        if (text.match(reg)) {
          // eslint-disable-next-line no-param-reassign
          array_label[i].style.display = 'block';
          array_label[i].classList.add('active');
        } else {
          // eslint-disable-next-line no-param-reassign
          array_label[i].style.display = 'none';
          array_label[i].classList.remove('active');
        }
      }
      // eslint-disable-next-line camelcase
      const array_label_active = item.querySelectorAll('.mail-subscription__search-results-item.active');
      // eslint-disable-next-line camelcase
      const array_error = item.querySelectorAll('.js--mail-subscription-error');
      if (array_label_active.length === 0) {
        const parent = item.querySelector('.mail-subscription__search-results');

        if (array_error.length === 0) {
          // eslint-disable-next-line camelcase
          const element_error = document.createElement('p');
          element_error.classList.add('mail-subscription__search-results-error', 'js--mail-subscription-error');
          element_error.innerHTML += 'Ничего не найдено';
          parent.append(element_error);
        }
      }
      if (array_label_active.length !== 0 && array_error.length !== 0) {
        item.querySelector('.js--mail-subscription-error').remove();
      }
    };
}

// Закрытие онкна поиска по клику на body
function closeWindowSearch() {
  document.body.onclick = function () {
    // eslint-disable-next-line camelcase
    const array_parent = document.querySelectorAll('.js--container-mailing');
    // eslint-disable-next-line camelcase,no-restricted-syntax
    for (const item of array_parent) {
      // eslint-disable-next-line func-names
      item.onclick = function (w) {
        w.stopImmediatePropagation();
      };
      item.classList.remove('active');
      // eslint-disable-next-line camelcase
      const array_parent_check = item.querySelectorAll('.mail-subscription__search-results.active');
      for (let i = 0; i < array_parent_check.length; i++) {
        array_parent_check[i].classList.remove('active');
      }
    }
  };
}
export default function mailingPage() {
  dropdownTopic();
  selectAllCheckboxes();
  resetButton();
  generalTagFunction();
  // liveSearch()
  closeWindowSearch();
  // headerCheckboxActive()
}
