export default function pageProgressBar() {
    const progressBar = document.querySelector('.js--progress-bar');
    if (!progressBar) { return false; }

    const progressBarLine = document.querySelector('.js--progress-bar-line');
    const pageContent = document.querySelector('.courses');

    const scrollProgressBar = () => {
        const header = document.querySelector('.header');
        const headerHeight = header.offsetHeight;
        const scrollDistance = -(pageContent.getBoundingClientRect().top);
        const progressPercentage = (scrollDistance / (pageContent.getBoundingClientRect().height
            - document.documentElement.clientHeight)) * 100;

        const val = Math.floor(progressPercentage);
        progressBarLine.style.width = `${val}%`;

        if (val < 0) {
            progressBarLine.style.width = `${0}%`;
        }

        if (document.documentElement.scrollTop >= headerHeight) {
            progressBar.classList.add('is-scrolled');
        } else {
            progressBar.classList.remove('is-scrolled');
        }
    };

    document.addEventListener('scroll', scrollProgressBar);
}
