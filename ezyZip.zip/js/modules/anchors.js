import scrollIt from './scroll-it';

export default function anchors() {
    const anchorItems = document.querySelectorAll('.js--anchor');

    for (let i = 0; anchorItems[i]; i++) {
        anchorItems[i].addEventListener('click', (e) => {
            e.preventDefault();
            scrollIt(document.querySelector(anchorItems[i].href.slice(anchorItems[i].href.indexOf('#'))), 700, 'linear');
        });
    }
}
