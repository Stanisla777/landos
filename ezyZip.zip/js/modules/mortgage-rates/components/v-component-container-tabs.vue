<template lang="pug">
  .v-mortgage__wr-tabs
    .v-mortgage__tabs-item(
      v-for="btn in tabs"
      :data-support="btn.support"
      :class="[btn.active===true?'active':false]"
      @click ="eventClickButton"
    )
      p {{btn.title}}
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
export default {
  name: 'v-container-tabs',
  props:[],
  data(){
    return {
      tabs: [
        {
          title: 'Все программы',
          active:true,
          support:2,
        },
        {
          title: 'Ипотека с господдержкой',
          support:1,
        },
        {
          title: 'Ипотека',
          support:0,
        },

      ],
    }
  },
  methods:{
    eventClickButton(el){
      const element =el.currentTarget

      if(!element.classList.contains('active')){
        const parent = element.closest('.v-mortgage__wr-tabs')
        const arrow_btn = parent.querySelectorAll('.active')

        const promice = new Promise((resolve)=> {
          for(let item of arrow_btn){
            item.classList.remove('active')
          }
          resolve()
        }).then(()=>{
          return new Promise((resolve)=> {
            element.classList.add('active')
            resolve()
          })
        })
      }
      else {
        return false
      }
      const data = element.getAttribute('data-support')
      Storage.dispatch('actionProgramDisplay',data)
      eventBus.$emit('pass_parametrSupport',data)
    }
  },
  mounted(){

  },
  computed:{},
  watch:{
  },
  components:{},
  created() {

  }
};
</script>
<style scoped>
</style>
