<template lang="pug">
  .v-mortgage__schedule.v-mortgage__common-schedule
    .my-calendar
      .my-calendar__item(
        v-for="item in obj_rate_calendar"
      )
        p {{item}}
    ChartYear(
      :series="obj_rate_common"
      :options="chartOptionsYear"
      :props_new_format_calendar="obj_rate_calendar"

    )

</template>
<script>
import Chart from './LineChart.vue';
import ChartYear from './LineChartYear.vue';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-component-schedule-common',
  props: ['props_calendar'],
  data() {
    return {
      series: this.obj_rate_common,
      chartOptionsYear: {
        xaxis: {
          type: 'category',
          categories: this.props_calendar,
          labels:{
            style: {
              colors:'#77798C',
              fontSize: '10px',
              fontFamily: 'Gilroy-Bold, Helvetica, Arial, sans-serif',
            },
            offsetX: 0, //смещение точки пересечения,
            rotate: 0,
            rotateAlways: false,
            trim: true
          },
          tooltip:{
            enabled: false
          },
          crosshairs: {
            show: true,
            width: 1,
            position: 'front',
            opacity: 1,
            stroke: {
              color: '#BDC3D1',
              width: 1,
              dashArray: 0,
            },
            fill: {
              type: 'solid',
              color: '#000',
              gradient: {
                colorFrom: '#000',
                colorTo: '#000',
                stops: [0, 100],
                opacityFrom: 1,
                opacityTo: 1,
              },
            },
            dropShadow: {
              enabled: false,
              top: 0,
              left: 0,
              blur: 1,
              opacity: 1,
            },
          },
          tickPlacement: 'off'

        },
        yaxis: {
          show: true,
          showAlways: true,
          axisBorder:true,
          tickAmount:4,
          labels:{
            style: {
              colors:'#aca8a8',
              fontSize: '16px',
              fontFamily: 'Gilroy-Regular, Helvetica, Arial, sans-serif',

            },
            formatter: (value) => { return value.toFixed(0) + "%" },
          },
        },
        tooltip: {
          enabled: true,
          shared: true,
          theme: false,
          style: {
            fontSize: '14px',
            fontFamily: 'Gilroy-Regular,sans-serif'
          },
          fixed: {
            enabled: false,
            position: 'topRight',
            // offsetX: 0,
            // offsetY: 0,
          },
          y: {
            formatter: (value, {
              series,
              seriesIndex,
              dataPointIndex,
              w
            }) => {
              if (value != undefined) {
                const tooltip = document.querySelector('.apexcharts-tooltip');
                const array_tool = tooltip.querySelectorAll('.apexcharts-tooltip-series-group');
                tooltip.querySelector('.apexcharts-tooltip-title').style.order = -1001;





                for (let item of array_tool) {
                  let value = item.querySelector('.apexcharts-tooltip-text-y-value').textContent;
                  value = value.slice(0, -1)

                  const last_number = value.slice(-1);
                  value = parseInt(value);
                  let final_number=String(value)+last_number
                  final_number = parseInt(final_number)
                  item.style.order = -final_number;
                }
                return value.toFixed(1) + '%';
              }

            }

          },
          x: {
            show: true,
            formatter: function (value, {
              series,
              seriesIndex,
              dataPointIndex,
              w
            }) {
              return w.globals.categoryLabels[value - 1];
            },
          },

        },
        fill: {
          colors: ['#b8b9ba', '#e0e1e2', '#eeefef']
        },
        markers: {//кругляшки появляющиеся на координатах на линии
          size:0,
          // colors: '#000', //если это стоит то больше 5 графиков не добавляются
          strokeColors: '#8BC540',
          strokeWidth: 0,
          // shape: "square",
          discrete: [],
          radius: 2,
          offsetX: 0,
          offsetY: 0,
          onClick: undefined,
          onDblClick: undefined,
          showNullDataPoints: true,
          hover: {}
        },
        colors: ['#9BC540', '#FEC403', '#000','#5679e3','#e35656','#56e3b6','#f5d928','#8d071b','#0d2e82','#ce56e3','#de5e19','#374b23'],
        chart: {
          redrawOnWindowResize:true,
          redrawOnParentResize: true,
          toolbar: {
            show: false,
          },
          id: '',
          animations: {
            speed: 200
          },
          zoom:{
            enabled:false
          },
          type: 'line'
        },
        dataLabels: {
          enabled: false,
          style: {
            fontSize: '14px',
            fontFamily: 'Gilroy-Regular, Helvetica, Arial, sans-serif',
            // colors: '#fff'
          },
          background: {
            enabled: true,
            foreColor: '#fff',
            padding: 4,
            borderRadius: 2,
            borderWidth: 1,
            borderColor: '#fff',
            backgroundColor:'#8BC540'
          }
        },
        plotOptions: {
          bar: {
            distributed: true
          }
        },
        legend: { // названия графиков
          show: true,
          showForSingleSeries:true,
          showForNullSeries:true,
          position: 'bottom',
          horizontalAlign: 'center',
          fontSize: '12px',
          fontFamily: 'Gilroy-SemiBold, Arial',
          onItemClick: {
            toggleDataSeries: true
          },
          onItemHover: {
            highlightDataSeries: true
          },
          itemMargin: {
            horizontal: 5,
            vertical: 0
          },
          markers: {
            width: 9,
            height: 9,
            strokeWidth: 0,
            strokeColor: '#fff',
            fillColors: undefined,
            radius: 9,
            customHTML: undefined,
            onClick: undefined,
            offsetX: 0,
            offsetY: 0
          }
        },
        zoom: {
          enabled: false
        },
        grid: {
          borderColor: '#BDC3D1',
          strokeDashArray: 0,
          xaxis: {
            lines: {
              show: true
            }
          }, //линии пересечения на графике
          yaxis: {
            lines: {
              show: true
            }

          },
          row: {
            colors: ['#F1F2F4', '#F1F2F4', '#F1F2F4']
          },
          column: {
            colors: ['#F1F2F4', '#F1F2F4', '#F1F2F4']
          }
        },
        stroke: {
          curve: 'smooth',
          width: 1,
        },
        responsive: [{
          breakpoint: 600,
          options: {
            yaxis: {
              labels:{
                show: false,
                fontSize: '12px',

              }
            },
            xaxis: {
              labels:{
                // show: false,
                rotate: 0,
                rotateAlways: false,
                style: {
                  fontSize: '10px',
                }
              }
            },

          },
        }]
      },
    };
  },

  methods: {
    changeMonth(){

    }

  },
  render() {

  },
  mounted() {

  },
  computed: {
    obj_rate_common(){
      return Storage.getters.NAME_PROGRAMM_RATE_COMMON
    },
    obj_rate_calendar(){
      return Storage.getters.CHANGE_CALENDAR_RATE_COMMON
    }
  },

  components: {
    ChartYear,
    Chart
  },

};
</script>
<style scoped>
</style>
