<template  lang="pug">
  div.v-mortgage__vue-apexcharts(data-period="1")(@mouseover="sheduleHover" @touchmove="toolTip" @touchend="endToolTip")
    .v-mortgage__average_rate_country
      p.v-mortgage__average_rate_country_day {{options.xaxis.categories[options.xaxis.categories.length - 1]}}
      p.v-mortgage__average_rate_country_rate <span>{{series[0].data[series[0].data.length - 1]}}</span>%
    apexcharts(width='100%' height='100%' :options='options' :series='series')
</template>

<script>
// import VueApexCharts from "vue-apexcharts";
import eventBus from '../development-tools/eventBus.vue';
const VueApexCharts = () => import ("vue-apexcharts");


export default {
  props:['series','options','props_new_format_calendar'],
  name: "ChartYear",
  components: {
    apexcharts: VueApexCharts
  },
  data: function() {
    return {

    };
  },
  methods: {
    getValueHover() {
      //Доделать, чтобы не было повторяющегося кода!!!!
      const grid_column = document.querySelectorAll('.apexcharts-grid-column')
      for (let item of grid_column) {
        item.addEventListener('mousemove',()=>{
          {
            setTimeout(() => {
              const parent = item.closest('.v-mortgage__vue-apexcharts.active')
              const tooltip_title = parent.querySelectorAll('.apexcharts-active .apexcharts-tooltip-title')
              for (let item of tooltip_title){
                const text_title = item.textContent
                parent.querySelector('.v-mortgage__average_rate_country_day').textContent = text_title
              }

              const tooltip_text = parent.querySelector('.apexcharts-active .apexcharts-tooltip-text-y-value')
              if (tooltip_text) {
                parent.querySelector('.v-mortgage__average_rate_country_rate span').textContent = tooltip_text.textContent
              }
            }, 1000)
          }
        })
        item.addEventListener('click',()=>{
          {

            setTimeout(() => {
              const parent = item.closest('.v-mortgage__vue-apexcharts.active')
              const tooltip_title = parent.querySelector('.apexcharts-active .apexcharts-tooltip-title')
              if (tooltip_title) {
                parent.querySelector('.v-mortgage__average_rate_country_day').textContent = tooltip_title.textContent
              }

              const tooltip_text = parent.querySelector('.apexcharts-active .apexcharts-tooltip-text-y-value')
              if (tooltip_text) {
                parent.querySelector('.v-mortgage__average_rate_country_rate span').textContent = tooltip_text.textContent
              }
            }, 1000)

          }
        })
      }
    },
    sheduleHover(el){
      const element = el.currentTarget
      const parent = document.querySelector('.apexcharts-gridlines-horizontal')
      element.querySelector('.v-mortgage__average_rate_country').classList.add('unactive')
    },
    toolTip(el){
      document.body.classList.add('body-modal')
      const element = el.currentTarget
      if(!element.classList.contains('unactive')){
        element.querySelector('.v-mortgage__average_rate_country').classList.add('unactive')
      }
      else {
        return false
      }
    },
    endToolTip(){
      document.body.classList.remove('body-modal')
    },
  },
  computed:{

  },
  created() {

  },

  mounted() {
    // this.getValueHover()
  }
};
</script>
