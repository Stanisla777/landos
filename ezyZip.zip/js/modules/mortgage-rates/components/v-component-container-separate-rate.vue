<template lang="pug">
  .v-mortgage__container-separate-rate
    .v-mortgage__wrapper-separate-rate(
      v-for="item in object_rate_separate"

      v-bind:data-support="item[1].with_state_support"
    )
      .v-mortgage__name-programm.v-mortgage__separate_name-programm
        a(
          v-bind:href="item[1].link"
          target="_blank"
        ) {{item[1].name}}
        .v-mortgage__name-programm-icon
          svg(width='3' height='13' viewbox='0 0 3 13' fill='none' xmlns='http://www.w3.org/2000/svg')
            path(d='M1.173 2.346C1.819 2.346 2.346 1.802 2.346 1.173C2.346 0.527 1.819 0 1.173 0C0.527 0 0 0.527 0 1.173C0 1.802 0.527 2.346 1.173 2.346ZM0.255 12.121H2.091V3.621H0.255V12.121Z' fill='white')
          .v-mortgage__description-programm
            p {{item[1].description}}

      .v-mortgage__separate-rate.v-mortgage__block-rate
        template
          v-component-schedule-separate(
            :props_rate_year="item[1].rates"
            :props_rate_date="item[1].new_date"

          )
        template
          v-component-banks(
            :props_data_banks="item[0]"
          )

</template>
<script>
import vComponentScheduleSeparate from './v-component-schedule-separate.vue';
import vComponentBanks from './v-component-banks.vue';
import Storage from '../development-tools/state.vue';
import eventBus from '../development-tools/eventBus.vue';

export default {
  name: 'v-container-separate-rate',
  props:[''],
  data(){
    return {
      show_programm:true

    }
  },
  methods:{
    displayWithSupport(param){
      const container_separate_shedule = document.querySelector('.v-mortgage__container-separate-rate')
      if (container_separate_shedule) {
        const array_separate_shedule = container_separate_shedule.querySelectorAll('.v-mortgage__wrapper-separate-rate')
        for (let item_shedule of array_separate_shedule) {
          const data_attr = item_shedule.getAttribute('data-support')
          item_shedule.classList.remove('active')
          item_shedule.classList.remove('unactive')
          if (data_attr==param&&param!=2){
            item_shedule.classList.add('active')
          }
          else if (data_attr!=param&&param!=2) {
            item_shedule.classList.add('unactive')
          }
        }
      }
    }
  },
  mounted(){

  },
  computed:{
    loaded(){
      return Storage.state.loaded
    },

    object_rate_separate(){
      return Storage.getters.RATE_SEPARATE
    },

  },
  created() {
    eventBus.$on('pass_parametrSupport', (param) => {
      this.displayWithSupport(param)
    });

  },
  watch:{
  },
  components:{
    vComponentScheduleSeparate,
    vComponentBanks
  }
};
</script>
<style scoped>
</style>
