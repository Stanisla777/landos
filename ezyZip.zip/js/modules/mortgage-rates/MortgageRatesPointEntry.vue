<template lang="pug">
  div
    template
      mortgage-rates

</template>
<script>
const MortgageRates = () => import ("./MortgageRates.vue");


export default {
  name: 'StoriesPointEntry',
  data(){
    return {

    }
  },
  methods:{
  },
  mounted(){
  },
  computed:{
  },
  watch:{
  },
  components:{
    MortgageRates
  }
};
</script>
<style scoped>
</style>
