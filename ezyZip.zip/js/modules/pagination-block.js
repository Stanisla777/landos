export default function paginationBlock() {
  const pagination = document.querySelectorAll('.js--paginaton-block');
  for (let i = 0; i < pagination.length; i++) {
    // eslint-disable-next-line camelcase
    const array_pag = pagination[i].querySelectorAll('li');
    if (array_pag.length > 3) {
      // eslint-disable-next-line camelcase
      const element_after = pagination[i].querySelector('ul li:nth-child(4)');
      const element = document.createElement('li');
      element.classList.add('paginaton__ellipsis');
      pagination[i].querySelector('ul').insertBefore(element, element_after);
    } else {
      pagination[i].querySelector('.js--paginaton-btn').classList.add('unactive');
    }
  }
}
