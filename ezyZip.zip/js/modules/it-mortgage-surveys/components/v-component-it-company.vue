<template lang="pug">
  div
    p.mortgage-surveys__step-title Перечень аккредитованных IT-компаний
    .mortgage-surveys__wr-select
      .calculator_s__calculator-input.mortgage-surveys__input.js--inn-mask(
        @focusin="focusIn"
        @focusout="focusOut"
      )
        input(type="text" placeholder="Введите  ИНН организации")(
          @input="liveSearch"
          @paste="liveSearchPaste"
          @keydown="onlyNumber"

        )
      .mortgage-surveys__wr-list
        ul.mortgage-surveys__list
          li(
            v-for="item in output"
            @click="commonClickSelect"
          ) {{item}}


</template>
<script>
import Storage from '../development-tools/state.vue';
import IMask from 'imask';
export default {
  name: 'v-component-it-company',
  data(){
    return {
      output:[]

    }
  },
  methods:{
    onlyNumber(el){
      // console.log(el.keyCode);
      const element = el.currentTarget
      element.closest('.js--inn-mask').classList.remove('error')
      if(el.keyCode == 8){
        var letterNumber = /^[a-zA-Zа-яА-ЯёЁ ]+$/;
        console.log(letterNumber.test(element.value));
      }
      if ( el.keyCode == 46 || el.keyCode == 8 || el.keyCode == 9 || el.keyCode == 27 ||
        // Разрешаем: Ctrl+A
        (el.keyCode == 65 && el.ctrlKey === true) || (el.keyCode == 86 && el.ctrlKey === true) ||
        // Разрешаем: home, end, влево, вправо
        (el.keyCode >= 35 && el.keyCode <= 39)) {

        // Ничего не делаем
        return;
      } else {
        // Запрещаем все, кроме цифр на основной клавиатуре, а так же Num-клавиатуре
        if ((el.keyCode < 48 || el.keyCode > 57) && (el.keyCode < 96 || el.keyCode > 105 )) {
          element.closest('.js--inn-mask').classList.add('error')
          el.preventDefault();
        }
        if ( el.ctrlKey === true) {
          element.closest('.js--inn-mask').classList.remove('error')
          // el.preventDefault();
        }
      }


    },

    inputCost(){
      const input_status = document.querySelectorAll('.js--inn-mask input');
      const maskOptions = {
        mask: Number,
        // thousandsSeparator: ' ',
        max:'0000000000'
      };
      for (const item of input_status) {
        new IMask(item, maskOptions);
      }
    },


    liveSearchPaste(el){
      const element = el.currentTarget
      let element_val = (el.clipboardData || window.clipboardData).getData('text');
      if ( element_val.search(/[^0-9]/g) != -1 ) {
        el.preventDefault();
      }

      this.output.length=0
      const pattern = new RegExp(`${element_val}`, 'i')
      // console.log(element_val);

      this.massive_company.forEach(el=>{
        if(pattern.test(el)){
          this.output.push(el);
        }
      })

    },

    liveSearch(el){
      const element = el.currentTarget
      let element_val = element.value;

      var letterNumber = /^[a-zA-Zа-яА-ЯёЁ ]+$/i;


      if (element_val.length > 9){
        this.output.length=0
        const pattern = new RegExp(`${element_val}`, 'i')

        this.massive_company.forEach(el=>{
          if(pattern.test(el)){
            this.output.push(el);
          }
        })

      }



      else if (element_val.length ===0) {
        this.output=[]
        element.closest('.mortgage-surveys__wr-select').querySelector('.mortgage-surveys__wr-list').classList.remove('active')
        element.closest('.mortgage-surveys').classList.remove('active')
        element.closest('.mortgage-surveys').classList.remove('active-refusal')
      }
      if (element_val.length ==10 && this.output.length>0&&letterNumber.test(element_val)!==true){
        element.closest('.mortgage-surveys__wr-select').querySelector('.mortgage-surveys__wr-list').classList.add('active')
      }
      if (element_val.length ==10 && this.output.length==0){
        element.closest('.mortgage-surveys').classList.add('active-refusal')
        element.closest('.mortgage-surveys__wr-select').querySelector('.mortgage-surveys__wr-list').classList.remove('active')
      }
      if (element_val.length > 1 && this.output.length>0){
        element.closest('.mortgage-surveys').classList.remove('active-refusal')
      }
      if (element_val.length <10){
        element.closest('.mortgage-surveys__wr-select').querySelector('.mortgage-surveys__wr-list').classList.remove('active')
      }


    },
    countFoundElements(el){
      const element = el.currentTarget
      const element_val = element.value;
      const list_banks = element.closest('.mortgage-surveys__wr-select').querySelector('.mortgage-surveys__list')
      const element_val_1 = "Общество с ограниченной ответственностью"
      const element_val_2 = "Общество с ограниченной ответственностью "
      const element_val_3 = "Акционерное общество"
      const element_val_4 = "Акционерное общество "
      const element_val_5 = "Закрытое акционерное общество"
      const element_val_6 = "Закрытое акционерное общество"

      if (element_val.length > 2 && list_banks.querySelectorAll('li').length==0 && element_val!= element_val_1 &&
        element_val!= element_val_2 && element_val!= element_val_3 && element_val!= element_val_4 &&
        element_val!= element_val_5 && element_val!= element_val_6
         ){
        element.closest('.mortgage-surveys').classList.add('active-refusal')
      }
    },
    focusIn(el){
      const element = el.currentTarget
      element.classList.add('active')
    },
    focusOut(el){
      const element = el.currentTarget
      element.classList.remove('active')
    },
    commonClickSelect(el){
      this.elementSelect(el)
      this.showFinalBlock(el)
    },
    elementSelect(el){
      const element = el.currentTarget
      element.closest('.mortgage-surveys__wr-select').querySelector('input').value = element.textContent
      element.closest('.mortgage-surveys__wr-list').classList.remove('active')
    },
    showFinalBlock(el){
      const element = el.currentTarget
      element.closest('.mortgage-surveys').classList.add('active')
    }
  },
  mounted(){
    // this.inputCost()


  },
  computed:{
    massive_company(){
      return Storage.getters.MASSIVE_COMPANY
    },

  },
  watch:{
  },
  components:{

  },


  created() {

  }
};
</script>
<style scoped>
</style>
