<script>
import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios';
import VueAxios from 'vue-axios';
Vue.use(VueAxios, axios);
Vue.use(Vuex);

export default new Vuex.Store({
  state:{
    banks:[],
    company:[],
    documents:[],

    it_module:{
      it_companies:[
        {
          name: "АО РНИЦ ГОРОДА СЕВАСТОПОЛЯ ИНН 9201510872"
        }
      ],
      banks:[
        {name: "ПАО СБЕРБАНК", link: "https://www.sberbank.ru/ru/about/today", rate: "0"}
      ],
      documents:[
        {
          link: "https://docs.cntd.ru/document/350305162",
          name: "Постановление Правительства N 805 от 30.04.2022"
        }
      ]
    }



  },
  getters:{
    MASSIVE_COMPANY(state){
      return state.company
    },
    MASSIVE_BANK(state){
      return state.banks
    },
    MASSIVE_DOCUMENTS(state){
      return state.documents
    },



  },
  mutations:{
    mutationObjCompany(state,received_perem){
      const massive_company=[]
      for( let item of received_perem.it_companies){
        // let new_item = item.name.replace(/\«/g, "\'").replace(/\»/g, "\'");
        let new_item = item.name
        massive_company.push(new_item)
      }
      state.company=massive_company
      // console.log(state);
    },
    mutationObjBank(state,received_perem){
      for (let item of received_perem.banks){
        state.banks.push(item)
      }
    },
    mutationObjDocument(state,received_perem){
      for (let item of received_perem.documents){
        state.documents.push(item)
      }
      // console.log(state);
    }


  },
  actions:{
    // Получаю данные по ставкам и месяцам
    axiosGetObjectBanks_Company({commit,state}){

      // это для тестов заархивировать
      // commit('mutationObjCompany',state.it_module)
      // commit('mutationObjBank',state.it_module)
      // commit('mutationObjDocument',state.it_module)


      //------------------------это для боя разархивировать

      const config_header = {
        headers: {
          'Content-Type': 'application/json',
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
          Accept: 'application/json',
        }
      }

      // return axios.get(`http://localhost:3000/MortgageSurveys`,config_header)
      return axios.get(`/api/local/it-mortgage/`,config_header)
        .then((res)=>{
          commit('mutationObjCompany',res.data.result)
          commit('mutationObjBank',res.data.result)
          commit('mutationObjDocument',res.data.result)

        }).catch((error) => {
          console.log(error);
        });


    },

  },
})
</script>
