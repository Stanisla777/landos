<template lang="pug">
  div
    template
      v-component-it-company
    template
      v-component-it-banks

</template>
<script>
import Vue from 'vue';
import Storage from './development-tools/state.vue';
import vComponentItCompany from './components/v-component-it-company.vue';
import vComponentItBanks from './components/v-component-banks.vue';


export default {
  name: 'ItMortgageSurveys',
  data(){
    return {
      final_result:true
    }
  },
  methods:{
    callingCallToAPI(){
      Storage.dispatch('axiosGetObjectBanks_Company')
    },


  },
  mounted(){
    this.callingCallToAPI()

  },
  computed:{

  },
  watch:{
  },
  components:{
    vComponentItCompany,
    vComponentItBanks
  },


  created() {

  }
};
</script>
<style scoped>
</style>
