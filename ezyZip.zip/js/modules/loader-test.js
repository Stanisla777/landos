export default function loaderTest() {
  // eslint-disable-next-line no-shadow
  const loaderTest = document.querySelectorAll('.tab-panel__test .filter-sort .filter-sort__item');
  // eslint-disable-next-line no-unused-vars
  loaderTest.forEach((item) => {
    // eslint-disable-next-line no-param-reassign
    item.onclick = function () {
      const parent = item.closest('.filter-sort');
      // eslint-disable-next-line no-unused-vars
      const loader = parent.previousElementSibling;
      loader.setAttribute('style', 'display:flex');
      setTimeout(() => {
        loader.setAttribute('style', 'display:none');
      }, 1000);
    };
  });
}
