<template lang="pug">
  .test-cotainer-result-answers()
    .test-cotainer-result-emty-block
    .test-window__response-status-icon(v-if="!correct")
      .test-window__response-icon
        img(src="/local/templates/main/img/test-inter-fail.png")
      p.test-window__response-status-des Неверно
    .test-window__response-status-icon(v-else)
      .test-window__response-icon
        img(src="/local/templates/main/img/test-inter-well.png")
      p.test-window__response-status-des Верно
    .test-window__response-correct-answer
      p.test-window__response-des.fs-1rem(
        v-for="item in response_description"
        v-html="item"
      )


</template>

<script>
export default {
  name: "StatusAnswer",
  data(){
    return{
      status_answer:this.correct,
      status:this.win,
      response_description:[]
    }
  },

  props:['correct','description','win'],
  methods:{
    heightIntermediateWindow(){

      const elem = document.querySelector('.test-cotainer-result-answers')
      const elem_em = elem.querySelector('.test-cotainer-result-emty-block')
      const elem_em_2= elem.querySelector('.test-cotainer-result-answers')
      const style = window.getComputedStyle(elem_em).getPropertyValue("display");
      const style_2 = window.getComputedStyle(elem_em_2).getPropertyValue("display");

      const height_el = elem.clientHeight
      elem.closest('.swiper-wrapper').setAttribute('style','height:auto')
      elem.closest('.test-window').setAttribute('style',`height:${height_el+125}px`)

    },
    sameAnswers(){
      this.response_description = Array.from(new Set(this.description))
    }

  },
  watch:{
    description() {
      this.sameAnswers()
    }
  },
  mounted() {
    // this.sameAnswers()
  }

}
</script>

<style scoped>

</style>
