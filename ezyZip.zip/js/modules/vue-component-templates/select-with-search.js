/* eslint-disable */
import Vue from 'vue';
import mixinLiveSearch from '../mixinForVueComponent/mixinLiveSearch.js';
import mixinOpenListAndSelectItem from '../mixinForVueComponent/mixinOpenListAndSelectItem';
import mixinremoveAllCheckboxes from '../mixinForVueComponent/mixinremoveAllCheckboxes';

export default function SelectWithSearch() {
  const app = new Vue({
    el: '#select-with-search',
    data() {
      return {
        data_search:false,
        input:[
          {
            active:false,
            placeholder:'Регион',
            input:[]
          },
          {
            active:false,
            placeholder:'Тип программы',
            input:[]
          },
          {
            active:false,
            placeholder:'Категории участников',
            input:[]
          },
        ]
      };
    },
    mixins: [mixinLiveSearch,mixinOpenListAndSelectItem,mixinremoveAllCheckboxes],
    methods: {
      liveSearch(el) {
        const input_search = el.currentTarget;
        this.sampleliveSearch(input_search)
      },




    },
    filters: {
    },
    updated() {
    },
    computed: {
    },
    watch: {

    },
    mounted() {
      window.smartFilter
    }
  });
}
