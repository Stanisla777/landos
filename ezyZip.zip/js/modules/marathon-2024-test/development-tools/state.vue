<script>
import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios';

Vue.use(Vuex);

export default new Vuex.Store({
  state:{
    data_open:null,
    nickname:null,
    loader2:false,
    data_state:null,




    id_user:null,
    id:null,

    post_answer:null, // сюда записывается ответ от посто запроса

    finish_window:false,
    final_window_form:false,
    loading_complete:false,


    btn_next_slider:false, // активная или нет кнопка слайдера Дальше



    test_radiogroup:{},
    temporary_data_dual:{},
    temporary_data_check:{},
    temporary_data_slider:{},
    temporary_data_img:{},
    temporary_data_multi_radio:{},

    selected_data_check:[],
    selected_data_radio:[],
    selected_data_multi_radio:[],
    selected_data_dual:[],
    selected_data_slider:[],
    selected_data_img:[],

    selected_data_check_temp:[],

    time_end:false,
    nextQuestion:null,
    count_question:null,
    time_limit:null,
    current_slide:0,
    objectPost:{
      items:[
      ]
    },
    objectPostTempChec:{
      items:[
      ]
    },

    call_button_lock:false,
    status_internet:true,
    status_btn:false,

    attempt:0,
    hint:'',
    loader:false,

    correct_answers:null,

    inn:null,
    date_birth:'',
    window_successful_sending:false,

    error_sand_variant:false,
    error_sand_variant_text:'Ошибка отправки формы',

    error_sand_form_text:'Ошибка отправки формы',
    error_sand_form:false


  },
  getters:{

    LOADINGCOMPLETE(state){
      return state.loading_complete
    },
    DATAOPEN(state){
      return state.data_open
    },
    FINALWINDOWFORM(state){
      return state.final_window_form
    },

    DATASTATE(state){
      return state.data_state
    },


    ERRORSANDVARIANTTEXT(state){
      return state.error_sand_variant_text
    },

    ERRORSANDVARIANT(state){
      return state.error_sand_variant
    },
    ERRORSANDFORM(state){
      return state.error_sand_form
    },

    ERRORSANDFORMTEXT(state){
      return state.error_sand_form_text
    },

    WINDOWSUCCESSFULSENDING(state){
      return state.window_successful_sending
    },

    DATEBIRTH(state){
      return state.date_birth
    },
    NICKNAME(state){
      return state.nickname
    },

    INN(state){
      return state.inn
    },



    CURRENTSLIDE(state){
      return state.current_slide
    },

    COUNTQUESTION(state){
      return state.count_question
    },

    TIMELIMIT(state){
      return state.time_limit
    },

    TIMEEND(state){
      return state.time_end
    },

    LOADER(state){
      return state.loader
    },
    NEXTQUESTION(state){
      return state.nextQuestion
    },
    FINISHWINDOW(state){
      return state.finish_window
    },
    POSTANSWER(state){
      return state.post_answer
    },

    BTNNEXT(state){
      return state.btn_next_slider
    },

    CALL_BUTTON_LOCK(state){
      return state.call_button_lock
    },
    STATUSINTERNET(state){
      return state.status_internet
    },
    STATUSBTN(state){
      return state.status_btn
    },
    HINT(state){
      return state.hint
    },
    IDUSER(state){
      return state.id_user
    },
    CORRECTANSWERS(state){
      return state.correct_answers
    },
    LOADER2(state){
      return state.loader2
    },



  },
  mutations:{

    mutationFirstDataGet(state,received_perem){
      if (received_perem.items) {
        state.nextQuestion = received_perem.items[0]
        state.count_question = received_perem.items[0].totalCount
        state.time_limit = received_perem.items[0].timeLimit + 2
        state.current_slide = received_perem.items[0].id
        state.finish_window=false
        state.nickname = received_perem.nickname
        state.time_end=false
        state.loading_complete=true
      }
      if (received_perem.finishData) {
        state.loading_complete=false
        state.count_question = received_perem.finishData.pointsTotal
        state.correct_answers = received_perem.finishData.pointsScored
        state.nickname = received_perem.finishData.nickname
        state.inn = received_perem.finishData.inn
        state.finish_window=true
      }

      state.id_user = received_perem.id

    },

    mutatioSendVariantPost(state){
      state.loader=true
      axios({
        method:'post',
        url:'/api/local/marathon/test/question/',//расскрментировать
        // url:'http://localhost:3000/result3', //убрать
        headers: {
          "Content-type": "application/json; charset=UTF-8",
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        },

        data:state.objectPost
      })
        // Если запрос успешен, тут переписать, как если бы я получал данные от апи
        .then((res)=>{

          state.objectPost.items=[]

          //бой
          if (res.data.result.items) {
            state.nextQuestion = res.data.result.items[0];
            state.count_question = res.data.result.items[0].totalCount;
            state.time_limit = res.data.result.items[0].timeLimit + 2;
            state.current_slide = res.data.result.items[0].id;
            state.nickname = res.data.result.nickname;
            state.finish_window = false;
            state.loading_complete=true
          }
          if (res.data.result.finishData) {
            state.loading_complete=false
            state.count_question = res.data.result.finishData.pointsTotal;
            state.correct_answers = res.data.result.finishData.pointsScored;
            state.nickname = res.data.result.finishData.nickname;
            state.inn = res.data.result.finishData.inn;
            state.finish_window = true;
          }
          state.id_user = res.data.result.id
          state.time_end=false



          //тестовое, убрать
          // state.nextQuestion = {
          //   "type": "test_radioimages",
          //   "id": "2",
          //   "name": "Выберите один или несколько радиокнопок",
          //   "description": "",
          //
          //   "totalCount":16,
          //   "options": [
          //     {
          //       "id": 10,
          //       "name": "1",
          //       "image": "img/content-img_03.png"
          //     },
          //     {
          //       "id": 20,
          //       "name": "2",
          //       "image": "img/banner_mortgage_marathon_2022.png"
          //     },
          //     {
          //       "id": 30,
          //       "name": "3",
          //       "image": "img/banner_itmortgage_main.png"
          //     },
          //     {
          //       "id": 40,
          //       "name": "4",
          //       "image": "img/banner-programs-2x.png"
          //     }
          //   ]
          //
          //
          // }
          // state.count_question = 2
          // state.time_limit = 120
          // state.time_end=false
          // state.current_slide=2



          //
          // if (res.data.finishData) {
          //   state.count_question = res.data.finishData.pointsTotal
          //   state.correct_answers = res.data.finishData.pointsScored
          //   state.nickname = res.data.finishData.nickname
          //   state.inn = res.data.finishData.inn
          //   state.finish_window=true
          //   state.count_question = 15
          //   state.correct_answers = 20
          // }
          //
          //
          // state.finish_window=true

          //----------End----------------


          setTimeout(()=>{
            state.loader=false
          },1000)
        })

        // Если запрос с ошибкой
        .catch((error)=> {
          state.loader=false
          if(error.response){
            if (error.response.data.description!=undefined){
              state.error_sand_variant=true
              state.error_sand_variant_text=error.response.data.description
            }
          }
          console.log(error);
        });
    },
    mutationSendFForm(state,received_perem){
      state.loader=true
      const data={}
      data.NAME=received_perem[0]
      data.DATEBIRTH=received_perem[1]
      data.REGION=received_perem[2]
      data.MAIL=received_perem[3]
      data.TEL=received_perem[4]
      data.AGREEPERSONAL=received_perem[5]
      data.AGREEADVERTISING=received_perem[6]
      axios({
        method:'post',
        url:'/api/local/marathon/personaldata/',
        // url:'http://localhost:3000/result3', //убрать
        headers: {
          "Content-type": "application/json; charset=UTF-8",
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        },

        data:data
      })
        .then((res)=>{
          state.error_sand_form=false
          state.finish_window=false
          state.window_successful_sending=true
          setTimeout(()=>{
            state.loader=false
          },2000)
        })

        // Если запрос с ошибкой
        .catch((error)=> {
          state.loader=false
          if(error.response){
            if (error.response.data.description!=undefined){
              state.error_sand_form=true
              state.error_sand_form_text=error.response.data.description
            }
          }
          console.log(error);
        });
    },







    mutationLoader(state,received_perem){
      state.loader2 = received_perem
    },
    mutatioSendDateBirth(state,received_perem){
      state.date_birth = received_perem
    },
    mutationStatusTest(state,received_perem){
      state.data_open = received_perem
    },
    mutationStateTest(state,received_perem){
      state.data_state = received_perem
      if(received_perem===1) {
        state.finish_window=false
        state.window_successful_sending=true
      }
    },
    mutationNickName(state,received_perem){
      state.nickname=received_perem
    },

    mutationActionTimeEnd(state,received_perem){
      state.time_end = received_perem
    },

    mutationVariantRadio(state,received_perem){
      state.test_radiogroup= {}
      state.selected_data_radio=[]
      state.objectPost.items=[]
      let key = received_perem[0];
      Vue.set(state.test_radiogroup,'id_question',key)
      Vue.set(state.test_radiogroup,'id_answer', { 'id':parseInt(received_perem[1]),value:true })
      const id = state.test_radiogroup.id_question
      for(let i=0;i<state.selected_data_radio.length;i++){
        if(state.selected_data_radio[i].id_question==id){
          const index = state.selected_data_radio.findIndex(n => n.id_question === id);
          if (index !== -1) {
            state.selected_data_radio.splice(index, 1);
          }
        }
      }
      if(Object.entries(state.test_radiogroup).length!==0){
        state.selected_data_radio.push(state.test_radiogroup)
      }
      state.test_radiogroup= {}
      let obj_radio = {}
      let obj_2_radio = {}
      let array_radio = []
      for (let i = 0; i < state.selected_data_radio.length; i++) {
        Vue.set(obj_radio, state.selected_data_radio[i].id_answer.id, state.selected_data_radio[i].id_answer.value)
        array_radio.push(obj_radio)
        Vue.set(obj_2_radio, state.selected_data_radio[i].id_question, array_radio)
        state.objectPost.items.push(obj_2_radio)
        array_radio = []
        obj_radio = {}
        obj_2_radio = {}
      }
    },

    mutationVariantDual(state,received_perem){
      let main_obj = {}
      state.temporary_data_dual= {}
      state.selected_data_dual=[]
      state.objectPost.items=[]
      let key = received_perem[0];
      Vue.set(state.temporary_data_dual,'id_question',key)
      Vue.set(state.temporary_data_dual,'id_answer', { 'id':received_perem[1],value:true })

      const id_dual = state.temporary_data_dual.id_question
      for(let i=0;i<state.selected_data_dual.length;i++){
        if(state.selected_data_dual[i].id_question==id_dual){

          const index = state.selected_data_dual.findIndex(n => n.id_question === id_dual);
          if (index !== -1) {
            state.selected_data_dual.splice(index, 1);
          }
        }
      }
      if(Object.entries(state.temporary_data_dual).length!==0){
        state.selected_data_dual.push(state.temporary_data_dual)
      }
      state.temporary_data_dual= {}

      let obj_dual_btn = {}
      let obj_2_btn = {}
      let array_btn = []
      for (let i = 0; i < state.selected_data_dual.length; i++) {
        Vue.set(obj_dual_btn, state.selected_data_dual[i].id_answer.id, state.selected_data_dual[i].id_answer.value)
        array_btn.push(obj_dual_btn)
        Vue.set(obj_2_btn, state.selected_data_dual[i].id_question, array_btn)
        state.objectPost.items.push(obj_2_btn)
        array_btn = []
        obj_dual_btn = {}
        obj_2_btn = {}
      }


    },

    mutationVariantChec(state,received_perem){
      let main_obj = {}
      let key = received_perem[0];
      state.temporary_data_check= {}
      state.selected_data_check=[]
      if (state.objectPost.items.length===0){
        state.objectPost.items.push(main_obj)
        Vue.set(state.objectPost.items[0],key, [])
      }
      Vue.set(state.temporary_data_check, received_perem[1], true)
      state.objectPost.items[0][key].push(state.temporary_data_check)
    },
    mutationVariantChecDelete(state,received_perem){
      const id_question = received_perem[0]
      const id_answer = received_perem[1]
      for (let i =0; i<state.objectPost.items[0][id_question].length; i++) {
        if (id_answer == Object.keys(state.objectPost.items[0][id_question][i])[0]) {
          state.objectPost.items[0][id_question].splice(i, 1)
          break;
        }
      }
    },

    mutationVariantSlider(state,received_perem){
      // console.log(received_perem);
      state.temporary_data_slider= {}
      state.selected_data_slider=[]
      state.objectPost.items=[]
      let key = received_perem[0];
      Vue.set(state.temporary_data_slider,'id_question',key)
      Vue.set(state.temporary_data_slider,'id_answer', { 'id':parseInt(received_perem[1]),value:true })
      const id = state.temporary_data_slider.id_question
      for(let i=0;i<state.selected_data_slider.length;i++){
        if(state.selected_data_slider[i].id_question==id){
          const index = state.selected_data_slider.findIndex(n => n.id_question === id);
          if (index !== -1) {
            state.selected_data_slider.splice(index, 1);
          }
        }
      }
      if(Object.entries(state.temporary_data_slider).length!==0){
        state.selected_data_slider.push(state.temporary_data_slider)
      }
      state.temporary_data_slider= {}
      let obj_radio = {}
      let obj_2_radio = {}
      let array_radio = []
      for (let i = 0; i < state.selected_data_slider.length; i++) {
        Vue.set(obj_radio, state.selected_data_slider[i].id_answer.id, state.selected_data_slider[i].id_answer.value)
        array_radio.push(obj_radio)
        Vue.set(obj_2_radio, state.selected_data_slider[i].id_question, array_radio)
        state.objectPost.items.push(obj_2_radio)
        array_radio = []
        obj_radio = {}
        obj_2_radio = {}
      }

    },


    mutationVariantMultiRadio(state,received_perem){
      let main_obj = {}
      state.temporary_data_multi_radio= {}
      let key = received_perem[0];
      Vue.set(state.temporary_data_multi_radio,'id_question',key)
      Vue.set(state.temporary_data_multi_radio,'id_answer', [{ 'id':received_perem[1],value:received_perem[2] }])
      const id = received_perem[0]
      const id_answer = received_perem[1]
      for(let i=0;i<state.selected_data_multi_radio.length;i++){
        if(state.selected_data_multi_radio[i].id_question==id&&state.selected_data_multi_radio[i].id_answer[0].id==id_answer){
          const index = state.selected_data_multi_radio.findIndex(n => n.id_question === id&&n.id_answer[0].id===id_answer);
          if (index !== -1) {
            state.selected_data_multi_radio.splice(index, 1);
          }
        }
      }
      state.selected_data_multi_radio.push(state.temporary_data_multi_radio)
    },
    mutationVariantMultiRadioDelete(state,received_perem){
      const id = received_perem[0]
      const id_answer = received_perem[1]
      for(let i=0;i<state.selected_data_multi_radio.length;i++){
        if(state.selected_data_multi_radio[i].id_question==id&&state.selected_data_multi_radio[i].id_answer[0].id==id_answer){
          const index = state.selected_data_multi_radio.findIndex(n => n.id_question === id&&n.id_answer[0].id===id_answer);
          if (index !== -1) {
            state.selected_data_multi_radio.splice(index, 1);
          }
        }
      }
    },
    mutationInitializationSlider(state,received_perem){
      let main_obj = {}
      state.temporary_data_slider= {}
      let key = received_perem[0];
      Vue.set(state.temporary_data_slider,'id_question',key)
      Vue.set(state.temporary_data_slider,'id_answer', { 'id':received_perem[1],value:true })
      state.selected_data_slider.push(state.temporary_data_slider)
    },

    mutationVariantImg(state,received_perem){
      let main_obj = {}
      state.temporary_data_img= {}
      let key = received_perem[0];
      Vue.set(state.temporary_data_img,'id_question',key)
      Vue.set(state.temporary_data_img,'id_answer', [{ 'id':received_perem[1],value:true }])
      state.selected_data_img.push(state.temporary_data_img)
    },
    mutationVariantImgDelete(state,received_perem){
      const id = received_perem[0]
      const id_answer = received_perem[1]
      for(let i=0;i<state.selected_data_img.length;i++){
        if(state.selected_data_img[i].id_question==id&&state.selected_data_img[i].id_answer[0].id==id_answer){
          const index = state.selected_data_img.findIndex(n => n.id_question === id&&n.id_answer[0].id===id_answer);
          if (index !== -1) {
            state.selected_data_img.splice(index, 1);
          }
        }
      }
    },





    mutatioBtnSlider(state,received_perem){
      state.btn_next_slider=received_perem
    },
    mutatioInternet(state,received_perem){
      state.status_internet=received_perem
    },
    mutatioStatusBtn(state,received_perem){
      state.status_btn=received_perem
    },


  },
  actions:{
    //Время закончилось активировать кнопку Следующий вопрос
    ActionTimeEnd({commit,state},param){
      commit('mutationActionTimeEnd',param)
    },

    //первое получение данных
    ActionFirstDataGet({commit,state},param){
      commit('mutationFirstDataGet',param)
    },

    //кликнули по варианту ответа радиокнопка
    ActionVariantRadio({commit,state},param){
      commit('mutationVariantRadio',param)
    },
    //клик по чекбоксу
    ActionVariantChec({commit,state},param){
      commit('mutationVariantChec',param)
    },
    //клик по чекбоксу которые ранее был выбран
    ActionVariantChecDelete({commit,state},param){
      commit('mutationVariantChecDelete',param)
    },
    //данные от компонента слайдер-ползунок ghb инициалтзации
    ActionInitializationSlider({commit,state},param){
      commit('mutationInitializationSlider',param)
    },
    //данные от компонента слайдер-ползунок
    ActionVariantSlider({commit,state},param){
      commit('mutationVariantSlider',param)
    },

    //клик по чекбоксу
    ActionVariantImg({commit,state},param){
      commit('mutationVariantImg',param)
    },
    //клик по чекбоксу которые ранее был выбран
    ActionVariantImgDelete({commit,state},param){
      commit('mutationVariantImgDelete',param)
    },

    //Клик в элементе две кнопки
    ActionVariantDual({commit,state},param){
      commit('mutationVariantDual',param)
    },

    //кликнули по варианту ответа мульти-радиокнопка
    ActionVariantMultiRadio({commit,state},param){
      commit('mutationVariantMultiRadio',param)
    },



    ActionBtnSlider({commit,state},param){
      commit('mutatioBtnSlider',param)
    },

  //  проверка есть ли интернет
    ActionInternet({commit,state},param){
      commit('mutatioInternet',param)
    },
    ActionStatusBtn({commit,state},param){
      commit('mutatioStatusBtn',param)
    },
    ActionSendVariantPost({commit,state}){
      commit('mutatioSendVariantPost')
    },
    ActionDateBirth({commit,state},param){
      commit('mutatioSendDateBirth',param)
    },

    //  Отправка данных на сервер
    ActionSendFForm({commit,state},param){
      commit('mutationSendFForm',param)
    },
    ActionLoader({commit,state},param){
      commit('mutationLoader',param)
    },
    ActionStatusTest({commit,state},param){
      commit('mutationStatusTest',param)
    },
    ActionStateTest({commit,state},param){
      commit('mutationStateTest',param)
    },
    ActionNickName({commit,state},param){
      commit('mutationNickName',param)
    },

  }
})
</script>
