<template lang="pug">
  .test-a__counter
    .test-a__container-counter-des
      p.test-a__counter-des.
        Вопрос <span>{{current_slide}}</span> из {{count_slide}}
      .test-a__counter-des-time(
        :class="[!timer?'opacity':time_end?'error':'']"
      )
        p Осталось
        .js--coundown-page
          span
            //i.js--hour {{hour}}
            ////| :
            i.js--minutes {{minutes}}
            | :
            i.js--seconds {{seconds}}
    .test-a__progress-bar
      .test-a__progress-bar_count-answered(
        :style="[current_slide==1?{'width': '0'}:{'width':`calc((100% / ${count_slide}) * ${current_slide - 1})`}]"
      )
      .test-a__progress-bar_count-current-question(
        :style="{'width':`calc((100% / ${count_slide}) * ${current_slide})`}"
      )
    .test-a__counter-des-time.error.time-end(v-if="time_end")
      p Время ответа на вопрос закончилось
</template>
<script>

import Storage from '../development-tools/state.vue';
import eventBus from '../development-tools/eventBus.vue';
let obratniyOtschet;

export default {
  name: 'SlideCalculator',
  props:['count_slide','current_slide','count_down'],
  data(){
    return {
      timer:false,
      screenWidth : window.innerWidth,
      hour:'00',
      minutes:'00',
      seconds:'00',
    }
  },
  watch:{
    count_down(){
      this.countdownPage(this.time_limit);
    },

    next_question(){
      this.countdownPage(this.time_limit);

    },

  },
  methods: {
    updateScreenWidth() {
      this.screenWidth = window.innerWidth;
      let width = this.$refs.MarathonTestBar.closest('.js--test-container').querySelector('.js--test-cont').offsetWidth
      setTimeout(()=>{
        this.$refs.MarathonTestBar.style.width=(width - 48)+'px'
      },100)

    },
    countdownPage(counter) {
      if (obratniyOtschet!=undefined) {
        clearInterval(obratniyOtschet);
      }


      this.hour='00'
      this.minutes='00'
      this.seconds='00'
      let hour=0
      let minuti=0
      let secundi=0

      let time=0;
      // let obratniyOtschet;

      const coundown = document.querySelector('.js--coundown-page');

        if(counter!==undefined) {
          time =counter
        } else {
          time=0
        }
        time = parseInt(time)
        let kolichestvoMinut = time/60;  // желаемое время таймера в минутах (5 минут)
        let tekuscheyeVremya = new Date(); // получаем сегодняшнюю дату и время
        // let deadlineTime = tekuscheyeVremya.setMinutes(tekuscheyeVremya.getMinutes() + 5); // устанавливаем таймер на 5 минут
        let deadlineTime = new Date( new Date().getTime() + (kolichestvoMinut * 60 * 1000) ); // можно и так установить таймер на 5 минут
        // обновляем скрипт каждую секунду - так мы получаем обратный отсчет
        obratniyOtschet = setInterval(()=> {
          let seychas = new Date().getTime(); // текущее время
          let ostatokVremeni = deadlineTime - seychas; // находим различие между текущим моментом и временем дедлайна
          // преобразовываем значение миллисекунд в минуты и секунды
          hour = Math.floor( (ostatokVremeni % (1000 * 60 * 60 * 60)) / (1000 * 60 *60) );
          minuti = Math.floor( (ostatokVremeni % (1000 * 60 * 60)) / (1000 * 60) );
          secundi = Math.floor( (ostatokVremeni % (1000 * 60)) / 1000 );
          // если значение текущей минуты или секунды меньше 10, добавляем вначале ведущий ноль
          hour = hour < 10 ? "0" +  hour : hour;
          minuti = minuti < 10 ? "0" +  minuti : minuti;
          secundi = secundi < 10 ? "0" + secundi : secundi;
          // отображаем результат таймера в элементе с id="deadline-timer"
          // coundown.querySelector('.js--hour').textContent = hour;
          coundown.querySelector('.js--minutes').textContent = minuti;
          coundown.querySelector('.js--seconds').textContent = secundi;
          // если в таймере остались только секунды, меняем слово "минуты" на "секунды"
          this.timer=true
          // когда обратный отсчет закончился, отображаем соответствующее уведомление
          if (ostatokVremeni <= 0) {
            clearInterval(obratniyOtschet);
            // coundown.querySelector('.js--hour').textContent = '00';
            coundown.querySelector('.js--minutes').textContent = '00';
            coundown.querySelector('.js--seconds').textContent = '00';
            Storage.dispatch('ActionTimeEnd',true)
          }
        }, 1000);
      }
  },
  mounted() {
    // this.updateScreenWidth();
    // window.addEventListener('resize', this.updateScreenWidth);
    // this.countdownPage(this.time_limit);
  },
  computed: {
    time_end() {
      return Storage.getters.TIMEEND;
    },
    time_limit(){
      return Storage.getters.TIMELIMIT
    },
    next_question(){
      return Storage.getters.NEXTQUESTION
    },
  },
  created(){
    // eventBus.$on('TimerBegin',()=>{
    //   alert()
    //   console.log(this.time_limit);
    //   this.countdownPage(this.time_limit);
    // })
  }
};
</script>
<style scoped>
</style>
