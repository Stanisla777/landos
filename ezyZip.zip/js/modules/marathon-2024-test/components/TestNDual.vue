<template lang="pug">
  .test-a__container(
    ref="test_container"
  )
    .test-a__body(
      ref="BodyLabelDual"
    )
      .test-a__dual-wr-btn(ref="btnDual")
        .polls__test-btn.test-n-dual__button.js--dual-btn.js--percent-row(
          data-active=""
          :class="time_end?'disabled':''"
          v-for="(answer, index) in param_component.options" :key="index"
          @click="!time_end?changeVarint($event,param_component.id,answer.id):null"
        ) {{ answer.name }}

    template
      test-button(
        :modal='modal'
        :status_internet='status_internet'
        :btn_next='btn_next'
        :status_btn='status_btn'
        :btn_prev='btn_prev'
        :error_sand_variant='error_sand_variant'
        :error_sand_variant_text='error_sand_variant_text'
      )
</template>

<script>


import Storage from '../development-tools/state.vue';
import eventBus from '../development-tools/eventBus.vue';
import autoHeight from '../mixin/autoHeight';
import TestButton from './TestButton.vue';

export default {
  name: 'TextNDual',
  mixins: [autoHeight],
  props: {
    param_component:Object,
    modal:Boolean
  },
  data() {
    return {
      btn_next:false,
      btn_prev:true,
      count:0
    }
  },

  methods: {

    autoHeight() {
      if (document.documentElement.clientWidth < 470) {
        const parent = this.$refs.test_container.closest('.js--test-cont');
        const title_height = parent.querySelector('.test-a__question').offsetHeight;
        parent.querySelector('.test-a__container')
          .setAttribute('style', `min-height:calc(100vh - 32px - 26px - 24px - ${title_height}px - 40px)`);
      }
    },
    // btnNext(){
    //   this.count=0
    //   eventBus.$emit('eventbtnNext')
    // },
    btnPrev(){
      this.count=0
      eventBus.$emit('eventbtnPrev')
    },

    fullnessCheck(){
      const array_label = this.$refs.BodyLabelDual.querySelectorAll('.js--percent-row.active');
      if(array_label.length!==0){
        this.btn_next=true
      }
    },

    changeVarint(elem,id_question,id_answer){
      const element = elem.currentTarget
      const array_btn = this.$refs.btnDual.querySelectorAll('.js--dual-btn');
      array_btn.forEach((item)=>{
        item.setAttribute('data-active','')
      })
      element.setAttribute('data-active','active')
      Storage.dispatch('ActionVariantDual',[id_question,id_answer])
      this.btn_next=true
    },

    /**
     * Подготавливает необходимые данные и вызывает событие для отправки
     */
    prepareDataForSend() {
      const data = {
        isAnswerValueCorrect: this.isAnswerValueCorrect
      };
      this.$emit('readyForDataSending', data);
    }
  },
  created(){
    eventBus.$on('slideNextTransition',()=>{
      if(this.count===0){
        // this.fullnessCheck()
        this.count=1
      }
    })
    eventBus.$on('slidePrevTransition',()=>{
      if(this.count===0){
        // this.fullnessCheck()
        this.count=1
      }
    })
    eventBus.$on('slideReachBeginning',()=>{
      this.btn_prev=false
    })
    eventBus.$on('slideFromEdge',()=>{
      this.btn_prev=true
    })

  },
  computed: {
    error_sand_variant() {
      return Storage.getters.ERRORSANDVARIANT;
    },
    error_sand_variant_text() {
      return Storage.getters.ERRORSANDVARIANTTEXT;
    },
    status_internet() {
      return Storage.getters.STATUSINTERNET;
    },
    status_btn() {
      return Storage.getters.STATUSBTN;
    },
    hint() {
      return Storage.getters.HINT;
    },
    time_end() {
      return Storage.getters.TIMEEND;
    }

  },
  watch: {

  },
  mounted() {
  },
  updated() {
  },
  components: {
    TestButton
  }

}
</script>
