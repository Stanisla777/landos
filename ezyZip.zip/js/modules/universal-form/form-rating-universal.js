/* eslint-disable */
import Vue from 'vue';

export default function formRating() {
  const formRate=document.querySelectorAll('.js--form-rating-universal');
  const cookie_key = `was_useful_rating_${window.location.pathname}`;
  for(let item=0;item<formRate.length;item++){
    formRate[item].id = `js--form-rating-universal${item}`;
    const app = new Vue({
      el: `#js--form-rating-universal${item}`,
      data: {
        array_star:[`form-rating-input-${item}-1`,`form-rating-input-${item}-2`,`form-rating-input-${item}-3`,`form-rating-input-${item}-4`,`form-rating-input-${item}-5`],
        rate:0,
        count: 0
      },
      methods: {
        changeGrade(el,index){
          const element = el.currentTarget
          const parent = this.$refs.formRating;
          this.rate = this.array_star.length - index
          //действие над звёздочками оценки
          const array_star = parent.querySelectorAll('.js--grade-item')
          for(let i=0;i<array_star.length-this.rate;i++){
            array_star[i].checked=false
          }
          for(let i=0;i<this.rate;i++){
            array_star[(array_star.length-1)-i].checked=true
          }
          this.$refs.ratingInputHidden.value=element.getAttribute('for-raiting')
          if(element.closest('.js--form-rating-universal') && element.closest('.js--form-rating-universal').querySelector('.js--input__error_radio-group')) {
            element.closest('.js--form-rating-universal').querySelector('.js--input__error_radio-group').remove()
            element.closest('.js--form-rating-universal').classList.remove('input_error')
          }

        },

        handleExternalClick() {
          let count =0;
          let count_check =0;
          const array_radio = this.$refs.formRating.querySelectorAll('.js--grade-item')
          count = array_radio.length
          for (let item of array_radio) {
            if (item.checked) {
              count_check+=1
            }
          }

        }

      },
      computed: {
      },
      watch: {
      },
      mounted() {

        const externalButton = document.querySelector('.js--another-thing-new-foc .js--btn-universal-form')
        if (externalButton) {

          this.externalClickHandler = () => this.handleExternalClick();
          externalButton.addEventListener('click', this.externalClickHandler);

        }

      },
      components: {

      },
      beforeDestroy() {
        const externalButton = document.querySelector('.js--another-thing-new-foc .js--btn-universal-form')
        if (externalButton) {
          externalButton.removeEventListener('click',this.externalClickHandler)
        }
      }
    })
  }

}
