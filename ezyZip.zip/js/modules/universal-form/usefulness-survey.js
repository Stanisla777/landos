/* eslint-disable */
import Vue from 'vue';
import universalForm from '../universal-form/universal-form';

export default function formRating() {
  const formRate=document.querySelectorAll('.js--usefulness-survey');
  const cookie_key = `was_useful_rating_${window.location.pathname}`;
  for(let item=0;item<formRate.length;item++){
    formRate[item].id = `js--usefulness-survey${item}`;
    const useful = new Vue({
      el: `#js--usefulness-survey${item}`,
      data: {
        value_radio:'',
        data_yes_label:'',
        data_yes_required_hint:'',
        data_no_label:'',
        data_no_required_hint:'',
        data_required_hint:'Поле не заполнено'


      },
      methods: {
        changeUsefulness(el) {
          const element = el.currentTarget
          this.value_radio = element.getAttribute('data-value')
          if (this.value_radio==='yes') {
            this.data_required_hint = this.data_yes_required_hint
            if (this.$refs.feedBackTextarea.querySelector('.js--input__error_required')) {
              this.$refs.feedBackTextarea.querySelector('.js--input__error_required').textContent = this.data_required_hint
            }
          } else if (this.value_radio==='no') {
            this.data_required_hint = this.data_no_required_hint
            if (this.$refs.feedBackTextarea.querySelector('.js--input__error_required')) {
              this.$refs.feedBackTextarea.querySelector('.js--input__error_required').textContent = this.data_required_hint
            }
          }
          const parent = element.closest('.js--usefulness-survey')
          // this.$refs.feedBackTextarea.classList.remove('input_error')
          // if (this.$refs.feedBackTextarea.querySelector('.js--input__error_required')) {
          //   this.$refs.feedBackTextarea.querySelector('.js--input__error_required').remove()
          // }
        }

      },
      computed: {
      },
      watch: {
      },
      mounted() {
        this.data_no_label = this.$el.dataset.noLabel
        this.data_no_required_hint = this.$el.dataset.noRequiredHint
        this.data_yes_label = this.$el.dataset.yesLabel
        this.data_yes_required_hint = this.$el.dataset.yesRequiredHint

        const array_radio = this.$refs.usefulnessSurvey.querySelectorAll('input[type="radio"]')
        for (let item of array_radio) {
          if (item.checked) {
            this.value_radio = item.getAttribute('data-value')
            if (this.value_radio==='yes') {
              this.data_required_hint = this.data_yes_required_hint
            } else if (this.value_radio==='no') {
              this.data_required_hint = this.data_no_required_hint
            }
          }
        }
        universalForm();

      },
      components: {

      },
    })
  }

}
