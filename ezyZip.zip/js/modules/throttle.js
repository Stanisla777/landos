export default function throttle(f, t, buttons, top) {
    // eslint-disable-next-line func-names
    return function () {
        const previousCall = this.lastCall;
        this.lastCall = Date.now();
        if (previousCall === undefined || (this.lastCall - previousCall) > t) {
            f(buttons, top);
        }
    };
}
