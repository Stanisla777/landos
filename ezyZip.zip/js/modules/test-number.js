export default function testNumber() {
  let parentEl = document.querySelectorAll('.test-window-js');
  parentEl = Array.prototype.slice.call(parentEl);
  if (parentEl.length > 0) {
    const countEl = parentEl.length;
    parentEl.forEach((item, ind) => {
      // eslint-disable-next-line no-unused-vars,no-multi-assign
      const elemNumberAll = item.querySelector('.test-window__number p span:nth-child(2)');
      elemNumberAll.textContent = countEl;
      const elemNumberCurrent = item.querySelector('.test-window__number p span:first-child');
      elemNumberCurrent.textContent = ind + 1;
    });
  }
}
