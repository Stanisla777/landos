<template lang="pug">
  .form-ocenka__block
    form#form.form-ocenka
    p(v-show="simply") адресс
    p(v-show="showErrorSearch") Ничего не найдено

      .form-ocenka__row(ref="ocenkaRow")

        .form-ocenka__col(v-for="inp in inputs" :key="inp.id" :data-id="inp.id")

          p.form-ocenka__col_label {{inp.label}}
          label.input
            .select.select_hidden
              .select__background
              template(v-if="inp.mark === 'area'")
                input(:placeholder="inp.plh" v-model="inp.value" @input="firstZero" type="number" inputmode="numeric")
                p.input__error(style="display:block;") Площадь
              template(v-else-if="inp.mark === 'adress'")
                input(:placeholder="inp.plh" v-model="inp.value" @input="someMethods")
                .select__list-wrapper(style='display:block;' ref="searchResults")
                  ul.select__list
                    li.select__list-item Москва
                    li.select__list-item Волгоград


              input(v-else :placeholder="inp.plh" v-model="inp.value")



        .form-ocenka__col
          p.form-ocenka__col_label.media
          p.form-ocenka__clear(@click="clearField") Очистить все
        .form-ocenka__col

          p.form-ocenka__col_label.media
          button.btn.full Оценить




    .map__cont(style="height: 640px;background-color: red;position: relative;")
      .bullet(style="margin-top:80px;position:relative;")
        button.bullet__close
        h3.bullet__title г. Москва, ул. Пилота Нестерова, д. 9А
        .bullet__body
          .bullet__info
            .bullet__col
              span.bullet__lbl Цена за м²
              span.bullet__data {{bullet.priceMin | format}} ₽
            .bullet__col
              span.bullet__lbl Цена
              span.bullet__data {{bullet.price | format}} ₽
            .bullet__col
              span.bullet__lbl ДИАПАЗОН ЦЕН
              .bullet__row
                span.bullet__data {{ bullet.price_range[0] | format }} -
                span.bullet__data {{ bullet.price_range[1] | format }} ₽
            .bullet__col.bullet__col_xl(v-if="bullet.stations.length")
              span.bullet__lbl(v-if="bullet.stations[0].type === 'метро'") Ближайшее {{ bullet.stations[0].type }}
              span.bullet__lbl(v-else) Ближайший {{ bullet.stations[0].type }}
              .bullet__station-container
                .bullet__data.bullet__station-wr(v-for="item in bullet.stations")
                  .bullet__distance-wr
                    span {{ item.distance }}&nbsp;м
                  span.bullet__name-station {{ item.name }}
        .bullet__more
          p.bullet__link-more(@click.prevent="handlerBuildInfo(true)") Подробнее о доме


    .bullet__infrastructure-block
      h3.bullet__infrastructure-title Инфраструктура для&nbsp;жизни
      .map-filter__wr-container
        .map-filter__container
          .map-filter
            //правка переделал .map-filter__item
            .map-filter__item(
              v-for="(item, idx) in social"
              :class="{'is-active': idx === idActiveFilter}"
              @click.capture="handlerFilter(idx,$event)"
            )
              p {{item.category}}

              .map-filter__item-icon(@click="clearFilter")
                svg(width='16', height='16', viewbox='0 0 16 16', fill='none', xmlns='http://www.w3.org/2000/svg')
                  path(fill-rule='evenodd', clip-rule='evenodd', d='M3.52876 3.5286C3.78911 3.26825 4.21122 3.26825 4.47157 3.5286L8.00016 7.05719L11.5288 3.5286C11.7891 3.26825 12.2112 3.26825 12.4716 3.5286C12.7319 3.78895 12.7319 4.21106 12.4716 4.47141L8.94297 8L12.4716 11.5286C12.7319 11.7889 12.7319 12.2111 12.4716 12.4714C12.2112 12.7318 11.7891 12.7318 11.5288 12.4714L8.00016 8.94281L4.47157 12.4714C4.21122 12.7318 3.78911 12.7318 3.52876 12.4714C3.26841 12.2111 3.26841 11.7889 3.52876 11.5286L7.05735 8L3.52876 4.47141C3.26841 4.21106 3.26841 3.78895 3.52876 3.5286Z', fill='white')







    .map__cont(style="height: 640px;background-color: red;position: relative;")
      .bullet.bullet_infrastructure(v-if="bulletInfraShow")
        button.bullet__close
        .bullet__header(v-if="bldPhotos")
          img(:src="bldPhotos[0]")
        .bullet__body
          .bullet__info
            .bullet__col.bullet__col_alone
              h3.bullet__title ВкусВилл

              p.bullet__desc магазин с доставкой полезных продуктов
              p.bullet__desc-time 2 мин

        .bullet__more
          a.bullet__link-more(href="#" target="_blank") Посмотреть на карте

    .block-container
      .bullet__info-block
        p Информация носит справочный характер и&nbsp;не&nbsp;является публичной офертой


</template>
<script>
import dropDown from '../../dropDown';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-component-it-bullet',
  data(){
    return {
      output:[],

      inputs: [
        {
          id: 0,
          plh: 'Введите адрес',
          type: 'text',
          value: '',
          isNotValid: false,
          validate: true,

          mark:'adress',
          label:'Адрес здания',
        },
        {
          id: 1,
          type: 'number',
          plh: 'Введите площадь',
          value: '',
          isNotValid: false,
          validate: true,

          mark:'area',
          label:'Площадь, м2',
        },
        {
          id: 2,
          plh: 'Студия',
          value: '',
          type: 'select',
          lists: [
            {
              id: 0,
              title: 'Студия',
              value: '1'
            },
            {
              id: 1,
              title: '1 комнатная',
              value: '1'
            },
            {
              id: 2,
              title: '2 комнатная',
              value: '2'
            },
            {
              id: 3,
              title: '3 комнатная',
              value: '3'
            },
            {
              id: 4,
              title: '4 комнатная',
              value: '4'
            }
          ],

          mark:'type',
          label:'Количество комнат',
        },
      ],
      showBullet:false,
      social: [
        {category:'Продукты'},
        {category:'Музыка'},
        {category:'Спорт'},
      ],
      idActiveFilter: 0,
      bulletInfraShow:true,
      showErrorSearch:false,
      simply:false
    }
  },
  methods:{
    someMethods(){
      console.log('Привет');
    },

    firstZero(el){
      this.inputs[1].value = this.inputs[1].value.replace(/^0+/gi, '1').replace(',', '.').replace(/[^\d\.]/g, "").replace(/\./, "x").replace(/\./g, "").replace(/x/, ".")
    },
    characterBan(e){
      return false
      // const invalidChars = [
      //   "-",
      //   "+"
      // ];
      // if (invalidChars.includes(e.key)) {
      //   e.preventDefault();
      // }

    },

    //правка добавил метод
    clearFilter(){
      this.idActiveFilter=null
      this.bulletInfraShow=false
    },

    handlerFilter(id,el) {

      const element = el.currentTarget;
      if(!element.classList.contains('is-active')){
        this.idActiveFilter = id;
        // this.setObjectToMap();
      }

    },

    clearField(el){
      this.inputs[0].value=''
      this.inputs[1].value=''
      this.inputs[0].isNotValid=false
      this.inputs[1].isNotValid=false
      console.log(this.$refs.SelectList);
      this.$refs.SelectList[0].querySelector('.select__list-item:first-child').click()
      this.bullet.showBullet=false
    },
    searchError(el){
      alert()
      if(this.inputs[0].value.length>8){
        if(this.$refs.searchResults[0].querySelectorAll('ul li').length===0){
          this.showErrorSearch=true
        }
        else {
          this.showErrorSearch=false
        }
      }
      else{
        this.showErrorSearch=false
      }

    }
  },
  filters: {

    format: (val) => {
      const sign = Math.sign(Number(val));
      // Nine Zeroes for Billions
      return Math.abs(Number(val)) >= 1.0e9
        ? (sign * (Math.abs(Number(val)) / 1.0e9).toFixed(3) + " блн").replace('.', ',')
        : // Six Zeroes for Millions
        Math.abs(Number(val)) >= 1.0e6
          ? (sign * (Math.abs(Number(val)) / 1.0e6).toFixed(3) + " млн").replace('.', ',')
          : // Three Zeroes for Thousands
          Math.abs(Number(val)) >= 1.0e3
            ? (sign * (Math.abs(Number(val)) / 1.0e3).toFixed(1) + " тыс").replace('.', ',')
            : Math.abs(Number(val));
    },
    format_spase:(val) => {
      return `${val}`.replace(/(\d)(?=(\d{3})+([^\d]|$))/g, '$1 ').replace('.', ',')
    },
    format_date:(val) => {
      return `${val}`.split('-').reverse().join('.');
    },
    format_point_comma:(val) => {
      return `${val}`.replace('.', ',');
    },

  },
  mounted(){

  },
  computed:{
    bullet(){
      return Storage.getters.BULLET
    },
    bldPhotos(){
      return Storage.getters.PHOTOS
    },




  },
  watch:{
    inputs: {
      handler(e) {
        console.log(e);
      },
      deep: true
    }
  },
  components:{

  },


  created() {

  }
};
</script>
<style scoped>
</style>
