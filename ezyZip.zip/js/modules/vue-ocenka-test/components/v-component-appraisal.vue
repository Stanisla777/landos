<template lang="pug">
  .white-back
    .container

      .appraisal__block
        .appraisal

          .appraisal__headline-row

            h2.bullet__title г. Москва, ул. Пилота Нестерова
          .appraisal__wrap
            .appraisal__header
              .appraisal__tabs.tab
                .tab__nav
                  button.tab__nav-item.is-active
                    | О доме
                  button.tab__nav-item
                    | О квартире

                .tab__content.is-show
                  .appraisal__info(v-for="item in tabs[0].content" :key="item.id" v-if="item.data")
                    span.appraisal__desc(v-html="item.desc")
                    a.appraisal__data(v-if="item.link" :href="item.linkUrl")
                      span {{ item.linkLabel || item.data }}
                      span.appraisal__icon(v-show="item.linkUrl" :class="item.additionalClass")
                    span.appraisal__data(v-else-if="item.isCost") {{ item.data | format_spase }} ₽
                    span.appraisal__data(v-else-if="item.isArea") {{ item.data | format_point_comma }} м²
                    span.appraisal__data(v-else-if="item.isWearIndex") {{ item.data | format_point_comma }}
                    span.appraisal__data(v-else-if="item.isDateCost") {{ item.data | format_date }}
                    span.appraisal__data(v-else) {{ item.data }}
            .appraisal__body
              //тут менял, для разработки!!!!
              //img.appraisal__img(:src="bldPhotos[0]")
              .swiper-container#swiper-appraisal
                .swiper-wrapper
                  .swiper-slide(v-for="(photo, idx) in bldPhotos" :key="idx")
                    img.appraisal__img(:src="photo")
                .swiper-footer
                  .swiper-pagination
                .swiper-button-prev
                .swiper-button-next

</template>
<script>
import dropDown from '../../dropDown';
import Storage from '../development-tools/state.vue';
import Swiper, { Navigation, Pagination } from 'swiper';
Swiper.use([Navigation, Pagination]);

export default {
  name: 'v-component-it-bullet',
  data(){
    return {
      output:[]

    }
  },
  methods:{
    appraisalSlider() {
      // eslint-disable-next-line no-unused-vars
      const mySwiper = new Swiper('#swiper-appraisal', {
        slidesPerView: 1,
        spaceBetween: 80,
        loop: true,
        observer: true,
        observeParents: true,
        pagination: {
          el: '.swiper-pagination',
          clickable: true,
        },
        navigation: {
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
        }
      });
    },


  },
  filters: {

    format: (val) => {
      const sign = Math.sign(Number(val));
      // Nine Zeroes for Billions
      return Math.abs(Number(val)) >= 1.0e9
        ? (sign * (Math.abs(Number(val)) / 1.0e9).toFixed(3) + " блн").replace('.', ',')
        : // Six Zeroes for Millions
        Math.abs(Number(val)) >= 1.0e6
          ? (sign * (Math.abs(Number(val)) / 1.0e6).toFixed(3) + " млн").replace('.', ',')
          : // Three Zeroes for Thousands
          Math.abs(Number(val)) >= 1.0e3
            ? (sign * (Math.abs(Number(val)) / 1.0e3).toFixed(1) + " тыс").replace('.', ',')
            : Math.abs(Number(val));
    },
    format_spase:(val) => {//правка
      return `${val}`.replace(/(\d)(?=(\d{3})+([^\d]|$))/g, '$1 ').replace('.', ',')
    },
    format_date:(val) => { //правка
      return `${val}`.split('-').reverse().join('.');
    },
    format_point_comma:(val) => { //правка
      return `${val}`.replace('.', ',');
    },

  },
  mounted(){
    this.appraisalSlider()
  },
  computed:{
    tabs(){
      return Storage.getters.APPRAISAL
    },
    bldPhotos(){
      return Storage.getters.PHOTOS
    },




  },
  watch:{
  },
  components:{

  },


  created() {

  }
};
</script>
<style scoped>
</style>
