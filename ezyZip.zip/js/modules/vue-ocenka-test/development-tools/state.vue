<script>
import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios';
import VueAxios from 'vue-axios';
Vue.use(VueAxios, axios);
Vue.use(Vuex);

export default new Vuex.Store({
  state:{
    bullet: {
      showBullet: true,
      address: '',
      priceMin: '',
      price: '',
      price_range:[],
      stations: []
    },
    tabs: [
      {
        id: 0,
        title: 'О доме',
        isActive: false,
        content: [
          {
            id: 0,
            desc: 'Кадастровый номер',
            data: '',
            link: true,
            linkUrl: '',
            additionalClass: 'appraisal__icon_download'
          },
          {
            id: 1,
            desc: 'Цена',
            data: '',
            isCost: true
          },
          {
            id: 2,
            desc: 'Цена за м²',
            data: '',
            isCost: true
          },
          {
            id: 3,
            desc: 'Минимальная цена за м²',
            data: '',
            isCost: true
          },
          {
            id: 4,
            desc: 'Год постройки',
            data: ''
          },
          {
            id: 5,
            desc: 'Этажность дома',
            data: ''
          },
          {
            id: 6,
            desc: 'Количество подъездов',
            data: ''
          },
          {
            id: 7,
            desc: 'Количество лифтов',
            data: ''
          },
          {
            id: 8,
            desc: 'Количество подземных этажей',
            data: ''
          },
          {
            id: 9,
            desc: 'Тип здания',
            data: ''
          },
          {
            id: 10,
            desc: 'Материалы стен',
            data: ''
          },
          {
            id: 11,
            desc: 'Индекс износа здания',
            data: '',
            isWearIndex: true
          },
          {
            id: 12,
            desc: 'Проект здания',
            data: ''
          },
          {
            id: 13,
            desc: 'Материал перекрытий',
            data: ''
          },
          {
            id: 14,
            desc: 'Наличие газоснабжения',
            data: ''
          },
        ]
      },
      {
        id: 1,
        title: 'О квартире',
        isActive: true,
        content: [
          {
            id: 0,
            desc: 'Идентификатор записи в&nbsp;ЕГРН',
            data: ''
          },
          {
            id: 1,
            desc: 'Идентификатор записи в&nbsp;ГКН',
            data: ''
          },
          {
            id: 2,
            desc: 'Кадастровый номер',
            data: ''
          },
          {
            id: 3,
            desc: 'Кадастровая стоимость',
            data: '',
            isCost: true
          },
          {
            id: 4,
            desc: 'Дата установления кадастровой стоимости',
            data: '',
            isDateCost:true
          },
          {
            id: 5,
            desc: 'Площадь',
            data: '',
            isArea: true
          },
          {
            id: 6,
            desc: 'Этаж',
            data: ''
          },
          {
            id: 7,
            desc: 'Количество комнат',
            data: ''
          },
          {
            id: 8,
            desc: 'Информация о&nbsp;зарегистрированных правах',
            data: ''
          },
          {
            id: 9,
            desc: 'Информация об&nbsp;обременении права',
            data: ''
          },
        ]
      }
    ],
    bldPhotos:[
      "https://i4.photo.2gis.com/main/geo/1/141373143520913/view","https://i4.photo.2gis.com/main/geo/1/141373143520913/view"
    ],




  },
  getters:{
    BULLET(state){
      return state.bullet
    },

    APPRAISAL(state){
      return state.tabs
    },
    PHOTOS(state){
      return state.bldPhotos
    },



  },
  mutations:{
    mutationObjCompany(state,received_perem){
      state.bullet.address = received_perem.address;
      state.bullet.priceMin = received_perem.stats.min;
      state.bullet.price = received_perem.stats.price;
      state.bullet.price_range = received_perem.stats.priceRange;
      if (received_perem.bld.stations) {
        state.bullet.stations = received_perem.bld.stations;
      }
      // state.bldPhotos=received_perem.bld.photos

      state.tabs[0].content[0].data = received_perem.bld.cadNum;
      state.tabs[0].content[0].linkUrl = received_perem.bld.linkPKK;
      state.tabs[0].content[1].data = received_perem.stats.price;
      state.tabs[0].content[2].data = received_perem.stats.min;
      state.tabs[0].content[3].data = received_perem.stats.min;
      state.tabs[0].content[4].data = received_perem.bld.bldYear;
      state.tabs[0].content[5].data = received_perem.bld.maxFloor;
      state.tabs[0].content[6].data = received_perem.bld.entranceCount;
      state.tabs[0].content[7].data = received_perem.bld.elevatorCount;
      state.tabs[0].content[8].data = received_perem.bld.uFloors;
      state.tabs[0].content[9].data = received_perem.bld.bldType;
      state.tabs[0].content[10].data = received_perem.bld.wallMaterial;
      state.tabs[0].content[11].data = received_perem.bld.wearout;
      state.tabs[0].content[12].data = received_perem.bld.bldProject;
      state.tabs[0].content[13].data = received_perem.bld.floorMaterial;
      state.tabs[0].content[14].data = received_perem.bld.supplyTypeGas;














      if (received_perem.flat) {
        state.flat = true;
        state.tabs[1].content[0].data = received_perem.flat.premisesId;
        state.tabs[1].content[1].data = received_perem.flat.parcelId;
        state.tabs[1].content[2].data = received_perem.flat.cadNum;
        state.tabs[1].content[3].data = received_perem.flat.cadCost;
        state.tabs[1].content[4].data = received_perem.flat.dateCost;
        state.tabs[1].content[5].data = received_perem.flat.area;
        state.tabs[1].content[6].data = received_perem.flat.floor;
        state.tabs[1].content[7].data = received_perem.flat.rooms;
        if (received_perem.flat.rights) {
          state.tabs[1].content[8].data = received_perem.flat.rights[0].desc;
        }
        if (received_perem.flat.rights[0].encum) {
          state.tabs[1].content[9].data = received_perem.flat.rights[0].encum[0].desc;
        }
      }
      console.log(state);

    },

  },
  actions:{
    // Получаю данные по ставкам и месяцам
    axiosGetObjectBanks_Company({commit,state}){

      const config_header = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        }
      }

      return axios.get(`http://localhost:3000/result`,config_header)
        .then((res)=>{
          commit('mutationObjCompany',res.data)

        }).catch((error) => {
          console.log(error);
        });


    },

  },
})
</script>
