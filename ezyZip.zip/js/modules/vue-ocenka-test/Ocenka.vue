<template lang="pug">
  div
    template
      v-component-it-bullet

    .appraisal__back(@click="goBack")
      .appraisal__back-arrow
        svg(width='20', height='20', viewbox='0 0 20 20', fill='none', xmlns='http://www.w3.org/2000/svg')
          path(fill-rule='evenodd', clip-rule='evenodd', d='M1.91058 10.5601C1.58514 10.2507 1.58514 9.74918 1.91058 9.43983L7.21388 4.39864C7.53932 4.08929 8.06696 4.08929 8.39239 4.39864C8.71783 4.70799 8.71783 5.20955 8.39239 5.5189L4.51168 9.20781H17.4998C17.9601 9.20781 18.3332 9.56247 18.3332 9.99996C18.3332 10.4374 17.9601 10.7921 17.4998 10.7921H4.51168L8.39239 14.481C8.71783 14.7904 8.71783 15.2919 8.39239 15.6013C8.06696 15.9106 7.53932 15.9106 7.21388 15.6013L1.91058 10.5601Z', fill='#252628')
      p Назад


    template
      v-component-it-appraisal

</template>
<script>
import Vue from 'vue';
import Storage from './development-tools/state.vue';
import vComponentItBullet from './components/v-component-bullet.vue';
import vComponentItAppraisal from './components/v-component-appraisal.vue';


export default {
  name: 'VOcenka',
  data(){
    return {
      final_result:true,
      showBuildInfo:false,
      bulletInfraShow:false
    }
  },
  methods:{
    callingCallToAPI(){
      Storage.dispatch('axiosGetObjectBanks_Company')
    },

    //правка добавил метод возвращения назад
    goBack(){
      this.bulletInfraShow=false
      this.showBuildInfo=false
    }


  },
  mounted(){
    this.callingCallToAPI()

  },
  computed:{

  },
  watch:{
  },
  components:{
    vComponentItBullet,
    vComponentItAppraisal
  },


  created() {

  }
};
</script>
<style scoped>
</style>
