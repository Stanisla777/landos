/* eslint-disable */
import VanillaCalendar from './vanilla-calendar';

function activeSort() {
  // eslint-disable-next-line camelcase
  const array_material_sort = document.querySelectorAll('.js--material-sorting-title');
  // eslint-disable-next-line no-restricted-syntax,camelcase
  for (const item of array_material_sort) {
    item.onclick = () => {
      for (let i=0;i<array_material_sort.length;i++){
        if (!item.closest('.js--material-sorting').classList.contains('active')){
          array_material_sort[i].closest('.js--material-sorting').classList.remove('active');
          array_material_sort[i].classList.remove('active');
        }

      }
      if (item.closest('.js--material-sorting').classList.contains('active')) {
        item.closest('.js--material-sorting').classList.remove('active');
        item.classList.remove('active');
      } else {
        item.closest('.js--material-sorting').classList.add('active');
        item.classList.add('active');
      }
    };
  }
}

function addButton(item){
  const div_2 = document.createElement('div');
  div_2.className = 'material-sorting__calendar-btn';
  div_2.innerHTML = `<div class="material-sorting__calendar-btn-wr">
                         <div class="material-sorting__calendar-btn-icon">
                           <svg width="18" height="20" viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                             <path fill-rule="evenodd" clip-rule="evenodd" d="M5.66663 0.833374C6.12686 0.833374 6.49996 1.20647 6.49996 1.66671V2.50004H11.5V1.66671C11.5 1.20647 11.8731 0.833374 12.3333 0.833374C12.7935 0.833374 13.1666 1.20647 13.1666 1.66671V2.50004H14.8333C16.214 2.50004 17.3333 3.61933 17.3333 5.00004V16.6667C17.3333 18.0474 16.214 19.1667 14.8333 19.1667H3.16663C1.78591 19.1667 0.666626 18.0474 0.666626 16.6667V5.00004C0.666626 3.61933 1.78591 2.50004 3.16663 2.50004H4.83329V1.66671C4.83329 1.20647 5.20639 0.833374 5.66663 0.833374ZM4.83329 4.16671H3.16663C2.70639 4.16671 2.33329 4.5398 2.33329 5.00004V7.50004H15.6666V5.00004C15.6666 4.5398 15.2935 4.16671 14.8333 4.16671H13.1666V5.00004C13.1666 5.46028 12.7935 5.83337 12.3333 5.83337C11.8731 5.83337 11.5 5.46028 11.5 5.00004V4.16671H6.49996V5.00004C6.49996 5.46028 6.12686 5.83337 5.66663 5.83337C5.20639 5.83337 4.83329 5.46028 4.83329 5.00004V4.16671ZM15.6666 9.16671H2.33329V16.6667C2.33329 17.1269 2.70639 17.5 3.16663 17.5H14.8333C15.2935 17.5 15.6666 17.1269 15.6666 16.6667V9.16671Z" fill="black"/>
                           </svg>
                          </div>
                         <p>Выбрать период</p>
                       </div>`;
  item.append(div_2);
}

function initCalendar() {
  const array_calendar = document.querySelectorAll('.js__vanilla-calendar')
  const array_inp = document.querySelectorAll('.js--sort-calendar');
  for(let item of array_calendar){
    const calendar = new VanillaCalendar(item, {
      settings: {
        lang: 'ru',
        range: {
          max: new Date().toISOString().slice(0, 10)
        },
        selection: {
          day: 'multiple-ranged',
        },
      },
      actions: {
        clickDay(e, dates) {
          // console.log(dates);
          dates = dates.sort((data1, data2) => data1.split('.').reverse().join('-').localeCompare(data2.split('.').reverse().join('-')) > 0 ? 1 : -1);
          // console.log(dates);
          e.target.closest('.js--sort-calendar-item').classList.remove('clear-calendar')
          e.target.closest('.js--sort-calendar-item').classList.remove('auto-click')
          e.target.closest('.js--sort-calendar-item').classList.remove('period-selected')
          for (let i = 0; i < dates.length; i++) {
            if (dates.length == 1) {
              e.target.closest('.js--sort-calendar-item').querySelector('.js--sort-calendar').value = (dates[0].replace(/-/g, '.')).replace(/([0-9]+)\.([0-9]+)\.([0-9]+)/, '$3.$2.$1');
              e.target.closest('.js--container-filter').querySelector('.js--sort-begin').value = (dates[0].replace(/-/g, '.')).replace(/([0-9]+)\.([0-9]+)\.([0-9]+)/, '$3.$2.$1');
              e.target.closest('.js--container-filter').querySelector('.js--sort-end').value = (dates[0].replace(/-/g, '.')).replace(/([0-9]+)\.([0-9]+)\.([0-9]+)/, '$3.$2.$1');
            } else {
              for(let item of array_inp){
                item.value = `${(dates[0].replace(/-/g, '.')).replace(/([0-9]+)\.([0-9]+)\.([0-9]+)/, '$3.$2.$1')} - ${(dates[dates.length - 1].replace(/-/g, '.')).replace(/([0-9]+)\.([0-9]+)\.([0-9]+)/, '$3.$2.$1')}`;
              }
              e.target.closest('.js--container-filter').querySelector('.js--sort-begin').value = (dates[0].replace(/-/g, '.')).replace(/([0-9]+)\.([0-9]+)\.([0-9]+)/, '$3.$2.$1');
              e.target.closest('.js--container-filter').querySelector('.js--sort-end').value = (dates[dates.length - 1].replace(/-/g, '.')).replace(/([0-9]+)\.([0-9]+)\.([0-9]+)/, '$3.$2.$1');
            }
          }
          // console.log("начало: "+e.target.closest('.js--sort-calendar-item').querySelector('.js--sort-begin').value);
          // console.log("конец: "+e.target.closest('.js--sort-calendar-item').querySelector('.js--sort-end').value);

        },
        clickMonth(e, month) {
          setTimeout(()=>{
            addButton(item)
          },50)

        },
        clickYear(e, year) {
          setTimeout(()=>{
            addButton(item)
          },50)
        },
      }
    });
    calendar.init();
    addButton(item)
    item.addEventListener('click', choosePeriod,item)
  }

}
function openCalendar() {
  const array_input = document.querySelectorAll('.js--sort-calendar');
  for (const item of array_input) {
    item.onclick = () => {
      const array_material_sort = document.querySelectorAll('.js--material-sorting-title');
      for (let i=0;i<array_material_sort.length;i++){
        array_material_sort[i].closest('.js--material-sorting').classList.remove('active');
        array_material_sort[i].classList.remove('active');
      }
      const parent = item.closest('.js--sort-calendar-item');
      parent.querySelector('.js__vanilla-calendar').classList.add('visibility');
      if (item.closest('.js--sort-calendar-item').querySelector('.material-sorting__block-fixed')) {
        item.closest('.js--sort-calendar-item').querySelector('.material-sorting__block-fixed').style.display = 'block';
      }
    };
  }
}

function choosePeriod(elem) {
  if (elem.target.classList.contains('material-sorting__calendar-btn') || elem.target.closest('.material-sorting__calendar-btn')) {
    const array_btn = document.querySelectorAll('.material-sorting__calendar-btn');
    const now_date = new Date();

    const container = elem.target.closest('.js--container-filter');
    const parent = elem.target.closest('.js--sort-calendar-item');

    const array_selected_day = parent.querySelectorAll('.vanilla-calendar-day__btn_selected');
    const event = new Event('change');

    if (array_selected_day.length == 1) {
      const array_inp = document.querySelectorAll('.js--sort-calendar');
      for (let i = 0; i < array_inp.length; i++) {
        array_inp[i].value = `${(array_selected_day[0].getAttribute('data-calendar-day')
          .replace(/-/g, '.')).replace(/([0-9]+)\.([0-9]+)\.([0-9]+)/, '$3.$2.$1')} - ${(array_selected_day[0].getAttribute('data-calendar-day')
          .replace(/-/g, '.')).replace(/([0-9]+)\.([0-9]+)\.([0-9]+)/, '$3.$2.$1')}`;
      }
    }

    if (array_selected_day.length == 0) {
      const array_inp = document.querySelectorAll('.js--sort-calendar');
      for (let i = 0; i < array_inp.length; i++) {
        array_inp[i].value = `${now_date.toLocaleDateString()} - ${now_date.toLocaleDateString()}`;
      }
      container.querySelector('.js--sort-begin').value = now_date.toLocaleDateString();
      container.querySelector('.js--sort-end').value = now_date.toLocaleDateString();
    }
    if (parent.classList.contains('js--modal-sort-calendar') && parent.classList.contains('auto-click')) {
      parent.querySelector('.js--sort-calendar-modal').value = `${now_date.toLocaleDateString()} - ${now_date.toLocaleDateString()}`;
    }
    container.querySelector('.js--sort-begin')
      .dispatchEvent(event);
    container.querySelector('.js--sort-end')
      .dispatchEvent(event);
    parent.querySelector('.js__vanilla-calendar')
      .classList
      .remove('visibility');
    parent.querySelector('.material-sorting__block-fixed').style.display = 'none';
    parent.classList.add('period-selected');

    if (parent.classList.contains('js--modal-sort-calendar')) {
      parent.querySelector('.js--sort-calendar-modal')
        .setAttribute('style', 'width:155px;');
    }
  }



}
function closeAllTabs() {
  let count = 0;
  const array_parent = document.querySelectorAll('.js--material-sorting-filter');
  if (array_parent.length > 0) {
    document.body.onclick = function () {
      for (const item of array_parent) {
        // eslint-disable-next-line func-names
        item.onclick = function (w) {
          w.stopImmediatePropagation();
        };
        if (count > 0) {
          // eslint-disable-next-line camelcase
          const array_element = item.querySelectorAll('.js--material-sorting.active');
          for (let i = 0; i < array_element.length; i++) {
            array_element[i].classList.remove('active');
            array_element[i].querySelector('.js--material-sorting-title').classList.remove('active');
          }
        }
        if (count < 1) {
          count += 1;
        }
      }
    };

    const bl = document.querySelectorAll('.material-sorting__block-fixed');
    // eslint-disable-next-line no-restricted-syntax,no-unused-vars
    for (const item of bl) {
      item.onclick = () => {
        const parent_con = item.closest('.js--sort-calendar-item');
        parent_con.classList.remove('active-bg')
        const array_calendar = parent_con.querySelectorAll('.js__vanilla-calendar');

        for (const item of array_calendar) {
          item.classList.remove('visibility');
          const parent = item.closest('.js--sort-calendar-item');
          if(!parent.classList.contains('period-selected')){
            parent.classList.add('clear-calendar')
            parent.querySelector('.js--sort-calendar').value='';
            const array_selected_day = parent.querySelectorAll('.vanilla-calendar-day__btn_selected');
            for(let item of array_selected_day){
              item.classList.remove('vanilla-calendar-day__btn_selected')

            }
          }


          //Может пригодиться
          // const container = item.closest('.js--modal-sort-calendar');
          //
          // const container_des = item.closest('.js--sort-calendar-item');
          //
          // if (container && container.querySelector('.js--sort-begin').value == '') {
          //   container.querySelector('.js--sort-calendar-modal').value = '';
          // }
          //
          // if (container_des && container_des.querySelector('.js--sort-begin').value == '') {
          //   container_des.querySelector('.js--sort-calendar').value = '';
          // }

        }
        item.style.display = 'none';
      };
    }
  }
}

function openFilterModal() {
  const btn = document.querySelectorAll('.js--msf-modal-opener');
  // eslint-disable-next-line no-restricted-syntax
  for (const item of btn) {
    item.onclick = () => {
      const filter = item.closest('.js--msf-wr');
      filter.querySelector('.js--msf-modal').classList.add('is-open');
      document.body.classList.add('body-modal');
    };
  }
}
function closeFilterModal() {
  // eslint-disable-next-line camelcase
  const btn_back = document.querySelector('.js--filter-modal-back');
  // eslint-disable-next-line camelcase
  if (btn_back) {
    btn_back.onclick = () => {
      btn_back.closest('.js--msf-modal').classList.remove('is-open');
      document.body.classList.remove('body-modal');
    };
  }
}
function activeModalFilter() {
  // eslint-disable-next-line camelcase
  const array_modal_sort_item = document.querySelectorAll('.js--modal-sort-item');
  // eslint-disable-next-line no-restricted-syntax,camelcase
  for (const item of array_modal_sort_item) {
    item.onclick = () => {
      const parent = item.closest('.js--modal-sort');
      // eslint-disable-next-line camelcase
      const array_modal_sort_active = parent.querySelectorAll('.js--modal-sort-item.active');
      for (let i = 0; i < array_modal_sort_active.length; i++) {
        array_modal_sort_active[i].classList.remove('active');
      }
      item.classList.add('active');
    };
  }
}
function clearModalFilter() {
  // eslint-disable-next-line camelcase
  const btn_clear = document.querySelector('.js--clear-filter');
  // eslint-disable-next-line camelcase
  if (btn_clear) {
    btn_clear.onclick = () => {
      const parent = btn_clear.closest('.js--msf-modal');
      // eslint-disable-next-line camelcase
      const array_all_modal_sort_item = parent.querySelectorAll('.js--modal-sort-item');
      // eslint-disable-next-line camelcase,no-restricted-syntax
      for (const item of array_all_modal_sort_item) {
        item.classList.remove('active');
      }
      // eslint-disable-next-line camelcase
      const array_wr_cal = parent.querySelectorAll('.js--modal-sort-calendar');
      // eslint-disable-next-line no-restricted-syntax,camelcase
      for (const item of array_wr_cal) {
        // eslint-disable-next-line camelcase
        const array_cal_item = item.querySelectorAll('input');
        // eslint-disable-next-line camelcase
        for (let i = 0; i < array_cal_item.length; i++) {
          array_cal_item[i].value = '';
        }
        parent.querySelector('.js--sort-calendar-modal').setAttribute('style', 'width: 105px;');
        parent.querySelector('.js--modal-sort-calendar').classList.add('auto-click');
      }
    };
  }
}
export default function Tags() {
  activeSort();

  initCalendar();
  openCalendar();
  // choosePeriod();
  closeAllTabs();

  openFilterModal();
  closeFilterModal();
  activeModalFilter();
  clearModalFilter();

}
