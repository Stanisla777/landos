<template lang="pug">
  .calculator_s__pop-up
    .calculator_s__tooltip-icon-close(@click="closePopUp")
      svg(xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewbox='0 0 16 16')
        g(fill='#000' fill-rule='evenodd' transform='translate(0 -1)')
          rect(width='2' height='20' x='7.2643' y='-1.2357' transform='rotate(45 8.264 8.764)' rx='1')
          rect(width='2' height='20' x='7.2643' y='-1.2357' transform='rotate(135 8.264 8.764)' rx='1')
    p(
      v-html="paramText"
    )
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';

export default {
  name: 'pop-up',
  props:['paramText'],
  data(){
    return {

    }
  },
  methods:{
    closePopUp(){
      this.$emit('eventClosePopUp',false)
    }
  },
  mounted(){

  },
  computed:{},
  watch:{
  },
  components:{}
};
</script>
<style scoped>
</style>
