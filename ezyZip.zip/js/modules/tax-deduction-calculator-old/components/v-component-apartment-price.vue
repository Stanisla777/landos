<template lang="pug">
  .calculator_s__calculator-row
    .calculator_s__period-input-wrapper
      p.calculator_s__calculator-label Стоимость квартиры
    .range-input__wrapper.calculator_s__wrapper-cost-apartment.js--number-cost(@click="inputFocus")
      input.range-input__value(inputmode="numeric")(
        @keydown="inputField"
        v-model="realtyPrice"
        type="text"
        ref="realtyInput"
        @input="showEnter"
        @change ="inputValue"
      )
      .calculator_s__enter-button(

        @click="enteredData"
        v-show="input_salary"
      )
        svg(width='20' height='20' viewbox='0 0 20 20' fill='none' xmlns='http://www.w3.org/2000/svg')
          path(d='M4.64119 12.5L7.51402 15.2038C7.81565 15.4877 7.83004 15.9624 7.54615 16.264C7.26226 16.5657 6.78761 16.58 6.48598 16.2961L2.23598 12.2961C2.08539 12.1544 2 11.9568 2 11.75C2 11.5432 2.08539 11.3456 2.23598 11.2038L6.48598 7.20385C6.78761 6.91996 7.26226 6.93435 7.54615 7.23598C7.83004 7.53761 7.81565 8.01226 7.51402 8.29615L4.64118 11L14.75 11C15.7165 11 16.5 10.2165 16.5 9.25V4.75C16.5 4.33579 16.8358 4 17.25 4C17.6642 4 18 4.33579 18 4.75V9.25C18 11.0449 16.5449 12.5 14.75 12.5L4.64119 12.5Z' fill='#8bc540')
      .range-input__slider(ref="mortgagePrice")
    .calculator_s__cost-flat
      p.calculator_s__cost-flat-min {{String(stgMin).slice(0,3)}} тыс.
      p.calculator_s__cost-flat-min {{String(stgMax).slice(0,2)}} млн.

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import noUiSlider from 'nouislider';
import Storage from '../development-tools/state.vue';
import IMask from 'imask';
export default {
  name: 'v-apartment-price',
  data(){
    return {
      realtySlider: '', // Слайдер "Стоимость недвижимости"
      realtyPrice: 0, // Стоимость недвижимости
      realtyPriceForCalculation: 0,
      subsidies: 0,
      stepApartment: 1, // Шаг для range инпутов
      stgMin: 625000, // Минимальное значение поля стоимости
      stgMiddle: 27000000, // Значение по середине (стоимость)
      stgMax: 55000000, // Максимальное значение поля стоимости
      input_salary:false
    }
  },
  methods:{
    initRealtySlider() {
      this.realtySlider = noUiSlider.create(this.$refs.mortgagePrice, {
        start: [this.stgMin],
        connect: 'lower',
        step: this.stepApartment,
        initial: this.stgMin,
        range: {
          min: this.stgMin,
          max: this.stgMax
        },
      });

      this.realtySlider.on('update', (val,handle) => {
        this.input_salary = false
        this.realtyPrice = parseInt(val[handle]).toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ') + ' ₽'
        this.realtyPriceForCalculation = parseInt(val[handle]).toFixed(0)
      });

    },
    inputCost(){
      const input_status = document.querySelectorAll('.js--number-cost input');
      const maskOptions = {
        mask: Number,
        thousandsSeparator: ' ',
        max:this.stgMax

      };
      for (const item of input_status) {
        new IMask(item, maskOptions);
      }
    },
    enteredData(el){
      const element = el.currentTarget
      const parent = element.closest('.js--number-cost')
      let value = parent.querySelector('input').value
      value = parseInt(value.replace(/\s/g, ''));
      this.realtySlider.set(value);
    },
    showEnter(el){
      const element = el.currentTarget
      this.input_salary=true
      let val = parseInt(element.value.replace(/\s/g, ''))
      console.log(element.value.length);
      if (element.value.length >8&&val >this.stgMax) {
        this.realtyPrice=this.stgMax
      }
    },
    inputFocus(el){
      const element = el.currentTarget
      element.querySelector('input').focus()
    },
    //Ввод значения пользователем
    inputField(event){
      const element = event.currentTarget
      let value = element.value
      const selection_start = element.selectionStart;
      var arr = Array.from(value);

      value = parseInt(value.replace(/\s/g, ''));
      if(event.keyCode == 13){
        const parent = element.closest('.js--number-cost')
        let value = parent.querySelector('input').value
        value = parseInt(value.replace(/\s/g, ''));
        this.realtySlider.set(value);
      }
      if(value>this.stgMax){
        event.preventDefault();
      }
    },

    // расчет ндфл стоимости квартиры и отправка данных о квартире в компоненту с итоговой суммой
    calculationPageLoad(){
      //цена квартиры минус сумма субсидий
      let data_calculation = parseInt(this.realtyPriceForCalculation) - parseInt(this.subsidies)
      if (data_calculation<0){
        data_calculation=0
      }
      const ndfl_cost_apartment = parseInt(data_calculation.toFixed(0))
      Storage.dispatch('ActionRealPriceAppartment',parseInt(this.realtyPriceForCalculation))
      Storage.dispatch('ActionApartmentPrice',ndfl_cost_apartment)
      Storage.dispatch('ActionApartmentPriceForMarried',ndfl_cost_apartment)

    },
    inputValue(el){
      const element = el.currentTarget;
      let value = element.value
      value = parseInt(value.replace(/\s/g, ''));
      if(this.realtyPrice=='NaN'){
        this.realtyPrice=''
      }
      this.realtyPriceForCalculation = value
      this.calculationPageLoad()
    },
  },
  mounted(){
    this.initRealtySlider()
    this.inputCost()
  },
  computed:{

  },
  watch:{
    //как только стоимость квартиры изменилась, вызываю функцию
    realtyPrice(){
      this.calculationPageLoad()
    }

  },
  created(){
    eventBus.$on('event_subsidies',(param)=>{
      this.subsidies = parseInt(param)
      this.calculationPageLoad()
    })
  },

  components:{}
};
</script>
<style scoped>
</style>
