<template lang="pug">
  .calculator_s__calculator-row
    .calculator_s__period-input-wrapper
      p.calculator_s__calculator-label Дата покупки квартиры
    .calculator_s__calculator-input.js--calendar-input
      input(type="text" placeholder="дд.мм.гггг")(
        @input="changeDate"
      )
</template>
<script>
import IMask from 'imask';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import PopUp from '../components/v-component-pop-up.vue';
export default {
  name: 'v-date-purchase',
  data(){
    return {
      paramName:null,
      hint_text:'Если вы использовали налоговый вычет на&#160;имущество, преобретенное до&#160;01.01.2014, то&#160;заявить его ' +
        'повторно нельзя, независимо от&#160;размера ранее предоставленного вычета.',
      pop_up_text:'Если вы использовали налоговый вычет на&#160;имущество, преобретенное до&#160;01.01.2014, то&#160;заявить его ' +
        'повторно нельзя, независимо от&#160;размера ранее предоставленного вычета.'
    }
  },
  methods:{
    inputCalendar(){
      const input_status = document.querySelectorAll('.js--calendar-input input');
      const maskOptions = {
        mask: Date,
        min: new Date(1982, 0, 1),
        max:new Date()
      };
      // eslint-disable-next-line no-restricted-syntax,camelcase,no-undef
      for (const item of input_status) {
        // eslint-disable-next-line no-new
        new IMask(item, maskOptions);
      }
    },
    changeDate(el){
      const element=el.currentTarget
      const container = element.closest('.js--tax-deduction_calculations')
      const checkbox = container.querySelector('.js--tax_checkbox')
      const checkbox_label = checkbox.querySelector('.js--date-signing label')
      const checkbox_input = checkbox.querySelector('.js--date-signing input')

      const checkbox_received = checkbox.querySelector('.js--received-payments')
      const checkbox_label_received = checkbox.querySelector('.js--received-payments label')
      const checkbox_input_received = checkbox.querySelector('.js--received-payments input')
      if(element.value.length===10){
        let substr = element.value.substring(element.value.length-4, element.value.length);
        substr=parseInt(substr)
        if (parseInt(substr)<2014){
          if (!checkbox_input.checked){
            checkbox_input.checked=true
          }
          checkbox_received.classList.add('unactive')
          if (checkbox_input_received.checked){
            checkbox_input_received.checked=false
            this.$emit('event_OtherTax',this.paramName=false)
          }
          element.focus()
          const info={
            condition:true,
            text:this.pop_up_text
          }
          this.$emit('eventPopUp',info)
          Storage.dispatch('ActionReturnMaximumChange',1)
        }
        else if(parseInt(substr)>=2014){
          if (checkbox_input.checked){
            checkbox_input.checked=false
          }
          checkbox_received.classList.remove('unactive')
          if (checkbox_input_received.checked){
            checkbox_input_received.checked=false

          }
          Storage.dispatch('ActionReturnMaximumChange',2)


        }
        eventBus.$emit('passYear',substr)
      }
      else if(element.value.length<10&&checkbox_input.checked){
        checkbox_received.classList.remove('unactive')
        checkbox_input.checked=false
        element.focus()
      }
    }
  },
  mounted(){
    this.inputCalendar()
  },
  computed:{},
  watch:{
  },
  components:{
    PopUp
  }
};
</script>
<style scoped>
</style>
