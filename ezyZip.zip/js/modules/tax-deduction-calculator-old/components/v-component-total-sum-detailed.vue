<template lang="pug">
  .calculator_s__wrapper-detailed-result
    .calculator_s__result-this-year-not-married(v-if="selected_married")
      .calculator_s__detailed-result-container
        .calculator_s__detailed-result-row
          .calculator_s__detailed-result-col
            p.calculator_s__detailed-label Можно вернуть в текущем году
            .calculator_s__detailed-result.active  {{can_returned_now_apartment_plus_interest}} ₽
          .calculator_s__detailed-result-col
            p.calculator_s__detailed-label Можно вернуть в последующих годах
            .calculator_s__detailed-result  {{can_returned_then_apartment_plus_interest}} ₽

      .calculator_s__detailed-result-container
        p.calculator_s__detailed-label Максимальная сумма возврата налога за недвижимость
        .calculator_s__detailed-result-row
          .calculator_s__detailed-result-col
            .calculator_s__detailed-result-label-row.calculator_s__appearance-tooltip
              p.calculator_s__sub-label За покупку
              .calculator_s__period-input-wrap-icon
                svg(width='6' height='9' viewbox='0 0 6 9' fill='none' xmlns='http://www.w3.org/2000/svg')
                  path(d='M2.29615 5.82809V5.87809H2.34615H3.38128H3.43128V5.82809C3.43128 5.17718 3.88001 4.74316 4.37092 4.26834C4.3939 4.24612 4.41697 4.2238 4.44009 4.20137C4.95161 3.70514 5.47928 3.15761 5.47928 2.27748C5.47928 1.56616 5.1798 1.02591 4.72144 0.664646C4.26438 0.304406 3.65179 0.123828 3.0251 0.123828C1.94115 0.123828 0.916704 0.644209 0.518245 1.74851L0.503822 1.78848L0.540948 1.80916L1.42025 2.2989L1.47368 2.32866L1.49223 2.27038C1.60592 1.91305 1.80522 1.65293 2.06481 1.48165C2.32489 1.31005 2.64868 1.22557 3.01397 1.22557C3.39653 1.22557 3.72964 1.31585 3.96588 1.49634C4.20027 1.67543 4.34415 1.94688 4.34415 2.322C4.34415 2.63879 4.22214 2.90106 4.03445 3.14622C3.87409 3.35566 3.66836 3.5496 3.45209 3.75346C3.41356 3.78978 3.37469 3.82642 3.33569 3.86351C2.82303 4.3511 2.29615 4.90943 2.29615 5.82809ZM2.85815 8.28226C3.29809 8.28226 3.63162 7.93659 3.63162 7.50879C3.63162 7.08098 3.29809 6.73531 2.85815 6.73531C2.42984 6.73531 2.08467 7.08048 2.08467 7.50879C2.08467 7.9371 2.42984 8.28226 2.85815 8.28226Z' fill='#1C1B28' stroke='#1C1B28' stroke-width='0.1')
              template
                tool-tip(
                  :hint_text="hint_text_2"
                )
            .calculator_s__detailed-result  {{maximum_purchase_amount}} ₽

          .calculator_s__detailed-result-col
            .calculator_s__detailed-result-label-row.calculator_s__appearance-tooltip
              p.calculator_s__sub-label За % по ипотеке
              .calculator_s__period-input-wrap-icon
                svg(width='6' height='9' viewbox='0 0 6 9' fill='none' xmlns='http://www.w3.org/2000/svg')
                  path(d='M2.29615 5.82809V5.87809H2.34615H3.38128H3.43128V5.82809C3.43128 5.17718 3.88001 4.74316 4.37092 4.26834C4.3939 4.24612 4.41697 4.2238 4.44009 4.20137C4.95161 3.70514 5.47928 3.15761 5.47928 2.27748C5.47928 1.56616 5.1798 1.02591 4.72144 0.664646C4.26438 0.304406 3.65179 0.123828 3.0251 0.123828C1.94115 0.123828 0.916704 0.644209 0.518245 1.74851L0.503822 1.78848L0.540948 1.80916L1.42025 2.2989L1.47368 2.32866L1.49223 2.27038C1.60592 1.91305 1.80522 1.65293 2.06481 1.48165C2.32489 1.31005 2.64868 1.22557 3.01397 1.22557C3.39653 1.22557 3.72964 1.31585 3.96588 1.49634C4.20027 1.67543 4.34415 1.94688 4.34415 2.322C4.34415 2.63879 4.22214 2.90106 4.03445 3.14622C3.87409 3.35566 3.66836 3.5496 3.45209 3.75346C3.41356 3.78978 3.37469 3.82642 3.33569 3.86351C2.82303 4.3511 2.29615 4.90943 2.29615 5.82809ZM2.85815 8.28226C3.29809 8.28226 3.63162 7.93659 3.63162 7.50879C3.63162 7.08098 3.29809 6.73531 2.85815 6.73531C2.42984 6.73531 2.08467 7.08048 2.08467 7.50879C2.08467 7.9371 2.42984 8.28226 2.85815 8.28226Z' fill='#1C1B28' stroke='#1C1B28' stroke-width='0.1')
              template
                tool-tip(
                  :hint_text="hint_text"
                )
            .calculator_s__detailed-result  {{maximum_interest_amount}} ₽


    .calculator_s__result-this-year-married(v-else)
      .calculator_s__detailed-result-container
        p.calculator_s__detailed-label Можно вернуть в текущем году
        .calculator_s__detailed-result-row
          .calculator_s__detailed-result-col
            p.calculator_s__sub-label Вам
            .calculator_s__detailed-result.active {{can_returned_now_apartment_plus_interest}} ₽
          .calculator_s__detailed-result-col
            p.calculator_s__sub-label Супругу/супруге
            .calculator_s__detailed-result.active  {{can_returned_now_apartment_plus_interest_married}} ₽

      .calculator_s__detailed-result-container
        p.calculator_s__detailed-label Можно вернуть в последующих годах
        .calculator_s__detailed-result-row
          .calculator_s__detailed-result-col
            p.calculator_s__sub-label Вам
            .calculator_s__detailed-result {{can_returned_then_apartment_plus_interest}} ₽

          .calculator_s__detailed-result-col
            p.calculator_s__sub-label Супругу/супруге
            .calculator_s__detailed-result  {{can_returned_then_apartment_plus_interest_married}} ₽

      //Тут данные статические(постоянные)
      .calculator_s__detailed-result-container
        p.calculator_s__detailed-label Максимальная сумма возврата налога за недвижимость
        .calculator_s__row-maximum-refund-amount
          .calculator_s__row-maximum-refund-amount-col
            .calculator_s__detailed-result-label-row.calculator_s__appearance-tooltip
              p.calculator_s__sub-label За покупку
              .calculator_s__period-input-wrap-icon
                svg(width='6' height='9' viewbox='0 0 6 9' fill='none' xmlns='http://www.w3.org/2000/svg')
                  path(d='M2.29615 5.82809V5.87809H2.34615H3.38128H3.43128V5.82809C3.43128 5.17718 3.88001 4.74316 4.37092 4.26834C4.3939 4.24612 4.41697 4.2238 4.44009 4.20137C4.95161 3.70514 5.47928 3.15761 5.47928 2.27748C5.47928 1.56616 5.1798 1.02591 4.72144 0.664646C4.26438 0.304406 3.65179 0.123828 3.0251 0.123828C1.94115 0.123828 0.916704 0.644209 0.518245 1.74851L0.503822 1.78848L0.540948 1.80916L1.42025 2.2989L1.47368 2.32866L1.49223 2.27038C1.60592 1.91305 1.80522 1.65293 2.06481 1.48165C2.32489 1.31005 2.64868 1.22557 3.01397 1.22557C3.39653 1.22557 3.72964 1.31585 3.96588 1.49634C4.20027 1.67543 4.34415 1.94688 4.34415 2.322C4.34415 2.63879 4.22214 2.90106 4.03445 3.14622C3.87409 3.35566 3.66836 3.5496 3.45209 3.75346C3.41356 3.78978 3.37469 3.82642 3.33569 3.86351C2.82303 4.3511 2.29615 4.90943 2.29615 5.82809ZM2.85815 8.28226C3.29809 8.28226 3.63162 7.93659 3.63162 7.50879C3.63162 7.08098 3.29809 6.73531 2.85815 6.73531C2.42984 6.73531 2.08467 7.08048 2.08467 7.50879C2.08467 7.9371 2.42984 8.28226 2.85815 8.28226Z' fill='#1C1B28' stroke='#1C1B28' stroke-width='0.1')
              template
                tool-tip(
                  :hint_text="hint_text_2"
                )
            .calculator_s__detailed-result  {{maximum_purchase_amount_general}} ₽
            .calculator_s__detailed-result-label-row.calculator_s__appearance-tooltip
              p.calculator_s__sub-label За % по ипотеке
              .calculator_s__period-input-wrap-icon
                svg(width='6' height='9' viewbox='0 0 6 9' fill='none' xmlns='http://www.w3.org/2000/svg')
                  path(d='M2.29615 5.82809V5.87809H2.34615H3.38128H3.43128V5.82809C3.43128 5.17718 3.88001 4.74316 4.37092 4.26834C4.3939 4.24612 4.41697 4.2238 4.44009 4.20137C4.95161 3.70514 5.47928 3.15761 5.47928 2.27748C5.47928 1.56616 5.1798 1.02591 4.72144 0.664646C4.26438 0.304406 3.65179 0.123828 3.0251 0.123828C1.94115 0.123828 0.916704 0.644209 0.518245 1.74851L0.503822 1.78848L0.540948 1.80916L1.42025 2.2989L1.47368 2.32866L1.49223 2.27038C1.60592 1.91305 1.80522 1.65293 2.06481 1.48165C2.32489 1.31005 2.64868 1.22557 3.01397 1.22557C3.39653 1.22557 3.72964 1.31585 3.96588 1.49634C4.20027 1.67543 4.34415 1.94688 4.34415 2.322C4.34415 2.63879 4.22214 2.90106 4.03445 3.14622C3.87409 3.35566 3.66836 3.5496 3.45209 3.75346C3.41356 3.78978 3.37469 3.82642 3.33569 3.86351C2.82303 4.3511 2.29615 4.90943 2.29615 5.82809ZM2.85815 8.28226C3.29809 8.28226 3.63162 7.93659 3.63162 7.50879C3.63162 7.08098 3.29809 6.73531 2.85815 6.73531C2.42984 6.73531 2.08467 7.08048 2.08467 7.50879C2.08467 7.9371 2.42984 8.28226 2.85815 8.28226Z' fill='#1C1B28' stroke='#1C1B28' stroke-width='0.1')
              template
                tool-tip(
                  :hint_text="hint_text"
                )
            .calculator_s__detailed-result  {{maximum_interest_amount}} ₽


          .calculator_s__row-maximum-refund-amount-col
            p.calculator_s__explanation Для обоих супругов
    .calculator_s__detailed-result-container.js-accordion-parent.calculator_s__detailed-result-last-container
      p.footnote-calculators.
        Результат расчета предварительный, сформирован в ознакомительных целях на основе предоставленных сведений и не
        является официальным заключением, офертой, индивидуальной оценкой. Для получения подробной информации и
        индивидуальной оценки рекомендуем обратиться за консультацией в налоговый орган по месту регистрации или в
        контакт-центр ФНС России.
      p.calculator_s__detailed-label Обязательные условия для получения налогового вычета:
      ul.calculator_s__detailed-result-list
        li Гражданство РФ
        li Официальный доход
        li Уплата налогов на доход
        li Продавец не является близким родственником или членом семьи

      ul.calculator_s__detailed-result-list.calculator_s__detailed-result-drop-down-list.js-accordion-body
        li Отсутствие брачного договора, ограничивающего права на данное имущество (если вы состоите в браке)
        li Жилье приобреталась в браке (если вы состоите в браке)
        li Покупка жилья на территории России

        li На жилье оформлено право собственности
        li Заем был выдан на покупку жилой недвижимости, на покупку земельного участка для постройки дома или на строительство (для ипотеки)
        li Налоговый вычет не получался за покупку недвижимости до 01.01.2014
      p.calculator_s__detailed-result-list-all(@click="dropDownList") показать все условия


</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import ToolTip from '../components/v-component-tooltip.vue';
export default {
  name: 'v-component-total-sum-detailed',
  data(){
    return {
      hint_text:"Непереносимый остаток (нельзя вернуть с&#160;последующих кредитов)",
      hint_text_2:"Переносимый остаток (можно вернуть в&#160;последующих годах)",
      selected_married:true,
      max_purchase:'260 000',
      max_interest:'65 000'
    }
  },
  methods:{
    dropDownList(el){
      const btn = el.currentTarget
      const parent = btn.closest('.js-accordion-parent');
      const container = parent.querySelector('.js-accordion-body ');
      if (parent.classList.contains('active')) {
        parent.classList.remove('active');
        // eslint-disable-next-line camelcase
        container.style.maxHeight = 0;
        btn.textContent="ПОКАЗАТЬ ВСЕ УСЛОВИЯ"
      } else {
        // eslint-disable-next-line no-restricted-syntax,camelcase
        parent.classList.add('active');
        container.style.maxHeight = `${container.scrollHeight}px`;
        btn.textContent="СКРЫТЬ ВСЕ УСЛОВИЯ"
      }
    },
    showDetailedCalculator(){
      this.$emit('eventDetailedCalculator')
      this.show_button=false
    }
  },
  mounted(){
  },
  computed:{
    final_interest_tax_deduction(){
      return Storage.getters.INTEREST_TAX_DEDUCTION
    },
    can_return_interest(){
      return Storage.getters.INTEREST_CAN_RETURN.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
    },
    final_interest_tax_deduction_married(){
      return Storage.getters.INTEREST_TAX_DEDUCTION_MARRIED
    },
    can_return_interest_married(){
      return Storage.getters.INTEREST_CAN_RETURN_MARRIED.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
    },

    can_returned_now_apartment(){
      return Storage.getters.AMOUNT_TAX_DEDUCTION
    },
    can_return_then_apartment(){
      return Storage.getters.CAN_RETURN.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
    },

    can_returned_now_apartment_for_married(){
      return Storage.getters.AMOUNT_TAX_DEDUCTION_MARRIED
    },
    can_return_then_apartment_for_married(){
      return Storage.getters.CAN_RETURN_MARRIED.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
    },
    can_returned_now_apartment_plus_interest(){
      let final = parseInt(this.can_returned_now_apartment.toString().replace(/\s/g, '')) + parseInt(this.final_interest_tax_deduction.toString().replace(/\s/g, ''))
      if(final>this.interest_paid_salary){
        final=this.interest_paid_salary
      }
      return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
    },
    can_returned_now_apartment_plus_interest_married(){
      let final = parseInt(this.can_returned_now_apartment_for_married.toString().replace(/\s/g, '')) + parseInt(this.final_interest_tax_deduction_married.toString().replace(/\s/g, ''))
      if(final>this.interest_paid_salary_married){
        final=this.interest_paid_salary_married
      }

      return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
    },

    can_returned_then_apartment_plus_interest(){
      let final = parseInt(this.maximum_purchase_amount.toString().replace(/\s/g, '')) +
        parseInt(this.maximum_interest_amount.toString().replace(/\s/g, '')) -
        parseInt(this.can_returned_now_apartment_plus_interest.toString().replace(/\s/g, ''))
      if(final<0){
        final=0
      }
// *
      return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
    },

    can_returned_then_apartment_plus_interest_married(){
      let final = parseInt(this.maximum_purchase_amount_for_married.toString().replace(/\s/g, '')) +
        parseInt(this.maximum_interest_amount.toString().replace(/\s/g, '')) -
        parseInt(this.can_returned_now_apartment_plus_interest_married.toString().replace(/\s/g, ''))
      if(final<0){
        final=0
      }


      return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
    },

    //Если скажут что оставить как есть, убрать "- this.other_deductions_for_married"
    maximum_purchase_amount(){
      let maximum_purchase = Storage.getters.APARTMENT_PRICE
      // let final = maximum_purchase - this.other_deductions
      let final = Storage.getters.APARTMENT_PRICE- this.other_deductions

      if(final<0){
          final = 0
        }
      return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
    },
    //На это обратить внимание, пока использовать не буду для вывода!!!, так как у супруги и супруна могут быть разные налоговые вычеты
    //Супруга
    maximum_purchase_amount_for_married(){
      let maximum_purchase = Storage.getters.APARTMENT_PRICE
      // let final = maximum_purchase - this.other_deductions_for_married
      let final = Storage.getters.APARTMENT_PRICE- this.other_deductions_for_married
      if(final>260000){
        final =  260000
      }
      if(final<0){
        final = 0
      }
      return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
    },
    //Общее
    maximum_purchase_amount_general(){
      let final = parseInt(this.maximum_purchase_amount.toString().replace(/\s/g, '')) +
        parseInt(this.maximum_purchase_amount_for_married.toString().replace(/\s/g, ''))
      return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
    },

    //Супруг
    maximum_purchase_amount_man(){
      let maximum_purchase = Storage.getters.APARTMENT_PRICE
      let final = maximum_purchase - this.other_deductions
      // console.log(final);
      if(final>260000){
        final =  260000
      }
      else if(final<0){
        final = 0
      }
      return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
    },

    maximum_interest_amount(){
      let date = Storage.getters.DATE
      let final = Storage.getters.INTEREST
      if(date==2||date==0){
        if(final>390000){
          final =  390000
        }
        return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
      }
      if(date==1){
        return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
      }
    },

    interest_paid_salary(){
      return parseInt(Storage.getters.SALARY_AMOUNT.toFixed(0))
    },
    interest_paid_salary_married(){
      return parseInt(Storage.getters.SALARY_AMOUNT_MARRIED.toFixed(0))
    },
    other_deductions(){
      return parseInt(Storage.getters.OTHER_DEDUCTIONS.toFixed(0))
    },
    other_deductions_for_married(){
      return parseInt(Storage.getters.OTHER_DEDUCTIONS_FOR_MARRIED.toFixed(0))
    }
  },

  watch:{

  },
  components:{
    ToolTip,
  },
  created(){
    eventBus.$on('event_SelectedMarriedDetaild',(param)=>{
      this.selected_married=param
    })


    eventBus.$on('pass_cost_apartament',(param)=>{
      this.data_cost_apartment=param
    })
    eventBus.$on('pass_salary',(param)=>{
      this.data_salary=param
    })
  }
};
</script>
<style scoped>
</style>
