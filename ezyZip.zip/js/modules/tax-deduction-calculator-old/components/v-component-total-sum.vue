<template lang="pug">
  .calculator_s__row-calculations
    .calculator_s__sum-deduction
      .calculator_s__label Сумма налогового вычета:
      p.calculator_s__deduction-value &#126; <span class="price">{{final_tax_deduction}}</span> руб
    .calculator_s__label.calculator_s__detailed-report.js-detailed-report(
      v-if="show_button"
      @click="showDetailedCalculator"
    ) Получить подробный расчёт
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
export default {
  name: 'v-component-total-sum',
  data(){
    return {
      data_cost_apartment:0,
      data_salary:0,
      calculation_result:0,
      max_pay:260000,
      show_button:true,
    }
  },
  methods:{
    showDetailedCalculator(){
      this.$emit('eventDetailedCalculator')
    }
  },
  mounted(){
  },
  computed:{
    salary(){
      return Storage.getters.SALARY_AMOUNT
    },
    cost_apartment(){
      return Storage.getters.APARTMENT_PRICE
    },

    final_tax_deduction(){
      return Storage.getters.AMOUNT_TAX_DEDUCTION
    }




  },

  watch:{
    //Потом это удалить
    data_cost_apartment() {
      if (this.data_salary >= this.data_cost_apartment) {
        const total_sum = this.data_cost_apartment
        if(total_sum<=this.max_pay){
          this.calculation_result = total_sum.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        }
        else{
          this.calculation_result = this.max_pay.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        }

      }
      else if (this.data_salary < this.data_cost_apartment) {
        const total_sum = this.data_salary
        if(total_sum<=this.max_pay){
          this.calculation_result = total_sum.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        }
        else{
          this.calculation_result = this.max_pay.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        }
      }
    },
    data_salary(){
      if(this.data_salary>=this.data_cost_apartment){
        const total_sum=this.data_cost_apartment
        if(total_sum<=this.max_pay){
          this.calculation_result = total_sum.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        }
        else{
          this.calculation_result = this.max_pay.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        }

      }
      else if(this.data_salary<this.data_cost_apartment){
        const total_sum = this.data_salary
        if(total_sum<=this.max_pay){
          this.calculation_result = total_sum.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        }
        else{
          this.calculation_result = this.max_pay.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        }
      }
    }
  },
  components:{},
  created(){
    eventBus.$on('pass_cost_apartament',(param)=>{
      this.data_cost_apartment=param
    })
    eventBus.$on('pass_salary',(param)=>{
      this.data_salary=param
    })
  }
};
</script>
<style scoped>
</style>
