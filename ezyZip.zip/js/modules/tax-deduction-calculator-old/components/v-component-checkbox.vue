<template lang="pug">
  .calculator_s__checkbox.calculator_s__calculator-row.js--tax_checkbox
    .calculator_s__checkbox-item.checkbox-stylized
      input#checkbox_1(type='checkbox')(@change="pass_SelectedMarried")
      label(for='checkbox_1') Я состою в браке
    .calculator_s__checkbox-item.checkbox-stylized.calculator_s__presence-tooltip.js--received-payments(ref="tax_deduction")
      input#checkbox_2(type='checkbox')(@change="pass_SelectedOtherTax")
      label(for='checkbox_2') Я получал налоговый вычет раньше
    .calculator_s__checkbox-item.checkbox-stylized
      input#checkbox_3(type='checkbox')(@change="pass_Subsidies")
      label(for='checkbox_3') Я использовал при оплате средства господдержки (субсидии, материнский капитал и прочее)
    .calculator_s__checkbox-item.checkbox-stylized.calculator_s__presence-tooltip.js--date-signing
      input#checkbox_4(type='checkbox')(@change="taxDeduction")
      label(for='checkbox_4') Кредитный договор был подписан до 01.01.2014 года
        .calculator_s__period-input-wrap-icon
          svg(width='6' height='9' viewbox='0 0 6 9' fill='none' xmlns='http://www.w3.org/2000/svg')
            path(d='M2.29615 5.82809V5.87809H2.34615H3.38128H3.43128V5.82809C3.43128 5.17718 3.88001 4.74316 4.37092 4.26834C4.3939 4.24612 4.41697 4.2238 4.44009 4.20137C4.95161 3.70514 5.47928 3.15761 5.47928 2.27748C5.47928 1.56616 5.1798 1.02591 4.72144 0.664646C4.26438 0.304406 3.65179 0.123828 3.0251 0.123828C1.94115 0.123828 0.916704 0.644209 0.518245 1.74851L0.503822 1.78848L0.540948 1.80916L1.42025 2.2989L1.47368 2.32866L1.49223 2.27038C1.60592 1.91305 1.80522 1.65293 2.06481 1.48165C2.32489 1.31005 2.64868 1.22557 3.01397 1.22557C3.39653 1.22557 3.72964 1.31585 3.96588 1.49634C4.20027 1.67543 4.34415 1.94688 4.34415 2.322C4.34415 2.63879 4.22214 2.90106 4.03445 3.14622C3.87409 3.35566 3.66836 3.5496 3.45209 3.75346C3.41356 3.78978 3.37469 3.82642 3.33569 3.86351C2.82303 4.3511 2.29615 4.90943 2.29615 5.82809ZM2.85815 8.28226C3.29809 8.28226 3.63162 7.93659 3.63162 7.50879C3.63162 7.08098 3.29809 6.73531 2.85815 6.73531C2.42984 6.73531 2.08467 7.08048 2.08467 7.50879C2.08467 7.9371 2.42984 8.28226 2.85815 8.28226Z' fill='#1C1B28' stroke='#1C1B28' stroke-width='0.1')
        template
          tool-tip(
            :hint_text="hint_text_2"
          )


</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import ToolTip from '../components/v-component-tooltip.vue';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-checkbox',
  data(){
    return {
      hint_text_1:"Вы получали ранее налоговый вычет за&#160;имущество, либо другие социальные налоговые вычеты",
      hint_text_2:"В случае приобретения жилья в&#160;ипотеку до&#160;01.01.2014, подоходный налог с&#160;расходов по&#160;уплате ипотечных " +
        "процентов возвращается в&#160;полной мере, без&#160;ограничений. Если же жилье было приобретено с&#160;помощью ипотечных " +
        "средств после 01.01.2014, то&#160;вычет по&#160;процентам ограничен суммой 390&#160;тыс. рублей.",
      paramName:null
    }

  },
  methods:{
    pass_SelectedMarried(el){
      const element = el.currentTarget
      if(element.checked){
        this.$emit('event_SelectedMarried',this.paramName=true)
        eventBus.$emit('event_SelectedMarriedDetaild',this.paramName=false)
      }
      else {
        this.$emit('event_SelectedMarried',this.paramName=false)
        eventBus.$emit('event_SelectedMarriedDetaild',this.paramName=true)
      }
    },
    pass_SelectedOtherTax(el){
      const element = el.currentTarget
      if(element.checked){
        this.$emit('event_OtherTax',this.paramName=true)
      }
      else {
        this.$emit('event_OtherTax',this.paramName=false)
      }
    },
    pass_Subsidies(el){
      const element = el.currentTarget
      if(element.checked){
        this.$emit('event_Subsidies',this.paramName=true)
      }
      else {
        this.$emit('event_Subsidies',this.paramName=false)
      }
    },
    taxDeduction(el){
      const element = el.currentTarget
      if(element.checked){
        this.$refs.tax_deduction.classList.add('unactive')
        if(this.$refs.tax_deduction.querySelector('input').checked){
          this.$refs.tax_deduction.querySelector('input').checked=false
          this.$emit('event_OtherTax',this.paramName=false)
        }

        Storage.dispatch('ActionOtherDeductions',0)
        Storage.dispatch('ActionReturnMaximumChange',1)
      }
      else {
        this.$refs.tax_deduction.classList.remove('unactive')
        Storage.dispatch('ActionReturnMaximumChange',2)
      }
    },


  },
  mounted(){

  },
  computed:{},
  watch:{
  },
  components:{
    ToolTip
  }
};
</script>
<style scoped>
</style>
