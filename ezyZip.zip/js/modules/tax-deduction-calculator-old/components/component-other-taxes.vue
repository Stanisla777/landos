<template lang="pug">
  .calculator_s__calculator-row
    .calculator_s__input-other-tax
      .calculator_s__period-input-wrapper
        p.calculator_s__calculator-label Размер ранее использованного имущественного вычета
      .calculator_s__calculator-input.calculator_s__numeric-set.js--number-appartment(
        @click="inputFocus"
      )
        input(type="text" inputmode="numeric" placeholder="0")(
          @input ="inputValue"

        )
        p ₽

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import IMask from 'imask';
import Storage from '../development-tools/state.vue';
export default {
  name: 'v-container-other-tax',
  data(){
    return {
      stgMax:260000
    }
  },
  methods:{
    inputCost(){
      const input_status = document.querySelectorAll('.js--number-appartment input');
      const maskOptions = {
        mask: Number,
        thousandsSeparator: ' ',
        max:this.stgMax

      };
      for (const item of input_status) {
        new IMask(item, maskOptions);
      }
    },
    inputValue(el){
      const element = el.currentTarget;
      element.style.width = 0+'px';
      if(element.value.length==0){
        element.style.width = element.scrollWidth + 15 + 'px';
      }
      else if(element.value.length==4){
        element.style.width = element.scrollWidth + 8 + 'px';
      }
      else if(element.value.length==8){
        element.style.width = element.scrollWidth - 4 + 'px';
        element.value=this.stgMax
        let val = element.value.replace(/\s/g, '')
        if(val>this.stgMax){
          val=this.stgMax
          element.value=val
        }
        this.sendInputChange(val)
        return false
      }

      else {
        element.style.width = element.scrollWidth + 7 + 'px';
      }
      let val = element.value.replace(/\s/g, '')
      if(val>this.stgMax){
        val=this.stgMax
        element.value=val
      }
      this.sendInputChange(val)
    },
    sendInputChange(param){
      if(param==''){
        param=0
      }
      Storage.dispatch('ActionOtherDeductions',param)
    },
    inputFocus(el){
      const element = el.currentTarget
      element.querySelector('input').focus()
    },
  },
  mounted(){
    this.inputCost()
  },
  computed:{},
  watch:{
  },
  components:{}
};
</script>
<style scoped>
</style>
