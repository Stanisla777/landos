<template lang="pug">
  div.calculator_s__calculator
    template
      tax-deduction-calculator-old

</template>
<script>
// import DduCalculator from './DduCalculator.vue';
import Storage from './development-tools/state.vue';
const TaxDeductionCalculatorOld = () => import ("./TaxDeductionCalculatorOld.vue");


export default {
  name: 'TaxDeductionCalculatorOldPointEntry',
  data(){
    return {

    }
  },
  methods:{
  },
  mounted(){
  },
  computed:{
  },
  watch:{
  },
  components:{
    TaxDeductionCalculatorOld
  }
};
</script>
<style scoped>
</style>
