<template lang="pug">
  div
    template(v-if="pop_up")
      pop-up(
        :paramText="text_pop_up"
        v-on:eventClosePopUp="closePopUp($event)"
      )
    div.calculator_s__calculations.js--tax-deduction_calculations
      template(v-if="data_detailed_calculator")
        component-checkbox(
          v-on:event_SelectedMarried="changeStatusMaried($event)"
          v-on:event_OtherTax="changeOtherTax($event)"
          v-on:event_Subsidies="changeSubsidies($event)"
        )
      template(v-if="data_detailed_calculator")
        date-purchase(
          v-on:event_OtherTax="changeOtherTax($event)"
          v-on:eventPopUp="contentPopUp($event)"
        )
      template
        apartment-price
      template(v-if="data_detailed_calculator")
        component-paid-interest
      .calculator_s__calculator-row
        template
          component-salary(
            :parametrTitle="title_componrnt_salary_1"
          )
        template(v-if="other_tax")
          component-other-tax
        template(v-if="other_tax")
          component-other-tax-not-appartment
        template(v-if="selected_married")
          component-salary-for-married(
            :parametrTitle="title_componrnt_salary_2"
          )
        template(v-if="other_tax&&selected_married")
          component-other-tax-for-married
        template(v-if="other_tax&&selected_married")
          component-other-tax-not-appartment-for-married

      template(v-if="subsidies")
        component-subsidies

    div.calculator_s__results
      template(v-if="!data_detailed_calculator")
        component-total-sum(
          v-on:eventDetailedCalculator="detailedCalculator($event)"
        )

      template(v-if="data_detailed_calculator")
        component-total-sum-detailed

</template>
<script>
import Vue from 'vue';
import eventBus from './development-tools/eventBus.vue';
import DatePurchase from './components/v-component-date-purchase.vue';
import ApartmentPrice from './components/v-component-apartment-price.vue';
import ComponentSalary from './components/v-component-salary.vue';
import ComponentTotalSum from './components/v-component-total-sum.vue';
import ComponentCheckbox from './components/v-component-checkbox.vue';
import ComponentOtherTax from './components/component-other-taxes.vue';
import ComponentOtherTaxForMarried from './components/component-other-taxes-for-married.vue';
import ComponentSubsidies from './components/component-subsidies.vue';
import ComponentTotalSumDetailed from './components/v-component-total-sum-detailed.vue';
import ComponentPaidInterest from './components/component-paid-interest.vue';
import ComponentSalaryForMarried from './components/v-component-salary-for-married.vue';
import ComponentOtherTaxNotAppartment from './components/component-other-taxes-not-appartment.vue';
import ComponentOtherTaxNotAppartmentForMarried from './components/component-other-taxes-not-appartment_for-married.vue';
import PopUp from './components/v-component-pop-up.vue';
export default {
  name: 'TaxDeductionCalculatorOld',
  data(){
    return {
      data_detailed_calculator:true,
      selected_married:false,
      other_tax:false,
      subsidies:false,
      salary_class:'tax-deduction__container-salary',
      title_componrnt_salary_1:"За какой срок можно заявить выплату",
      title_componrnt_salary_2:"За какой срок может заявить выплату ваш(а) супруг/супруга",
      pop_up:false,
      text_pop_up:null
    }
  },
  methods:{
    detailedCalculator(ev){
      this.data_detailed_calculator=true
    },
    changeStatusMaried(ev){
      this.selected_married = ev
    },
    changeOtherTax(ev){
      this.other_tax = ev
    },
    changeSubsidies(ev){
      this.subsidies = ev
    },
    contentPopUp(ev){
      console.log(ev);
      this.pop_up=ev.condition
      this.text_pop_up=ev.text
    },
    closePopUp(ev){
      this.pop_up=ev
    },

  },
  mounted(){

  },
  computed:{},
  watch:{
  },
  components:{
    DatePurchase,
    ApartmentPrice,
    ComponentSalary,
    ComponentTotalSum,
    ComponentCheckbox,
    ComponentOtherTax,
    ComponentOtherTaxForMarried,
    ComponentSubsidies,
    ComponentTotalSumDetailed,
    ComponentPaidInterest,
    ComponentSalaryForMarried,
    ComponentOtherTaxNotAppartment,
    ComponentOtherTaxNotAppartmentForMarried,
    PopUp

  }
};
</script>
<style scoped>
</style>
