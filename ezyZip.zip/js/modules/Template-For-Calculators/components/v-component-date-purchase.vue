<template lang="pug">
  .calculator_s__calculator-row
    .calculator_s__period-input-wrapper
      p.calculator_s__calculator-label Дата покупки квартиры
    .calculator_s__calculator-input.js--calendar-input
      input(type="text" placeholder="дд.мм.гггг")
</template>
<script>
import IMask from 'imask';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import PopUp from '../components/v-component-pop-up.vue';
export default {
  name: 'v-date-purchase',
  data(){
    return {

    }
  },
  methods:{
    inputCalendar(){
      const input_status = document.querySelectorAll('.js--calendar-input input');
      const maskOptions = {
        mask: Date,
        min: new Date(1982, 0, 1),
        max:new Date()
      };
      // eslint-disable-next-line no-restricted-syntax,camelcase,no-undef
      for (const item of input_status) {
        // eslint-disable-next-line no-new
        new IMask(item, maskOptions);
      }
    },
  },
  mounted(){
    this.inputCalendar()
  },
  computed:{},
  watch:{
  },
  components:{
    PopUp
  }
};
</script>
<style scoped>
</style>
