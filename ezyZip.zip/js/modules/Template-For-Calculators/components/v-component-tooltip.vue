<template lang="pug">
  .calculator_s__tooltip
    p(
      v-html="hint_text"
    )
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';

export default {
  name: 'v-tooltip',
  props:['hint_text'],
  data(){
    return {

    }
  },
  methods:{

  },
  mounted(){

  },
  computed:{},
  watch:{
  },
  components:{}
};
</script>
<style scoped>
</style>
