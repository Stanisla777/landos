<template lang="pug">
  div.calculator_s__calculator {{title_componrnt_salary_1}}
    template(v-if="pop_up")
      pop-up(
        :paramText="text_pop_up"
        v-on:eventClosePopUp="closePopUp($event)"
      )
    div.calculator_s__calculations.js--tax-deduction_calculations
      .calculator_s__calculator-row
        p Ghbs=dtn


    div.calculator_s__results
      template(v-if="data_detailed_calculator")
        component-total-sum-detailed

</template>
<script>
import Vue from 'vue';
import eventBus from './development-tools/eventBus.vue';
import DatePurchase from './components/v-component-date-purchase.vue';
import ApartmentPrice from './components/v-component-apartment-price.vue';
import ComponentSalary from './components/v-component-salary.vue';
import ComponentOtherTax from './components/component-other-taxes.vue';
import ComponentTotalSumDetailed from './components/v-component-total-sum-detailed.vue';
import PopUp from './components/v-component-pop-up.vue';
export default {
  name: 'CreditHolidaysCalculator',
  data(){
    return {
      data_detailed_calculator:false,
      salary_class:'tax-deduction__container-salary',
      title_componrnt_salary_1:"За какой срок можно заявить выплату",
      title_componrnt_salary_2:"За какой срок может заявить выплату ваш(а) супруг/супруга»",
      pop_up:false,
      text_pop_up:null
    }
  },
  methods:{
    detailedCalculator(ev){
      this.data_detailed_calculator=true
    },
    changeStatusMaried(ev){
      this.selected_married = ev
    },
    changeOtherTax(ev){
      this.other_tax = ev
    },
    changeSubsidies(ev){
      this.subsidies = ev
    },
    contentPopUp(ev){
      this.pop_up=ev.condition
      this.text_pop_up=ev.text
    },
    closePopUp(ev){
      this.pop_up=ev
    },

  },
  mounted(){

  },
  computed:{},
  watch:{
  },
  components:{
    DatePurchase,
    ApartmentPrice,
    ComponentSalary,
    ComponentOtherTax,
    ComponentTotalSumDetailed,
    PopUp

  }
};
</script>
<style scoped>
</style>
