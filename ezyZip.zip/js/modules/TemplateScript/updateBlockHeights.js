/* eslint-disable */
export default function setEqualHeight(array_block) {

  const elements = array_block
  let maxHeight = 0;

  elements.forEach(element => element.style.height = 'auto')
  elements.forEach(element => {
    const height = element.offsetHeight;
    if (height > maxHeight) maxHeight = height
  });
  elements.forEach(element => {
    element.style.height = `${maxHeight}px`;
  })







  // let maxHeight = 0; // переменная для хранения максимальной высоты
  // // eslint-disable-next-line camelcase
  // for (let i = 0; i < array_block.length; i++) {
  //   // eslint-disable-next-line no-param-reassign
  //   array_block[i].style.height = 'auto'; // сбрасываем высоту каждого элемента
  //   // eslint-disable-next-line max-len
  //   if (array_block[i].offsetHeight > maxHeight) { // проверяем, является ли высота элемента максимальной
  //     maxHeight = array_block[i].offsetHeight; // обновляем значение максимальной высоты
  //   }
  // }
  // for (let i = 0; i < array_block.length; i++) {
  //   // eslint-disable-next-line no-param-reassign
  //   array_block[i].style.height = `${maxHeight}px`; // устанавливаем высоту каждого элемента равной максимальной высоте
  // }
}
