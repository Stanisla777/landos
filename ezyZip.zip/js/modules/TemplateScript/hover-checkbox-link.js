/* eslint-disable */

export default function hoverCheckboxLink() {
  const array_checkbox_wrapper = document.querySelectorAll('.js--checkbox_wrapper');
  for (let item of array_checkbox_wrapper) {
    if (item.querySelector('a')) {
      item.querySelector('a').addEventListener('mouseover', (e) => {
        item.classList.add('checkbox-not-hover')
      })
      item.querySelector('a').addEventListener('mouseout', (e) => {
        item.classList.remove('checkbox-not-hover')
      })
    }
  }
}
