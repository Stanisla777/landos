/* eslint-disable */
import bodyLockMobileFilter from '../redesign-site/body-lock-mobile-filter';
import bodyUnlockMobileFilter from '../redesign-site/body-unlock-mobile-filter';

export default function openList(ev) {
  const element = ev.currentTarget;
  const parent = element.closest('.js--openlist-container');
  const container = element.closest('.js--modal');
  const wrapper = element.closest('.js--modal-main-content');
  if (!document.body.classList.contains('modal-opened')) {
    bodyLockMobileFilter(parent);
  }
  else {
    parent.closest('.js--modal').classList.add('modal-overflow')
  }



  const windowBackground = parent.querySelector('.js--openlist-background');
  if (!parent.classList.contains('open')) {
    parent.classList.add('open');
    if (wrapper && !windowBackground) {
      wrapper.classList.add('unactive-scroll')
    }
  }
  else {
    parent.classList.remove('open');
    if (wrapper) {
      wrapper.classList.remove('unactive-scroll')
    }
  }
  if (windowBackground) {
    windowBackground.style.display = 'block';
  }

  // закрытие окна
  if (windowBackground) {
    windowBackground.onclick = () => {
      parent.classList.remove('open');
      windowBackground.style.display = 'none';
      if (!document.body.classList.contains('modal-opened')) {
        bodyUnlockMobileFilter(parent)
      }
    };
  }

}
