/* eslint-disable */
export default function removeAllCheckboxes() {
  // const array_checkboxes = container.querySelectorAll('input[type="checkbox"]');
  // console.log(array_checkboxes);

}
