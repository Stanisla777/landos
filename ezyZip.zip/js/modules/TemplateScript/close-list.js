/* eslint-disable */
import bodyLockMobileFilter from '../redesign-site/body-lock-mobile-filter';
import bodyUnlockMobileFilter from '../redesign-site/body-unlock-mobile-filter';

export default function closeList(ev) {
  const element = ev.currentTarget;
  const parent = element.closest('.js--openlist-container');
  const container = parent.closest('.js--modal-main-content');
  parent.classList.remove('open');
  if (container) {
    container.classList.remove('unactive-scroll');
  }
  if (parent.querySelector('.js--openlist-background')) {
    parent.querySelector('.js--openlist-background').style.display='none';
  }
  if (!document.body.classList.contains('modal-opened')) {

    // bodyLockMobileFilter(parent);
    bodyUnlockMobileFilter(parent);
  }
}
