/* eslint-disable */
import bodyUnlockMobileFilter from '../redesign-site/body-unlock-mobile-filter';

//Убираю активность с пункта
function removeClassActiveItem(element,parent) {
  const SelectItemActive = parent.querySelector('.js--openlist-item.active');
  if (SelectItemActive) {
    SelectItemActive.classList.remove('active');
  }
}
//подставляю выбранный класс
function choiceActiveItem(element,parent) {
  const result = parent.querySelector('.js--openlist-btn p');
  element.classList.add('active');
  let content = element.textContent;
  content = content.replace(/^\s\s*/, '').replace(/\s\s*$/, '');
  if(element.closest('.js--openlist-container') &&
    element.closest('.js--openlist-container').querySelector('.js--openlist-btn') &&
    element.closest('.js--openlist-container').querySelector('.js--openlist-btn').classList.contains('unactive')) {
    element.closest('.js--openlist-container').querySelector('.js--openlist-btn').classList.remove('unactive')
  }
  if (result) {
    result.innerHTML = content
  }
  if (parent.querySelector('input[type="hidden"]') && element.hasAttribute('data-value')) {
    parent.querySelector('input[type="hidden"]').value=element.getAttribute('data-value')
    const event = new Event('change');
    parent.querySelector('input[type="hidden"]').dispatchEvent(event);
  }
  if (parent.querySelector('.js--openlist-btn p') && parent.querySelector('.js--openlist-btn p').classList.contains('input-emty')) {
    parent.querySelector('.js--openlist-btn p').classList.remove('input-emty')
  }
}
//Закрываю окно
function closeList(element,parent) {
  const container = parent.closest('.js--modal-main-content');
  parent.classList.remove('open')
  if (parent.querySelector('.js--openlist-background')) {
    parent.querySelector('.js--openlist-background').style.display='none';
  }
  if (container) {
    container.classList.remove('unactive-scroll');
  }
  if (!document.body.classList.contains('modal-opened')) {
    bodyUnlockMobileFilter(parent);
  }
}
//Убираю ошибку, если она есть
function deleteError(element,parent) {
  if (parent && parent.classList.contains('input_error')) {
    parent.classList.remove('input_error')
  }
}

export default function selectItemList(ev) {
  const element = ev.currentTarget;
  const mainContainer = element.closest('.js--openlist-container')
  removeClassActiveItem(element, mainContainer);
  choiceActiveItem(element, mainContainer);
  closeList(element, mainContainer);
  deleteError(element,mainContainer);
}
