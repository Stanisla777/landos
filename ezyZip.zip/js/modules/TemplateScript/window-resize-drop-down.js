/* eslint-disable */
import AddClassBody from '../redesign-site/disallow-body-scrolling';
import RemoveClassBody from '../redesign-site/allow-body-scrolling';

function changeWindow(){
  const array_element = document.querySelectorAll('.js-accordion-parent.active');
  for(let item of array_element) {
    const container = item.querySelector('.js-accordion-body');
    if (container) {
      container.style.maxHeight = `${container.scrollHeight}px`;
    }
  }
}

function removeScreenLockDesktop() {
  const arrayblockMobile = document.querySelectorAll('.js--only-mobile-fixed');
  const bodyPage = document.body;
  for (let item of arrayblockMobile) {
    if (item.classList.contains('open') && bodyPage.classList.contains('body-additional-class')) {
      const windowSize = window.innerWidth;
      if (windowSize >= 480) {
        RemoveClassBody();
      }
    }
    if (item.classList.contains('open') && !bodyPage.classList.contains('body-additional-class')) {
      const windowSize = window.innerWidth;
      if (windowSize < 480) {
        AddClassBody();
      }
    }
  }
}
export default function windowResizeDropDown() {
  window.addEventListener('resize', changeWindow);
  window.addEventListener('resize', removeScreenLockDesktop);
}
