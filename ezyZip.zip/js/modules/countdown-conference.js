export default function countdownConference() {
  const deadline = new Date(2021, 7, 16, 0, 20);
  const date = new Date();
  function getTimeRemaining(endtime) {
    const t = Date.parse(endtime) - Date.parse(new Date());
    const seconds = Math.floor((t / 1000) % 60);
    const minutes = Math.floor((t / 1000 / 60) % 60);
    const hours = Math.floor((t / (1000 * 60 * 60)) % 24);
    const days = Math.floor(t / (1000 * 60 * 60 * 24));
    return {
      total: t,
      days,
      hours,
      minutes,
      seconds
    };
  }
  function initializeClock(id, endtime) {
    const clock = document.getElementById(id);
    const daysSpan = clock.querySelector('.days');
    const hoursSpan = clock.querySelector('.hours');
    const minutesSpan = clock.querySelector('.minutes');
    const secondsSpan = clock.querySelector('.seconds');

    function updateClock() {
      const t = getTimeRemaining(endtime);

      daysSpan.innerHTML = t.days;
      hoursSpan.innerHTML = (`0${t.hours}`).slice(-2);
      minutesSpan.innerHTML = (`0${t.minutes}`).slice(-2);
      secondsSpan.innerHTML = (`0${t.seconds}`).slice(-2);

      // eslint-disable-next-line no-use-before-define
      if (t.total <= 0 || date >= deadline) {
        // eslint-disable-next-line camelcase
        const video_iframe = document.querySelectorAll('.video-iframe__conference');
        video_iframe.forEach((item) => {
          item.click();
        });
        // eslint-disable-next-line no-use-before-define
        clearInterval(timeinterval);
        return true;
      }
    }

    updateClock();
    const timeinterval = setInterval(updateClock, 1000);
  }
  initializeClock('countdown', deadline);
}
