export function subcategoryAccordion() {
    const subcategoriesContainer = document.querySelector('.js--subcategories');

    if (subcategoriesContainer) {
        subcategoriesContainer.addEventListener('click', (e) => {
            if (e.target.closest('.subcategory__opener')) {
                const opener = e.target.closest('.subcategory__opener');
                opener.classList.toggle('active');

                const subcategory = e.target.closest('.js--subcategory');
                const list = subcategory.querySelector('.subcategory__list');

                if (!(list.classList.contains('show'))) {
                    list.classList.add('show');

                    const instructions = list.querySelectorAll('li');
                    let listHeight = 0;

                    for (let j = 0; j < instructions.length; j++) {
                        listHeight += instructions[j].offsetHeight;
                    }

                    list.style.height = `${listHeight}px`;
                } else {
                    list.classList.remove('show');
                    list.style.height = 0;
                }
            }
        });
    }
}

export function documentAccordion() {
    const subcategories = document.querySelectorAll('.js--document-needed');

    if (subcategories) {
        for (let i = 0; i < subcategories.length; i++) {
            const content = subcategories[i].querySelector('.document-needed__content');
            const opener = subcategories[i].querySelector('.document-needed__opener ');

            opener.addEventListener('click', () => {
                opener.classList.toggle('active');

                if (!(content.classList.contains('show'))) {
                    content.classList.add('show');

                    const lists = content.querySelectorAll('.document-needed__list');
                    const links = content.querySelectorAll('.document-needed__link');
                    let contentHeight = 0;

                    for (let j = 0; j < lists.length; j++) {
                        contentHeight += lists[j].offsetHeight;
                    }

                    for (let k = 0; k < links.length; k++) {
                        contentHeight += links[k].offsetHeight;
                    }

                    content.style.height = `${contentHeight}px`;
                } else {
                    content.classList.remove('show');
                    content.style.height = 0;
                }
            });
        }
    }
}

export function catalogAsideAccordion() {
    const catalogAside = document.querySelector('.js--catalog-aside');
    let catalogMain;

    if (catalogAside) {
        catalogMain = catalogAside.querySelector('.catalog-aside__main');
        catalogAside.addEventListener('click', (e) => {
            if (e.target.closest('.catalog-aside__opener')) {
                e.target.closest('.catalog-aside__opener').classList.add('hidden');
                catalogMain.style.maxHeight = `${catalogMain.scrollHeight}px`;
            }
            if (e.target.closest('.catalog-aside__closer')) {
                catalogAside.querySelector('.catalog-aside__opener').classList.remove('hidden');
                catalogMain.style.maxHeight = '0px';
            }
        });
    }
}

export function coursesAccordion() {
    const courses = document.querySelectorAll('.js--courses-accord');

    if (courses) {
        for (let i = 0; i < courses.length; i++) {
            const content = courses[i].querySelector('.js--courses-accord-content');
            const opener = courses[i].querySelector('.js--courses-accord-btn');

            opener.addEventListener('click', () => {
                opener.parentNode.classList.toggle('active');
                opener.classList.toggle('active');

                if (!(content.classList.contains('show'))) {
                    content.classList.add('show');

                    const rte = content.querySelector('#RTE');
                    const contentHeight = rte.offsetHeight;

                    content.style.height = `${contentHeight}px`;
                } else {
                    content.classList.remove('show');
                    content.style.height = 0;
                }
            });
        }
    }
}

let ishousingCooperativeChoosenAccordionActivated = false;
// т.к. функция также вызывается при удалении элемента из корзины,
// пришлось сделать так, чтобы не вешать повторно обработчик

export function housingCooperativeChoosenAccordion() {
    const accordWrap = document.querySelector('.js--housing-cooperative-choosen-accord');

    if (!accordWrap) return;

    const listWrap = accordWrap.querySelector('.housing-cooperative-choosen__results-list');
    const listItems = accordWrap.querySelectorAll('.housing-cooperative-choosen__results-list-item');
    const opener = accordWrap.querySelector('.housing-cooperative-choosen__results-list-opener');

    if (listItems.length > 3) {
      let startHeight = 0;
      for (let i = 0; i < 3; i++) {
        startHeight += listItems[i].offsetHeight;
      }
      startHeight += 32; // margins

      opener.classList.remove('d-none');
      listWrap.style.height = `${startHeight}px`;

      if (!ishousingCooperativeChoosenAccordionActivated) {
        opener.addEventListener('click', () => {
          opener.classList.toggle('active');

          if (opener.classList.contains('active')) {
            listWrap.style.height = `${listWrap.scrollHeight}px`;
          } else {
            listWrap.style.height = `${startHeight}px`;
          }
        });
        ishousingCooperativeChoosenAccordionActivated = true;
      }
    } else {
      opener.classList.add('d-none');
      listWrap.style.height = 'auto';
    }
}
