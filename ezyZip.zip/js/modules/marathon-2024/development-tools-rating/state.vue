<script>
import Vue from 'vue';
import Vuex from 'vuex';


Vue.use(Vuex);

export default new Vuex.Store({
  state:{
    rating:[],
    rating_main:false,
    rating_other:false,
    not_found:false,
  },
  getters:{

    RATINGTEST(state){
      return state.rating
    },
    RATINGMAIN(state){
      return state.rating_main
    },
    RATINGOTHER(state){
      return state.rating_other
    },
    NOTFOUND(state){
      return state.not_found
    },









  },
  mutations:{

    mutationRating(state,received_perem){
      state.rating=received_perem
    },
    mutationRatingMain(state,received_perem){
      state.rating_main=received_perem
    },
    mutationRatingOther(state,received_perem){
      state.rating_other=received_perem
    },
    mutationNotFound(state,received_perem){
      state.not_found=received_perem
    },







  },
  actions:{
    //Время закончилось активировать кнопку Следующий вопрос
    ActionRating({commit,state},param){
      commit('mutationRating',param)
    },
    ActionRatingMain({commit,state},param){
      commit('mutationRatingMain',param)
    },
    ActionRatingOther({commit,state},param){
      commit('mutationRatingOther',param)
    },
    ActionNotFound({commit,state},param){
      commit('mutationNotFound',param)
    },





  },
})
</script>
