/* eslint-disable */
import Vue from 'vue';
import axios from 'axios';
import state from '../marathon-2024-test/development-tools/state.vue'
import stateBtn from './development-tools/state.vue'


export default function marathon2024TestInn() {
  const appInn = new Vue({
    el: '#modal-marathon-test-inn',
    data: {
      state_window:1,
      window_display:0,
      error_text_under_button:'',
      server_response_error:0,
      readiness_test:false,
      field_filling:false,
      checkbox_selected:false,

      field_error:false,
      checbox_error:false,

      error_sand_form:false,
      error_sand_form_text:'Ошибка отправки'

    },
    methods: {
      // sendRequest(token = '') {
      sendRequest() {
        axios({
          method: 'post',
          url: '/api/local/marathon/register/',
          headers: {
            'Content-type': 'application/json; charset=UTF-8',
            'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
          },

          data: {
            // grecaptcharesponse: token,
            inn: parseInt(this.$refs.InputInn.value)
          },
        })
          // Если запрос успешен
          .then((res) => {
            this.error_sand_form = false;

            //Либо ошибка с ИНН, либо был не заполненн ФОС
            if (res.data.result.state === 1) {
              this.server_response_error = 1;
              this.error_text_under_button = 'Кажется, вы уже проходили тест';
              this.field_error = true;
            }

            //Повторная попытка в рейтинге есть
            if (res.data.result.state === 2) {
              this.server_response_error = 0;
              this.error_text_under_button = '';
              this.field_error = false;
              this.state_window = 2;
            }
            //Если было слишком много попыток
            if (res.data.result.state === 3) {
              this.server_response_error = 0;
              this.error_text_under_button = '';
              this.field_error = false;
              this.state_window = 3;
            }
            //Если приложение с водом ИНН выводить не нужно
            // тут нужно так же запускать приложение с вопросом и делать в этом приложении гут запрос
            if (res.data.result.state === 4) {
              this.server_response_error = 0;
              this.error_text_under_button = '';
              this.field_error = false;
              this.state_window = 0;
              state.state.data_open = 1;
              stateBtn.state.state_bunner = false;
              document.body.classList.remove('modal-opened');
              document.body.classList.remove('body-modal');

              //здесь я должен вызывать тест
            }

          })
          // Если запрос с ошибкой
          .catch((error) => {

            state.loader = false;
            if (error.response) {
              if (error.response.data.description != undefined) {
                this.error_sand_form = true;
                this.error_sand_form_text = error.response.data.description;
              }
            }
            console.log(error);
          });
      },
      closeModal(e) {
        const element = e.currentTarget;
        const block_rating = document.querySelector('.marathon-new-last__container-rating')
        if (element.closest('.modal')) {
          element.closest('.modal').classList.remove('open')
          document.body.classList.remove('modal-opened')
          document.body.classList.remove('body-modal')
        }
        if (block_rating && this.state_window===2 && element.classList.contains('btn_s')) {
          const elementPosition = block_rating.getBoundingClientRect().top;
          window.scrollBy({
            top: elementPosition - 20,
            behavior: 'smooth'
          });
        }
        setTimeout(()=>{
          this.state_window=1
          this.field_error = false;
          this.checbox_error=false
        },1000)

      },
      fieldCalculation(e){
        const element = e.currentTarget;
        const parent = element.closest('.js--test-input')
        if (element.value.length > 0) {
          element.classList.add('active')
          parent.querySelector('.js--clear-calc-tax').classList.add('active')
        } else {
          element.classList.remove('active')
          parent.querySelector('.js--clear-calc-tax').classList.remove('active')
        }
      },
      inpFocus(el){
        const element = el.currentTarget;
        element.closest('.js--test-input').classList.add('input-focus')
      },
      inpBlur(el){
        const element = el.currentTarget;
        element.closest('.js--test-input').classList.remove('input-focus')
      },
      inputFieldChild(e){
        const element = e.currentTarget
        element.value = element.value.replace(/[^\d]/g, '');
        element.value = element.value.substring(0, 12)
        if(element.value.length===12) {
          this.field_filling=true
          this.field_error=false
        }
        else if (element.value.length<12){
          this.field_filling=false
        }
      },
      clearInput(e){
        const element = e.currentTarget;
        const parent = element.closest('.js--test-input')
        parent.querySelector('input').value='';
        element.classList.remove('active')
        this.field_filling=false
        this.field_error=false
      },
      changeCheckboxTest(e) {
        const element = e.currentTarget;
        if (element.checked) {
          this.checkbox_selected=true
          this.checbox_error=false
        }
        else {
          this.checkbox_selected=false
        }

      },
      clickInactiveButton(e){
        const element = e.currentTarget;
        if(this.$refs.InputInn.value.length<12) {
          this.field_error=true
          this.error_text_under_button='Заполните корректно ИНН'
        }
        if (!this.$refs.checkboxInn.checked) {
          this.checbox_error=true
        }
      },

      sendingData() {
        //разработка

        // axios({
        //   method:'post',
        //   url:'https://httpbin.org/post',
        //   headers: {
        //     "Content-type": "application/json; charset=UTF-8",
        //     // 'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        //   },
        //
        //   data:{
        //     // grecaptcharesponse: token,
        //     inn:parseInt(this.$refs.InputInn.value)
        //   },
        // })
        //   // Если запрос успешен
        //   .then((res)=>{
        //     this.error_sand_form=false
        //     if (res.data.json.inn===111111111111) {
        //       this.server_response_error=0
        //       this.error_text_under_button=''
        //       this.field_error=false
        //       this.state_window=0
        //       document.body.classList.remove('modal-opened')
        //       document.body.classList.remove('body-modal')
        //       state.state.data_open=1
        //       stateBtn.state.state_bunner=false
        //     }
        //
        //
        //     //Либо ошибка с ИНН, либо был не заполненн ФОС
        //     if (res.data.state===1) {
        //       this.server_response_error=1
        //       this.error_text_under_button='Кажется, вы уже проходили тест'
        //       this.field_error=true
        //     }
        //
        //     //Повторная попытка в рейтинге есть
        //     if (res.data.state===2) {
        //       this.server_response_error=0
        //       this.error_text_under_button=''
        //       this.field_error=false
        //       this.state_window=2
        //     }
        //     //Если было слишком много попыток
        //     if (res.data.state===3) {
        //       this.server_response_error=0
        //       this.error_text_under_button=''
        //       this.field_error=false
        //       this.state_window=3
        //     }
        //     //Если приложение с водом ИНН выводить не нужно
        //     // тут нужно так же запускать приложение с вопросом и делать в этом приложении гут запрос
        //     if (res.data.state===4) {
        //       this.server_response_error=0
        //       this.error_text_under_button=''
        //       this.field_error=false
        //       this.state_window=0
        //       document.body.classList.remove('modal-opened')
        //       document.body.classList.remove('body-modal')
        //
        //       //здесь я должен вызывать тест
        //       state.state.data_open=1
        //       stateBtn.state.state_bunner=false
        //     }
        //
        //   })
        //   // Если запрос с ошибкой
        //   .catch((error)=> {
        //
        //     state.loader=false
        //     if(error.response){
        //       if (error.response.data.description!=undefined){
        //         this.error_sand_form=true
        //         this.error_sand_form_text=error.response.data.description
        //       }
        //     }
        //     console.log(error);
        //   });

        //бой
        this.sendRequest()

        //Вместо гугл рекаптчи теперь используется яндекс рекаптча
        //Если в марафоне 2025 будет использоваться этот код переписать для яндексрекаптчи
        // let key = conf.reCAPTCHA_site_key
        // if (key && typeof window.grecaptcha !== 'undefined') {
        //   window.grecaptcha.ready(() => {
        //     window.grecaptcha.execute(key)
        //       .then((token) => {
        //         this.sendRequest(token)
        //         }
        //       )
        //   })
        // } else {
        //   this.sendRequest()
        // }

      },
    },
    filters: {

    },
    computed: {

    },
    watch: {

    },
    mounted() {
      if (this.$refs.ModalWindow!==undefined){
        if (this.$refs.ModalWindow.hasAttribute('data-state')) {
          this.state_window = parseInt(this.$refs.ModalWindow.getAttribute('data-state'));
        }
        if (this.$refs.ModalWindow.hasAttribute('data-open')) {
          this.window_display = parseInt(this.$refs.ModalWindow.getAttribute('data-open'));
        }
        if(this.window_display===1) {
          this.$refs.ModalWindow.classList.add('open')
          document.body.classList.add('modal-opened')
          document.body.classList.add('body-modal')
        }
      }

    },


  });
}

