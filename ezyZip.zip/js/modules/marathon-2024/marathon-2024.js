/* eslint-disable */
export default function marathon2024() {
 const array_element = document.querySelectorAll('.js--modal-opener[data-modal="#modal-marathon-stories"]')
 const modal = document.querySelector('#modal-marathon-stories')
 const modal_closer = document.querySelector('#modal-marathon-stories .js--modal-closer')
  let data='';
  for (let element of array_element) {
    element.onclick = () => {
      if (element.hasAttribute('data-video')) {
        data = element.getAttribute('data-video')

        if (modal && modal.querySelector('.js--stories-body-video')) {


          if (modal.querySelector('.js--stories-body-video video')
            && modal.querySelector('.js--stories-body-video video source').getAttribute('src') !==data) {

            modal.querySelector('.js--stories-body-video video').remove()
            const video = document.createElement('video');
            video.controls='controls';
            const source = document.createElement('source');
            source.src = data;
            source.type = 'video/mp4';

            video.appendChild(source);
            modal.querySelector('.js--stories-body-video').appendChild(video);
            video.play();
          }
          if (!modal.querySelector('.js--stories-body-video video')) {

            const video = document.createElement('video');
            video.controls='controls';
            const source = document.createElement('source');
            source.src = data;
            source.type = 'video/mp4';
            source.controls='controls';
            video.appendChild(source);
            modal.querySelector('.js--stories-body-video').appendChild(video);
            video.play();
          }
          if (modal.querySelector('.js--stories-body-video video')
            && modal.querySelector('.js--stories-body-video video source').getAttribute('src') ===data) {

            modal.querySelector('.js--stories-body-video video').play();
          }
        }
      }
    }
  }
}
