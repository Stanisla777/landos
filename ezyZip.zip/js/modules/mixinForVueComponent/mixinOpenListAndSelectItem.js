/* eslint-disable */
// пример html housing-cooperative-request.pug
// подключение миксина izhs-send-form.js
export default {
  props: {
  },
  data() {
    return {
      // data_search:false,
      // input:[
      //   {
      //     active:false,
      //     placeholder:'Регион',
      //     input:[]
      //   },
      //   {
      //     active:false,
      //     placeholder:'Тип программы',
      //     input:[]
      //   },
      //   {
      //     active:false,
      //     placeholder:'Категории участников',
      //     input:[]
      //   },
      // ]
    };
  },
  watch: {
  },
  created() {
  },
  methods: {

    //если выбор чекбоксов, то проверяется наличие класса js--checkbox-selected и если он есть,
    //то когда поле с выбором закрывается, выбранные значения подставляются в поле
    //если выбрано несколько значений, то в поле пявляется надпись Выбрано несколько
    substitutingDataFromArray(element,data){
      if (element.classList.contains('js--checkbox-selected')) {
        if (this.input[data].input.length===0){
          element.querySelector('.js--select-input').value = '';
          element.querySelector('.js--select-input').setAttribute('data-search', '');
        }
        else if (this.input[data].input.length===1){
          element.querySelector('.js--select-input').value = this.input[data].input;
          element.querySelector('.js--select-input').setAttribute('data-search', this.input[data].input);
        }
        else {
          element.querySelector('.js--select-input').value = 'Выбрано несколько';
          element.querySelector('.js--select-input').setAttribute('data-search', 'Выбрано несколько');
        }

        if (this.input[data].input.length>0 && element.closest('.js--filter-row')) {
          element.closest('.js--filter-row').classList.add('active')
        }
      }
    },



    // вызов - закрытие выпадающего списка
    openList(el) {
      const element = el.currentTarget;

      const parent = element.closest('.js--filter-row');
      const container = element.closest('.js--parent-filter');
      const array__select = container.querySelectorAll('.js--container-select.open')

      if (el.target.classList.contains('open') && el.target.tagName!=='INPUT' && el.target.tagName!=='LABEL' && el.target.tagName!=='BUTTON') {
        element.querySelector('.js--select-input').blur();
        if(parent && parent.querySelector('.js--window-background')) {
          parent.querySelector('.js--window-background').setAttribute('style','display:none')
        }
        el.target.classList.remove('open');
        el.target.setAttribute('style','z-index:11;')



        //если выбор чекбоксов, то проверяется наличие класса js--checkbox-selected и если он есть,
        //то когда поле с выбором закрывается, выбранные значения подставляются в поле
        //если выбрано несколько значений, то в поле пявляется надпись Выбрано несколько
        let data_input
        if(element.querySelector('.js--select-list') && element.querySelector('.js--select-list').hasAttribute('data-input')){
          data_input = element.querySelector('.js--select-list').getAttribute('data-input');
          data_input=parseInt(data_input);
          this.substitutingDataFromArray(element,data_input);
        }
        else {
          this.substitutingDataFromArray(element,0);
        }
        this.input[data_input].active=false

      }

      else if (!element.classList.contains('open') && el.target.tagName!=='LABEL' && el.target.tagName!=='BUTTON') {
        //Закрываю все открытые окна
        for (let item of array__select) {
          item.classList.remove('open')
          if (item.hasAttribute('data-input')) {
            this.substitutingDataFromArray(item,parseInt(item.getAttribute('data-input')));
            if (item.classList.contains('js--checkbox-selected')) {
              this.input[parseInt(item.getAttribute('data-input'))].active=false
            }
          }
        }
        //вызов метода сохранения данных в поле с выб.log ранным значением при закрытии окна
        element.querySelector('.js--select-input').value = '';
        this.sampleliveSearch(element.querySelector('.js--select-input'));
        if(parent && parent.querySelector('.js--window-background')) {
          parent.querySelector('.js--window-background').setAttribute('style','display:block')
        }
        if(element.closest('.js--filter-row')) {
          element.closest('.js--filter-row').classList.remove('active')
        }

        if (element.classList.contains('js--checkbox-selected')) {
          let data_input;
          if (element.hasAttribute('data-input')) {
            data_input = element.getAttribute('data-input');
            data_input=parseInt(data_input);
          }
          this.input[data_input].active=true
          element.setAttribute('style','z-index:14;')
        }

        setTimeout(() => {
          element.classList.add('open');
        },100)
      }

      if (element.querySelector('.js--input__error_required')) {
        element.querySelector('.js--input__error_required').remove();
      }
      if (element.classList.contains('.input_error')) {
        element.classList.remove('.input_error');
      }
      element.classList.remove('input_error');
    },
    //выбор одного и подстановка нужного пункта
    selectItem(el) {
      const element = el.currentTarget;
      const wrapper = element.closest('.js--select-list');
      const wrapperItem = wrapper.querySelectorAll('.js--select-item');
      wrapperItem.forEach((item) => {
        item.classList.remove('active-item');
      });
      element.classList.add('active-item');
      let text = element.textContent;
      // у вариантов списка в атрибуте data-value задается bitrix-id варианта
      // (мы не можем ориентироваться на просто кириллический текст).
      // Нужно именно его и передавать в input.value
      const { value } = element.dataset;
      text = text.trim();
      const parent = element.closest('.js--container-select');

      //проработать чтобы это работало только для ИЖС
      const added_class_parent = element.closest('.js--container-select');

      if(added_class_parent) {
        if (!added_class_parent.classList.contains('js--selected')){
          this.fullness_select += 1;
        }
        this.fullness_input = this.fullness_input_name+this.fullness_input_tel+this.fullness_input_mail+
          this.fullness_input_radio+this.fullness_select
      }

      if(parent) {
        parent.querySelector('.js--select-input').classList.add('active');
        parent.querySelector('.js--select-input').setAttribute('data-search', text);
        if (parent.querySelector('.js--select-input-value')) {
          parent.querySelector('.js--select-input-value').value = value;
        }
        parent.classList.add('js--selected');
        parent.classList.remove('input_error');
        this.sampleliveSearch(parent.querySelector('.js--select-input'));
      }

    },
    //функция сохранения данных в поле с выбранным значением при закрытии окна

    //метод, когда выбираю чекбокс и значения записыватся в массив, которые потом подставляются в поле
    // при закрытии окна
    selectChecBox(el){
      const element = el.currentTarget;
      const parent = element.closest('.js--container-select');
      let data_input;
      if(element.closest('.js--select-list') && element.closest('.js--select-list').hasAttribute('data-input')){
        data_input = element.closest('.js--select-list').getAttribute('data-input');
        data_input=parseInt(data_input)
      }
      else {
        data_input='undefined'
      }

      if (element.checked){
        let { value } = element.closest('.js--select-item-checkbox').dataset;
        let text = element.closest('.js--select-item-checkbox').querySelector('label').textContent;
        text = text.trim();
        if(data_input!=='undefined'){
          this.input[data_input].input.push(text)
        }

      }
      else {
        let text = element.closest('.js--select-item-checkbox').querySelector('label').textContent;
        text = text.trim();
        let index = this.input[data_input].input.indexOf(text);
        if (index !== -1 && data_input!=='undefined') {
          this.input[data_input].input.splice(index, 1);
        }
      }
    },

    closeSelect(element) {

      const container = element.closest('.js--parent-filter');
      if (container) {
        const array_filter = container.querySelectorAll('.js--container-select.open');
        for (let item of array_filter) {
          if (item.querySelector('.js--select-input')
            .hasAttribute('data-search') && item.querySelector('.js--select-input')
            .getAttribute('data-search').length > 0) {
            item.querySelector('.js--select-input').value = item.querySelector('.js--select-input')
              .getAttribute('data-search');
          }
          if ((!item.querySelector('.js--select-input')
            .hasAttribute('data-search') || item.querySelector('.js--select-input')
            .getAttribute('data-search').length === 0)) {
            item.querySelector('.js--select-input').value = '';
          }
          item.classList.remove('open');
        }
      }

    },
    //метод закрытия выпадающего списка при клике вне поля с выбором
    clickBackground(el){
      const element = el.currentTarget;
      const parent = element.closest('.js--filter-row');
      element.setAttribute('style','display:none')
      if (parent && parent.querySelector('.js--container-select')) {
        // this.closeSelect(element);
        parent.querySelector('.js--container-select').classList.remove('open');
        parent.querySelector('.js--container-select').setAttribute('style','z-index:11;')

        let data_input
        if(parent.querySelector('.js--select-list') && parent.querySelector('.js--select-list').hasAttribute('data-input')){
          data_input = parent.querySelector('.js--select-list').getAttribute('data-input');
          data_input=parseInt(data_input);
          this.substitutingDataFromArray(parent.querySelector('.js--container-select'),data_input)
        }
        this.input[data_input].active=false
      }
    }
  },
  mounted() {
  }
};
