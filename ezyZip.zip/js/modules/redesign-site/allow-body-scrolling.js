/* eslint-disable */
export default function RemoveClassBody() {
  if (!document.body.classList.contains('body-modal-modals')) {
    document.body.classList.remove('body-modal');
    document.body.classList.remove('body-additional-class');
  }
  const scrollY = document.body.style.top;
  document.body.style.position = '';
  document.body.style.top = '';
  window.scrollTo(0, parseInt(scrollY || '0') * -1);
}

