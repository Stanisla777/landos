export default function headerShowButtons() {
    const buttons = document.querySelectorAll('.js--header-fix-button');
    if (!buttons.length) return;

    const header = document.querySelector('.header');
    const top = header.offsetHeight;

    if (window.pageYOffset >= top) {
        for (let i = 0; i < buttons.length; i += 1) {
            buttons[i].classList.add('show');
        }
    }

    document.addEventListener('scroll', () => {
        if (window.pageYOffset >= top) {
            for (let i = 0; i < buttons.length; i += 1) {
                buttons[i].classList.add('show');
            }
        } else {
            for (let i = 0; i < buttons.length; i += 1) {
                buttons[i].classList.remove('show');
            }
        }
    });
}
