<template lang="pug">
  .polls.js--polls
    p.polls__call-action {{title_text}}
    template
      step-polls(
        v-show="main_window"
        v-if="viewsTest==='Test2'"
        :idTest ="idTest"
        :VOTE_ID="VOTE_ID"
        :QUESTIONS="QUESTIONS"
        :id_correct_answers="id_correct_answers"
        :massive_required="massive_required"
        :sessid="sessid"
        :button_text="button"
        :title_text="title_text"
        :views_test="viewsTest"
      )
    template
      slider-test(
        v-if="viewsTest==='Test1'"
        :idTest ="idTest"
        :VOTE_ID="VOTE_ID"
        :QUESTIONS="QUESTIONS"
        :id_correct_answers="id_correct_answers"
        :massive_required="massive_required"
        :sessid="sessid"
        :button_text="button"
        :title_text="title_text"
      )
    template
      thanks-window(
        v-show="thanks_window"
      )
</template>
<script>
import Vue from 'vue';
import StepPolls from './components/v-component-step-polls.vue';
import SliderTest from './components/v-component-slider-polls.vue';
import ThanksWindow from './components/v-component-thanks-window.vue';
import Storage from './development-tools/state.vue';
import eventBus from './development-tools/eventBus.vue';
import axios from 'axios';
import anchors from '../anchors';

export default {
  name:'Polls',
  data(){
    return {
      QUESTIONS:'',
      // "QUESTIONS": [
      //   // {
      //   //   "ID": "400",
      //   //   "FIELD_TYPE": "99999",
      //   //   "QUESTION": "Какие еще курсы вы хотели бы видеть на нашем сайте?",
      //   //   "CORRECT_ANSWERS": [
      //   //     31
      //   //   ],
      //   //   "DESCRIPTION_TO_ANSWER": "Характеристики объекта недвижимости - площадь, адрес, количество комнат, этаж и другие",
      //   //   "REQUIRED": "Y",
      //   //   "ANSWERS": {
      //   //     "1": {
      //   //       "MESSAGE": "634 тыс. рублей",
      //   //       "FIELD_WIDTH": "1",
      //   //       "FIELD_PARAM": "Верно",
      //   //       "COLOR": "1",
      //   //       "NAME_INPUT": "input_1",
      //   //       "VALUE_INPUT": "1",
      //   //       "DESCRIPTION_TO_ANSWER": "Ответ номер 6",
      //   //       "PLACEHOLDER": "Название темы",
      //   //       "ID": "31"
      //   //     }
      //   //   }
      //   // },
      //   {
      //     "ID": "200",
      //     "FIELD_TYPE": "0",
      //     "QUESTION": "Какой максимальный размер налогового вычета с процентов по ипотечному кредиту?",
      //     "CORRECT_ANSWERS": [
      //       12,
      //       13,
      //       14
      //     ],
      //     "DESCRIPTION_TO_ANSWER": "Характеристики объекта недвижимости - площадь, адрес, количество комнат, этаж и другие",
      //     "REQUIRED": "Y",
      //     "ANSWERS": {
      //       "1": {
      //         "MESSAGE": "634 тыс. рублей",
      //         "FIELD_WIDTH": "1",
      //         "FIELD_PARAM": "Верно",
      //         "COLOR": "0",
      //         "NAME_INPUT": "vote_radio_2",
      //         "VALUE_INPUT": "1",
      //         "DESCRIPTION_TO_ANSWER": "Ответ номер 6",
      //         "PLACEHOLDER": "Какие недостатки вы видите в нашей работе?",
      //         "ID": "12"
      //       },
      //       "2": {
      //         "MESSAGE": "524,5 тыс. рублей",
      //         "FIELD_WIDTH": "0",
      //         "FIELD_PARAM": "верный ответ",
      //         "COLOR": "0",
      //         "NAME_INPUT": "vote_radio_2",
      //         "VALUE_INPUT": "2",
      //         "DESCRIPTION_TO_ANSWER": "Ответ номер 6",
      //         "PLACEHOLDER": "Какие недостатки вы видите в нашей работе?",
      //         "ID": "13"
      //       },
      //       "3": {
      //         "MESSAGE": "452,5 тыс. рублей",
      //         "FIELD_WIDTH": "0",
      //         "FIELD_PARAM": "Чтобы выбрать подходящую квартиру, необходимо: оценить свои финансовые возможности, подобрать подходящее расположение, составить список квартир и записаться на просмотры (не следует приобретать первую же квартиру).",
      //         "COLOR": "1",
      //         "NAME_INPUT": "vote_radio_2",
      //         "VALUE_INPUT": "3",
      //         "DESCRIPTION_TO_ANSWER": "Ответ номер 6",
      //         "PLACEHOLDER": "Какие недостатки вы видите в нашей работе?",
      //         "ID": "14"
      //       }
      //     }
      //   },
      //   {
      //     "ID": "100",
      //     "FIELD_TYPE": "1",
      //     "QUESTION": "Какой минимальный размер материнского капитала?",
      //     "CORRECT_ANSWERS": [
      //       11,
      //       18
      //     ],
      //     "REQUIRED": "Y",
      //     "ANSWERS": {
      //       "1": {
      //         "MESSAGE": "Вариант чекбокс 1",
      //         "FIELD_WIDTH": "1",
      //         "FIELD_PARAM": "Не правильный выбор",
      //         "COLOR": "0",
      //         "NAME_INPUT": "vote_chek_1",
      //         "VALUE_INPUT": "1",
      //         "DESCRIPTION_TO_ANSWER": "Ответ номер 9",
      //         "PLACEHOLDER": "Какие недостатки вы видите в нашей работе?",
      //         "ID": "10"
      //       },
      //       "2": {
      //         "MESSAGE": "Вариант чекбокс 2",
      //         "FIELD_WIDTH": "1",
      //         "FIELD_PARAM": "Верно",
      //         "COLOR": "0",
      //         "NAME_INPUT": "vote_chek_1",
      //         "VALUE_INPUT": "2",
      //         "DESCRIPTION_TO_ANSWER": "Ответ номер 10",
      //         "PLACEHOLDER": "Ого",
      //         "ID": "11"
      //       },
      //       "3": {
      //         "MESSAGE": "Вариант 5",
      //         "FIELD_WIDTH": "0",
      //         "FIELD_PARAM": "Верно",
      //         "COLOR": "0",
      //         "NAME_INPUT": "vote_chek_1",
      //         "VALUE_INPUT": "3",
      //         "DESCRIPTION_TO_ANSWER": "Ответ номер 10",
      //         "PLACEHOLDER": "Ого",
      //         "ID": "18"
      //       }
      //     }
      //   },
      //   {
      //     "ID": "400",
      //     "FIELD_TYPE": "1",
      //     "QUESTION": "Какой минимальный размер материнского капитала?",
      //     "CORRECT_ANSWERS": [
      //       19,
      //       20,
      //       21
      //     ],
      //     "REQUIRED": "N",
      //     "ANSWERS": {
      //       "1": {
      //         "MESSAGE": "Вариант чекбокс 4",
      //         "FIELD_WIDTH": "1",
      //         "FIELD_PARAM": "Верно",
      //         "COLOR": "1",
      //         "NAME_INPUT": "vote_chek_2",
      //         "VALUE_INPUT": "1",
      //         "DESCRIPTION_TO_ANSWER": "Ответ номер 9",
      //         "PLACEHOLDER": "Какие недостатки вы видите в нашей работе?",
      //         "ID": "19"
      //       },
      //       "2": {
      //         "MESSAGE": "Вариант чекбокс 5",
      //         "FIELD_WIDTH": "0",
      //         "FIELD_PARAM": "Правильный ответ!",
      //         "COLOR": "1",
      //         "NAME_INPUT": "vote_chek_2",
      //         "VALUE_INPUT": "2",
      //         "DESCRIPTION_TO_ANSWER": "Ответ номер 10",
      //         "PLACEHOLDER": "Ого",
      //         "ID": "20"
      //       },
      //       "3": {
      //         "MESSAGE": "Вариант 10",
      //         "FIELD_WIDTH": "0",
      //         "FIELD_PARAM": "Верно",
      //         "COLOR": "1",
      //         "NAME_INPUT": "vote_chek_2",
      //         "VALUE_INPUT": "3",
      //         "DESCRIPTION_TO_ANSWER": "Ответ номер 10",
      //         "PLACEHOLDER": "Ого",
      //         "ID": "21"
      //       }
      //     }
      //   },
      //
      //   // {
      //   //   "ID": "300",
      //   //   "FIELD_TYPE": "0",
      //   //   "QUESTION": "Как можно получить сертификат на материнский капитал?",
      //   //   "CORRECT_ANSWERS": [
      //   //     16,
      //   //     17
      //   //   ],
      //   //   "DESCRIPTION_TO_ANSWER": "Характеристики объекта недвижимости - площадь, адрес, количество комнат, этаж и другие",
      //   //   "REQUIRED": "Y",
      //   //   "ANSWERS": {
      //   //     "1": {
      //   //       "MESSAGE": "634 тыс. рублей",
      //   //       "FIELD_WIDTH": "0",
      //   //       "FIELD_PARAM": "Не правильная сумма",
      //   //       "COLOR": "1",
      //   //       "NAME_INPUT": "vote_radio_3",
      //   //       "VALUE_INPUT": "1",
      //   //       "DESCRIPTION_TO_ANSWER": "Ответ номер 6",
      //   //       "PLACEHOLDER": "Какие недостатки вы видите в нашей работе?",
      //   //       "ID": "15"
      //   //     },
      //   //     "2": {
      //   //       "MESSAGE": "524,5 тыс. рублей",
      //   //       "FIELD_WIDTH": "1",
      //   //       "FIELD_PARAM": "Верно",
      //   //       "COLOR": "1",
      //   //       "NAME_INPUT": "vote_radio_3",
      //   //       "VALUE_INPUT": "2",
      //   //       "DESCRIPTION_TO_ANSWER": "Ответ номер 6",
      //   //       "PLACEHOLDER": "Какие недостатки вы видите в нашей работе?",
      //   //       "ID": "16"
      //   //     },
      //   //     "3": {
      //   //       "MESSAGE": "452,5 тыс. рублей",
      //   //       "FIELD_WIDTH": "1",
      //   //       "FIELD_PARAM": "Верно",
      //   //       "COLOR": "1",
      //   //       "NAME_INPUT": "vote_radio_3",
      //   //       "VALUE_INPUT": "3",
      //   //       "DESCRIPTION_TO_ANSWER": "Ответ номер 6",
      //   //       "PLACEHOLDER": "Какие недостатки вы видите в нашей работе?",
      //   //       "ID": "17"
      //   //     }
      //   //   }
      //   // },
      //   // {
      //   //   "ID": "400",
      //   //   "FIELD_TYPE": "99999",
      //   //   "QUESTION": "Какие еще курсы вы хотели бы видеть на нашем сайте?",
      //   //   "CORRECT_ANSWERS": [
      //   //     31
      //   //   ],
      //   //   "DESCRIPTION_TO_ANSWER": "Характеристики объекта недвижимости - площадь, адрес, количество комнат, этаж и другие",
      //   //   "REQUIRED": "Y",
      //   //   "ANSWERS": {
      //   //     "1": {
      //   //       "MESSAGE": "634 тыс. рублей",
      //   //       "FIELD_WIDTH": "1",
      //   //       "FIELD_PARAM": "Верно",
      //   //       "COLOR": "1",
      //   //       "NAME_INPUT": "input_1",
      //   //       "VALUE_INPUT": "1",
      //   //       "DESCRIPTION_TO_ANSWER": "Ответ номер 6",
      //   //       "PLACEHOLDER": "Название темы",
      //   //       "ID": "31"
      //   //     }
      //   //   }
      //   // }
      // ],

      viewsTest:'2',
      idTest:null,
      VOTE_ID:null,
      button:'Проверить ответы',
      title_text:'Проверьте себя',
      id_correct_answers:[],//Расскоментировать
      massive_required:[],//Расскоментировать
      // id_correct_answers:[11, 18, 19, 20, 21, 12, 13, 14, 16,17],//Убрать
      // massive_required:['Y'],//Убрать
      sessid:null,
    }
  },

  methods:{
    getParameterApi(param){
      const config_header = {
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        }
      }

      //расскоментировать


      axios.get(`/local/api/tests/?id_tests=${param}`, this.config_header)
        .then((res)=>{
          this.QUESTIONS = res.data.QUESTIONS
          for (let item of res.data.QUESTIONS){
            for (let elem of item.CORRECT_ANSWERS){
              this.id_correct_answers.push(elem)
            }
            if(item.REQUIRED=='Y'){
              this.massive_required.push(item.REQUIRED)
            }
          }
          // console.log(this.massive_required);
          let sessid=res.data.SESSID.split('=').pop();
          sessid = sessid.replace(/[^a-zа-яё0-9\s]/gi, '');
          sessid = sessid.trim()
          this.sessid = sessid

        }).catch((error) => {
          console.log(error);
        });
    },
    accordion() {
      const courses = document.querySelectorAll('.js--courses-accord');
      for (let i = 0; i < courses.length; i++) {
        const content = courses[i].querySelector('.js--courses-accord-content');
        const opener = courses[i].querySelector('.js--courses-accord-btn');
        opener.onclick = () => {
          if (courses[i].classList.contains('active')) {
            opener.classList.remove('active');
            courses[i].classList.remove('active');
            content.classList.remove('show');
            content.setAttribute('style', `height:0`);
          } else {
            courses[i].classList.add('active');
            opener.classList.add('active');
            content.classList.add('show');
            const rte = content.querySelector('#RTE');
            const contentHeight = rte.offsetHeight;
            content.style.height = `${contentHeight}px`;
          }
        };
      }
    }
  },
  mounted() {
    this.viewsTest = this.$attrs.views
    this.idTest = this.$attrs.id
    this.VOTE_ID = this.$attrs.id
    // console.log(this.$attrs.title_text);
    if(this.$attrs.button){
      this.button=this.$attrs.button
    }
    if(this.$attrs.button==='null') {
      this.button='Проверить ответы'
    }

    if(this.$attrs.title_text){
      this.title_text=this.$attrs.title_text
    }
    if(this.$attrs.title_text==='null') {
      this.title_text='Проверьте себя'
    }

    this.getParameterApi(this.idTest)//расскоментировать
  },
  computed:{
    thanks_window(){
      return Storage.getters.THANKSWINDOW
    },
    main_window(){
      return Storage.getters.MAINWINDOW
    },
  },
  components:{
    StepPolls,
    SliderTest,
    ThanksWindow
  },
}
</script>
