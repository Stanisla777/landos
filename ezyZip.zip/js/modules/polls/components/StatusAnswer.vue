<template lang="pug">
  .test-cotainer-result-answers()
    .test-cotainer-result-emty-block
    .test-window__response-status-icon(v-if="!correct")
      .test-window__response-icon
        svg(width="72" height="72" viewBox="0 0 72 72" fill="none" xmlns="http://www.w3.org/2000/svg")
          circle(cx="36" cy="36" r="36" fill="#FF0000")
          path(d="M20.9393 49.9393C20.3536 50.5251 20.3536 51.4749 20.9393 52.0607C21.5251 52.6464 22.4749 52.6464 23.0607 52.0607L20.9393 49.9393ZM52.0607 23.0607C52.6464 22.4749 52.6464 21.5251 52.0607 20.9393C51.4749 20.3536 50.5251 20.3536 49.9393 20.9393L52.0607 23.0607ZM49.9393 52.0607C50.5251 52.6464 51.4749 52.6464 52.0607 52.0607C52.6464 51.4749 52.6464 50.5251 52.0607 49.9393L49.9393 52.0607ZM23.0607 20.9393C22.4749 20.3536 21.5251 20.3536 20.9393 20.9393C20.3536 21.5251 20.3536 22.4749 20.9393 23.0607L23.0607 20.9393ZM23.0607 52.0607L52.0607 23.0607L49.9393 20.9393L20.9393 49.9393L23.0607 52.0607ZM52.0607 49.9393L23.0607 20.9393L20.9393 23.0607L49.9393 52.0607L52.0607 49.9393Z" fill="white")
      p.test-window__response-status-des Неверно
    .test-window__response-status-icon(v-else)
      .test-window__response-icon
        svg(width="72" height="72" viewBox="0 0 72 72" fill="none" xmlns="http://www.w3.org/2000/svg")
          circle(cx="36" cy="36" r="36" fill="#8BC540")
          path(d="M21.0821 38.9612C20.5084 38.3636 19.5588 38.3442 18.9612 38.9179C18.3636 39.4916 18.3442 40.4412 18.9179 41.0388L21.0821 38.9612ZM31.52 52L30.4379 53.0388C30.7563 53.3704 31.2091 53.5377 31.6665 53.4928C32.124 53.4479 32.5356 53.1957 32.7834 52.8086L31.52 52ZM53.2634 20.8086C53.71 20.1108 53.5063 19.1832 52.8086 18.7366C52.1108 18.29 51.1832 18.4937 50.7366 19.1914L53.2634 20.8086ZM18.9179 41.0388L30.4379 53.0388L32.6021 50.9612L21.0821 38.9612L18.9179 41.0388ZM32.7834 52.8086L53.2634 20.8086L50.7366 19.1914L30.2566 51.1914L32.7834 52.8086Z" fill="white")
      p.test-window__response-status-des Верно
    .test-window__response-correct-answer
      p.test-window__response-des.fs-1rem(
        v-for="item in response_description"
        v-html="item"
      )


</template>

<script>
export default {
  name: "StatusAnswer",
  data(){
    return{
      status_answer:this.correct,
      status:this.win,
      response_description:[]
    }
  },

  props:['correct','description','win'],
  methods:{
    heightIntermediateWindow(){

      const elem = document.querySelector('.test-cotainer-result-answers')
      const elem_em = elem.querySelector('.test-cotainer-result-emty-block')
      const elem_em_2= elem.querySelector('.test-cotainer-result-answers')
      const style = window.getComputedStyle(elem_em).getPropertyValue("display");
      const style_2 = window.getComputedStyle(elem_em_2).getPropertyValue("display");



        const height_el = elem.clientHeight
        console.log(height_el);
        elem.closest('.swiper-wrapper').setAttribute('style','height:auto')
        elem.closest('.test-window').setAttribute('style',`height:${height_el+125}px`)

    },
    sameAnswers(){
      this.response_description = Array.from(new Set(this.description))
    }

  },
  watch:{
    description() {
      this.sameAnswers()
    }
  },
  mounted() {
    // this.sameAnswers()
  }

}
</script>

<style scoped>

</style>
