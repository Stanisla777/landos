<template lang="pug">
  .polls__component-question.js--polls-component-radio(
    v-bind:class="[(required=='Y')?'required':'optional']"
  )
    p.polls__question(
      v-html="question"
    )
    .polls__list-answers.js--list-answers
      .checkbox-stylized.polls__list-answers-item.polls__list-radio.js--list-radio.js--list-variant(
        v-for ="(answer,key,ind) in variants"
        v-bind:data-sort="answer.ID"
        @click="pass_clickVariant($event,answer.FIELD_WIDTH,answer.FIELD_PARAM,answer.COLOR,answer.NAME_INPUT,answer.VALUE_INPUT,answer.ID,id_question)"
      )
        input(
          v-bind:id="[`${id_question}-${item_key}-${key}`]"
          v-on:click.stop=""
          v-bind:name="[`${id_question}-${item_key}`]"
        )(type="radio",value="")
        label(
          v-bind:for="[`${id_question}-${item_key}-${key}`]"
          v-html="answer.MESSAGE"
        )
        p.polls__answer-to-question.js--answer-to-question(
          v-if="answer.COLOR==1"
        ) {{answer.FIELD_PARAM}}
</template>
<script>
import Storage from '../development-tools/state.vue';
import eventBus from '../development-tools/eventBus.vue';

export default {
  name: 'v-conponent-radio-btn',
  props:['question','variants','item_key','required','current_answer','id_question'],
  data(){
    return {
      QUESTION:"",
    }
  },
  methods:{
    pass_clickVariant(elem,param_1,param_2,param_3,param_4,param_5,param_6,param_7){
      const element = elem.currentTarget
      let status;
      status = !element.querySelector('input').checked;
      const data = [param_4,param_5,param_7,element]
      if(element.closest('.js--polls-component-radio').classList.contains('required')){
        this.$emit('event_SelectRadioForButton',data)
      }
      this.$emit('event_actionSelectRadioForSend',data)
      this.$emit('event_clickVariant',[element,status])
    }
  },
  mounted(){

  },
  computed:{


  },
  created() {


  },
  watch:{
  },
  components:{
  }
};
</script>
<style scoped>
</style>
