/* eslint-disable */
export default function initializationPolls() {
  // eslint-disable-next-line no-unused-vars
  const testAvailability = document.querySelectorAll('polls');
  testAvailability.forEach((item) => {
    // eslint-disable-next-line no-unused-vars
    const id = item.getAttribute('id');
    // console.log(id);
    // eslint-disable-next-line no-unused-vars
    const views = item.getAttribute('views');
    // eslint-disable-next-line camelcase
    const color_text = item.getAttribute('color');
    // eslint-disable-next-line camelcase,no-unused-vars
    const title_text = item.getAttribute('title-text');
    // eslint-disable-next-line camelcase
    const content_btn = item.getAttribute('button');
    const Test = document.createElement('v-polls');
    Test.setAttribute('views', `${views}`);
    Test.setAttribute('id', `${id}`);
    Test.classList.add('js-polls-n')
    // eslint-disable-next-line camelcase
    Test.setAttribute('color', `${color_text}`);
    // eslint-disable-next-line camelcase,eqeqeq
    if (color_text == null || color_text == '') {
      Test.setAttribute('color', 'white');
    }
    // eslint-disable-next-line camelcase
    Test.setAttribute('button', `${content_btn}`);
    // eslint-disable-next-line camelcase
    Test.setAttribute('title_text', `${title_text}`);
    item.prepend(Test);
  });
}
