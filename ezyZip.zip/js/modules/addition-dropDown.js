// eslint-disable-next-line camelcase
export default function additionDropDown() {
  // eslint-disable-next-line camelcase
  const array_dropdown_llist = document.querySelectorAll('.js-accordion-parent.active');
  array_dropdown_llist.forEach((item) => {
    if (item.querySelector('.js-accordion-body')) {
      item.querySelector('.js-accordion-body').setAttribute('style', `max-height:${item.querySelector('.js-accordion-body').offsetHeight}px;`);
    }
  });
}
