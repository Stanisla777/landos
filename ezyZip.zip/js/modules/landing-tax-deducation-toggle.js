import dropDown from './dropDown';
// eslint-disable-next-line no-unused-vars
function scroolToSection() {
  // eslint-disable-next-line camelcase
  const scroll_btn = document.querySelector('.calculator_s__scroll-down');
  // eslint-disable-next-line no-empty,camelcase
  if (scroll_btn) {
    scroll_btn.onclick = () => {
      const yOffset = -20;
      const element = document.querySelector('.js-scroll');
      const y = element.getBoundingClientRect().top + window.pageYOffset + yOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    };
  }
}
function scroolToAddInfo() {
  // eslint-disable-next-line camelcase
  const scroll_btn = document.querySelectorAll('.js--anchor-links');
  // eslint-disable-next-line no-empty,camelcase,no-restricted-syntax
  for (const item of scroll_btn) {
    item.onclick = () => {
      // eslint-disable-next-line no-unused-vars
      const data = item.getAttribute('data-anchor');
      // eslint-disable-next-line no-unused-vars
      const yOffset = -20;
      // eslint-disable-next-line camelcase
      const el_add_info = document.querySelectorAll('.js--add-info .js--add-info-block');
      // eslint-disable-next-line no-restricted-syntax,no-shadow,no-unused-vars,camelcase,no-empty
      for (const item of el_add_info) {
        // eslint-disable-next-line no-shadow,no-unused-vars,camelcase
        const data_anchor = item.getAttribute('data-anchor');
        // eslint-disable-next-line camelcase,eqeqeq
        if (data_anchor == data) {
          // eslint-disable-next-line camelcase,eqeqeq,no-empty
          const y = item.getBoundingClientRect().top + window.pageYOffset + yOffset;
          window.scrollTo({
            top: y,
            behavior: 'smooth'
          });
        }
      }
    };
  }
}
function beesenderChat() {
  // eslint-disable-next-line no-unused-vars
  const iOS = navigator.userAgent.match(/iPhone|iPad|iPod/i);
  // eslint-disable-next-line no-unused-vars
  const event = 'click';
  // eslint-disable-next-line camelcase
  const btn_beesenderchat = document.querySelectorAll('.js--btn-call-beesenderchat');
  // eslint-disable-next-line camelcase
  const window_beesenderchat = document.querySelector('#beesenderchat-widget-startbutton');
  // eslint-disable-next-line camelcase
  if (window_beesenderchat) {
    window_beesenderchat.addEventListener('touchstart', () => {});
    window_beesenderchat.addEventListener('touchend', () => {});
    window_beesenderchat.addEventListener('touchcancel', () => {});
    window_beesenderchat.addEventListener('touchmove', () => {});
  }
  // eslint-disable-next-line no-empty,camelcase,no-restricted-syntax
  for (let item = 0; item < btn_beesenderchat.length; item++) {
    btn_beesenderchat[item].addEventListener('click', () => {
      // eslint-disable-next-line camelcase,no-shadow
      const window_beesenderchat2 = document.querySelector('#beesenderchat-widget-startbutton');
      // eslint-disable-next-line camelcase
      if (window_beesenderchat2) {
        window_beesenderchat2.click();
      }
    });
  }
}
export default function taxToggle() {
  // eslint-disable-next-line camelcase
  const btn_more = document.querySelectorAll('.js-accordion-btn');
  // eslint-disable-next-line no-empty,camelcase,no-restricted-syntax,no-unused-vars
  for (const item of btn_more) {
    item.onclick = (ev) => {
      const element = ev.currentTarget;
      dropDown(element, 0);
    };
  }
  // eslint-disable-next-line camelcase
  const btn_faq_list = document.querySelectorAll('.calculator_s__faq-list-accordion-button');
  // eslint-disable-next-line no-restricted-syntax,camelcase
  for (const btn of btn_faq_list) {
    btn.onclick = (ev) => {
      const element = ev.currentTarget;
      dropDown(element, 0);
    };
  }
  scroolToSection();
  beesenderChat();
  scroolToAddInfo();
}
