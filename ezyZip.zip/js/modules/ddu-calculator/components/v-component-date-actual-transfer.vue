<template lang="pug">
  .property-calculator__row.property-calculator__several-columns_col.ddu__time-margin.margin
    .property-calculator__wrapper-explanation
      p.property-calculator__row-label Передача объекта по факту
      .property-calculator__period-input-wrap-icon.green
        svg(width='6' height='9' viewbox='0 0 6 9' fill='none' xmlns='http://www.w3.org/2000/svg')
          path(d='M2.29615 5.82809V5.87809H2.34615H3.38128H3.43128V5.82809C3.43128 5.17718 3.88001 4.74316 4.37092 4.26834C4.3939 4.24612 4.41697 4.2238 4.44009 4.20137C4.95161 3.70514 5.47928 3.15761 5.47928 2.27748C5.47928 1.56616 5.1798 1.02591 4.72144 0.664646C4.26438 0.304406 3.65179 0.123828 3.0251 0.123828C1.94115 0.123828 0.916704 0.644209 0.518245 1.74851L0.503822 1.78848L0.540948 1.80916L1.42025 2.2989L1.47368 2.32866L1.49223 2.27038C1.60592 1.91305 1.80522 1.65293 2.06481 1.48165C2.32489 1.31005 2.64868 1.22557 3.01397 1.22557C3.39653 1.22557 3.72964 1.31585 3.96588 1.49634C4.20027 1.67543 4.34415 1.94688 4.34415 2.322C4.34415 2.63879 4.22214 2.90106 4.03445 3.14622C3.87409 3.35566 3.66836 3.5496 3.45209 3.75346C3.41356 3.78978 3.37469 3.82642 3.33569 3.86351C2.82303 4.3511 2.29615 4.90943 2.29615 5.82809ZM2.85815 8.28226C3.29809 8.28226 3.63162 7.93659 3.63162 7.50879C3.63162 7.08098 3.29809 6.73531 2.85815 6.73531C2.42984 6.73531 2.08467 7.08048 2.08467 7.50879C2.08467 7.9371 2.42984 8.28226 2.85815 8.28226Z' fill='#1C1B28' stroke='#1C1B28' stroke-width='0.1')
        template
          tool-tip(
            :hint_text="hint_text"
          )
    .property-calculator__input-field.ddu__calendar.js--calendar-input-actual.js--calendar
      input.property-calculator__value(type="text" value="16.12.2022" placeholder="дд.мм.гггг" inputmode="numeric")(
        @input="changeDate"
        @click ="showCalendar"
        @blur="lossFocus"
        ref="inputDateActual"
      )
      .js__vanilla-calendar-calc-actual.js__vanilla-calendar.vanilla-calendar-style.property-calculator__vanilla-calendar.ddd(
        @click.stop ="showCalendar"
        ref="mortgagePrice"
      )
      .property-calculator__input-additional-elem(
        @click ="showCalendar"
      )
        svg(width='20', height='20', viewbox='0 0 20 20', fill='none', xmlns='http://www.w3.org/2000/svg')
          path(d='M4.16658 0V0.833333H0.833252V19.1667H19.1666V0.833333H15.8333V0H14.1666V0.833333H5.83325V0H4.16658ZM2.49992 2.5H4.16658V3.33333H5.83325V2.5H14.1666V3.33333H15.8333V2.5H17.4999V4.16667H2.49992V2.5ZM2.49992 5.83333H17.4999V17.5H2.49992V5.83333ZM4.16658 10.8333V12.5H5.83325V10.8333H4.16658ZM7.49992 10.8333V12.5H9.16658V10.8333H7.49992ZM10.8333 10.8333V12.5H12.4999V10.8333H10.8333ZM14.1666 10.8333V12.5H15.8333V10.8333H14.1666ZM4.16658 14.1667V15.8333H5.83325V14.1667H4.16658ZM7.49992 14.1667V15.8333H9.16658V14.1667H7.49992ZM10.8333 14.1667V15.8333H12.4999V14.1667H10.8333Z', fill='black')
    p.ddu__error-green(v-if="delivery_date_fact&&appearance_error!==true") Дата передачи объекта ещё не наступила, расчёт может быть не точным
</template>
<script>
import IMask from 'imask';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import PopUp from '../components/v-component-pop-up.vue';
import ToolTip from '../components/v-component-tooltip.vue';
import VanillaCalendar from '../../vanilla-calendar';
export default {
  name: 'v-date-actual-transfer',
  data(){
    return {
      error_count:0,
      start_date:new Date().toLocaleDateString(),
      hint_text:'По закону период просрочки заканчивается в день подписания акта приема-передачи',
    }

  },
  methods:{
    inputCalendar(){
      const input_status = document.querySelectorAll('.js--calendar-input-actual input');
      const maskOptions = {
        mask: Date,
        min: new Date(1982, 0, 1),
        // max:new Date()
        // lazy:false
      };
      // eslint-disable-next-line no-restricted-syntax,camelcase,no-undef
      for (const item of input_status) {
        // eslint-disable-next-line no-new
        new IMask(item, maskOptions);
      }
    },
    initPluginCalendarVanilla(dates,month,year){
      const perem = this.$refs.mortgagePrice
      this.calendar = new VanillaCalendar('.js__vanilla-calendar-calc-actual', {
        settings: {
          lang: 'ru',
          range: {
            // max: new Date().toISOString().slice(0, 10)
          },
          selected: {
            dates: dates,
            month: month,
            year:year
          },
          selection: {
          },
        },
        actions: {
          clickDay(e, dates) {
            const data = String(dates[0])
              .substr(8, 2) + '.' + String(dates[0])
              .substr(5, 2) + '.' + String(dates[0])
              .substr(0, 4);
            if (dates.length !== 0) {
              const parent = e.currentTarget.closest('.js--calendar-input-actual');
              if(parent!==null){
                parent.querySelector('input').value = data;
                Storage.dispatch('ActionInputDateActual', [dates[0], true ]);
                e.currentTarget.closest('.js__vanilla-calendar-calc-actual').classList.remove('active');
              }
            }
          }
        }
      })
      this.calendar.init();
    },
    showCalendar(el){
      const element = el.currentTarget;
      element.closest('.js--calendar-input-actual').querySelector('.js__vanilla-calendar-calc-actual').classList.add('active')

    },
    changeDate(el) {
      const element = el.currentTarget;
      const container = element.closest('.js--tax-deduction_calculations');
      const data1 = new Date(element.value.replace(/(_|\s)+/g, "").substr(6, 4)+'-'+element.value.replace(/(_|\s)+/g, "").substr(3, 2)+"-"+element.value.replace(/(_|\s)+/g, "").substr(0, 2));
      const date2 = this.first_period_date;
      const oneDay = 1000 * 60 * 60 * 24;


      if (element.value.replace(/(_|\s)+/g, "").length===10&&element.value.replace(/(_|\s)+/g, "").substr(3, 2)<=12) {
        const date = element.value.replace(/(_|\s)+/g, "").substr(6, 4)+'-'+element.value.replace(/(_|\s)+/g, "").substr(3, 2)+"-"+element.value.replace(/(_|\s)+/g, "").substr(0, 2)
        const month = parseInt(element.value.replace(/(_|\s)+/g, "").substr(3, 2)) - 1;
        const year = element.value.replace(/(_|\s)+/g, "").substr(6, 4)

        this.calendar = null
        this.initPluginCalendarVanilla([`${date}`],month,year)

        const date_begin = element.value.replace(/(_|\s)+/g, "").substr(0, 2)
        setTimeout(()=>{
          element.closest('.js--calendar-input-actual').querySelector('.js__vanilla-calendar-calc-actual').classList.remove('active')
        },500)


        const data = element.value.replace(/(_|\s)+/g, "").substr(6, 4)+'-'+element.value.replace(/(_|\s)+/g, "").substr(3, 2)+"-"+element.value.replace(/(_|\s)+/g, "").substr(0, 2);
        Storage.dispatch('ActionInputDateActual', [data, true ]);

      }
      else if(element.value.replace(/(_|\s)+/g, "").length < 10){
        Storage.dispatch('ActionInputDateActual', [null, false ]);
      }

    },
    lossFocus(el){
      const element = el.currentTarget
      if(element.value===''){
        element.value=this.start_date

        const date = this.start_date.replace(/(_|\s)+/g, "").substr(6, 4)+'-'+this.start_date.replace(/(_|\s)+/g, "").substr(3, 2)+"-"+this.start_date.replace(/(_|\s)+/g, "").substr(0, 2)
        const month = parseInt(this.start_date.replace(/(_|\s)+/g, "").substr(3, 2)) - 1;
        const year = this.start_date.replace(/(_|\s)+/g, "").substr(6, 4)

        this.calendar = null
        this.initPluginCalendarVanilla([`${date}`],month,year)
        Storage.dispatch('ActionInputDateActual', [date, true ]);
      }
    },
    CalendarVanillaClose() {
      let count = 0;
      document.body.onclick = () => {
        const array_parent = document.querySelectorAll('.js--calendar-input-actual');
        const array_element = document.querySelectorAll('.js__vanilla-calendar-calc-actual.active');
        for (const item of array_parent) {
          item.onclick = function (w) {
            w.stopImmediatePropagation();
          };
        }
        if (count > 0) {
          for (let i = 0; i < array_element.length; i++) {
            array_element[i].classList.remove('active');
          }
        }
        if (count < 1) {
          count += 1;
        }

      };
    },
    todayDate(){
      this.$refs.inputDateActual.value = this.start_date
      const data = this.start_date.replace(/(_|\s)+/g, "").substr(6, 4)+'-'+this.start_date.replace(/(_|\s)+/g, "").substr(3, 2)+"-"+this.start_date.replace(/(_|\s)+/g, "").substr(0, 2);
      Storage.dispatch('ActionInputDateActual', [data, true ]);
    },
  },
  mounted(){
    this.inputCalendar()
    this.initPluginCalendarVanilla()
    // this.CalendarVanillaClose()
    this.todayDate()
  },
  computed:{
    appearance_error(){
      return Storage.getters.STATE_DIFFERENCE_DAYS
    },
    delivery_date_fact(){
      return Storage.getters.DELIVERY_DATE_FACT
    },
  },
  watch:{
  },
  components:{
    PopUp,
    ToolTip
  }
};
</script>
<style scoped>
</style>
