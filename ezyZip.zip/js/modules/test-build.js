// eslint-disable-next-line no-unused-vars
import axios from 'axios-jsonp-pro';
// eslint-disable-next-line no-unused-vars
function header() {
  // eslint-disable-next-line no-shadow,no-unused-vars
 const header = document.querySelectorAll('.wrap-test');
 if (header.length > 0) {
   header.forEach((item) => {
     // eslint-disable-next-line camelcase
     const header_parent = item.closest('.page-wrap');
     header_parent.querySelector('.header').setAttribute('style', 'border:none');
   });
 }
}

export default function testBuild() {
  // eslint-disable-next-line no-unused-vars
  const testAvailability = document.querySelectorAll('tests');
  testAvailability.forEach((item) => {
    // eslint-disable-next-line no-unused-vars
    const id = item.getAttribute('id');
    // eslint-disable-next-line no-unused-vars
    const views = item.getAttribute('views');
    // eslint-disable-next-line no-unused-vars
    const newDiv = document.createElement('div');
    newDiv.setAttribute('id', 'test');
    item.prepend(newDiv);
    const Test = document.createElement('Test');
    Test.setAttribute('views', `${views}`);
    Test.setAttribute('id', `${id}`);
    newDiv.prepend(Test);
  });
  header();
}
