<template lang="pug">
  .gameddreg__wrapper
    template
      registration-close
    .gameddreg__finish-alarm-img
      img(src="/dist/img/all-right.png")
    p.gameddreg__title  Почти закончили
    p.gameddreg__sub-title.margin.
      Мы выслали ссылку для подтверждения адреса на&nbsp;вашу электронную почту. Она будет активна в течение 24 часов.

</template>

<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import RegistrationClose from './RegistrationClose.vue'
export default {
  name: 'FinishMailChanged',

  props: {

  },
  data() {
    return {
      status_btn:false,
    }
  },
  computed: {

  },
  methods: {


  },
  created(){


  },
  updated() {

  },
  components:{
    RegistrationClose

  }

}
</script>
