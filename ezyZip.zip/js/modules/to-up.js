import throttle from './throttle';
import scrollIt from './scroll-it';

export default function toUp() {
    const toUppBtn = document.querySelector('.js--to-up');
    const footer = document.querySelector('footer');
    if (!toUppBtn) { return false; }

    const options = {
        root: null,
        rootMargin: '0px',
        threshold: 0
    };

    function callback(entries) {
        entries.forEach((entry) => {
            if (entry.target === footer && entry.isIntersecting) {
                toUppBtn.classList.add('fixed');
            } else {
                toUppBtn.classList.remove('fixed');
            }
        });
    }

    const observer = new IntersectionObserver(callback, options);

    observer.observe(footer);

    if (toUppBtn) {
        toUppBtn.querySelector('.to-up__button').addEventListener('click', () => {
            scrollIt(document.querySelector('body'), 700, 'linear');
            setTimeout(() => {
                toUppBtn.classList.remove('active');
            }, 800);
        });
    }

    document.addEventListener('scroll', throttle(() => {
        if (window.pageYOffset > 700) {
            toUppBtn.classList.add('active');
        } else {
            toUppBtn.classList.remove('active');
        }
    }, 30));
}
