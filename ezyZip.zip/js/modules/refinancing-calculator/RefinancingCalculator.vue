<template lang="pug">
  div
    .property-calculator__body-row.refinancing-calc__body-row
      div.property-calculator__calculations
        .property-calculator__block
          h2.property-calculator__title Действующий кредит
          template
            component-remainder-debt

          .property-calculator__several-columns.two-columns.grow
            template
              component-old-rate
            template
              component-remainder-time

        .property-calculator__block.js--refinancing-options
          h2.property-calculator__title Параметры рефинансирования
          template
            component-change-buttons

          template
            component-new-debt(
              v-show="button_state.parameter_debt"
            )
          .property-calculator__two-columns.grow
            template
              component-new-rate(
                v-show="button_state.parameter_rate"
              )
            template
              component-new-time(
                v-show="button_state.parameter_time"
              )



      //template
      //  component-check-other-means
      //.calculator_s__row-two-column.calculator_s__calculator-row(
      //  v-show="other_means"
      //)
      //
      //template
      //  component-type-payment
      //
      //template
      //  component-button(
      //    v-on:eventCalculate="showCalculation"
      //  )
      div.property-calculator__container-result.refinancing-calc__container-result.first-show
        template(v-show="final_state_confirmed")
          component-final-result
        p.refinancing-calc__footnote.
          Результат расчета предварительный, сформирован в ознакомительных целях на основе предоставленных сведений и
          не является официальным заключением, офертой, индивидуальной оценкой. Для получения подробной информации и
          индивидуальной оценки рекомендуем обратиться в кредитную организацию
    template
      pop-up(

        v-show="modal_state"
      )

</template>
<script>
import Vue from 'vue';
import eventBus from './development-tools/eventBus.vue';
import Storage from './development-tools/state.vue';
import ComponentRemainderDebt from './components/v-component-remainder-debt.vue';
import ComponentOldRate from './components/v-component-old-rate.vue';
import ComponentRemainderTime from './components/v-component-remainder-time.vue';
import ComponentChangeButtons from './components/v-component-change-buttons.vue';

import ComponentNewDebt from './components/v-component-new-debt.vue';
import ComponentNewRate from './components/v-component-new-rate.vue';
import ComponentNewTime from './components/v-component-new-time.vue';



import ComponentFinalBlockConfirmed from './components/v-component-block-final-result.vue';
import ComponentTypePayment from './components/v-component-type-payment.vue';
import ComponentCheckOtherMeans from './components/v-component-checkbox-other-means.vue';
import ToolTip from './components/v-component-tooltip.vue';
import ComponentButton from './components/v-component-button.vue';
import ComponentFinalResult from './components/v-component-block-final-result.vue';
import PopUp from './components/v-component-pop-up.vue';


export default {
  name: 'RefinancingCalculator',
  data(){
    return {
      other_means:false,
      final_result:true,
      final_state_confirmed:false,
      pop_up:false,
      text_pop_up:''
    }
  },
  methods:{
    showCalculation(){
      this.final_state_confirmed=false
      this.final_result=false
      this.final_state_confirmed=true
      setTimeout(()=>{
        this.final_result=true
      },100)
    },
    callPopUp(param){
      this.text_pop_up=param
      this.pop_up=true
    },
    closePopUp(){
      this.pop_up=false
    }
  },
  mounted(){
    // const parent = document.querySelector('.js--v-calculator').closest('.calculator_s')
    // parent.querySelector('.calculator_s__col:first-child').classList.add('mortgage-calculator__main-part')

  },
  computed:{
    button_state(){
      return  Storage.getters.BUTTON_STATE
    },
    modal_state(){
      return  Storage.getters.MODAL_STATE
    },

  },
  created(){
    eventBus.$on('eventcheckboxChanged',(param)=>{
      this.other_means=param
    })
  },
  watch:{
  },
  components:{
    ComponentRemainderDebt,
    ComponentOldRate,
    ComponentRemainderTime,
    ComponentChangeButtons,
    ComponentNewDebt,
    ComponentNewRate,
    ComponentNewTime,


    ComponentFinalBlockConfirmed,

    ComponentCheckOtherMeans,
    ToolTip,
    ComponentButton,
    ComponentTypePayment,
    ComponentFinalResult,
    PopUp
  }
};
</script>
<style scoped>
</style>
