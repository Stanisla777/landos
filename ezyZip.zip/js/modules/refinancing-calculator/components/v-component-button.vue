<template lang="pug">
  .mortgage-calculator__row-btn
    button.credit-holiday__btn(
      :class="[(interest_filled===true&&term_filled===true)?'active':'unactive']"
      @click="calculateData"
    ) Рассчитать
</template>
<script>
import Vue from 'vue';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-component-button',
  props:[],
  data(){
    return {
      data_type_payment:null
    }
  },
  methods:{
    calculateData(){
      Storage.dispatch('ActionCalculate',this.data_type_payment)
      this.$emit('eventCalculate')
    }
  },
  mounted(){
  },
  computed:{
    interest_filled(){
      return Storage.getters.INTERESTFILLED
    },
    term_filled(){
      return Storage.getters.TERMFILLED
    }
  },
  watch:{
  },
  created(){
    eventBus.$on('receivePaymentType',(param)=>{
      this.data_type_payment=param
    })
  },
  components:{}
};
</script>
<style scoped>
</style>
