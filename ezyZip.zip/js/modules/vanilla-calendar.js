/* eslint-disable */
!function (e, t) {
  if ('object' == typeof exports && 'object' == typeof module) {
    module.exports = t();
  } else if ('function' == typeof define && define.amd) {
    define([], t);
  } else {
    var l = t();
    for (var n in l) ('object' == typeof exports ? exports : e)[n] = l[n];
  }
}(self, (() => (() => {
  'use strict';
  var e = {
      d: (t, l) => {
        for (var n in l) {
          e.o(l, n) && !e.o(t, n) && Object.defineProperty(t, n, {
            enumerable: !0,
            get: l[n]
          });
        }
      },
      o: (e, t) => Object.prototype.hasOwnProperty.call(e, t),
      r: e => {
        'undefined' != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, { value: 'Module' }), Object.defineProperty(e, '__esModule', { value: !0 });
      }
    },
    t = {};
  e.r(t), e.d(t, { default: () => w });
  const l = e => {
      if (!['default', 'year'].includes(e.currentType)) return;
      const t = e.HTMLElement.querySelector('.vanilla-calendar-arrow_prev'),
        l = e.HTMLElement.querySelector('.vanilla-calendar-arrow_next');
      if (t instanceof HTMLElement && l instanceof HTMLElement) {
        const n = () => {
          e.dateMin && e.dateMax && 'year' === e.currentType && void 0 !== e.viewYear && (e.dateMin.getUTCFullYear() && e.viewYear - 7 <= e.dateMin.getUTCFullYear() ? t.style.visibility = 'hidden' : t.style.visibility = '', e.dateMax.getUTCFullYear() && e.viewYear + 7 >= e.dateMax.getUTCFullYear() ? l.style.visibility = 'hidden' : l.style.visibility = '');
        };
        (() => {
          if (!e.dateMin || !e.dateMax || 'default' !== e.currentType) return;
          const n = e.selectedMonth === e.dateMin.getUTCMonth(),
            a = e.selectedMonth === e.dateMax.getUTCMonth(),
            s = !e.settings.selection.year || e.selectedYear === e.dateMin.getUTCFullYear(),
            i = !e.settings.selection.year || e.selectedYear === e.dateMax.getUTCFullYear();
          n && s || !e.settings.selection.month ? t.style.visibility = 'hidden' : t.style.visibility = '', a && i || !e.settings.selection.month ? l.style.visibility = 'hidden' : l.style.visibility = '';
        })(), n();
      }
    },
    n = (e, t) => {
      if (e.popups) {
        for (const l in e.popups) {
          if (Object.hasOwnProperty.call(e.popups, l)) {
            const n = t.querySelector(`[data-calendar-day="${l}"]`);
            if (n) {
              const t = e.popups[l];
              n.classList.add(t.modifier), n.parentNode.innerHTML += `<div class="vanilla-calendar-day__popup">${t.html}</div>`;
            }
          }
        }
      }
    },
    a = e => {
      if (!e) return null;
      const t = new Date(e).getUTCDate(),
        l = new Date(e).getUTCMonth(),
        n = new Date(e).getUTCFullYear(),
        a = new Date(n, l, t),
        s = new Date(Date.UTC(a.getUTCFullYear(), 0, 1)),
        i = Math.ceil(((+a - +s) / 864e5 + 1) / 7);
      return {
        year: a.getUTCFullYear(),
        week: i
      };
    },
    s = (e, t, l) => {
      if (!e.settings.visibility.weekNumbers) return;
      const n = e.HTMLElement.querySelector('.vanilla-calendar-week-numbers'),
        s = e.HTMLElement.querySelectorAll('.vanilla-calendar-day__btn');
      if (n instanceof HTMLElement) {
        const e = Math.ceil((t + l) / 7),
          i = document.createElement('span');
        i.className = 'vanilla-calendar-week-number', n.innerHTML = '';
        for (let t = 0; t < e; t++) {
          const e = a(s[7 * t].dataset.calendarDay);
          if (!e) return;
          const l = i.cloneNode(!0);
          l instanceof HTMLElement && (l.innerText = `${e.week}`, l.dataset.calendarYearWeek = `${e.year}`, n.append(l));
        }
      }
    },
    i = e => {
      const t = e.getUTCFullYear();
      let l = e.getUTCMonth() + 1,
        n = e.getUTCDate();
      return l = l < 10 ? `0${l}` : l, n = n < 10 ? `0${n}` : n, `${t}-${l}-${n}`;
    },
    d = e => {
      if (void 0 === e.selectedMonth || void 0 === e.selectedYear) return;
      const t = new Date(Date.UTC(e.selectedYear, e.selectedMonth, 1)),
        l = new Date(Date.UTC(e.selectedYear, e.selectedMonth + 1, 0)).getUTCDate();
      let a = Number(t.getUTCDay());
      e.settings.iso8601 && (a = Number((0 !== t.getUTCDay() ? t.getUTCDay() : 7) - 1));
      const d = e.HTMLElement.querySelector('.vanilla-calendar-days');
      if (!d) return;
      const c = document.createElement('div'),
        r = document.createElement('button');
      c.className = 'vanilla-calendar-day', r.className = 'vanilla-calendar-day__btn', r.type = 'button', ['single', 'multiple', 'multiple-ranged'].includes(e.settings.selection.day) && d.classList.add('vanilla-calendar-days_selecting'), d.innerHTML = '';
      const o = (t, l, n, a, s) => {
        const i = c.cloneNode(!0),
          o = r.cloneNode(!0);
        i instanceof HTMLElement && o instanceof HTMLElement && (s && o.classList.add(s), o.innerText = t, o.dataset.calendarDay = n, ((t, l, n, a) => {
          !e.settings.visibility.weekend || 0 !== l && 6 !== l || t.classList.add('vanilla-calendar-day__btn_weekend'), Array.isArray(e.settings.selected.holidays) && e.settings.selected.holidays.forEach((e => {
            e === n && t.classList.add('vanilla-calendar-day__btn_holiday');
          }));
          let s = e.date.today.getDate(),
            i = e.date.today.getMonth() + 1;
          s = s < 10 ? `0${s}` : s, i = i < 10 ? `0${i}` : i;
          const d = `${e.date.today.getFullYear()}-${i}-${s}`;
          e.settings.visibility.today && t.dataset.calendarDay === d && t.classList.add('vanilla-calendar-day__btn_today'), e.selectedDates && 0 === e.selectedDates.indexOf(n) || e.selectedDates && e.selectedDates[0] && e.selectedDates.indexOf(n) === e.selectedDates.length - 1 ? t.classList.add('vanilla-calendar-day__btn_selected') : e.selectedDates && e.selectedDates.indexOf(n) > 0 && 'multiple-ranged' === e.settings.selection.day ? (t.classList.add('vanilla-calendar-day__btn_selected'), t.classList.add('vanilla-calendar-day__btn_intermediate')) : e.selectedDates && e.selectedDates.indexOf(n) > 0 && t.classList.add('vanilla-calendar-day__btn_selected'), (e.settings.range.min > n || e.settings.range.max < n) && (t.classList.add('vanilla-calendar-day__btn_disabled'), t.tabIndex = -1), e.settings.selection.month || a || (t.classList.add('vanilla-calendar-day__btn_disabled'), t.tabIndex = -1), e.settings.selection.year || new Date(n).getFullYear() === e.selectedYear || (t.classList.add('vanilla-calendar-day__btn_disabled'), t.tabIndex = -1), Array.isArray(e.settings.range.disabled) ? e.settings.range.disabled.forEach((e => {
            e === n && (t.classList.add('vanilla-calendar-day__btn_disabled'), t.tabIndex = -1);
          })) : Array.isArray(e.settings.range.enabled) && (t.classList.add('vanilla-calendar-day__btn_disabled'), t.tabIndex = -1, e.settings.range.enabled.forEach((e => {
            e === n && (t.classList.remove('vanilla-calendar-day__btn_disabled'), t.tabIndex = 0);
          })));
        })(o, l, n, a), i.append(o), d.append(i));
      };
      (() => {
        if (void 0 === e.selectedMonth || void 0 === e.selectedYear) return;
        let t = new Date(Date.UTC(e.selectedYear, e.selectedMonth, 0)).getUTCDate() - a,
          l = e.selectedYear,
          n = e.selectedMonth;
        0 === e.selectedMonth ? (n = e.locale.months.length, l = e.selectedYear - 1) : e.selectedMonth < 10 && (n = `0${e.selectedMonth}`);
        for (let s = 0; s < a; s++) {
          t += 1;
          const a = `${l}-${n}-${t}`,
            s = new Date(Date.UTC(e.selectedYear, e.selectedMonth, t - 1)).getUTCMonth() - 1,
            i = new Date(Date.UTC(e.selectedYear, s, t)).getUTCDay();
          o(String(t), i, a, !1, 'vanilla-calendar-day__btn_prev');
        }
      })(), (() => {
        if (void 0 !== e.selectedMonth && void 0 !== e.selectedYear) {
          for (let t = 1; t <= l; t++) {
            const l = new Date(Date.UTC(e.selectedYear, e.selectedMonth, t)),
              n = i(l),
              a = l.getUTCDay();
            o(String(t), a, n, !0, null);
          }
        }
      })(), (() => {
        if (void 0 === e.selectedMonth || void 0 === e.selectedYear) return;
        const t = a + l,
          n = Math.ceil(t / e.locale.weekday.length),
          s = e.locale.weekday.length * n - t;
        let i = e.selectedYear,
          d = String(e.selectedMonth + 2);
        e.selectedMonth + 1 === e.locale.months.length ? (d = '01', i = e.selectedYear + 1) : e.selectedMonth + 2 < 10 && (d = `0${e.selectedMonth + 2}`);
        for (let t = 1; t <= s; t++) {
          const l = `${i}-${d}-${t < 10 ? `0${t}` : String(t)}`,
            n = new Date(Date.UTC(e.selectedYear, e.selectedMonth, t)).getUTCMonth() + 1,
            a = new Date(Date.UTC(e.selectedYear, n, t)).getUTCDay();
          o(String(t), a, l, !1, 'vanilla-calendar-day__btn_next');
        }
      })(), n(e, d), s(e, a, l);
    },
    c = e => {
      const t = e.HTMLElement;
      'default' === e.currentType ? (t.classList.add('vanilla-calendar_default'), t.classList.remove('vanilla-calendar_month'), t.classList.remove('vanilla-calendar_year'), t.innerHTML = `\n\t\t<div class="vanilla-calendar-header">\n\t\t\t<button type="button"\n\t\t\t\tclass="vanilla-calendar-arrow vanilla-calendar-arrow_prev"\n\t\t\t\tdata-calendar-arrow="prev"\n\t\t\t\ttitle="Prev">\n\t\t\t</button>\n\t\t\t<div class="vanilla-calendar-header__content"></div>\n\t\t\t<button type="button"\n\t\t\t\tclass="vanilla-calendar-arrow vanilla-calendar-arrow_next"\n\t\t\t\tdata-calendar-arrow="next"\n\t\t\t\ttitle="Next">\n\t\t\t</button>\n\t\t</div>\n\t\t${e.settings.visibility.weekNumbers ? '\n\t\t<div class="vanilla-calendar-column">\n\t\t\t<b class="vanilla-calendar-column__title">#</b>\n\t\t\t<div class="vanilla-calendar-column__content vanilla-calendar-week-numbers"></div>\n\t\t</div>\n\t\t' : ''}\n\t\t<div class="vanilla-calendar-content">\n\t\t\t<div class="vanilla-calendar-week"></div>\n\t\t\t<div class="vanilla-calendar-days"></div>\n\t\t</div>\n\t\t${e.settings.selection.time ? '\n\t\t<div class="vanilla-calendar-time"></div>\n\t\t' : ''}\n\t`) : 'month' === e.currentType ? (t.classList.remove('vanilla-calendar_default'), t.classList.add('vanilla-calendar_month'), t.classList.remove('vanilla-calendar_year'), t.innerHTML = '\n\t\t<div class="vanilla-calendar-header">\n\t\t\t<div class="vanilla-calendar-header__content"></div>\n\t\t</div>\n\t\t<div class="vanilla-calendar-content">\n\t\t\t<div class="vanilla-calendar-months"></div>\n\t\t</div>') : 'year' === e.currentType && (t.classList.remove('vanilla-calendar_default'), t.classList.remove('vanilla-calendar_month'), t.classList.add('vanilla-calendar_year'), t.innerHTML = '\n\t\t<div class="vanilla-calendar-header">\n\t\t\t<button type="button"\n\t\t\t\tclass="vanilla-calendar-arrow vanilla-calendar-arrow_prev"\n\t\t\t\ttitle="prev">\n\t\t\t</button>\n\t\t\t<div class="vanilla-calendar-header__content"></div>\n\t\t\t<button type="button"\n\t\t\t\tclass="vanilla-calendar-arrow vanilla-calendar-arrow_next"\n\t\t\t\ttitle="next">\n\t\t\t</button>\n\t\t</div>\n\t\t<div class="vanilla-calendar-content">\n\t\t\t<div class="vanilla-calendar-years"></div>\n\t\t</div>');
    },
    r = e => {
      const t = e.HTMLElement.querySelector('.vanilla-calendar-header__content');
      if (void 0 === e.selectedMonth || void 0 === e.selectedYear || !t) return;
      const l = e.settings.selection.month ? '' : ' vanilla-calendar-month_disabled',
        n = e.settings.selection.year ? '' : ' vanilla-calendar-year_disabled',
        a = `\n\t<button type="button"\n\t\ttabindex="${e.settings.selection.month ? 0 : -1}"\n\t\tclass="vanilla-calendar-month${l}"\n\t\tdata-calendar-selected-month="${e.selectedMonth}">\n\t\t${e.locale.months[e.selectedMonth]}\n\t</button>`.replace(/[\n\t]/g, ''),
        s = `\n\t<button type="button"\n\t\ttabindex="${e.settings.selection.year ? 0 : -1}"\n\t\tclass="vanilla-calendar-year${n}"\n\t\tdata-calendar-selected-year="${e.selectedYear}">\n\t\t${e.selectedYear}\n\t</button>`.replace(/[\n\t]/g, '');
      let i = e.settings.visibility.templateHeader.replace('%M', a);
      i = i.replace('%Y', s), t.innerHTML = i;
    },
    o = e => {
      e.currentType = 'month', c(e), r(e);
      const t = e.HTMLElement.querySelector('.vanilla-calendar-months');
      if (void 0 === e.selectedMonth || void 0 === e.selectedYear || !e.dateMin || !e.dateMax || !t) return;
      e.settings.selection.month && t.classList.add('vanilla-calendar-months_selecting');
      const l = document.createElement('button');
      l.type = 'button', l.className = 'vanilla-calendar-months__month';
      for (let n = 0; n < e.locale.months.length; n++) {
        const a = e.locale.months[n],
          s = l.cloneNode(!0);
        s instanceof HTMLElement && (n === e.selectedMonth && s.classList.add('vanilla-calendar-months__month_selected'), n < e.dateMin.getUTCMonth() && e.selectedYear === e.dateMin.getUTCFullYear() && (s.classList.add('vanilla-calendar-months__month_disabled'), s.tabIndex = -1), n > e.dateMax.getUTCMonth() && e.selectedYear === e.dateMax.getUTCFullYear() && (s.classList.add('vanilla-calendar-months__month_disabled'), s.tabIndex = -1), s.dataset.calendarMonth = String(n), s.title = `${a}`, s.innerText = `${e.settings.visibility.monthShort ? a.substring(0, 3) : a}`, t.append(s));
      }
    },
    u = e => {
      const t = Number(e);
      let l = String(t);
      return 0 === t ? l = '12' : 13 === t ? l = '01' : 14 === t ? l = '02' : 15 === t ? l = '03' : 16 === t ? l = '04' : 17 === t ? l = '05' : 18 === t ? l = '06' : 19 === t ? l = '07' : 20 === t ? l = '08' : 21 === t ? l = '09' : 22 === t ? l = '10' : 23 === t && (l = '11'), l;
    },
    v = (e, t) => {
      const l = Number(e);
      let n = String(l);
      return 'AM' === t ? 12 === l && (n = '00') : 'PM' === t && (1 === l ? n = '13' : 2 === l ? n = '14' : 3 === l ? n = '15' : 4 === l ? n = '16' : 5 === l ? n = '17' : 6 === l ? n = '18' : 7 === l ? n = '19' : 8 === l ? n = '20' : 9 === l ? n = '21' : 10 === l ? n = '22' : 11 === l && (n = '23')), n;
    },
    g = (e, t) => {
      const l = e.HTMLElement.querySelector('.vanilla-calendar-time__range input[name="hours"]'),
        n = e.HTMLElement.querySelector('.vanilla-calendar-time__range input[name="minutes"]'),
        a = e.HTMLElement.querySelector('.vanilla-calendar-time__hours input[name="hours"]'),
        s = e.HTMLElement.querySelector('.vanilla-calendar-time__minutes input[name="minutes"]'),
        i = e.HTMLElement.querySelector('.vanilla-calendar-time__keeping'),
        d = (e, t) => {
          e.addEventListener('mouseover', (() => t.classList.add('is-focus')));
        },
        c = (e, t) => {
          e.addEventListener('mouseout', (() => t.classList.remove('is-focus')));
        },
        r = (t, l, n) => {
          'hours' === n ? e.selectedHours = `${l}` : 'minutes' === n && (e.selectedMinutes = `${l}`), e.selectedTime = `${e.selectedHours}:${e.selectedMinutes}${e.selectedKeeping ? ` ${e.selectedKeeping}` : ''}`, e.settings.selected.time = e.selectedTime, e.actions.changeTime && e.actions.changeTime(t, e.selectedTime, e.selectedHours, e.selectedMinutes, e.selectedKeeping);
        },
        o = (t, l, n, a) => {
          t.addEventListener('input', (t => {
            let s = Number(t.target.value);
            s = s < 10 ? `0${s}` : `${s}`, 'hours' === n && 12 === a ? Number(t.target.value) < a && Number(t.target.value) > 0 ? (l.value = s, e.selectedKeeping = 'AM', i.innerText = e.selectedKeeping, r(t, s, n)) : (0 === Number(t.target.value) ? (e.selectedKeeping = 'AM', i.innerText = 'AM') : (e.selectedKeeping = 'PM', i.innerText = 'PM'), l.value = u(t.target.value), r(t, u(t.target.value), n)) : (l.value = s, r(t, s, n));
          }));
        },
        g = (t, l, n, a) => {
          l.addEventListener('change', (l => {
            const s = l.target;
            let d = Number(s.value);
            d = d < 10 ? `0${d}` : `${d}`, 'hours' === n && 12 === a ? s.value && Number(s.value) <= a && Number(s.value) > 0 ? (s.value = d, t.value = v(d, e.selectedKeeping), r(l, d, n)) : s.value && Number(s.value) < 24 && (Number(s.value) > a || 0 === Number(s.value)) ? (0 === Number(s.value) ? (e.selectedKeeping = 'AM', i.innerText = 'AM') : (e.selectedKeeping = 'PM', i.innerText = 'PM'), s.value = u(s.value), t.value = d, r(l, u(s.value), n)) : s.value = e.selectedHours : s.value && Number(s.value) <= a && Number(s.value) >= 0 ? (s.value = d, t.value = d, r(l, d, n)) : 'hours' === n ? s.value = e.selectedHours : 'minutes' === n && (s.value = e.selectedMinutes);
          }));
        };
      d(l, a), d(n, s), c(l, a), c(n, s), o(l, a, 'hours', 24 === t ? 23 : 12), o(n, s, 'minutes', 0), g(l, a, 'hours', 24 === t ? 23 : 12), g(n, s, 'minutes', 59), i && i.addEventListener('click', (t => {
        i.innerText.includes('AM') ? e.selectedKeeping = 'PM' : e.selectedKeeping = 'AM', l.value = v(e.selectedHours, e.selectedKeeping), r(t, e.selectedHours, 'hours'), i.innerText = e.selectedKeeping;
      }));
    },
    m = e => {
      const t = e.HTMLElement.querySelector('.vanilla-calendar-time');
      if (!t) return;
      const l = !0 === e.settings.selection.time ? 12 : e.settings.selection.time,
        n = 'range' === e.settings.selection.controlTime;
      t.innerHTML = `\n\t<div class="vanilla-calendar-time__content">\n\t\t<label class="vanilla-calendar-time__hours">\n\t\t\t<input type="text"\n\t\t\t\tname="hours"\n\t\t\t\tmaxlength="2"\n\t\t\t\tvalue="${e.selectedHours}"\n\t\t\t\t${n ? 'disabled' : ''}>\n\t\t</label>\n\t\t<label class="vanilla-calendar-time__minutes">\n\t\t\t<input type="text"\n\t\t\t\tname="minutes"\n\t\t\t\tmaxlength="2"\n\t\t\t\tvalue="${e.selectedMinutes}"\n\t\t\t\t${n ? 'disabled' : ''}>\n\t\t</label>\n\t\t${12 === l ? `\n\t\t<button type="button"\n\t\t\tclass="vanilla-calendar-time__keeping"\n\t\t\t${n ? 'disabled' : ''}>${e.selectedKeeping}</button>\n\t\t` : ''}\n\t</div>\n\t<div class="vanilla-calendar-time__ranges">\n\t\t<label class="vanilla-calendar-time__range">\n\t\t\t<input type="range"\n\t\t\t\tname="hours"\n\t\t\t\tmin="0"\n\t\t\t\tmax="23"\n\t\t\t\tstep="${e.settings.selection.stepHours}"\n\t\t\t\tvalue="${e.selectedKeeping ? v(e.selectedHours, e.selectedKeeping) : e.selectedHours}">\n\t\t</label>\n\t\t<label class="vanilla-calendar-time__range">\n\t\t\t<input type="range"\n\t\t\t\tname="minutes"\n\t\t\t\tmin="0"\n\t\t\t\tmax="59"\n\t\t\t\tstep="${e.settings.selection.stepMinutes}"\n\t\t\t\tvalue="${e.selectedMinutes}">\n\t\t</label>\n\t</div>`, g(e, l);
    },
    y = e => {
      const t = [...e.locale.weekday];
      if (!t[0]) return;
      const l = e.HTMLElement.querySelector('.vanilla-calendar-week'),
        n = document.createElement('b');
      if (n.className = 'vanilla-calendar-week__day', e.settings.iso8601 && t.push(t.shift()), l instanceof HTMLElement) {
        l.innerHTML = '';
        for (let a = 0; a < t.length; a++) {
          const s = t[a],
            i = n.cloneNode(!0);
          i instanceof HTMLElement && (e.settings.visibility.weekend && e.settings.iso8601 ? 5 !== a && 6 !== a || i.classList.add('vanilla-calendar-week__day_weekend') : e.settings.visibility.weekend && !e.settings.iso8601 && (0 !== a && 6 !== a || i.classList.add('vanilla-calendar-week__day_weekend')), i.innerText = `${s}`, l.append(i));
        }
      }
    },
    h = e => {
      if (void 0 === e.viewYear || !e.dateMin || !e.dateMax) return;
      e.currentType = 'year', c(e), r(e), l(e);
      const t = e.HTMLElement.querySelector('.vanilla-calendar-years');
      if (!t) return;
      e.settings.selection.year && t.classList.add('vanilla-calendar-years_selecting');
      const n = document.createElement('button');
      n.type = 'button', n.className = 'vanilla-calendar-years__year';
      for (let l = e.viewYear - 7; l < e.viewYear + 8; l++) {
        const a = l,
          s = n.cloneNode(!0);
        s instanceof HTMLElement && (a === e.selectedYear && s.classList.add('vanilla-calendar-years__year_selected'), a < e.dateMin.getUTCFullYear() && (s.classList.add('vanilla-calendar-years__year_disabled'), s.tabIndex = -1), a > e.dateMax.getUTCFullYear() && (s.classList.add('vanilla-calendar-years__year_disabled'), s.tabIndex = -1), s.dataset.calendarYear = String(a), s.innerText = `${a}`, t.append(s));
      }
    },
    p = e => {
      if ('define' !== e.settings.lang) {
        e.locale.weekday = [];
        for (let t = 0; t < 7; t++) {
          let l = new Date(0, 0, t).toLocaleString(e.settings.lang, { weekday: 'short' });
          l = `${l.charAt(0)
            .toUpperCase()}${l.substring(1, l.length)}`, l = l.replace(/\./, ''), e.locale.weekday.push(l);
        }
        e.locale.months = [];
        for (let t = 0; t < 12; t++) {
          let l = new Date(0, t).toLocaleString(e.settings.lang, { month: 'long' });
          l = `${l.charAt(0)
            .toUpperCase()}${l.substring(1, l.length)}`, l = l.replace(/\./, ''), e.locale.months.push(l);
        }
      }
    },
    M = e => {
      null !== e.settings.selected.dates ? e.selectedDates = e.settings.selected.dates : e.selectedDates = [], null !== e.settings.selected.month && e.settings.selected.month >= 0 && e.settings.selected.month < 12 ? e.selectedMonth = e.settings.selected.month : e.selectedMonth = e.date.today.getMonth(), null !== e.settings.selected.year && e.settings.selected.year >= 0 && e.settings.selected.year <= 9999 ? e.selectedYear = e.settings.selected.year : e.selectedYear = e.date.today.getFullYear(), e.viewYear = e.selectedYear, e.dateMin = e.settings.visibility.disabled ? new Date(e.date.min) : new Date(e.settings.range.min), e.dateMax = e.settings.visibility.disabled ? new Date(e.date.max) : new Date(e.settings.range.max);
      const t = !0 === e.settings.selection.time || 12 === e.settings.selection.time;
      if (t || 24 === e.settings.selection.time) {
        if ('string' == typeof e.settings.selected.time) {
          const l = t ? /^([0-9]|0[1-9]|1[0-2]):([0-5][0-9])|(AM|PM)/g : /^([0-1]?[0-9]|2[0-3]):([0-5][0-9])/g;
          e.settings.selected.time.replace(l, ((l, n, a, s) => (n && a && (e.userTime = !0, e.selectedHours = n, e.selectedMinutes = a), s && t ? e.selectedKeeping = s : t && (e.selectedKeeping = 'AM'), '')));
        }
        !e.userTime && t ? (e.selectedHours = u(String(e.date.today.getHours())), e.selectedMinutes = String(e.date.today.getMinutes()), e.selectedKeeping = Number(e.date.today.getHours()) > 12 ? 'PM' : 'AM') : e.userTime || (e.selectedHours = String(e.date.today.getHours()), e.selectedMinutes = String(e.date.today.getMinutes())), e.selectedHours = Number(e.selectedHours) < 10 ? `0${Number(e.selectedHours)}` : `${e.selectedHours}`, e.selectedMinutes = Number(e.selectedMinutes) < 10 ? `0${Number(e.selectedMinutes)}` : `${e.selectedMinutes}`, e.selectedTime = `${e.selectedHours}:${e.selectedMinutes}${e.selectedKeeping ? ` ${e.selectedKeeping}` : ''}`;
      } else {
        e.settings.selection.time && (e.settings.selection.time = !1, console.error('The value of the time property can be: false, true, 12 or 24.'));
      }
    },
    b = e => {
      M(e), p(e), c(e), r(e), l(e), m(e), 'default' === e.currentType ? (y(e), d(e)) : 'month' === e.currentType ? o(e) : 'year' === e.currentType && h(e);
    },
    _ = (e, t) => {
      if (void 0 === e.selectedMonth || void 0 === e.selectedYear) return;
      const n = e.locale.months.length - 1;
      switch (t) {
        case'prev':
          0 !== e.selectedMonth ? e.selectedMonth -= 1 : e.settings.selection.year && (e.selectedYear -= 1, e.selectedMonth = n);
          break;
        case'next':
          e.selectedMonth !== n ? e.selectedMonth += 1 : e.settings.selection.year && (e.selectedYear += 1, e.selectedMonth = 0);
      }
      e.settings.selected.month = e.selectedMonth, e.settings.selected.year = e.selectedYear, r(e), l(e), d(e);
    },
    T = e => {
      e.HTMLElement.addEventListener('click', (t => {
        const l = t.target,
          n = l.closest('.vanilla-calendar-arrow'),
          a = l.closest('.vanilla-calendar-arrow_prev'),
          s = l.closest('.vanilla-calendar-arrow_next'),
          c = l.closest('.vanilla-calendar-day__btn'),
          r = l.closest('.vanilla-calendar-day__btn_prev'),
          u = l.closest('.vanilla-calendar-day__btn_next'),
          v = l.closest('.vanilla-calendar-year'),
          g = l.closest('.vanilla-calendar-years__year'),
          m = l.closest('.vanilla-calendar-month'),
          y = l.closest('.vanilla-calendar-months__month');
        n && 'year' !== e.currentType && 'month' !== e.currentType && _(e, l.dataset.calendarArrow), (() => {
          if (['single', 'multiple', 'multiple-ranged'].includes(e.settings.selection.day) && c) {
            switch (e.settings.selection.day) {
              case'single':
                e.selectedDates && c && c.dataset.calendarDay && (c.classList.contains('vanilla-calendar-day__btn_selected') ? e.selectedDates.splice(e.selectedDates.indexOf(c.dataset.calendarDay), 1) : (e.selectedDates = [], e.selectedDates.push(c.dataset.calendarDay)));
                break;
              case'multiple':
                e.selectedDates && c && c.dataset.calendarDay && (c.classList.contains('vanilla-calendar-day__btn_selected') ? e.selectedDates.splice(e.selectedDates.indexOf(c.dataset.calendarDay), 1) : e.selectedDates.push(c.dataset.calendarDay));
                break;
              case'multiple-ranged':
                (() => {
                  if (!e.selectedDates || !c || !c.dataset.calendarDay) return;
                  if (e.selectedDates.length > 1 && (e.selectedDates = []), e.selectedDates.push(c.dataset.calendarDay), !e.selectedDates[1]) return;
                  const t = new Date(Date.UTC(new Date(e.selectedDates[0]).getUTCFullYear(), new Date(e.selectedDates[0]).getUTCMonth(), new Date(e.selectedDates[0]).getUTCDate())),
                    l = new Date(Date.UTC(new Date(e.selectedDates[1]).getUTCFullYear(), new Date(e.selectedDates[1]).getUTCMonth(), new Date(e.selectedDates[1]).getUTCDate())),
                    n = t => {
                      if (!e.selectedDates) return;
                      const l = i(t);
                      e.settings.range.disabled && e.settings.range.disabled.includes(l) || e.selectedDates.push(l);
                    };
                  if (e.selectedDates = [], l > t) for (let e = t; e <= l; e.setUTCDate(e.getUTCDate() + 1)) n(e); else for (let e = t; e >= l; e.setUTCDate(e.getUTCDate() - 1)) n(e);
                })();
            }
            e.actions.clickDay && e.actions.clickDay(t, e.selectedDates), e.settings.selected.dates = e.selectedDates, r ? _(e, 'prev') : u ? _(e, 'next') : d(e);
          }
        })(), (() => {
          if (e.settings.selection.year) {
            if (n && 'year' === e.currentType) {
              if (void 0 === e.viewYear) return;
              s ? e.viewYear += 15 : a && (e.viewYear -= 15), h(e);
            } else if ('year' !== e.currentType && v) {
              h(e);
            } else if ('year' === e.currentType && v) {
              e.currentType = e.type, b(e);
            } else if (g) {
              if (void 0 === e.selectedMonth || !e.dateMin || !e.dateMax) return;
              e.selectedYear = Number(g.dataset.calendarYear), e.currentType = e.type, e.selectedMonth < e.dateMin.getUTCMonth() && e.selectedYear === e.dateMin.getUTCFullYear() && (e.settings.selected.month = e.dateMin.getUTCMonth()), e.selectedMonth > e.dateMax.getUTCMonth() && e.selectedYear === e.dateMax.getUTCFullYear() && (e.settings.selected.month = e.dateMax.getUTCMonth()), e.actions.clickYear && e.actions.clickYear(t, e.selectedYear), e.settings.selected.year = e.selectedYear, b(e);
            }
          }
        })(), e.settings.selection.month && ('month' !== e.currentType && m ? o(e) : 'month' === e.currentType && m ? (e.currentType = e.type, b(e)) : y && (e.selectedMonth = Number(y.dataset.calendarMonth), e.currentType = e.type, e.actions.clickMonth && e.actions.clickMonth(t, e.selectedMonth), e.settings.selected.month = e.selectedMonth, b(e)));
      }));
    },
    D = e => {
      e.HTMLElement && (b(e), T(e));
    };

  class f {
    constructor(e, t) {
      var l,
        n,
        a,
        s,
        i,
        d,
        c,
        r,
        o,
        u,
        v,
        g,
        m,
        y,
        h,
        p,
        M,
        b,
        _,
        T,
        f,
        w,
        L,
        Y,
        x,
        $,
        H,
        C,
        U,
        k,
        E,
        N,
        S,
        K,
        A,
        F,
        q,
        P,
        O,
        I,
        j,
        V,
        W,
        z,
        B,
        G,
        J,
        Q,
        R,
        X,
        Z,
        ee,
        te,
        le,
        ne,
        ae,
        se,
        ie,
        de,
        ce,
        re,
        oe,
        ue,
        ve,
        ge,
        me,
        ye,
        he,
        pe,
        Me,
        be,
        _e,
        Te,
        De,
        fe,
        we,
        Le,
        Ye,
        xe,
        $e,
        He,
        Ce,
        Ue,
        ke,
        Ee,
        Ne,
        Se,
        Ke,
        Ae,
        Fe;
      this.init = () => D(this), this.HTMLElement = 'string' == typeof e ? document.querySelector(e) : e, this.HTMLElement && (this.type = null != (l = null == t ? void 0 : t.type) ? l : 'default', this.date = {
        min: null != (a = null == (n = null == t ? void 0 : t.date) ? void 0 : n.min) ? a : '1970-01-01',
        max: null != (i = null == (s = null == t ? void 0 : t.date) ? void 0 : s.max) ? i : '2470-12-31',
        today: null != (c = null == (d = null == t ? void 0 : t.date) ? void 0 : d.today) ? c : new Date
      }, this.settings = {
        lang: null != (o = null == (r = null == t ? void 0 : t.settings) ? void 0 : r.lang) ? o : 'en',
        iso8601: null == (v = null == (u = null == t ? void 0 : t.settings) ? void 0 : u.iso8601) || v,
        range: {
          min: null != (y = null == (m = null == (g = null == t ? void 0 : t.settings) ? void 0 : g.range) ? void 0 : m.min) ? y : this.date.min,
          max: null != (M = null == (p = null == (h = null == t ? void 0 : t.settings) ? void 0 : h.range) ? void 0 : p.max) ? M : this.date.max,
          disabled: null != (T = null == (_ = null == (b = null == t ? void 0 : t.settings) ? void 0 : b.range) ? void 0 : _.disabled) ? T : null,
          enabled: null != (L = null == (w = null == (f = null == t ? void 0 : t.settings) ? void 0 : f.range) ? void 0 : w.enabled) ? L : null
        },
        selection: {
          day: null != ($ = null == (x = null == (Y = null == t ? void 0 : t.settings) ? void 0 : Y.selection) ? void 0 : x.day) ? $ : 'single',
          month: null == (U = null == (C = null == (H = null == t ? void 0 : t.settings) ? void 0 : H.selection) ? void 0 : C.month) || U,
          year: null == (N = null == (E = null == (k = null == t ? void 0 : t.settings) ? void 0 : k.selection) ? void 0 : E.year) || N,
          time: null != (A = null == (K = null == (S = null == t ? void 0 : t.settings) ? void 0 : S.selection) ? void 0 : K.time) && A,
          controlTime: null != (P = null == (q = null == (F = null == t ? void 0 : t.settings) ? void 0 : F.selection) ? void 0 : q.controlTime) ? P : 'all',
          stepHours: null != (j = null == (I = null == (O = null == t ? void 0 : t.settings) ? void 0 : O.selection) ? void 0 : I.stepHours) ? j : 1,
          stepMinutes: null != (z = null == (W = null == (V = null == t ? void 0 : t.settings) ? void 0 : V.selection) ? void 0 : W.stepMinutes) ? z : 1
        },
        selected: {
          dates: null != (J = null == (G = null == (B = null == t ? void 0 : t.settings) ? void 0 : B.selected) ? void 0 : G.dates) ? J : null,
          month: null != (X = null == (R = null == (Q = null == t ? void 0 : t.settings) ? void 0 : Q.selected) ? void 0 : R.month) ? X : null,
          year: null != (te = null == (ee = null == (Z = null == t ? void 0 : t.settings) ? void 0 : Z.selected) ? void 0 : ee.year) ? te : null,
          holidays: null != (ae = null == (ne = null == (le = null == t ? void 0 : t.settings) ? void 0 : le.selected) ? void 0 : ne.holidays) ? ae : null,
          time: null != (de = null == (ie = null == (se = null == t ? void 0 : t.settings) ? void 0 : se.selected) ? void 0 : ie.time) ? de : null
        },
        visibility: {
          templateHeader: null != (oe = null == (re = null == (ce = null == t ? void 0 : t.settings) ? void 0 : ce.visibility) ? void 0 : re.templateHeader) ? oe : '%M %Y',
          monthShort: null == (ge = null == (ve = null == (ue = null == t ? void 0 : t.settings) ? void 0 : ue.visibility) ? void 0 : ve.monthShort) || ge,
          weekNumbers: null != (he = null == (ye = null == (me = null == t ? void 0 : t.settings) ? void 0 : me.visibility) ? void 0 : ye.weekNumbers) && he,
          weekend: null == (be = null == (Me = null == (pe = null == t ? void 0 : t.settings) ? void 0 : pe.visibility) ? void 0 : Me.weekend) || be,
          today: null == (De = null == (Te = null == (_e = null == t ? void 0 : t.settings) ? void 0 : _e.visibility) ? void 0 : Te.today) || De,
          disabled: null != (Le = null == (we = null == (fe = null == t ? void 0 : t.settings) ? void 0 : fe.visibility) ? void 0 : we.disabled) && Le
        }
      }, this.locale = {
        months: null != (xe = null == (Ye = null == t ? void 0 : t.locale) ? void 0 : Ye.months) ? xe : [],
        weekday: null != (He = null == ($e = null == t ? void 0 : t.locale) ? void 0 : $e.weekday) ? He : []
      }, this.actions = {
        clickDay: null != (Ue = null == (Ce = null == t ? void 0 : t.actions) ? void 0 : Ce.clickDay) ? Ue : null,
        clickMonth: null != (Ee = null == (ke = null == t ? void 0 : t.actions) ? void 0 : ke.clickMonth) ? Ee : null,
        clickYear: null != (Se = null == (Ne = null == t ? void 0 : t.actions) ? void 0 : Ne.clickYear) ? Se : null,
        changeTime: null != (Ae = null == (Ke = null == t ? void 0 : t.actions) ? void 0 : Ke.changeTime) ? Ae : null
      }, this.popups = null != (Fe = null == t ? void 0 : t.popups) ? Fe : null, this.currentType = this.type, this.selectedKeeping = null, this.userTime = !1)
    }
  }

  window.VanillaCalendar = f;
  const w = f;
  return t
})()));
