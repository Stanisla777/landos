<script>
import Vue from 'vue';
import Vuex from 'vuex';
Vue.use(Vuex);

export default new Vuex.Store({
  state:{
    amount_tax_deduction_for_show:0,
    amount_tax_deduction:0,
    amount_tax_deduction_for_show_married:0,
    amount_tax_deduction_married:0,

    can_return_for_show:0,
    can_return:0,
    can_return_for_show_married:0,
    can_return_married:0,

    salary_amount:0,
    salary_amount_for_deduction:0,
    salary_amount_married:0,
    salary_amount_for_deduction_married:0,

    remaining_amount_appartnent:0,
    remaining_amount_appartnent_married:0,

    real_price_apartment:0,
    real_price_without_calculation:0,
    apartment_price:0,


    max_pay:260000,
    max_pay_for_married:260000,
    max_pay_for_other_deductions:260000,

    other_deductions:0,
    other_deductions_for_married:0,

    other_deductions_not_apartment:0,
    other_deductions_not_apartment_for_married:0,
    other_deductions_for_married_apartment:0,

    subsidies:0,

    interest:0,
    interest_tax_deduction:0,
    interest_tax_deduction_for_show:0,
    max_pay_interest:390000,
    remaining_amount_interest:0,
    real_interest:0,

    interest_without_limitation:0,

    interest_married:0,
    interest_tax_deduction_married:0,
    interest_tax_deduction_for_show_married:0,
    max_pay_interest_married:390000,
    remaining_amount_interest_married:0,

    date:0,

    footnote:{
      condition:false,
      text:''
    },

    footnote_status:false





  },
  getters:{
    AMOUNT_TAX_DEDUCTION(state){
      return state.amount_tax_deduction_for_show
    },
    AMOUNT_TAX_DEDUCTION_MARRIED(state){
      return state.amount_tax_deduction_for_show_married
    },

    INTEREST_TAX_DEDUCTION(state){
      return state.interest_tax_deduction_for_show
    },
    INTEREST_TAX_DEDUCTION_MARRIED(state){
      return state.interest_tax_deduction_for_show_married
    },
    INTEREST_CAN_RETURN(state){
      return state.remaining_amount_interest
    },
    INTEREST_CAN_RETURN_MARRIED(state){
      return state.remaining_amount_interest_married
    },

    CAN_RETURN(state){
      return state.remaining_amount_appartnent
    },
    CAN_RETURN_MARRIED(state){
      return state.remaining_amount_appartnent_married
    },
    REAL_PRISE_APPARTMENT(state){
      return state.real_price_apartment
    },
    REAL_PRISE_APPARTMENT_WITHOUT_CALCULATION(state){
      return state.real_price_without_calculation
    },

    SALARY_AMOUNT(state){
      return state.salary_amount
    },
    SALARY_AMOUNT_MARRIED(state){
      return state.salary_amount_married
    },
    APARTMENT_PRICE(state){
      return state.apartment_price
    },
    INTEREST(state){
      return state.interest
    },

    DATE(state){
      return state.date
    },

    SUBSIDIES(state){
      return state.subsidies
    },
    OTHER_DEDUCTIONS(state){
      return state.other_deductions
    },
    OTHER_DEDUCTIONS_FOR_MARRIED(state){
      return state.other_deductions_for_married
    },

    FOOTNOTE(state){
      return state.footnote
    },
    FOOTNOTE_STATUS(state){
      return state.footnote_status
    },





  },
  mutations:{
    mutationRealPriceAppartment(state, received_perem){
      state.real_price_apartment = received_perem * 0.13;
    },
    mutationRealPriceAppartmentWithoutCalculation(state, received_perem){
      state.real_price_without_calculation = received_perem;

    },


    //Для неженатых
    mutationAmountTaxDeduction(state){

      if(state.salary_amount>=state.apartment_price){
        state.amount_tax_deduction_for_show = state.apartment_price.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        state.amount_tax_deduction = parseInt(state.apartment_price.toFixed(0));
        if (state.amount_tax_deduction>state.max_pay){
          state.amount_tax_deduction = state.max_pay
          state.amount_tax_deduction_for_show = state.max_pay.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        }
      }
      else if(state.salary_amount<state.apartment_price){
        state.amount_tax_deduction_for_show = state.salary_amount.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        state.amount_tax_deduction = parseInt(state.salary_amount.toFixed(0));
        if (state.amount_tax_deduction>state.max_pay){
          state.amount_tax_deduction = state.max_pay
          state.amount_tax_deduction_for_show = state.max_pay.toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        }
      }
      // console.log(state);
    },
    mutationSalary(state, received_perem) {
      state.salary_amount = (received_perem*12)*0.13
      state.salary_amount_for_deduction = (received_perem*12)*0.13
    },
    mutationApartmentPrice(state, received_perem) {
      state.apartment_price = received_perem * 0.13;
      if (state.apartment_price>260000){
        state.apartment_price=260000
      }


    },
    mutationCanReturnAfter(state){
      if(state.apartment_price>state.salary_amount){
        state.remaining_amount_appartnent = state.apartment_price-state.amount_tax_deduction
        if(state.apartment_price>state.max_pay){
          const max = state.max_pay
          state.remaining_amount_appartnent = max-state.salary_amount
          if(state.remaining_amount_appartnent<0){
            state.remaining_amount_appartnent=0
          }
        }
        if(state.amount_tax_deduction>state.max_pay){
          state.remaining_amount_appartnent = 0
        }
      }
      else if(state.apartment_price<state.salary_amount){
        state.remaining_amount_appartnent = 0
      }
      else if(state.apartment_price==state.salary_amount){
        state.remaining_amount_appartnent = 0
      }
    },
    //Иные вычеты по аппартаментам
    mutationOtherDeductions(state,received_perem){
      state.other_deductions=parseInt(received_perem)
      state.max_pay = state.max_pay_for_other_deductions - state.other_deductions
      if(state.max_pay<0){
        state.max_pay=0
      }

    },

    //Иные вычеты не квартира
    mutationOtherDeductionsNotApartment(state,received_perem){
      state.other_deductions_not_apartment=parseInt(received_perem)
      state.salary_amount = state.salary_amount_for_deduction - state.other_deductions_not_apartment
      if(state.salary_amount<0){
        state.salary_amount=0
      }

    },


    //Проценты
    mutationInterest(state,received_perem){
      state.real_interest = received_perem
      state.interest = received_perem * 0.13
    },
    mutationInterestTaxDeduction(state){
      if(state.salary_amount>=state.interest){
        state.interest_tax_deduction_for_show = state.interest.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        state.interest_tax_deduction = parseInt(state.interest.toFixed(0));
        if (state.interest_tax_deduction>state.max_pay_interest){
          state.interest_tax_deduction = state.max_pay_interest
          state.interest_tax_deduction_for_show = state.max_pay_interest.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        }
      }
      else if(state.salary_amount<state.interest){
        state.interest_tax_deduction_for_show = state.salary_amount.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        state.interest_tax_deduction = parseInt(state.salary_amount.toFixed(0));
        if (state.interest_tax_deduction>state.max_pay_interest){
          state.interest_tax_deduction = state.max_pay_interest
          state.interest_tax_deduction_for_show = state.max_pay_interest.toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        }
      }
      // console.log(state);
    },

    mutationCanReturnInterestAfter(state){
      if(state.interest>state.salary_amount){
        state.remaining_amount_interest = state.interest-state.salary_amount
        if(state.interest>state.max_pay_interest){
          const max = state.max_pay_interest
          state.remaining_amount_interest = max-state.salary_amount
          if(state.remaining_amount_interest<0){
            state.remaining_amount_interest=0
          }
        }
        if(state.interest_tax_deduction>state.max_pay_interest){
          state.remaining_amount_interest = 0
        }
      }
      else if(state.interest<state.salary_amount&&state.apartment_price>state.salary_amount){
        state.remaining_amount_interest = state.interest
      }
      else if(state.interest<state.salary_amount&&!state.apartment_price>state.salary_amount){
        state.remaining_amount_interest = 0
      }
      else if(state.interest<state.salary_amount&&state.apartment_price<state.salary_amount&&state.interest_tax_deduction+
        state.amount_tax_deduction<=state.salary_amount){
        state.remaining_amount_interest = 0
      }



      else if(state.interest==state.salary_amount){
        state.remaining_amount_interest = 0
      }

    },

    //Для женатых
    mutationAmountTaxDeductionForMarried(state){
      if(state.salary_amount_married>=state.apartment_price){
        state.amount_tax_deduction_for_show_married = state.apartment_price.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        state.amount_tax_deduction_married = parseInt(state.apartment_price.toFixed(0));
        if (state.amount_tax_deduction_married>state.max_pay_for_married){
          state.amount_tax_deduction_married = state.max_pay_for_married
          state.amount_tax_deduction_for_show_married = state.max_pay_for_married.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        }
      }
      else if(state.salary_amount_married<state.apartment_price){
        state.amount_tax_deduction_for_show_married = state.salary_amount_married.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        state.amount_tax_deduction_married = parseInt(state.salary_amount_married.toFixed(0));
        if (state.amount_tax_deduction_married>state.max_pay_for_married){
          state.amount_tax_deduction_married = state.max_pay_for_married
          state.amount_tax_deduction_for_show_married = state.max_pay_for_married.toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        }
      }
    },
    mutationSalaryForMarried(state,received_perem){
      state.salary_amount_married = (received_perem*12)*0.13
      state.salary_amount_for_deduction_married = (received_perem*12)*0.13
    },
    mutationCanReturnAfterForMarried(state){
      if(state.apartment_price>state.salary_amount_married){
        state.remaining_amount_appartnent_married = state.apartment_price-state.salary_amount_married
        if(state.apartment_price>state.max_pay_for_married){
          const max = state.max_pay_for_married
          state.remaining_amount_appartnent_married = max-state.salary_amount_married
          if(state.remaining_amount_appartnent_married<0){
            state.remaining_amount_appartnent_married=0
          }
        }
        if(state.amount_tax_deduction_married>state.max_pay_for_married){
          state.remaining_amount_appartnent_married = 0
        }
      }
      else if(state.apartment_price<state.salary_amount_married){
        state.remaining_amount_appartnent_married = 0
      }
      else if(state.apartment_price==state.salary_amount_married){
        state.remaining_amount_appartnent_married = 0
      }

    },
    //Иные вычеты
    mutationOtherDeductionsForMarried(state,received_perem){
      state.other_deductions_for_married=parseInt(received_perem)
      state.max_pay_for_married = state.max_pay_for_other_deductions - state.other_deductions_for_married
      if(state.max_pay_for_married<0){
        state.max_pay_for_married=0
      }
    },
    //Иные вычеты не квартира
    mutationOtherDeductionsNotApartmentForMarried(state,received_perem){
      state.other_deductions_not_apartment_for_married=parseInt(received_perem)
      state.salary_amount_married = state.salary_amount_for_deduction_married - state.other_deductions_not_apartment_for_married
      if(state.salary_amount_married<0){
        state.salary_amount_married=0
      }
      // console.log(state);
    },

    //Проценты
    mutationInterestTaxDeduction_married(state){
      if(state.salary_amount_married>=state.interest){
        state.interest_tax_deduction_for_show_married = state.interest.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        state.interest_tax_deduction_married = parseInt(state.interest.toFixed(0));
        if (state.interest_tax_deduction_married>state.max_pay_interest_married){
          state.interest_tax_deduction_married = state.max_pay_interest_married
          state.interest_tax_deduction_for_show_married = state.max_pay_interest_married.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        }
      }
      else if(state.salary_amount_married<state.interest){
        state.interest_tax_deduction_for_show_married = state.salary_amount_married.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        state.interest_tax_deduction_married = parseInt(state.salary_amount_married.toFixed(0));
        if (state.interest_tax_deduction_married>state.max_pay_interest_married){
          state.interest_tax_deduction_married = state.max_pay_interest_married
          state.interest_tax_deduction_for_show_married = state.max_pay_interest_married.toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
        }
      }

    },
    mutationCanReturnInterestAfter_married(state){
      if(state.interest>state.salary_amount_married){
        state.remaining_amount_interest_married = state.interest-state.salary_amount_married
        if(state.interest>state.max_pay_interest_married){
          const max = state.max_pay_interest_married
          state.remaining_amount_interest_married = max-state.salary_amount_married
          if(state.remaining_amount_interest_married<0){
            state.remaining_amount_interest_married=0
          }
        }
        if(state.interest_tax_deduction_married>state.max_pay_interest_married){
          state.remaining_amount_interest_married = 0
        }
      }
      else if(state.interest<state.salary_amount_married){
        state.remaining_amount_interest_married = 0
      }
      else if(state.interest==state.salary_amount_married){
        state.remaining_amount_interest_married = 0
      }
    },

    mutationinterestWithoutLimitation(state,received_perem){
      state.date=received_perem
    },

    //Субсидии
    mutationSubsidies(state,received_perem){

      state.subsidies = parseInt(received_perem)
    },

    //  Дата для изменения максимальной суммы возврата по процентам

    mutationDate(state,received_perem){
      state.date=received_perem

    },
    mutationReturnMaximumChange(state,received_perem){
      if(state.date==1){
        state.max_pay_interest = 1000000000
        state.max_pay_interest_married = 1000000000
      }
      if(state.date==2){
        state.max_pay_interest = 390000
        state.max_pay_interest_married = 390000
      }

    },
    mutationFootnote(state,received_perem){
      state.footnote=received_perem
    },
    mutationFootnoteStus(state,received_perem){
      state.footnote_status=received_perem
    },




  },
  actions:{
    ActionRealPriceAppartment({commit},param){
      commit('mutationRealPriceAppartment',param)
      commit('mutationRealPriceAppartmentWithoutCalculation',param)
    },

    //Для неженатых

    ActionSalary({commit},param){
      commit('mutationSalary',param)
      commit('mutationAmountTaxDeduction')
      commit('mutationCanReturnAfter')
      commit('mutationInterestTaxDeduction')
      commit('mutationCanReturnInterestAfter')

    },
    ActionApartmentPrice({commit},param){
      commit('mutationApartmentPrice',param)
      commit('mutationAmountTaxDeduction')
      commit('mutationCanReturnAfter')
    },



    //Для женатых
    ActionSalaryForMarried({commit},param){
      commit('mutationSalaryForMarried',param)
      commit('mutationAmountTaxDeductionForMarried')
      commit('mutationCanReturnAfterForMarried')
      commit('mutationInterestTaxDeduction_married')
      commit('mutationCanReturnInterestAfter_married')
    },
    ActionApartmentPriceForMarried({commit},param){
      commit('mutationApartmentPrice',param)
      commit('mutationAmountTaxDeductionForMarried')
      commit('mutationCanReturnAfterForMarried')
    },

  //  Проценты
    //Для не женатых
    ActionInterest({commit},param){
      commit('mutationInterest',param)
      commit('mutationInterestTaxDeduction')
      commit('mutationCanReturnInterestAfter')
    },
    //Для женатых
    ActionInterest_Married({commit},param){
      commit('mutationInterest',param)
      commit('mutationInterestTaxDeduction_married')
      commit('mutationCanReturnInterestAfter_married')
    },

    //  Инне налоговые вычеты
    //Для не женатых
    ActionOtherDeductions({commit},param){
      commit('mutationOtherDeductions',param)
      commit('mutationAmountTaxDeduction')
      commit('mutationCanReturnAfter')
    },
    //Для женатых
    ActionOtherDeductionsForMarried({commit},param){
      commit('mutationOtherDeductionsForMarried',param)
      commit('mutationAmountTaxDeductionForMarried')
      commit('mutationCanReturnAfterForMarried')
    },

    //вычеты не квартира
    //Для не женатых
    ActionOtherDeductionsNotAppartment({commit},param){
      commit('mutationOtherDeductionsNotApartment',param)
      commit('mutationAmountTaxDeduction')
      commit('mutationCanReturnAfter')
    },
    //Для женатых
    ActionOtherDeductionsNotAppartmentForMarried({commit},param){
      commit('mutationOtherDeductionsNotApartmentForMarried',param)
      commit('mutationAmountTaxDeductionForMarried')
      commit('mutationCanReturnAfterForMarried')
    },

    //  Субсидии
    ActionSubsidies({commit},param){
      commit('mutationSubsidies',param)
    },

    ActionFootnote({commit},param){
      commit('mutationFootnote',param)
    },
    ActionFootnoteStatus({commit},param){
      commit('mutationFootnoteStus',param)
    },

  //  Дата для изменения максимальной суммы возврата по процентам
    ActionReturnMaximumChange({commit},param){
      commit('mutationDate',param)
      commit('mutationReturnMaximumChange')
      commit('mutationInterestTaxDeduction')
      commit('mutationInterestTaxDeduction_married')
      commit('mutationCanReturnInterestAfter')
      commit('mutationCanReturnInterestAfter_married')


    }







  },
})
</script>
