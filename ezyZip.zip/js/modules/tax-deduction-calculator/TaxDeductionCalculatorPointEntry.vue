<template lang="pug">
  div.property-calculator__body.refinancing-calc__body.white
    template
      tax-deduction-calculator

</template>
<script>
// import DduCalculator from './DduCalculator.vue';
import Storage from './development-tools/state.vue';
const TaxDeductionCalculator = () => import ("./TaxDeductionCalculator.vue");


export default {
  name: 'TaxDeductionCalculatorPointEntry',
  data(){
    return {

    }
  },
  methods:{
  },
  mounted(){
  },
  computed:{
  },
  watch:{
  },
  components:{
    TaxDeductionCalculator
  }
};
</script>
<style scoped>
</style>
