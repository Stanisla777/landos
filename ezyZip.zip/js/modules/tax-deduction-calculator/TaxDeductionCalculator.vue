<template lang="pug">
  div
    .property-calculator__body-row.tax-deduction__body-row.js--tax-deduction_calculations
      template(v-if="footnote.condition===true")
        pop-up(
          :paramText="footnote.text"
          v-on:eventClosePopUp="closePopUp($event)"
        )
      div.property-calculator__calculations
        .property-calculator__block
          h2.property-calculator__title Уточните информацию о себе
          template(v-if="data_detailed_calculator")
            component-checkbox(
              v-on:event_SelectedMarried="changeStatusMaried($event)"
              v-on:event_OtherTax="changeOtherTax($event)"
              v-on:event_Subsidies="changeSubsidies($event)"
            )
        .property-calculator__block
          h2.property-calculator__title Общая информация
          template(v-if="data_detailed_calculator")
            date-purchase(
              v-on:event_OtherTax="changeOtherTax($event)"
              v-on:eventPopUp="contentPopUp($event)"
            )
          template
            apartment-price
          template(v-if="data_detailed_calculator")
            component-paid-interest
          .property-calculator__row.margin
            template
              component-salary(
                :parametrTitle="title_componrnt_salary_1"
              )
            template(v-if="other_tax")
              component-other-tax
            template(v-if="other_tax")
              component-other-tax-not-appartment
            template
              component-salary-for-married(
                v-bind:class="selected_married?'active':''"
                :parametrTitle="title_componrnt_salary_2"
              )
            template(v-if="other_tax&&selected_married")
              component-other-tax-for-married
            template(v-if="other_tax&&selected_married")
              component-other-tax-not-appartment-for-married

          template(v-if="subsidies")
            component-subsidies

      .property-calculator__container-result.first-show
        template(v-if="data_detailed_calculator")
          component-total-sum-detailed
        p.refinancing-calc__footnote.
          Результат расчета предварительный, сформирован в ознакомительных целях на основе предоставленных сведений и
          не является официальным заключением, офертой, индивидуальной оценкой. Для получения подробной информации и
          индивидуальной оценки рекомендуем обратиться в кредитную организацию

</template>
<script>
import Vue from 'vue';
import eventBus from './development-tools/eventBus.vue';
import DatePurchase from './components/v-component-date-purchase.vue';
import ApartmentPrice from './components/v-component-apartment-price.vue';
import ComponentSalary from './components/v-component-salary.vue';
import ComponentTotalSum from './components/v-component-total-sum.vue';
import ComponentCheckbox from './components/v-component-checkbox.vue';
import ComponentOtherTax from './components/component-other-taxes.vue';
import ComponentOtherTaxForMarried from './components/component-other-taxes-for-married.vue';
import ComponentSubsidies from './components/component-subsidies.vue';
import ComponentTotalSumDetailed from './components/v-component-total-sum-detailed.vue';
import ComponentPaidInterest from './components/component-paid-interest.vue';
import ComponentSalaryForMarried from './components/v-component-salary-for-married.vue';
import ComponentOtherTaxNotAppartment from './components/component-other-taxes-not-appartment.vue';
import ComponentOtherTaxNotAppartmentForMarried from './components/component-other-taxes-not-appartment_for-married.vue';
import PopUp from './components/v-component-pop-up.vue';
import Storage from './development-tools/state.vue'
export default {
  name: 'TaxDeductionCalculator',
  data(){
    return {
      data_detailed_calculator:true,
      selected_married:false,
      other_tax:false,
      subsidies:false,
      salary_class:'tax-deduction__container-salary',
      title_componrnt_salary_1:"За какой срок можно заявить выплату",
      title_componrnt_salary_2:"За какой срок может заявить выплату ваш(а) супруг/супруга",
      pop_up:false,
      text_pop_up:null
    }
  },
  methods:{
    detailedCalculator(ev){
      this.data_detailed_calculator=true
    },
    changeStatusMaried(ev){
      this.selected_married = ev
    },
    changeOtherTax(ev){
      this.other_tax = ev
    },
    changeSubsidies(ev){
      this.subsidies = ev
    },
    contentPopUp(ev){
      this.pop_up=ev.condition
      this.text_pop_up=ev.text
    },
    closePopUp(ev){
      this.pop_up=ev
    },

  },
  mounted(){

  },
  computed:{
    footnote(){
      return Storage.getters.FOOTNOTE
    },
  },
  watch:{
  },
  components:{
    DatePurchase,
    ApartmentPrice,
    ComponentSalary,
    ComponentTotalSum,
    ComponentCheckbox,
    ComponentOtherTax,
    ComponentOtherTaxForMarried,
    ComponentSubsidies,
    ComponentTotalSumDetailed,
    ComponentPaidInterest,
    ComponentSalaryForMarried,
    ComponentOtherTaxNotAppartment,
    ComponentOtherTaxNotAppartmentForMarried,
    PopUp

  }
};
</script>
<style scoped>
</style>
