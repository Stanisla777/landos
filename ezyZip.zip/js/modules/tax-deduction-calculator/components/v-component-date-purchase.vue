<template lang="pug">
  .property-calculator__row.margin
    p.property-calculator__row-label Дата оформления права собственности на квартиру или дата акта о передаче - для долевого строительства
    .property-calculator__input-field.js--credit-calendar-input
      input.property-calculator__value(type="text" value="01.01.2019" placeholder="дд.мм.гггг" inputmode="numeric")(
        @input="changeDate"
        @click ="showCalendar"
      )
      .js__vanilla-calendar-calc.vanilla-calendar-style.property-calculator__vanilla-calendar(
        @click.stop ="showCalendar"
      )
      .property-calculator__input-additional-elem(
        @click ="showCalendar"
      )
        svg(width='20', height='20', viewbox='0 0 20 20', fill='none', xmlns='http://www.w3.org/2000/svg')
          path(d='M4.16658 0V0.833333H0.833252V19.1667H19.1666V0.833333H15.8333V0H14.1666V0.833333H5.83325V0H4.16658ZM2.49992 2.5H4.16658V3.33333H5.83325V2.5H14.1666V3.33333H15.8333V2.5H17.4999V4.16667H2.49992V2.5ZM2.49992 5.83333H17.4999V17.5H2.49992V5.83333ZM4.16658 10.8333V12.5H5.83325V10.8333H4.16658ZM7.49992 10.8333V12.5H9.16658V10.8333H7.49992ZM10.8333 10.8333V12.5H12.4999V10.8333H10.8333ZM14.1666 10.8333V12.5H15.8333V10.8333H14.1666ZM4.16658 14.1667V15.8333H5.83325V14.1667H4.16658ZM7.49992 14.1667V15.8333H9.16658V14.1667H7.49992ZM10.8333 14.1667V15.8333H12.4999V14.1667H10.8333Z', fill='black')
</template>
<script>
import IMask from 'imask';
import VanillaCalendar from '../../vanilla-calendar';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import PopUp from '../components/v-component-pop-up.vue';

export default {
  name: 'v-date-purchase',
  data(){
    return {
      calendar_input:'',
      paramName:null,
      hint_text:'Если вы использовали налоговый вычет на&#160;имущество, преобретенное до&#160;01.01.2014, то&#160;заявить его ' +
        'повторно нельзя, независимо от&#160;размера ранее предоставленного вычета.',
      pop_up_text:'Если вы использовали налоговый вычет на&#160;имущество, преобретенное до&#160;01.01.2014, то&#160;заявить его ' +
        'повторно нельзя, независимо от&#160;размера ранее предоставленного вычета.'
    }
  },
  methods:{
    inputCalendar(){
      const input_status = document.querySelectorAll('.js--credit-calendar-input input');
      const maskOptions = {
        mask: Date,
        min: new Date(1982, 0, 1),
        max:new Date()
      };
      // eslint-disable-next-line no-restricted-syntax,camelcase,no-undef
      for (const item of input_status) {
        // eslint-disable-next-line no-new
        new IMask(item, maskOptions);
      }
    },
    initPluginCalendarVanilla(dates,month,year){
      let text_footnote = this.pop_up_text
      this.calendar = new VanillaCalendar('.js__vanilla-calendar-calc', {
        settings: {
          lang: 'ru',
          range: {
            max: new Date().toISOString().slice(0, 10)
          },
          selected: {
            dates: dates,
            month: month,
            year:year
          },
          selection: {

          },
        },
        actions: {
          clickDay(e, dates) {
            const element=e.target
            const container = element.closest('.js--tax-deduction_calculations')
            if(container!==null){
              const checkbox = container.querySelector('.js--tax_checkbox')
              const checkbox_label = checkbox.querySelector('.js--date-signing label')
              const checkbox_input = checkbox.querySelector('.js--date-signing input')

              const checkbox_received = checkbox.querySelector('.js--received-payments')
              const checkbox_label_received = checkbox.querySelector('.js--received-payments label')
              const checkbox_input_received = checkbox.querySelector('.js--received-payments input')
              const data = String(dates[0])
                .substr(8, 2) + '.' + String(dates[0])
                .substr(5, 2) + '.' + String(dates[0])
                .substr(0, 4);
              const substr = String(dates[0]).substr(0, 4);
              if (dates.length !== 0) {
                const parent = e.target.closest('.js--credit-calendar-input');
                if(parent!==null){
                  parent.querySelector('input').value = data;
                  e.target.closest('.js__vanilla-calendar-calc').classList.remove('active');
                }
              }
              if (parseInt(substr)<2014){
                if (!checkbox_input.checked){
                  checkbox_input.checked=true
                }
                checkbox_received.classList.add('unactive')
                if (checkbox_input_received.checked){
                  checkbox_input_received.checked=false
                  this.$emit('event_OtherTax',this.paramName=false)
                }
                const info={
                  condition:true,
                  text:text_footnote
                }
                Storage.dispatch('ActionFootnote',info) // это для модалки, но её решил пока убрать
                Storage.dispatch('ActionFootnoteStatus',true) // это альтернатива - footnote
                Storage.dispatch('ActionReturnMaximumChange',1)
              }
              else if(parseInt(substr)>=2014){
                if (checkbox_input.checked){
                  checkbox_input.checked=false
                }
                checkbox_received.classList.remove('unactive')
                if (checkbox_input_received.checked){
                  checkbox_input_received.checked=false

                }
                eventBus.$emit('event_footnote',false)
                Storage.dispatch('ActionReturnMaximumChange',2)

                Storage.dispatch('ActionFootnote',{// это для модалки, но её решил пока убрать
                  condition:false,
                  text:''
                })
                Storage.dispatch('ActionFootnoteStatus',false)// это альтернатива - footnote
              }
              eventBus.$emit('passYear',parseInt(substr))
            }
          }
        }
      })
      this.calendar.init();
    },
    showCalendar(el){
      const element = el.currentTarget;
      element.closest('.js--credit-calendar-input').querySelector('.js__vanilla-calendar-calc').classList.add('active')

    },
    changeDate(el){
      const element=el.currentTarget
      const container = element.closest('.js--tax-deduction_calculations')
      const checkbox = container.querySelector('.js--tax_checkbox')
      const checkbox_label = checkbox.querySelector('.js--date-signing label')
      const checkbox_input = checkbox.querySelector('.js--date-signing input')

      const checkbox_received = checkbox.querySelector('.js--received-payments')
      const checkbox_label_received = checkbox.querySelector('.js--received-payments label')
      const checkbox_input_received = checkbox.querySelector('.js--received-payments input')
      const oneDay = 1000 * 60 * 60 * 24
      const date_today = new Date()
      if(element.value.replace(/(_|\s)+/g, "").length===10&&element.value.replace(/(_|\s)+/g, "").substr(3, 2)<=12){
        let substr = element.value.substring(element.value.length-4, element.value.length);
        substr=parseInt(substr)
        if (parseInt(substr)<2014){
          if (!checkbox_input.checked){
            checkbox_input.checked=true
          }
          checkbox_received.classList.add('unactive')
          if (checkbox_input_received.checked){
            checkbox_input_received.checked=false
            this.$emit('event_OtherTax',this.paramName=false)
          }
          element.focus()
          const info={
            condition:true,
            text:this.pop_up_text
          }

          Storage.dispatch('ActionFootnote',info)
          Storage.dispatch('ActionFootnoteStatus',true)// это альтернатива - footnote

          Storage.dispatch('ActionReturnMaximumChange',1)
        }
        else if(parseInt(substr)>=2014){
          if (checkbox_input.checked){
            checkbox_input.checked=false
          }
          checkbox_received.classList.remove('unactive')
          if (checkbox_input_received.checked){
            checkbox_input_received.checked=false
          }
          Storage.dispatch('ActionReturnMaximumChange',2)

          Storage.dispatch('ActionFootnote',{
            condition:false,
            text:''
          })
          Storage.dispatch('ActionFootnoteStatus',false)// это альтернатива - footnote


        }
        eventBus.$emit('passYear',substr)
        const date1 = new Date(element.value.replace(/(_|\s)+/g, "").substr(6, 4)+'-'+element.value.replace(/(_|\s)+/g, "").substr(3, 2)+"-"+element.value.replace(/(_|\s)+/g, "").substr(0, 2));
        const present_date = date_today.getTime() - date1.getTime();
        const diffpresent_date= Math.round(present_date / oneDay);
        if(diffpresent_date>=0){
          const date = element.value.replace(/(_|\s)+/g, "").substr(6, 4)+'-'+element.value.replace(/(_|\s)+/g, "").substr(3, 2)+"-"+element.value.replace(/(_|\s)+/g, "").substr(0, 2)
          const month = parseInt(element.value.replace(/(_|\s)+/g, "").substr(3, 2)) - 1;
          const year = element.value.replace(/(_|\s)+/g, "").substr(6, 4)

          this.calendar = null
          this.initPluginCalendarVanilla([`${date}`],month,year)

          const date_begin = element.value.replace(/(_|\s)+/g, "").substr(0, 2)

          setTimeout(()=>{
            element.closest('.js--credit-calendar-input').querySelector('.js__vanilla-calendar-calc').classList.remove('active')
          },500)
        }

      }
      else if(element.value.replace(/(_|\s)+/g, "").length===10&&element.value.replace(/(_|\s)+/g, "").substr(3, 2)<=12&&checkbox_input.checked){
        checkbox_received.classList.remove('unactive')
        checkbox_input.checked=false
        // element.focus()
      }

    },
    CalendarVanillaClose() {
      let count = 0;
      document.body.onclick = () => {
        const array_parent = document.querySelectorAll('.js--credit-calendar-input');
        const array_element = document.querySelectorAll('.js__vanilla-calendar-calc.active');
        for (const item of array_parent) {
          item.onclick = function (w) {
            w.stopImmediatePropagation();
          };
        }
        if (count > 0) {
          for (let i = 0; i < array_element.length; i++) {
            array_element[i].classList.remove('active');
          }
        }
        if (count < 1) {
          count += 1;
        }

      };
    }

  },
  mounted(){
    this.inputCalendar()
    this.initPluginCalendarVanilla()
    this.CalendarVanillaClose()
  },
  created(){
    eventBus.$on('event_for_caledar',(param)=>{

      const oneDay = 1000 * 60 * 60 * 24
      const element = document.querySelector('.js--credit-calendar-input input')


      const date1 = new Date(element.value.replace(/(_|\s)+/g, "").substr(6, 4)+'-'+element.value.replace(/(_|\s)+/g, "").substr(3, 2)+"-"+element.value.replace(/(_|\s)+/g, "").substr(0, 2));
      const date2 = new Date('2014-01-01');
      const present_date = date2.getTime() - date1.getTime();
      const diffpresent_date= Math.round(present_date / oneDay);

      if (param===true&&diffpresent_date<0){
        this.calendar_input=element.value
        if(element){
          element.value = '31.12.2013'
          const date = '2013-12-31'
          const month = 11
          const year = 2013
          this.calendar = null
          this.initPluginCalendarVanilla([`${date}`],month,year)
        }
      }
      else if(param===false&&this.calendar_input!==''){
        if(element){
          element.value = this.calendar_input
          const date = this.calendar_input.replace(/(_|\s)+/g, "").substr(6, 4)+'-'+this.calendar_input.replace(/(_|\s)+/g, "").substr(3, 2)+"-"+this.calendar_input.replace(/(_|\s)+/g, "").substr(0, 2)
          const month = parseInt(this.calendar_input.replace(/(_|\s)+/g, "").substr(3, 2)) - 1;
          const year = this.calendar_input.replace(/(_|\s)+/g, "").substr(6, 4)

          this.calendar = null
          this.initPluginCalendarVanilla([`${date}`],month,year)
          this.calendar_input=''
        }
      }
      else if(param===false&&this.calendar_input===''&&diffpresent_date>0){
        this.calendar_input=element.value
        if(element){
          element.value = '01.01.2019'
          const date = '2019-01-01'
          const month = 0
          const year = 2019
          this.calendar = null
          this.initPluginCalendarVanilla([`${date}`],month,year)
        }
      }
    })
  },
  computed:{


  },
  watch:{
  },
  components:{
    PopUp
  }
};
</script>
<style scoped>
</style>
