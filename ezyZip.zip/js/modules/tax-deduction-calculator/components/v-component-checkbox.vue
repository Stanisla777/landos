<template lang="pug">
  .property-calculator__row.tax_checkbox.margin.js--tax_checkbox
    .tax-deduction__checbox-slider
      .tax-deduction__swiper-container
          .property-calculator__checkbox-view-button.tax-deduction__checkbox-view-button.checkbox-stylized
            input#checkbox_1(type='checkbox')(@change="pass_SelectedMarried")
            label(for='checkbox_1') Я состою в браке

          .property-calculator__checkbox-view-button.tax-deduction__checkbox-view-button.checkbox-stylized.calculator_s__presence-tooltip.js--received-payments(ref="tax_deduction")
            input#checkbox_2(type='checkbox')(@change="pass_SelectedOtherTax")
            label(for='checkbox_2') Я получал налоговый вычет раньше

          .property-calculator__checkbox-view-button.tax-deduction__checkbox-view-button.checkbox-stylized
            input#checkbox_3(type='checkbox')(@change="pass_Subsidies")
            label(for='checkbox_3') Использовал при оплате средства гос. поддержки

          .property-calculator__checkbox-view-button.tax-deduction__checkbox-view-button.checkbox-stylized.calculator_s__presence-tooltip.js--date-signing(
            data-footnote="0"
          )
            input#checkbox_4(type='checkbox')(@change="taxDeduction")
            label(for='checkbox_4') Кредитный договор был подписан до 01.01.2014 года

    template(v-if="footnote_status")
      foot-note(
        :footnote="footnote[0].text"
      )

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import ToolTip from '../components/v-component-tooltip.vue';
import FootNote from '../components/v-component-footnote.vue';
import Storage from '../development-tools/state.vue';
import Swiper, { Navigation, Pagination } from 'swiper';
Swiper.use([Navigation, Pagination]);
let mySwiper;

export default {
  name: 'v-checkbox',
  data(){
    return {
      hint_text_1:"Вы получали ранее налоговый вычет за&#160;имущество, либо другие социальные налоговые вычеты",
      hint_text_2:"В случае приобретения жилья в&#160;ипотеку до&#160;01.01.2014, подоходный налог с&#160;расходов по&#160;уплате ипотечных " +
        "процентов возвращается в&#160;полной мере, без&#160;ограничений. Если же жилье было приобретено с&#160;помощью ипотечных " +
        "средств после 01.01.2014, то&#160;вычет по&#160;процентам ограничен суммой 390&#160;тыс. рублей.",
      paramName:null,
      footnote:[{
        status:false,
        // text:"В случае приобретения жилья в ипотеку до 01.01.2014, подоходный налог с расходов по уплате ипотечных процентов возвращается в полной мере, без ограничений. Если же жилье было приобретено с помощью ипотечных средств после 01.01.2014, то вычет по процентам ограничен суммой 390 тыс. рублей.<br> Если вы использовали налоговый вычет на имущество, преобретенное до 01.01.2014, то заявить его повторно нельзя, независимо от размера ранее предоставленного вычета."
        text:[
          'В случае приобретения жилья в ипотеку до 01.01.2014, подоходный налог с расходов по уплате ипотечных процентов ' +
          'возвращается в полной мере, без ограничений. Если же жилье было приобретено с помощью ипотечных средств ' +
          'после 01.01.2014, то вычет по процентам ограничен суммой 390 тыс. рублей.'
        ]

      }]
    }

  },
  methods:{
    initSliderStoriesButton() {
      mySwiper = new Swiper('.js-button-slider-tax', {
        // init:false,
        loop: false,
        simulateTouch: true,
        allowTouchMove: false,
        centeredSlides: false,
        slidesPerView:1,
        slidesPerGroup:1,
        spaceBetween: 12,
        navigation: false,
        pagination: false,
        breakpoints: {
          0: {
            init:true,
            slidesPerView:2,
            allowTouchMove: true,
            centeredSlides: true,
            spaceBetween: 6,
          },
          370: {
            init:true,
            slidesPerView:2,
            allowTouchMove: true,
            centeredSlides: true,
          },
          470: {

            slidesPerView:3,
            allowTouchMove: false,
            centeredSlides: false,
          }
        },
      });
      mySwiper.on('slideChange', () => {


      });

    },
    pass_SelectedMarried(el){
      const element = el.currentTarget
      if(element.checked){
        this.$emit('event_SelectedMarried',this.paramName=true)
        eventBus.$emit('event_SelectedMarriedDetaild',this.paramName=false)

      }
      else {
        this.$emit('event_SelectedMarried',this.paramName=false)
        eventBus.$emit('event_SelectedMarriedDetaild',this.paramName=true)
      }
    },
    pass_SelectedOtherTax(el){
      const element = el.currentTarget
      if(element.checked){
        this.$emit('event_OtherTax',this.paramName=true)
      }
      else {
        this.$emit('event_OtherTax',this.paramName=false)
      }
    },
    pass_Subsidies(el){
      const element = el.currentTarget
      if(element.checked){
        this.$emit('event_Subsidies',this.paramName=true)
      }
      else {
        this.$emit('event_Subsidies',this.paramName=false)
      }
    },
    taxDeduction(el){
      const element = el.currentTarget
      if(element.checked){
        this.$refs.tax_deduction.classList.add('unactive')
        if(this.$refs.tax_deduction.querySelector('input').checked){
          this.$refs.tax_deduction.querySelector('input').checked=false
          this.$emit('event_OtherTax',this.paramName=false)
        }

        Storage.dispatch('ActionOtherDeductions',0)
        Storage.dispatch('ActionReturnMaximumChange',1)
        eventBus.$emit('event_for_caledar',true)
        if(element.closest('.js--date-signing').hasAttribute('data-footnote')){
          const param = element.closest('.js--date-signing').getAttribute('data-footnote')
          // this.footnote[param].status=true
          Storage.dispatch('ActionFootnoteStatus',true)
        }
      }
      else {
        this.$refs.tax_deduction.classList.remove('unactive')
        Storage.dispatch('ActionReturnMaximumChange',2)
        eventBus.$emit('event_for_caledar',false)
        if(element.closest('.js--date-signing').hasAttribute('data-footnote')){
          const param = element.closest('.js--date-signing').getAttribute('data-footnote')
          // this.footnote[param].status=false
          Storage.dispatch('ActionFootnoteStatus',false)
        }
      }
    },



  },
  mounted(){
    this.initSliderStoriesButton()
  },
  computed:{
    footnote_status(){
      return Storage.getters.FOOTNOTE_STATUS
    },
  },
  watch:{
  },
  created(){
    eventBus.$on('event_footnote',(param)=>{
      this.footnote.status=param
    })
  },

  components:{
    ToolTip,
    FootNote
  }
};
</script>
<style scoped>
</style>
