<template lang="pug">
  .property-calculator__wrapper-detailed-result.black.js-scroll
    .property-calculator__final-calc
      .calculator_s__result-this-year-not-married(v-if="selected_married")
        .property-calculator__final-item-block

          .property-calculator__final-item-row
            .property-calculator__detailed-res-col
              p.property-calculator__final-item-value  {{can_returned_now_apartment_plus_interest}} ₽
              p.property-calculator__final-item-key Можно вернуть в текущем году
            .property-calculator__detailed-res-col
              p.property-calculator__final-item-value  {{can_returned_then_apartment_plus_interest}} ₽
              p.property-calculator__final-item-key Можно вернуть в последующих годах

        .property-calculator__final-item-block.not-border
          p.property-calculator__final-sub-title Максимальная сумма возврата налога за недвижимость
          .property-calculator__final-item-row
            .property-calculator__detailed-res-col
              p.property-calculator__final-item-value  {{maximum_purchase_amount}} ₽
              .calculator_s__detailed-result-label-row.calculator_s__appearance-tooltip
                p.property-calculator__final-item-key За покупку
                .property-calculator__period-input-wrap-icon.white
                  svg(width='6' height='9' viewbox='0 0 6 9' fill='none' xmlns='http://www.w3.org/2000/svg')
                    path(d='M2.29615 5.82809V5.87809H2.34615H3.38128H3.43128V5.82809C3.43128 5.17718 3.88001 4.74316 4.37092 4.26834C4.3939 4.24612 4.41697 4.2238 4.44009 4.20137C4.95161 3.70514 5.47928 3.15761 5.47928 2.27748C5.47928 1.56616 5.1798 1.02591 4.72144 0.664646C4.26438 0.304406 3.65179 0.123828 3.0251 0.123828C1.94115 0.123828 0.916704 0.644209 0.518245 1.74851L0.503822 1.78848L0.540948 1.80916L1.42025 2.2989L1.47368 2.32866L1.49223 2.27038C1.60592 1.91305 1.80522 1.65293 2.06481 1.48165C2.32489 1.31005 2.64868 1.22557 3.01397 1.22557C3.39653 1.22557 3.72964 1.31585 3.96588 1.49634C4.20027 1.67543 4.34415 1.94688 4.34415 2.322C4.34415 2.63879 4.22214 2.90106 4.03445 3.14622C3.87409 3.35566 3.66836 3.5496 3.45209 3.75346C3.41356 3.78978 3.37469 3.82642 3.33569 3.86351C2.82303 4.3511 2.29615 4.90943 2.29615 5.82809ZM2.85815 8.28226C3.29809 8.28226 3.63162 7.93659 3.63162 7.50879C3.63162 7.08098 3.29809 6.73531 2.85815 6.73531C2.42984 6.73531 2.08467 7.08048 2.08467 7.50879C2.08467 7.9371 2.42984 8.28226 2.85815 8.28226Z' fill='#1C1B28' stroke='#1C1B28' stroke-width='0.1')
                template
                  tool-tip(
                    :hint_text="hint_text_2"
                  )

            .property-calculator__detailed-res-col
              p.property-calculator__final-item-value  {{maximum_interest_amount}} ₽
              .calculator_s__detailed-result-label-row.calculator_s__appearance-tooltip
                p.property-calculator__final-item-key За % по ипотеке
                .property-calculator__period-input-wrap-icon.white
                  svg(width='6' height='9' viewbox='0 0 6 9' fill='none' xmlns='http://www.w3.org/2000/svg')
                    path(d='M2.29615 5.82809V5.87809H2.34615H3.38128H3.43128V5.82809C3.43128 5.17718 3.88001 4.74316 4.37092 4.26834C4.3939 4.24612 4.41697 4.2238 4.44009 4.20137C4.95161 3.70514 5.47928 3.15761 5.47928 2.27748C5.47928 1.56616 5.1798 1.02591 4.72144 0.664646C4.26438 0.304406 3.65179 0.123828 3.0251 0.123828C1.94115 0.123828 0.916704 0.644209 0.518245 1.74851L0.503822 1.78848L0.540948 1.80916L1.42025 2.2989L1.47368 2.32866L1.49223 2.27038C1.60592 1.91305 1.80522 1.65293 2.06481 1.48165C2.32489 1.31005 2.64868 1.22557 3.01397 1.22557C3.39653 1.22557 3.72964 1.31585 3.96588 1.49634C4.20027 1.67543 4.34415 1.94688 4.34415 2.322C4.34415 2.63879 4.22214 2.90106 4.03445 3.14622C3.87409 3.35566 3.66836 3.5496 3.45209 3.75346C3.41356 3.78978 3.37469 3.82642 3.33569 3.86351C2.82303 4.3511 2.29615 4.90943 2.29615 5.82809ZM2.85815 8.28226C3.29809 8.28226 3.63162 7.93659 3.63162 7.50879C3.63162 7.08098 3.29809 6.73531 2.85815 6.73531C2.42984 6.73531 2.08467 7.08048 2.08467 7.50879C2.08467 7.9371 2.42984 8.28226 2.85815 8.28226Z' fill='#1C1B28' stroke='#1C1B28' stroke-width='0.1')
                template
                  tool-tip(
                    :hint_text="hint_text"
                  )



      .calculator_s__result-this-year-married(v-else)
        .property-calculator__final-item-block
          p.property-calculator__final-sub-title Можно вернуть в текущем году
          .property-calculator__final-item-row
            .property-calculator__detailed-res-col
              p.property-calculator__final-item-value {{can_returned_now_apartment_plus_interest}} ₽
              p.property-calculator__final-item-key Вам
            .property-calculator__detailed-res-col
              p.property-calculator__final-item-value  {{can_returned_now_apartment_plus_interest_married}} ₽
              p.property-calculator__final-item-key Супругу/супруге

        .property-calculator__final-item-block
          p.property-calculator__final-sub-title Можно вернуть в последующих годах
          .property-calculator__final-item-row
            .property-calculator__detailed-res-col
              p.property-calculator__final-item-value {{can_returned_then_apartment_plus_interest}} ₽
              p.property-calculator__final-item-key Вам

            .property-calculator__detailed-res-col
              p.property-calculator__final-item-value  {{can_returned_then_apartment_plus_interest_married}} ₽
              p.property-calculator__final-item-key Супругу/супруге

        //Тут данные статические(постоянные)
        .property-calculator__final-item-block.not-border
          p.property-calculator__final-sub-title Максимальная сумма возврата налога за недвижимость (для обоих супругов)
          .property-calculator__final-item-row
            .property-calculator__detailed-res-col
              p.property-calculator__final-item-value  {{maximum_purchase_amount_general}} ₽
              .calculator_s__detailed-result-label-row.calculator_s__appearance-tooltip.tax-deduction__label-row
                p.property-calculator__final-item-key За покупку
                .property-calculator__period-input-wrap-icon.white
                  svg(width='6' height='9' viewbox='0 0 6 9' fill='none' xmlns='http://www.w3.org/2000/svg')
                    path(d='M2.29615 5.82809V5.87809H2.34615H3.38128H3.43128V5.82809C3.43128 5.17718 3.88001 4.74316 4.37092 4.26834C4.3939 4.24612 4.41697 4.2238 4.44009 4.20137C4.95161 3.70514 5.47928 3.15761 5.47928 2.27748C5.47928 1.56616 5.1798 1.02591 4.72144 0.664646C4.26438 0.304406 3.65179 0.123828 3.0251 0.123828C1.94115 0.123828 0.916704 0.644209 0.518245 1.74851L0.503822 1.78848L0.540948 1.80916L1.42025 2.2989L1.47368 2.32866L1.49223 2.27038C1.60592 1.91305 1.80522 1.65293 2.06481 1.48165C2.32489 1.31005 2.64868 1.22557 3.01397 1.22557C3.39653 1.22557 3.72964 1.31585 3.96588 1.49634C4.20027 1.67543 4.34415 1.94688 4.34415 2.322C4.34415 2.63879 4.22214 2.90106 4.03445 3.14622C3.87409 3.35566 3.66836 3.5496 3.45209 3.75346C3.41356 3.78978 3.37469 3.82642 3.33569 3.86351C2.82303 4.3511 2.29615 4.90943 2.29615 5.82809ZM2.85815 8.28226C3.29809 8.28226 3.63162 7.93659 3.63162 7.50879C3.63162 7.08098 3.29809 6.73531 2.85815 6.73531C2.42984 6.73531 2.08467 7.08048 2.08467 7.50879C2.08467 7.9371 2.42984 8.28226 2.85815 8.28226Z' fill='#1C1B28' stroke='#1C1B28' stroke-width='0.1')
                template
                  tool-tip(
                    :hint_text="hint_text_2"
                  )
            .property-calculator__detailed-res-col

              p.property-calculator__final-item-value  {{maximum_interest_amount}} ₽
              .calculator_s__detailed-result-label-row.calculator_s__appearance-tooltip.tax-deduction__label-row
                p.property-calculator__final-item-key За % по ипотеке
                .property-calculator__period-input-wrap-icon.white
                  svg(width='6' height='9' viewbox='0 0 6 9' fill='none' xmlns='http://www.w3.org/2000/svg')
                    path(d='M2.29615 5.82809V5.87809H2.34615H3.38128H3.43128V5.82809C3.43128 5.17718 3.88001 4.74316 4.37092 4.26834C4.3939 4.24612 4.41697 4.2238 4.44009 4.20137C4.95161 3.70514 5.47928 3.15761 5.47928 2.27748C5.47928 1.56616 5.1798 1.02591 4.72144 0.664646C4.26438 0.304406 3.65179 0.123828 3.0251 0.123828C1.94115 0.123828 0.916704 0.644209 0.518245 1.74851L0.503822 1.78848L0.540948 1.80916L1.42025 2.2989L1.47368 2.32866L1.49223 2.27038C1.60592 1.91305 1.80522 1.65293 2.06481 1.48165C2.32489 1.31005 2.64868 1.22557 3.01397 1.22557C3.39653 1.22557 3.72964 1.31585 3.96588 1.49634C4.20027 1.67543 4.34415 1.94688 4.34415 2.322C4.34415 2.63879 4.22214 2.90106 4.03445 3.14622C3.87409 3.35566 3.66836 3.5496 3.45209 3.75346C3.41356 3.78978 3.37469 3.82642 3.33569 3.86351C2.82303 4.3511 2.29615 4.90943 2.29615 5.82809ZM2.85815 8.28226C3.29809 8.28226 3.63162 7.93659 3.63162 7.50879C3.63162 7.08098 3.29809 6.73531 2.85815 6.73531C2.42984 6.73531 2.08467 7.08048 2.08467 7.50879C2.08467 7.9371 2.42984 8.28226 2.85815 8.28226Z' fill='#1C1B28' stroke='#1C1B28' stroke-width='0.1')
                template
                  tool-tip(
                    :hint_text="hint_text"
                  )

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import ToolTip from '../components/v-component-tooltip.vue';
export default {
   name: 'v-component-total-sum-detailed',
  data(){
    return {
      hint_text:"Непереносимый остаток (нельзя вернуть с&#160;последующих кредитов)",
      hint_text_2:"Переносимый остаток (можно вернуть в&#160;последующих годах)",
      selected_married:true,
      max_purchase:'260 000',
      max_interest:'65 000'
    }
  },
  methods:{

  },
  mounted(){
  },
  computed:{



    final_interest_tax_deduction(){
      return Storage.getters.INTEREST_TAX_DEDUCTION
    },
    can_return_interest(){
      return Storage.getters.INTEREST_CAN_RETURN.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
    },

    final_interest_tax_deduction_married(){
      return Storage.getters.INTEREST_TAX_DEDUCTION_MARRIED
    },
    can_return_interest_married(){
      return Storage.getters.INTEREST_CAN_RETURN_MARRIED.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
    },

    can_returned_now_apartment(){
      return Storage.getters.AMOUNT_TAX_DEDUCTION
    },
    can_return_then_apartment(){
      return Storage.getters.CAN_RETURN.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
    },

    can_returned_now_apartment_for_married(){
      return Storage.getters.AMOUNT_TAX_DEDUCTION_MARRIED
    },
    can_return_then_apartment_for_married(){
      return Storage.getters.CAN_RETURN_MARRIED.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
    },

    can_returned_now_apartment_plus_interest(){
      let final = parseInt(this.can_returned_now_apartment.toString().replace(/\s/g, '')) + parseInt(this.final_interest_tax_deduction.toString().replace(/\s/g, ''))
      if(final>this.interest_paid_salary){
        final=this.interest_paid_salary
      }
      return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
    },
    can_returned_now_apartment_plus_interest_married(){
      let final = parseInt(this.can_returned_now_apartment_for_married.toString().replace(/\s/g, '')) + parseInt(this.final_interest_tax_deduction_married.toString().replace(/\s/g, ''))
      if(final>this.interest_paid_salary_married){
        final=this.interest_paid_salary_married
      }

      return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
    },

    can_returned_then_apartment_plus_interest(){
      let final = parseInt(this.maximum_purchase_amount.toString().replace(/\s/g, '')) +
        parseInt(this.maximum_interest_amount.toString().replace(/\s/g, '')) -
        parseInt(this.can_returned_now_apartment_plus_interest.toString().replace(/\s/g, ''))
      if(final<0){
        final=0
      }
// *
      return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
    },

    can_returned_then_apartment_plus_interest_married(){
      let final = parseInt(this.maximum_purchase_amount_for_married.toString().replace(/\s/g, '')) +
        parseInt(this.maximum_interest_amount.toString().replace(/\s/g, '')) -
        parseInt(this.can_returned_now_apartment_plus_interest_married.toString().replace(/\s/g, ''))
      if(final<0){
        final=0
      }
      return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
    },

    //Если скажут что оставить как есть, убрать "- this.other_deductions_for_married"
    maximum_purchase_amount(){
      let maximum_purchase = Storage.getters.APARTMENT_PRICE
      let final = Storage.getters.APARTMENT_PRICE- this.other_deductions

      if(final<0){
          final = 0
        }
      return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
    },

    //На это обратить внимание, пока использовать не буду для вывода!!!, так как у супруги и супруна могут быть разные налоговые вычеты
    //Супруга
    maximum_purchase_amount_for_married(){
      let maximum_purchase = Storage.getters.APARTMENT_PRICE
      // let final = maximum_purchase - this.other_deductions_for_married
      let final = Storage.getters.APARTMENT_PRICE- this.other_deductions_for_married
      if(final>260000){
        final =  260000
      }
      if(final<0){
        final = 0
      }
      return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
    },
    //Общее
    maximum_purchase_amount_general(){
      let final = parseInt(this.maximum_purchase_amount.toString().replace(/\s/g, '')) +
        parseInt(this.maximum_purchase_amount_for_married.toString().replace(/\s/g, ''))
      return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
    },


    //Супруг
    maximum_purchase_amount_man(){
      let maximum_purchase = Storage.getters.APARTMENT_PRICE
      let final = maximum_purchase - this.other_deductions

      if(final>260000){
        final =  260000
      }
      else if(final<0){
        final = 0
      }
      return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
    },




    maximum_interest_amount(){
      let date = Storage.getters.DATE
      let final = Storage.getters.INTEREST
      if(date==2||date==0){
        if(final>390000){
          final =  390000
        }
        return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
      }
      if(date==1){
        return final.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ');
      }

    },

    interest_paid_salary(){
      return parseInt(Storage.getters.SALARY_AMOUNT.toFixed(0))
    },
    interest_paid_salary_married(){
      return parseInt(Storage.getters.SALARY_AMOUNT_MARRIED.toFixed(0))
    },
    other_deductions(){
      return parseInt(Storage.getters.OTHER_DEDUCTIONS.toFixed(0))
    },
    other_deductions_for_married(){
      return parseInt(Storage.getters.OTHER_DEDUCTIONS_FOR_MARRIED.toFixed(0))
    }
  },

  watch:{

  },
  components:{
    ToolTip,
  },
  created(){
    eventBus.$on('event_SelectedMarriedDetaild',(param)=>{
      this.selected_married=param
    })


    eventBus.$on('pass_cost_apartament',(param)=>{
      this.data_cost_apartment=param
    })
    eventBus.$on('pass_salary',(param)=>{
      this.data_salary=param
    })
  }
};
</script>
<style scoped>
</style>
