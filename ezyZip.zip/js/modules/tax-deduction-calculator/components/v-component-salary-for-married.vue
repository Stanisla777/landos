<template lang="pug">
  .calculator_s__wrapper-salary.tax-deduction__wrapper-salary.tax-deduction__wrapper-salary-married(data-period="3")
    .calculator_s__period-input-wrapper
      .property-calculator__sub-title {{parametrTitle}}
      .property-calculator__period-input-wrap-icon.green
        svg(width='6' height='9' viewbox='0 0 6 9' fill='none' xmlns='http://www.w3.org/2000/svg')
          path(d='M2.29615 5.82809V5.87809H2.34615H3.38128H3.43128V5.82809C3.43128 5.17718 3.88001 4.74316 4.37092 4.26834C4.3939 4.24612 4.41697 4.2238 4.44009 4.20137C4.95161 3.70514 5.47928 3.15761 5.47928 2.27748C5.47928 1.56616 5.1798 1.02591 4.72144 0.664646C4.26438 0.304406 3.65179 0.123828 3.0251 0.123828C1.94115 0.123828 0.916704 0.644209 0.518245 1.74851L0.503822 1.78848L0.540948 1.80916L1.42025 2.2989L1.47368 2.32866L1.49223 2.27038C1.60592 1.91305 1.80522 1.65293 2.06481 1.48165C2.32489 1.31005 2.64868 1.22557 3.01397 1.22557C3.39653 1.22557 3.72964 1.31585 3.96588 1.49634C4.20027 1.67543 4.34415 1.94688 4.34415 2.322C4.34415 2.63879 4.22214 2.90106 4.03445 3.14622C3.87409 3.35566 3.66836 3.5496 3.45209 3.75346C3.41356 3.78978 3.37469 3.82642 3.33569 3.86351C2.82303 4.3511 2.29615 4.90943 2.29615 5.82809ZM2.85815 8.28226C3.29809 8.28226 3.63162 7.93659 3.63162 7.50879C3.63162 7.08098 3.29809 6.73531 2.85815 6.73531C2.42984 6.73531 2.08467 7.08048 2.08467 7.50879C2.08467 7.9371 2.42984 8.28226 2.85815 8.28226Z' fill='#1C1B28' stroke='#1C1B28' stroke-width='0.1')
        template
          tool-tip(
            :hint_text="hint_text"
          )
    .calculator_s__period-selection.calculator_s__wrapper-select.js--wrapper-select.unactive(
      @mouseenter="activityStateAtive"
      @mouseleave="activityStateUnAtive"
    )

      .refinancing-calc__row-buttons-change.js--list-wrapper
        .swiper-container.js-period-button-slider_married
          .swiper-wrapper
            .swiper-slide
              .refinancing-calc__buttons-change.js--select-item(
                data-period="1"
                :data-year="current_year-1"
                @click="periodSelection"
              )
                p 1 год
            .swiper-slide
              .refinancing-calc__buttons-change.js--select-item(
                data-period="2"
                :data-year="current_year-2"
                @click="periodSelection"
              )
                 p 2 года
            .swiper-slide
              .refinancing-calc__buttons-change.active.js--select-item(
                data-period="3"
                :data-year="current_year-3"
                @click="periodSelection"
              )
                 p 3 года

    .property-calculator__several-columns.three-columns.grow.tax-deduction__period-input-select
      .property-calculator__row.property-calculator__several-columns_col.margin.js--period-input-selected(
        :data-year="current_year-1"
      )
        p.property-calculator__row-label Зарплата в {{current_year-1}} году, ₽
        .property-calculator__input-field.js--salary-input.js--salary-input0(@click="inputFocus")
          input.property-calculator__value(type="text" inputmode="numeric" placeholder="0")(
            @input ="inputValue"
            :value="value_salary"
          )
      .property-calculator__row.property-calculator__several-columns_col.margin.js--period-input-selected(
        :data-year="current_year-2"
      )
        p.property-calculator__row-label Зарплата в {{current_year-2}} году, ₽
        .property-calculator__input-field.js--salary-input.js--salary-input1(@click="inputFocus")
          input.property-calculator__value(type="text" inputmode="numeric" placeholder="0")(
            :value="value_salary"
            @input ="inputValue"
          )
      .property-calculator__row.property-calculator__several-columns_col.margin.js--period-input-selected(
        :data-year="current_year-3"
      )
        p.property-calculator__row-label Зарплата в {{current_year-3}} году, ₽
        .property-calculator__input-field.js--salary-input.js--salary-input2(@click="inputFocus")
          input.property-calculator__value(type="text" inputmode="numeric" placeholder="0")(
            :value="value_salary"
            @input ="inputValue"
          )

</template>
<script>
// import IMask from 'imask';
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import ToolTip from '../components/v-component-tooltip.vue';
import Swiper, { Navigation, Pagination } from 'swiper';
Swiper.use([Navigation, Pagination]);
let mySwiper_2;
let mask_array_2 = []

export default {
  name: 'v-component-salary-for-married',
  props:['parametrTitle'],
  data(){
    return {
      realtySalary: 0, // Стоимость недвижимости
      realtySalaryForCalculation:0,
      stepApartment: 10, // Шаг для range инпутов
      stgMin: 15000, // Минимальное значение поля стоимости
      stgMax: 100000000, // Максимальное значение поля стоимости
      value_salary:'13 890',
      hint_text:'Необходимо указать среднюю ежемесячную заработную плату',
      year_purchase:null,
      current_year:null
    }
  },

  methods:{
    initSliderStoriesButton() {
      mySwiper_2 = new Swiper('.js-period-button-slider_married', {
        loop: false,
        simulateTouch: true,
        allowTouchMove: false,
        centeredSlides: false,
        slidesPerView:3,
        slidesPerGroup:1,
        spaceBetween: 12,
        // autoHeight:false,
        // observer:true,
        // autoResize:false,
        // visibilityFullFit: true,
        // centeredSlides:true,

        navigation: false,
        pagination: false,
        breakpoints: {
          0: {
            slidesPerView:2,
            allowTouchMove: true,
            centeredSlides: true,
          },
          470: {
            slidesPerView:3,
            allowTouchMove: false,
            centeredSlides: false,
          }
        },
      });
      mySwiper_2.on('slideChange', () => {


      });
      // mySwiper_2.on('transitionEnd', function() {
      //   const slide_calculator = document.querySelectorAll('.test-slide-calculator')
      //   slide_calculator.forEach(function (item){
      //     item.querySelector('p:first-child').textContent = mySwiper_2.realIndex+1
      //   })
      // });
      // this.current_slide = current_slide
    },
    inputCost(){
      // const input_status = document.querySelectorAll('.js--salary-input-mar input');
      // const maskOptions = {
      //   mask: Number,
      //   thousandsSeparator: ' ',
      //   max:this.stgMax
      // };
      // for (let i=0; i<input_status.length;i++) {
      //   mask_array_2.push(IMask(input_status[i], maskOptions));
      // }

    },
    inputValue(el){
      const element = el.currentTarget;
      if(element.value.replace(/\s/g, '')>this.stgMax){
        element.value = this.stgMax
      }
      const target = el.target
      let position = target.selectionStart;
      const val = parseInt(element.value.replace(/\s/g, ''))
      element.value = new Intl.NumberFormat("ru-RU").format(val);

      if (el.inputType==="deleteContentBackward"){
        target.selectionEnd = position;
      }
      if (element.value=='не число') {
        element.value=''
      }
      // if (element.value.replace(/\s/g, '') > this.stgMax){
      //   element.value=(count).toFixed(0)
      //     .toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
      // }
      this.sendInputChange(element)
    },

    //Убираю - добавляю класс при наведении на элемент, который влияет, когда будет раскрываться список при клике на li
    activityStateAtive(el){
      const element = el.currentTarget;
      element.classList.remove('unactive')
    },
    activityStateUnAtive(el){
      const element = el.currentTarget;
      element.classList.add('unactive')
    },




  //  Выбор года из списка
    periodSelection(el){
      const element = el.currentTarget
      const value = element.textContent
      const parent = element.closest('.js--wrapper-select')
      const container = parent.querySelector('.js--list-wrapper');
      const main_container = element.closest('.calculator_s__wrapper-salary')

      if(!element.classList.contains('active')){
        const swiper_btn_array = element.closest('.swiper-wrapper').querySelectorAll('.refinancing-calc__buttons-change')
        for(let item of swiper_btn_array){
          item.classList.remove('active')
        }
        element.classList.add('active')
      }

      const data_period = element.getAttribute('data-period')
      main_container.setAttribute('data-period',data_period)
      const array = main_container.querySelectorAll('.js--period-input-selected')
      for(let item=0;item<array.length;item++){
        let style = window.getComputedStyle(array[item]).getPropertyValue("display");
        if(style=='none'){
          array[item].querySelector('.js--salary-input input').value = ''
          // mask_array_2[item].value='';
        }
      }
      this.sendInputChange(element)


    },
    //Отправляю данный в state для дальнейшего расчёта
    sendInputChange(el){
      const parent = el.closest('.calculator_s__wrapper-salary')
      const array_input = parent.querySelectorAll('.js--period-input-selected')
      let sum_salary=0
      for(let item of array_input){
        let input = item.querySelector('input')
        if(window.getComputedStyle(item).getPropertyValue("display")=="flex"){
          let value = input.value.replace(/\s/g, '');
          if(value==''){
            value=0
          }
          if(value>this.stgMax){
            value=this.stgMax
          }
          value = parseInt(value)
          sum_salary=sum_salary+value
        }
      }

      Storage.dispatch('ActionSalaryForMarried',sum_salary.toFixed(0))


      // eventBus.$emit('pass_salary',tax_calculation)
    },
    inputFocus(el){
      const element = el.currentTarget
      element.querySelector('input').focus()
    },
  //подсчитываю данные при загрузке страницы
    dataPageLoad(){
      let input_data = this.value_salary.replace(/\s/g, '');
      input_data = parseInt(input_data)
      const tax_calculation = input_data*3
      Storage.dispatch('ActionSalaryForMarried',tax_calculation)
    },
    //получаю текущий год
    currentYear(){
      this.current_year = new Date().getFullYear()

    },

  },
  mounted(){
    this.dataPageLoad()
    this.inputCost()
    this.initSliderStoriesButton()
    this.currentYear()
  },
  created(){
    eventBus.$on('passYear',(param)=>{
      this.year_purchase=param
    })
    // eventBus.$on('event_SelectedMar',(param)=>{
    //   console.log(param);
    // })

  },
  computed:{},
  watch:{
    //как только стоимость квартиры изменилась, вызываю функцию
    realtySalary(){
      this.calculationPageLoad()
    },
    year_purchase(){
      const wrap_salary = document.querySelectorAll('.calculator_s__wrapper-salary')
      for(let item of wrap_salary){
        const input = item.querySelectorAll('.js--period-input-selected input')
        const period = item.querySelectorAll('.js--list-wrapper .select__list .js--select-item')
        for (let i = 0; i < period.length; i++) {
          period[i].classList.remove('unactive')
        }
        if(this.year_purchase<this.current_year - 3){
          item.querySelector('.js--list-wrapper .js--select-item[data-period="3"]').click()
        }
        if(this.year_purchase>=this.current_year - 3&&this.year_purchase<=this.current_year - 1){
          for (let i = 0; i < period.length; i++) {
            const data_year = period[i].getAttribute('data-year');
            if (data_year == this.year_purchase) {
              period[i].click();
              // this.inputCost();
            }
            if(this.year_purchase>data_year){
              period[i].setAttribute('style','pointer-events: none;')
            }
            if(this.year_purchase<=data_year){
              period[i].setAttribute('style','pointer-events: auto;')
            }

            else if(data_year < this.year_purchase){
              period[i].classList.add('unactive')
            }
          }
        }
        if (this.year_purchase >= this.current_year) {
          item.querySelector('.tax-deduction__period-input-select').setAttribute('style','display:none;')
          for (let i = 0; i < period.length; i++) {
            period[i].setAttribute('style','pointer-events: none;')
            period[i].classList.remove('active')
          }
          for (let i = 0; i < input.length; i++) {
            input[i].value = ''
            // mask_array_2[i].value='';
          }
          Storage.dispatch('ActionSalaryForMarried',0)
        }
        if(this.year_purchase<this.current_year){
          item.querySelector('.tax-deduction__period-input-select').setAttribute('style','display:flex;')
        }
        if(this.year_purchase<=this.current_year-3){
          for (let i = 0; i < period.length; i++) {
            period[i].setAttribute('style','pointer-events: auto;')
          }
        }

      }
    }
    // ss--
  },

  components:{
    ToolTip
  }
};
</script>
<style scoped>
</style>
