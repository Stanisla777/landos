<template lang="pug">
  .mortgage-surveys__final-block-refusal
    p.mortgage-surveys__final-attention.success.
      Спортивная организация или ИП есть в перечне Минспорта России
    .mortgage-surveys__finale-explanation
      p.
        Если вы оплачивали услугу в этом году, то налоговый вычет можно получить через работодателя. О порядке читайте ниже.
      p.
        Если вы оплачивали услугу в 2022 году, можете получить вычет через ФНС России: онлайн - <a target="_blank" href="https://lkfl2.nalog.ru/lkfl/">через личный кабинет
        налогоплательщика</a>, лично через МФЦ или в территориальном отделении ФНС России
</template>
<script>
import dropDown from '../../dropDown';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-component-success',
};
</script>
<style scoped>
</style>
