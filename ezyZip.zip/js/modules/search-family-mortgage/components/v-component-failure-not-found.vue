<template lang="pug">
  .mortgage-surveys__final-block-refusal
    p.mortgage-surveys__final-attention.error Упс, такой компании нет!
    .mortgage-surveys__finale-explanation
      p.
        Мы не нашли такой организации или ИП в перечне Минспорта России
      p.
        Подробности вы можете уточнить на <a target="_blank" href="http://minsport.gov.ru/activities/o-nalogovom-vychete-za-zanyatiya-sportom/">странице Минспорта России о налоговом вычете за спорт</a>
</template>
<script>

export default {
  name: 'v-component-failure-not-found',
};
</script>
<style scoped>
</style>
