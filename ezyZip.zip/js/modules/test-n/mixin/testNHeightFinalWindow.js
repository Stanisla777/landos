export default {
  props: {
  },
  data() {
    return {
    };
  },
  watch: {
  },
  created() {
  },
  methods: {
    heightFinalWindow() {
      // eslint-disable-next-line camelcase
      const swiper_wrapper = this.$refs.finalWindow.closest('.swiper-wrapper');
      setTimeout(() => {
        swiper_wrapper.style.height = 'auto';
      }, 500);
    }
  },
  mounted() {
    this.heightFinalWindow();
  }
};
