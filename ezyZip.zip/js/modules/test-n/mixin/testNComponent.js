export default {
  props: {
    options: {
      type: Array,
      required: true
    },
    isAnswered: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      answerValues: []
    };
  },
  watch: {
    answerValues() {
      if (this.answerValues.includes(true)) { // если хоть один вариант ответа выбран
        this.$emit('valuesIsChosen');
      } else {
        this.$emit('valuesIsUnchosen');
      }
    },
    isAnswered() {
      if (this.isAnswered) {
        this.prepareDataForSend();
      } else {
        this.setDefaultValues();
      }
    },
  },
  created() {
    this.setDefaultValues();
  },
  methods: {
    /**
     * Устанавливает длинну для массива ответов и задаёт дефолтные значения для них
     */
     setDefaultValues() {
      this.answerValues = new Array(this.options.length);
      this.answerValues.fill(false);
    }
  }
};
