<template lang="pug">
  .test-n(
    :class="themeColorClass"
    ref="testWrap"
  )
    .test-n__area-question-loader(
        :class="themeColorClass"
        v-if="loader"
      )
        .loader
          .circle.one
          .circle.two
          .circle.three

    .test-n__area-question(v-if="!final_window")
      h3.test-n__title {{ title }}
      p.test-n__description(v-if="isShowDescription" v-html="description")
      component(
        :is="typeOfTest"
        :is-answered="isAnswered"
        :options="options"
        :description="description"
        :id="id"
        @valuesIsChosen="setValues(true)"
        @valuesIsUnchosen="setValues(false)"
        @answerIsSetted="setAnswered()"
        @readyForDataSending="sendData"
      )
      .test-n__footer.js--test-footer(
        v-show="!isHideFooter"
        )
        .test-n__answer(v-if="isShowAnswer")
          h4.test-n__answer-title(v-if="answerTitle") {{ answerTitle }}
          p.test-n__answer-body(v-html="answerText")
        .test-n__controls(v-if="state_slider")
          button.polls__test-btn.btn_green-with-hover(
            v-if="isShowAnswerButton&&!isShowRestartButton"
            :class="{ disabled : isAnswerButtonDisabled }"
            @click="setAnswered"
          ) {{ buttonText }}
          button.polls__test-btn.btn_green-with-hover(
            v-if="isShowRestartButton"
            @click="restart()"
          ) Попробовать еще

      div.test-n__controls(v-if="!state_slider")
        button.btn_s.black(
          :class="[isAnswerButtonDisabled&&param_test.typeOfTest!=='slider'?'disabled':'']"
          :data-slider-question="[isAnswered&&param_test.typeOfTest==='slider'?'disabled':'']"
          @click="setAnswered()"
        ) {{ buttonText }}
        button.btn_s.transparent_black_border(
          @click="nextSlide"
          :class="{ disabled : !isAnswered }"
        ) Далее
    template(v-if="final_window&&final_window_view==='common'")
      final-window-usual(
        :final_window="final_window"
        :smile="smile"
        :final_text="final_text"
        :location_content_new="location_content_new"
      )
    template(v-if="final_window&&final_window_view==='marathon_2023'")
      final-window-marathon2023(
        :final_window="final_window"
        :smile="smile"
        :final_text="final_text"
        :percentage_responses="percentage_responses"
        :button_web_status="button_web_status"
        @repeatTest ="repeatTest"
        @eventloader ="showLoader"
      )



</template>

<script>
import Vue from 'vue';
import VueAxios from 'vue-axios';
import axios from 'axios';
import TestNSlider from './components/TestNSlider.vue';
import TestNImages from './components/TestNImages.vue';
import TestNMultipleChoice from './components/TestNMultipleChoice.vue';
import TestNPercent from './components/TestNPercent.vue';
import TestNDual from './components/TestNDual.vue';
import TextNChecBox from './components/TestNCheckBox.vue';
import TextNRadioBtn from './components/TestNRadioBtn.vue';
import FinalWindowUsual from './components/final-window/FinalWindowUsual.vue';
import FinalWindowMarathon2023 from './components/final-window/FinalWindowMarathon2023.vue';

Vue.use(VueAxios, axios);
const apiForGet = '/local/ajax/tests.php';
const apiForSend = '/api/local/polls/'; //'/local/ajax/add_tests.php';
// const apiForSend = 'https://httpbin.org/post';


export default {
  name: 'TestN',
  components: {
    'slider': TestNSlider,
    'images': TestNImages,
    'multiple-choice': TestNMultipleChoice,
    'percent': TestNPercent,
    'dual': TestNDual,
    'justcheckboxes':TextNChecBox,
    'justradio':TextNRadioBtn,
    FinalWindowUsual,
    FinalWindowMarathon2023
  },
  props: {
    id: { // нужен для запрашивания данных по api
      type: [String,Number],
      required: true
    }
  },
  // props:['id'],
  data() {
    return {
      typeOfTest: null, // тип теста, определяет какой компонент будет использоваться, может принимать значения: 'slider', 'images', 'multiple-choice', 'percent' или 'dual'
      colorTheme: 'black', // тип цветовой темы, может принимать значения: 'white', 'gray или 'black'
      title: null, // заголовок
      description: null, // описание/подзаголовок
      answerText: null, // текст ответа
      answerTitle: null, // заголовок ответа
      options: null, // настройки для дочернего компонента
      isAnswered: false, // был ли дан ответ (нажата кнопка проверки)
      isValuesChosen: false, // были ли выбраны ответы в тесте,
      buttonText: 'Проверить ответ', // текст кнопки проверки ответа
      param_test:null,
      state_slider:true,
      height_swiper:0,
      data_last_slide:false,
      final_window:false,
      final_window_view:'common', //расскоментировать
      // final_window_view:'marathon_2023', //убрать
      percentage_responses:null,
      smile:6,
      final_text:'<p>Вы прошли тест<p>',
      final_text_good:'<p>Отлично!</p><p>Вы на верном пути к званию гуру</p>',
      final_text_bad:'<p>Хорошая попытка!<p><p>Но есть с чем ознакомиться в уроке повторно</p>',
      loader:false,
      scroll_point:0,
      scroll_top:false,
      button_web_status:false,
      location_content_new:false
    }
  },
  computed: {
    isShowDescription() {
      return (this.typeOfTest !== 'dual' && this.description); // для типа теста "да/нет" описание не отображаем, для него оно идёт как пропс и отображается внутри него
    },
    isHideFooter() {
      return (this.typeOfTest === 'dual' && !this.isAnswered); // для типа теста "да/нет" отображаем футер только после ответа
    },
    isShowAnswerButton() {
      return this.typeOfTest !== 'dual'; // для типа теста "да/нет" не отображаем кнопку дефолтную кнопку ответа, так как он имеет две свои кнопки для ответа
    },
    isShowAnswer() {
      return this.answerText && this.isAnswered;
    },
    isAnswerButtonDisabled() {
      return this.isAnswered || !this.isValuesChosen;
    },
    isShowRestartButton() {
      return (this.typeOfTest !== 'percent' && this.isAnswered); // для типа теста с процентами кнопку сброса не отображаем, для остальных типов после ответа
    },
    /**
     * В зависимости от типа цветовой темы добавляет соответствующий класс. Для дефолтной чёрной темы класс не добавляем
     */
    themeColorClass() {
      return {
        'test-n_white': this.colorTheme === 'white',
        'test-n_gray': this.colorTheme === 'gray'
      };
    }
  },

  methods: {
    //Для разработки
    forDevelopment(){

      const { typeOfTest, options, title, description, end_text, end_title, btn, colorTheme } = this.param_test;
      this.typeOfTest = typeOfTest;
      this.options = options;
      this.title = title;
      this.description = description;
      this.answerText = end_text;
      this.answerTitle = end_title;
      if (btn) this.buttonText = btn; // если условие не выполнено, то останется дефолтный текст
      if (colorTheme) this.colorTheme = colorTheme; // если условие не выполнено, то останется дефолтная тема
    },


    /**
     * Запрашивает данные по api, заносит их в data
     */
    getData() {
      axios.get(apiForGet, {
        params:{
          id: this.id
        }
      })
        .then((res) => {
          const { typeOfTest, options, title, description, end_text, end_title, btn, colorTheme } = res.data;
          this.typeOfTest = typeOfTest;
          this.options = options;
          this.title = title;
          this.description = description;
          this.answerText = end_text;
          this.answerTitle = end_title;
          if (btn) this.buttonText = btn; // если условие не выполнено, то останется дефолтный текст
          if (colorTheme) this.colorTheme = colorTheme; // если условие не выполнено, то останется дефолтная тема
        })
        .catch((err) => {
          console.error(err);
        });
    },
    /**
     * Отправляет данные
     * @param data
     */
    sendData(data) {
      const wr_polls_swiper = this.$refs.testWrap.closest('.js--test-polls-swiper')
      if(wr_polls_swiper){
        const data_correct_answers = this.$refs.testWrap.closest('.js--test-polls-swiper').getAttribute('data-correct-answers')
        //Картинки
        if(data.imagesWithAnswers!==undefined){
          let count_correct_answers = 0
          let count_selected_correct_answers = 0
          let count_selected_failed_answers = 0
          for (let keys in data.imagesWithAnswers) {
            if (data.imagesWithAnswers[keys].isCorrect === true) count_correct_answers++
            if (data.imagesWithAnswers[keys].isCorrect === true&&data.imagesWithAnswers[keys].isChosen === true) count_selected_correct_answers++
            if (data.imagesWithAnswers[keys].isCorrect === false&&data.imagesWithAnswers[keys].isChosen === true) count_selected_failed_answers++
          }
          // console.log(count_selected_failed_answers);

          if(count_correct_answers==count_selected_correct_answers&&count_selected_failed_answers==0){
            this.$refs.testWrap.closest('.js--test-polls-swiper').setAttribute('data-correct-answers',parseInt(data_correct_answers)+1)
          }
        }
        //Простые чекбоксы
        if(data.checkBoxWithAnswers!==undefined){
          let count_correct_answers = 0
          let count_selected_correct_answers = 0
          let count_selected_failed_answers = 0
          for (let keys in data.checkBoxWithAnswers) {
            if (data.checkBoxWithAnswers[keys].isCorrect === true) count_correct_answers++
            if (data.checkBoxWithAnswers[keys].isCorrect === true&&data.checkBoxWithAnswers[keys].isChosen === true) count_selected_correct_answers++
            if (data.checkBoxWithAnswers[keys].isCorrect === false&&data.checkBoxWithAnswers[keys].isChosen === true) count_selected_failed_answers++
          }

          if(count_correct_answers==count_selected_correct_answers&&count_selected_failed_answers==0){
            this.$refs.testWrap.closest('.js--test-polls-swiper').setAttribute('data-correct-answers',parseInt(data_correct_answers)+1)
          }
        }
        //Простые радиокнопки
        if (data.radioBtnWithAnswers !== undefined) {
          let count_correct_answers = 0;
          for (let keys in data.radioBtnWithAnswers) {
            if (data.radioBtnWithAnswers[keys].isCorrect === true && data.radioBtnWithAnswers[keys].isChosen === true) {
              this.$refs.testWrap.closest('.js--test-polls-swiper')
                .setAttribute('data-correct-answers', parseInt(data_correct_answers) + 1);
            }
          }
          // this.$refs.testWrap.closest('.js--test-polls-swiper').setAttribute('data-correct-answers',parseInt(data_correct_answers)+1)

        }

        if(data.isAnswerValueCorrect!==undefined){
          if(data.isAnswerValueCorrect===true){
            this.$refs.testWrap.closest('.js--test-polls-swiper').setAttribute('data-correct-answers',parseInt(data_correct_answers)+1)
          }
        }
        if(data.answerValuesWithText!==undefined){

          let count_answers = (data.answerValuesWithText).length
          let count_selected_correct_answers = 0
          for (let keys in data.answerValuesWithText) {
            if (data.answerValuesWithText[keys].isCorrect==data.answerValuesWithText[keys].isChosen) count_selected_correct_answers++
          }

          //
          if(count_selected_correct_answers==count_answers){
            this.$refs.testWrap.closest('.js--test-polls-swiper').setAttribute('data-correct-answers',parseInt(data_correct_answers)+1)
          }
        }

        //percent
        if(data.textsOfChosenValues!==undefined){
          this.$refs.testWrap.closest('.js--test-polls-swiper').setAttribute('data-correct-answers',parseInt(data_correct_answers)+1)
        }


        // console.log(this.$refs.testWrap.closest('.js--test-polls-swiper').getAttribute('data-correct-answers'));
      }


      data.id = this.id; // добавляем id теста
      data.typeOfTest = this.typeOfTest; // добавляем тип теста
      data.URL = document.URL; // добавляем url страницы

      axios({
        method: 'post',
        url: apiForSend,
        headers: {
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
        },
        data: data
      }).catch((error)=> {
        console.log(error);
      });
    },
    setAnswered() {
      this.isAnswered = true;
      this.scroll_point = window.scrollY


      const elementRect = this.$refs.testWrap.getBoundingClientRect();
      const elementHidesUp = elementRect.top < 0;
      const elementHidesLeft = elementRect.left < 0;
      const elementHidesDown = elementRect.bottom > window.innerHeight;
      const elementHidesRight = elementRect.right > window.innerWidth;
      const elementHides = elementHidesUp || elementHidesLeft || elementHidesDown || elementHidesRight;
      if(elementHides){
        this.scroll_top=true
      }

      setTimeout(()=>{
        const element = this.$refs.testWrap
        const parent = element.closest('.swiper-wrapper')
        const parent_slide = element.closest('.swiper-slide')
        if(parent){
          const footer_height = parent.querySelector('.js--test-footer')
          const height_footer = footer_height.offsetHeight
          const height_swiper = parent.offsetHeight

          this.height_swiper = height_swiper
          const height = height_footer+height_swiper
          // parent.style.height=`${height}px`
          parent.style.height=`auto`
        }

        if(parent_slide&&!this.state_slider){
          const data_last_slide = parent_slide.getAttribute('data-last-slide')
          if(data_last_slide=='true'){
           this.data_last_slide=true
          }
        }
      },10)
      //моя доработка


    },
    restart() {
      this.isAnswered = false;
      setTimeout(()=>{
        const element = this.$refs.testWrap
        const parent = element.closest('.swiper-wrapper')
        if(parent){
          parent.style.height=`${this.height_swiper}px`
        }
      },10)
    },
    /**
     * устанавливает isValuesChoosen в true/false
     * @param {Boolean} value
     */
    setValues(value) {
      this.isValuesChosen = value;
    },
    //Мои правки
    nextSlide(el) {

      this.isAnswered=false
      this.isValuesChosen=false
      const element = el.currentTarget;
      const parent = element.closest('.js--test-polls-swiper');
      const offsetTop = parent.offsetTop;
      if (parent && !this.data_last_slide) {

        const btn_next = parent.querySelector('.js--next-slide');
        if (btn_next) {
          btn_next.click();
          if (!this.scroll_top) {
            window.scrollTo({ top: this.scroll_point, behavior: 'smooth'});
          } else{
            parent.scrollIntoView({
              behavior: 'smooth',
              block: 'start'
            });
          }
        }
      }
      if (parent && this.data_last_slide) {
        let final_text_attr = parent.getAttribute('data-final-text');
        if (final_text_attr != null) {
          final_text_attr = JSON.parse(final_text_attr);
        }
        const count_final_text = final_text_attr.length;
        let final_window_view = parent.getAttribute('data-final-window');

        if (final_window_view != null) {
          this.final_window_view=final_window_view
        }
        this.loader=true
        setTimeout(()=>{
          this.loader=false
        },1500)
        this.final_window=true
        parent.querySelector('.js-test-pagination').classList.remove('active')
        setTimeout(()=>{
          const final_text = parent.querySelector('.js--wr-correct_answers')
          const array_slider =parent.querySelectorAll('.swiper-slide')
          const height = (array_slider[array_slider.length-1]).offsetHeight;
          // parent.querySelector('.swiper-wrapper').style.height=`auto`
          if (!this.scroll_top) {
            window.scrollTo({ top: this.scroll_point, behavior: 'smooth'});
          } else{
            parent.scrollIntoView({
              behavior: 'smooth',
              block: 'start'
            });
          }
          if(final_text){

            const correct_answers = parent.getAttribute('data-correct-answers')
            const count_questions = parent.getAttribute('data-slide')
            final_text.querySelector('span:first-child').textContent = correct_answers
            final_text.querySelector('span:last-child').textContent = count_questions


            const percentage_responses = (parseInt(correct_answers)*100)/count_questions
            this.percentage_responses=percentage_responses

            if(this.final_window_view==='marathon_2023'){
              if(percentage_responses<100&&final_text_attr!=null){
                this.final_text=final_text_attr[0]
              }
              if(percentage_responses===100&&final_text_attr!=null){
                this.final_text=final_text_attr[1]
              }
            }

            else {
              if(count_final_text===6){
                if(percentage_responses===0&&final_text_attr!=null){
                  this.final_text=final_text_attr[0]
                }
                if(percentage_responses>=1&&percentage_responses<=25&&final_text_attr!=null){
                  this.final_text=final_text_attr[1]
                }
                if(percentage_responses>=26&&percentage_responses<=50&&final_text_attr!=null){
                    this.final_text=final_text_attr[2]
                }
                if(percentage_responses>=51&&percentage_responses<=75&&final_text_attr!=null){
                    this.final_text=final_text_attr[3]
                }
                if(percentage_responses>=76&&percentage_responses<=99&&final_text_attr!=null){
                    this.final_text=final_text_attr[4]
                }
                if(percentage_responses===100&&final_text_attr!=null){
                    this.final_text=final_text_attr[5]
                }
              }
              else if(count_final_text<6){
                const count_range = 100/count_final_text
                let range=0
                for (let i = 0; i < count_final_text; i++) {
                  range = count_range * i;
                  if (percentage_responses < range) {
                    break;
                  }
                  this.final_text=final_text_attr[i]
                }
              }


            }

            if(percentage_responses===0){
              this.smile=1
            }
            if(percentage_responses>=1&&percentage_responses<=25){
              this.smile=2
            }
            if(percentage_responses>=26&&percentage_responses<=50){
              this.smile=3
            }
            if(percentage_responses>=51&&percentage_responses<=75){
              this.smile=4
            }
            if(percentage_responses>=76&&percentage_responses<=99){
              this.smile=5
            }
            if(percentage_responses===100){
              this.smile=6
            }
          }
        },10)
      }
    },
    repeatTest(element){
      const parent = element.closest('.js--test-polls-swiper');
      if (parent) {
        parent.setAttribute('data-correct-answers',0)
        const count_questions = parent.getAttribute('data-slide')
        const btn_repeat = parent.querySelector('.js--prev-slide');
        if(btn_repeat){
          this.$forceUpdate()
          this.final_window=false
          btn_repeat.click();
          if(parent.querySelector('.js-test-pagination')){
            parent.querySelector('.js-test-pagination').classList.add('active')
          }
        }
      }
    },
    showLoader(event){
      this.loader=event
    }

  },
  mounted() {
    //Старый вызов метода
    // this.getData();
    // Узнаю сколько слайдов в слайдере
    const wrap_slide = this.$el.closest('.js--test-polls-swiper')
    if(wrap_slide){
      const count_slider = wrap_slide.getAttribute('data-slide')

      if(count_slider==1||count_slider==0){
        this.state_slider=true
      }
      else {
        this.state_slider=false
      }
      setTimeout(()=>{
        const element = this.$el.querySelector('.test-n__title')
        const style = getComputedStyle(element)
        wrap_slide.querySelector('.js-test-pagination').style.color=style.color
      },10)
    }
    else{
      this.state_slider=true
    }

    if(this.$attrs.param!==undefined&&this.$attrs.param!==''){
      this.param_test = JSON.parse(this.$attrs.param)
      this.forDevelopment()
    }
    else {
      this.getData();
    }

    window.addEventListener('online', () => {
      this.button_web_status=false
    });
    window.addEventListener('offline', () => {
      this.button_web_status=true
    });

    if(this.$el.closest('.content-block-new')) {
      this.location_content_new = true
    }


    //  -----------------------------------------------------

  },
}
</script>
