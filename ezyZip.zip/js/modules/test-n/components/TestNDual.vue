<template lang="pug">
  .test-n-dual
    .test-n-dual__image(v-if="options.imageSrc" :class="setImageClasses()")
      img(
        :src="options.imageSrc"
        :alt="options.text"
      )
    p.test-n-dual__text(v-if="description" v-html="description")
    .test-n-dual__footer(ref="dualBtn")
      button.polls__test-btn.test-n-dual__button(@click="setAnswerValue($event,true)") {{ buttonYesText }}
      button.polls__test-btn.test-n-dual__button(@click="setAnswerValue($event,false)") {{ buttonNoText }}
</template>

<script>
export default {
  name: 'TextNDual',
  props: {
    options: {
      type: Object,
      required: true
    },
    isAnswered: {
      type: Boolean,
      default: false
    },
    description: {
      type: String,
      default: null
    }
  },
  data() {
    return {
      answerValue: null,
      index_elem:null,
      array_btn:[
        false,false
      ]
    }
  },
  computed: {
    buttonYesText() {
      return this.options.btn_yes ? this.options.btn_yes : 'Да';
    },
    buttonNoText() {
      return this.options.btn_no ? this.options.btn_no : 'Нет';
    },
    isAnswerValueCorrect() {
      if (typeof this.answerValue === 'boolean') return this.answerValue === this.options.correctAnswer;
    }
  },
  watch: {
    answerValue() {
      if (typeof this.answerValue === 'boolean') { // если выбран вариант ответа
        this.$emit('valuesIsChosen');
        // this.$emit('answerIsSetted');
      }
    },
    isAnswered() {
      this.isAnswered ? this.prepareDataForSend() : this.setAnswerValue(null);
      // if(this.isAnswered){
      //   this.prepareDataForSend()
      // }
      // else {
      //   this.setAnswerValue(null)
      // }

    },
  },
  methods: {
    setAnswerValue(el,value) {
      if(!this.isAnswered){
      const array_btn = this.$refs.dualBtn.querySelectorAll('.polls__test-btn')
      for (let i = 0; i < array_btn.length; i++) {
        array_btn[i].classList.remove('correct-answer');
        array_btn[i].classList.remove('uncorrect-answer');
        array_btn[i].classList.remove('uncorrect-answer');
        array_btn[i].classList.remove('correct-answer');
        array_btn[i].classList.remove('active_dual');
        array_btn[i].style.pointerEvents = 'auto';
      }
    }

      if(el!==null){
        const element = el.currentTarget;
        this.index_elem = [...element.parentNode.children].indexOf(element);
        const array_btn = this.$refs.dualBtn.querySelectorAll('.polls__test-btn')
        for(let item of array_btn){
          item.classList.remove('active_dual')
        }
        element.classList.add('active_dual')
        this.answerValue = value;
        this.$emit('valuesIsChosen');
      }

    },
    setImageClasses() {
      const classesObj = {
        'test-n-dual__image_correct': this.isAnswerValueCorrect,
        'test-n-dual__image_uncorrect': !this.isAnswerValueCorrect
      };
      return this.isAnswered ? classesObj : {};
    },
    prepareDataForSend() {
      // console.log(this.isAnswerValueCorrect);
      const array_btn = this.$refs.dualBtn.querySelectorAll('.polls__test-btn')
      for(let i=0;i<array_btn.length;i++){
        if(array_btn[i].classList.contains('active_dual')&&this.isAnswerValueCorrect){
          array_btn[i].classList.add('correct-answer')
        }
        else if((!array_btn[i].classList.contains('active_dual')&&this.isAnswerValueCorrect)) {
          array_btn[i].classList.add('uncorrect-answer')
        }

        if(array_btn[i].classList.contains('active_dual')&&!this.isAnswerValueCorrect){
          array_btn[i].classList.add('uncorrect-answer')
        }
        else if((!array_btn[i].classList.contains('active_dual')&&!this.isAnswerValueCorrect)) {
          array_btn[i].classList.add('correct-answer')
        }
        array_btn[i].style.pointerEvents='none'
      }
      const data = {
        isAnswerValueCorrect: this.isAnswerValueCorrect
      };
      this.$emit('readyForDataSending', data);
    }
  }
}
</script>
