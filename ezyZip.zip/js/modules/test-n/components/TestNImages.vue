<template lang="pug">
  .test-n-images
    .test-n-images__item(v-for="(option, index) in options" :key="option.imageSrc")
      label(:class="{ disabled: isAnswered }")
        input(
          v-model="answerValues[index]"
          :disabled="isAnswered"
          type="checkbox"
        )
        .test-n-images__image(:class="setImageClasses(index)")
          img(:src="option.imageSrc" :alt="option.text")
      p.test-n-images__description(v-if="option.text") {{ option.text }}
</template>

<script>
import testNComponent from '../mixin/testNComponent.js';

export default {
  name: 'TextNImages',
  mixins: [testNComponent],
  computed: {
    imagesWithAnswers() { // все изображения с отметкой были лы выбраны
      const images = [];
      if (this.isAnswered) {
        this.options.forEach((image, index) => {
          const imageWithAnswer = { // создаём новый объект чтобы не изменять исходные данные
            isChosen: this.answerValues[index]
          }
          Object.assign(imageWithAnswer, image); // копируем свойства исходных данных
          images.push(imageWithAnswer);
        });
      }
      return images;
    }
  },
  methods: {
    setImageClasses(index) {
      const classesObj = {
        'test-n-images__image_correct': this.options[index].isCorrect, // если картинка верная
        'test-n-images__image_uncorrect': !this.options[index].isCorrect, // если картинка неверная
        'test-n-images__image_answered': this.answerValues[index] === true, // если картинка была выбрана
      };
      return this.isAnswered ? classesObj : {};
    },
    prepareDataForSend() {
      const data = {
        imagesWithAnswers: this.imagesWithAnswers
      };
      this.$emit('readyForDataSending', data);
    }
  }
}
</script>
