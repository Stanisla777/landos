<template lang="pug">
  .test-n__area-final-window(ref="finalWindow")
    .test-n__emoticon(v-if="smile==1")
      img(src="/dist/img/emoji-1.svg")
    .test-n__emoticon(v-if="smile==2")
      img(src="/dist/img/emoji-2.svg")
    .test-n__emoticon(v-if="smile==3")
      img(src="/dist/img/emoji-3.svg")
    .test-n__emoticon(v-if="smile==4")
      img(src="/dist/img/emoji-4.svg")
    .test-n__emoticon(v-if="smile==5")
      img(src="/dist/img/emoji-5.svg")
    .test-n__emoticon(v-if="smile==6")
      img(src="/dist/img/emoji-6.svg")

    .test-n__title.center Тест завершен
    p.test-n__correct_answers.js--wr-correct_answers.center.
      Правильных ответов: <span>0</span>/<span>0</span>
    .test-n__area-final-window-status(v-if="percentage_responses===100")
      .test-n__area-final-window-des.test-n__area-final-window-des-marathon2023
        p(v-html="final_text")
      div(v-if="!sending_data")
        .test-n__area-final-window-wr-call-action
          p.test-n__area-final-window-title-call-action Хотите получить сертификат? Оставьте email
        .test-n__area-final-window-wr-sand(ref="windowWrSand")
          .test-n__area-final-window-wr-input.js--validate-mask-parent
            input.test-n__area-final-window-sand-input.js--validate-mask-email-form(
              ref="mailInput"
              type="text"
              inputmode="email"
              placeholder="Введите email"
              @focus="activeInput"
              @blur="UnActiveInput"
              @keyup="inputValue"
              )
            p.test-n__area-final-window-error.js--validate-mask-error Недопустимый символ
            p.test-n__area-final-window-error.js--validate-mask-error-format {{error_format}}
          button.polls__test-btn.btn_green-with-hover(
            type="button"
            v-if="this.validation_state_check+this.validation_state_input===2&&this.button_web_status===false"
            @click="sendingData"
          ) Отправить
          button.polls__test-btn.btn_green-with-hover.disabled(
            type="button"
            v-if="this.validation_state_check+this.validation_state_input!==2||this.button_web_status===true"
            @click="attemptSend"
          ) Отправить
          .test-n__area-final-window-checbox
            .checkbox-stylized.checkbox-stylized-wr
              .personal-office__user-form-subscription-em
              .personal-office__user-form-block
                input#perinfo(
                  type="checkbox"
                  @change="changeCheckbox"
                  )
                label(for="perinfo")
                  p Даю согласие на обработку
                  <a href="/user-agreement/#user-agreement" target="_blank">персональных данных</a>

            p.test-n__area-final-window-error.js--validate-chek Согласитесь с условиями
          p.test-n__error(v-if="button_web_status===true") {{internet_fail}}

      .test-n__sending-result(v-if="sending_data && sand_status===0")
        p Спасибо!
        p Сертификат отправлен
      .test-n__sending-result.error(v-if="sending_data && sand_status===1")
        //p Ошибка!
        p(v-html="text_error")
    .test-n__area-final-window-status(v-if="percentage_responses<100")
      .test-n__area-final-window-des.test-n__area-final-window-des-marathon2023
        p(v-html="final_text")
      .test-n__area-final-window-center
        button.polls__test-btn.btn_green-with-hover(@click="repeatTest") Пройти тест еще раз
    #yandex-captcha-final-window-2023
</template>

<script>
import validationSet from '../../../validation-set/validation-set'
import testNHeightFinalWindow from '../../mixin/testNHeightFinalWindow.js';
import axios from 'axios';
export default {
  name: 'FinalWindowMarathon2023',
  props: ['final_window','smile','final_text','percentage_responses','button_web_status'],
  data() {
    return {
      value_input:'',
      validation_state_check:0,
      validation_state_input:0,
      sending_data:false,
      sand_status:null,
      text_error:'Попробуйте ещё раз',
      error_format:'Введите корректный e-mail',
      internet_fail:'Отсутствует подключение к интернету',
      captcha_id:null
    }
  },
  mixins: [testNHeightFinalWindow],
  computed: {

  },
  watch: {

  },
  methods: {
    iMaskMail(){
      validationSet()
    },
    activeInput(el){
      const element = el.currentTarget
      element.classList.add('active')
    },
    UnActiveInput(el){
      const element = el.currentTarget
      const parent = element.closest('.js--validate-mask-parent')
      if(element.value.length===0){
        element.classList.remove('active')
      }
      if(parent&&parent.querySelector('.js--validate-mask-error')){
        parent.querySelector('.js--validate-mask-error').classList.remove('active')
      }
      if (!element.value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)
        &&element.value.length!==0) {
        if (parent) {
          parent.querySelector('.js--validate-mask-error-format').classList.add('active')
        }
      }
    },
    inputValue(el){
      const element = el.currentTarget
      const parent = element.closest('.js--validate-mask-parent')
      parent.querySelector('.js--validate-mask-error-format').classList.remove('active')
      if (!element.value.match(/^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/i)) {
        if(this.validation_state_input>0){
          this.validation_state_input-=1
        }
      }
      else {
        if(this.validation_state_input===0){
          this.validation_state_input+=1
        }
      }
    },
    changeCheckbox(el){
      const element = el.currentTarget
      if (element.checked){
        this.validation_state_check+=1
        this.$refs.windowWrSand.querySelector('.js--validate-chek').classList.remove('active');
      }
      else {
        this.validation_state_check-=1
      }
    },
    repeatTest(el){
      const element = el.currentTarget;
      this.$emit('repeatTest',element)
    },

    //Отправка мэйла
    //яндекс капча
    captchaInit(element) {
      this.captcha_id = window.smartCaptcha.render('yandex-captcha-final-window-2023', {
        sitekey: conf.smartcaptcha_key,
        invisible: true,
        callback: (token) => {
          this.functionSendingData(element,token)
        },
      });
    },


    sendingData(el){
      const element = el.currentTarget
      this.captchaInit(element);
      let recaptchaKey = null;
      if (typeof conf !== 'undefined') {
        recaptchaKey = conf.smartcaptcha_key;
      }
      if ((typeof recaptchaKey !== 'undefined') && recaptchaKey !== null) {
        window.smartCaptcha.execute(this.captcha_id);
      }
      else {
        this.functionSendingData(element)
      }

      // if(typeof conf !== 'undefined'){
      //  recaptchaKey = conf.reCAPTCHA_site_key
      // }

      // if (typeof recaptchaKey !== 'undefined'&& (typeof grecaptcha !== 'undefined')) {
      //   grecaptcha.ready(() => {
      //     grecaptcha.execute(recaptchaKey).then((token) => {
      //       this.functionSendingData(element,token)
      //     });
      //   });
      // }
      // else {
      //   this.functionSendingData(element)
      // }
    },
    functionSendingData(element, token=''){
      let obj={}

      let massive_inputValues=[]
      let obj_inputValues={}

      obj_inputValues.EMAIL=this.$refs.mailInput.value
      obj_inputValues['smart-token']=token
      obj.inputValues=obj_inputValues
      obj_inputValues={}

      obj.id='1_1'
      obj.typeOfTest='marathon'


      this.$emit('eventloader',true)
      axios({
        method:'post',
        // url:'https://httpbin.org/post', //для тестирования
        url:'/api/local/polls/',

        headers: {
          "Content-type": "application/json; charset=UTF-8",
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(), //раскомментировать
        },
        data:obj
      })
        // Если запрос успешен
        .then((res) => {
          this.functionResultSand(element,0,'')
          setTimeout(()=>{
            this.$emit('eventloader',false)
            obj={}
          },1000)

        })
        // обработка ошибок
        .catch((error)=> {
          console.log('ошибка - ' + error);
          if (error.response) {
            if (error.response.status == 401 || error.response.status == 403) {
              this.functionResultSand(element,1,`Время сессии истекло, перезагрузите страницу`)
            } else {
              if (error.response && error.response.data.error != undefined && error.response.data.error.description) {
                this.functionResultSand(element,1,error.response.data.error.description) // вызываю ошибку
              } else {
                this.functionResultSand(element,1,`Ошибка. Обратитесь в колл-центр.`) // вызываю ошибку
              }
            }
          } else if (error.request) {
            console.log(error.request);
            this.functionResultSand(element,1,`Нет связи с сервером`) // вызываю ошибку
          }
          setTimeout(()=>{
            this.$emit('eventloader',false)
            obj={}
          },1000)
        });
    },

    //Вызов В случае успешной отправки
    functionResultSand(element,status,text_error){
      const swiper_wrapper = element.closest('.swiper-wrapper')
      const promice = new Promise((resolve,reject)=> {
        this.sending_data=true
        this.sand_status=status
        this.text_error=text_error
        resolve()
      }).then(()=>{
        return new Promise((resolve,reject)=> {
          setTimeout(()=>{
            swiper_wrapper.style.height = 'auto';
            resolve()
          },10)

        })
      })
    },


    //попытка отправки мэйла, когда поля не заполнены
    attemptSend(){
      if(this.validation_state_input===0){
        this.$refs.windowWrSand.querySelector('.js--validate-mask-error').classList.remove('active');
        this.$refs.windowWrSand.querySelector('.js--validate-mask-error-format').classList.add('active');
      }
      if(this.validation_state_check===0){
        this.$refs.windowWrSand.querySelector('.js--validate-chek').classList.add('active');
      }


    }



  },
  mounted() {
    const swiper_wrapper = this.$refs.finalWindow.closest('.swiper-wrapper');
    const parent = this.$refs.finalWindow.closest('.test-n')
    const style_container = window.getComputedStyle(swiper_wrapper)
    const style_transform = style_container.getPropertyValue('transform');
  },
  updated() {
    this.iMaskMail()
  }
}
</script>
