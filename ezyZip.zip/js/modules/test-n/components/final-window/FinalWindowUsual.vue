<template lang="pug">
  .test-n__area-final-window(ref="finalWindow")
    .test-n__emoticon(v-if="smile==1")
      img(src="/dist/img/emoji-1.svg")
    .test-n__emoticon(v-if="smile==2")
      img(src="/dist/img/emoji-2.svg")
    .test-n__emoticon(v-if="smile==3")
      img(src="/dist/img/emoji-3.svg")
    .test-n__emoticon(v-if="smile==4")
      img(src="/dist/img/emoji-4.svg")
    .test-n__emoticon(v-if="smile==5")
      img(src="/dist/img/emoji-5.svg")
    .test-n__emoticon(v-if="smile==6")
      img(src="/dist/img/emoji-6.svg")

    .test-n__title.center Тест завершен
    p.test-n__correct_answers.js--wr-correct_answers.center.
      Правильных ответов: <span>0</span>/<span>0</span>
    .test-n__area-final-window-des(v-html="final_text")
</template>

<script>
import testNHeightFinalWindow from '../../mixin/testNHeightFinalWindow.js';
export default {
  name: 'FinalWindowUsual',
  props: ['final_window','smile','final_text','location_content_new'],
  data() {
    return {

    }
  },
  mixins: [testNHeightFinalWindow],
  computed: {

  },
  watch: {
    location_content_new() {
      if (this.location_content_new) {
        this.$el.closest('.test-n').setAttribute('style','padding-top:24px;')
      }
    }
  },
  methods: {

  },
  mounted() {

  }
}
</script>
