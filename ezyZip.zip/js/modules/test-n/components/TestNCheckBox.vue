<template lang="pug">
  .test-n-percent
    //.test-n-images__item(v-for="(option, index) in options" :key="index")

    label.test-n-multiple-choice__checkbox-wrap.test-n-just-checkbox__label(
      v-for="(option, index) in options" :key="index"
    )
      .test-n-just-checkbox(:class="setCheckboxClasses(index)")
        input(
          v-model="answerValues[index]"
          :disabled="isAnswered"
          type="checkbox"
        )
        .test-n-just-checkbox__icon
      p.test-n-percent__text(v-if="option.text") {{ option.text }}



      //label(:class="{ disabled: isAnswered }")
      //  input(
      //    v-model="answerValues[index]"
      //    :disabled="isAnswered"
      //    type="checkbox"
      //  )
      //  .test-n-images__image(:class="setImageClasses(index)")
      //    img(:src="option.imageSrc" :alt="option.text")
      //p.test-n-images__description(v-if="option.text") {{ option.text }}
</template>

<script>
import testNComponent from '../mixin/testNComponent.js';

export default {
  name: 'TextNChecBox',
  mixins: [testNComponent],
  computed: {
    imagesWithAnswers() { // все изображения с отметкой были лы выбраны
      const images = [];
      if (this.isAnswered) {
        this.options.forEach((image, index) => {
          const imageWithAnswer = { // создаём новый объект чтобы не изменять исходные данные
            isChosen: this.answerValues[index]
          }
          Object.assign(imageWithAnswer, image); // копируем свойства исходных данных
          images.push(imageWithAnswer);
        });
      }
      return images;
    }
  },
  methods: {
    /**
     * Устанавливает классы для отображения правильных/неправильных и выбранных ответов
     * @param {Number} index - индекс ответа/вопроса
     */
    setCheckboxClasses(index) {
      const classesObj = {
        'correct': this.options[index].isCorrect, // если картинка верная
        'uncorrect': !this.options[index].isCorrect, // если картинка неверная
        // 'test-n-real-checkbox__answered': this.answerValues[index] === true, // если картинка была выбрана
      };
      return this.isAnswered ? classesObj : {};
    },
    /**
     * Подготавливает необходимые данные и вызывает событие для отправки
     */
    prepareDataForSend() {
      const data = {
        checkBoxWithAnswers: this.imagesWithAnswers
      };
      this.$emit('readyForDataSending', data);
    }
  }
}
</script>
