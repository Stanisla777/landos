<template lang="pug">
  .test-n-percent(ref="radioBtn")
    //.test-n-images__item(v-for="(option, index) in options" :key="index")

    label.test-n-multiple-choice__checkbox-wrap.test-n-just-checkbox__label.js--test-n-radio-label(
      v-for="(option, index) in options" :key="index"
    )
      .test-n-radio-btn.js--test-n-radio
        input(
          :data-index='index'
          type="radio"
          :name="id"
          :value="option.text"
          @change="changeRadioBtn"
        )
        .test-n-radio-btn__icon
      p.test-n-percent__text(v-if="option.text") {{ option.text }}
</template>

<script>
import testNComponent from '../mixin/testNComponent.js';

export default {
  name: 'TextNRadioBtn',
  // mixins: [testNComponent],
  props: {
    id: {
      type: [String,Number],
      required: true
    },
    options: {
      type: Array,
      required: true
    },
    isAnswered: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      answerValue: null,
      answerRadio:[]

    }
  },
  methods: {
    changeRadioBtn(el){
      const element=el.currentTarget
      this.$emit('valuesIsChosen');
      const ind = element.getAttribute('data-index')
      this.answerRadio=[]
      const array_obj = {}

      for (let i = 0; i < this.options.length; i++) {
        this.answerRadio.push(this.options[i]);
        if (i != ind) {
          this.answerRadio[i].isChosen = false;
        } else {
          this.answerRadio[i].isChosen = true;

        }
      }


      // array_obj.text = element.value
      // array_obj.isCorrect = this.options[ind].isCorrect
      // array_obj.isChosen=true
      // this.answerRadio.push(array_obj)



      // this.answerRadio.text = element.value
      //
      // this.answerRadio.isCorrect=this.options[ind].isCorrect
      // this.answerRadio.isChosen=true
    },


    setAnswerValue(value) {
      this.answerValue = value;
    },
    /**
     * Устанавливает класс картинке для отображения правильного/неправильного ответа
     */
    setImageClasses() {
      const classesObj = {
        'test-n-dual__image_correct': this.isAnswerValueCorrect,
        'test-n-dual__image_uncorrect': !this.isAnswerValueCorrect
      };
      return this.isAnswered ? classesObj : {};
    },
    /**
     * Подготавливает необходимые данные и вызывает событие для отправки
     */
    prepareDataForSend() {
      const array_radio = this.$refs.radioBtn.querySelectorAll('.js--test-n-radio')
      for(let i=0;i<array_radio.length;i++){
        if(this.options[i].isCorrect==true){
          array_radio[i].classList.add('correct')
        }
        else {
          array_radio[i].classList.add('uncorrect')
        }

      }
      const data = {
        radioBtnWithAnswers: this.answerRadio
      };
      this.$emit('readyForDataSending', data);
    }
  },
  computed: {

    isAnswerValueCorrect() {

    }
  },
  watch: {
    answerValue() {
      if (typeof this.answerValue === 'boolean') { // если выбран вариант ответа
        this.$emit('valuesIsChosen');
        this.$emit('answerIsSetted');
      }
    },
    isAnswered() {
      if(this.isAnswered){
        const array_radio = this.$refs.radioBtn.querySelectorAll('.js--test-n-radio-label')
        for (let item of array_radio){
          item.style.pointerEvents='none'
        }
        this.prepareDataForSend()
      }
      if(!this.isAnswered){
        const array_radio = this.$refs.radioBtn.querySelectorAll('.js--test-n-radio-label')
        for (let item of array_radio){
          item.style.pointerEvents='auto'
          if(item.querySelector('.js--test-n-radio').classList.contains('uncorrect')){
            item.querySelector('.js--test-n-radio').classList.remove('uncorrect')
          }
          if(item.querySelector('.js--test-n-radio').classList.contains('correct')){
            item.querySelector('.js--test-n-radio').classList.remove('correct')
          }
          if(item.querySelector('input:checked')){
            item.querySelector('input').checked=false
          }

        }
      }
    },
  },

}
</script>
