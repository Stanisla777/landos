<template lang="pug">
  .test-n-multiple-choice(:class="{ 'test-n-multiple-choice_answered' : isAnswered }")
    .test-n-multiple-choice__row.test-n-multiple-choice__row_main
      .test-n-multiple-choice__elections
        span.test-n-multiple-choice__election-text Да
        span.test-n-multiple-choice__election-text Нет
    .test-n-multiple-choice__row(v-for="(option, index) in options" :key="option.text")
      p.test-n-multiple-choice__text {{ option.text }}
      .test-n-multiple-choice__elections
        label.test-n-multiple-choice__checkbox-wrap
          .test-n-checkbox(:class="setCheckboxClasses(index)")
            input(
              v-model="answerValues[index]"
              :value="true"
              :name="option.text"
              :disabled="isAnswered"
              type="radio"
            )
            .test-n-checkbox__icon
          span.test-n-multiple-choice__checkbox-text Да
        label.test-n-multiple-choice__checkbox-wrap
          .test-n-checkbox(:class="setCheckboxClasses(index)")
            input(
              v-model="answerValues[index]"
              :value="false"
              :name="option.text"
              :disabled="isAnswered"
              type="radio"
            )
            .test-n-checkbox__icon
          span.test-n-multiple-choice__checkbox-text Нет
</template>

<script>
import testNComponent from '../mixin/testNComponent.js';

export default {
  name: 'TextNMultipleChoice',
  mixins: [testNComponent],
  computed: {
    answerValuesWithText() { // все ответы в виде объектов
      return this.answerValues.map((isChosen, index) => {
        return {
          text: this.options[index].text,
          isCorrect:this.options[index].isCorrect,
          isChosen
        }
      });
    }
  },
  watch: {
    answerValues() {
      !this.answerValues.includes(undefined) ? this.$emit('valuesIsChosen') : this.$emit('valuesIsUnchosen'); // если на все вопросы даны ответы
    },
  },
  methods: {
    /**
     * Устанавливает длинну для массива ответов
     */
    setDefaultValues() {
      this.answerValues = new Array(this.options.length);
    },
    /**
     * Устанавливает классы для отображения правильных/неправильных ответов + блокирующий класс
     * @param {Number} index - индекс ответа/вопроса
     */
    setCheckboxClasses(index) {
      const classesObj = {
        disabled: true, // блокирует взаимодействие с чекбоксом
        uncorrect: this.answerValues[index] !== this.options[index].isCorrect // если ответ неверный
      };
      return this.isAnswered ? classesObj : {};
    },
    /**
     * Подготавливает необходимые данные и вызывает событие для отправки
     */
    prepareDataForSend() {
      const data = {
        answerValuesWithText: this.answerValuesWithText
      };
      this.$emit('readyForDataSending', data);
    }
  }
}
</script>
