// eslint-disable-next-line no-unused-vars
export default function scrollToAddedItems(param) {
  // eslint-disable-next-line no-empty,camelcase,no-restricted-syntax
  if (param) {
    const container = param.closest('.js-tabs-item');
    if (container) {
      // eslint-disable-next-line camelcase
      const item_scroll = container.querySelector('.js--item-scroll-to[data-attr="new"]');
      // eslint-disable-next-line camelcase
      const scroll_block = container.querySelector('.js--wrap-scroll');
      scroll_block.scrollTo({ top: item_scroll.offsetTop, behavior: 'smooth' });
    }
  }
}
