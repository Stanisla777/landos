<template lang="pug">
  .calculator_s__calculator-row
    .calculator_s__period-input-wrapper
      p.calculator_s__calculator-label Регион
    .calculator_s__period-selection.calculator_s__wrapper-select.js--wrapper-select
      .calculator_s__select-choosen(@click="openList")
        p.calculator_s__selected-value.js--selected-value {{cities_with_restrictions[0].mortgage[0].name}}
        input.js__hidden-field(type="hidden")
        .calculator_s__selected-arrow
          svg(width='18' height='10' viewbox='0 0 18 10' fill='none' xmlns='http://www.w3.org/2000/svg')
            path(d='M1 1L8.29289 8.29289C8.68342 8.68342 9.31658 8.68342 9.7071 8.29289L17 1' stroke='#6B7081' stroke-width='2' stroke-linecap='round' stroke-linejoin='round')
      .calculator_s__list-wrapper.credit-holiday__list-wrapper.js--list-wrapper
        ul.select__list
          li.select__list-item.js--select-item(
            v-for="item in cities_with_restrictions[0].mortgage"
            @click="periodSelection"
          ) {{item.name}}


</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import PopUp from '../components/v-component-pop-up.vue';
export default {
  name: 'v-component-region',
  data(){
    return {
      select_region:null
    }
  },
  methods:{
//  Раскрываю список с выбором периода зарплаты
    openList(el){
      const item = el.currentTarget;
      const parent = item.closest('.js--wrapper-select');
      const container = parent.querySelector('.js--list-wrapper');

      if (parent.classList.contains('active')) {
        parent.classList.remove('active');
        container.style.maxHeight = 0;
      } else {
        parent.classList.add('active');
        container.style.maxHeight = `${container.scrollHeight}px`;
      }

    },
    //  Выбор года из списка
    periodSelection(el){
      const element = el.currentTarget
      const value = element.textContent
      const parent = element.closest('.js--wrapper-select')
      const container = parent.querySelector('.js--list-wrapper');
      const main_container = element.closest('.calculator_s__wrapper-salary');
      parent.querySelector('.js--selected-value').textContent = value;
      this.select_region=value;
      parent.classList.remove('active');
      container.style.maxHeight = 0;
      this.sendInputChange(value)
    },
    sendInputChange(value){
      Storage.dispatch('ActionRegion',value)
    },
  },
  mounted(){
    //При загрузке страницы отправил регион
    this.sendInputChange(this.cities_with_restrictions[0].mortgage[0].name)

  },
  computed:{
    cities_with_restrictions(){
      return Storage.getters.REGIONAL_RESTRICTIONS
    },
  },
  watch:{
  },
  components:{
    PopUp
  }
};
</script>
<style scoped>
</style>
