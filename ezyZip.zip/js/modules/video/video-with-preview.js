export default function videoWithPreview() {
  // eslint-disable-next-line camelcase
  const video_iframe = document.querySelectorAll('.video-iframe');
  video_iframe.forEach((item) => {
    // eslint-disable-next-line no-param-reassign
    item.onclick = function () {
      // item.querySelector('.video-iframe__prevew').setAttribute('style', 'display:none');
      item.querySelector('.video-iframe__prevew').classList.add('unactive');
      // eslint-disable-next-line no-unused-vars
      const promice = new Promise(((resolve) => {
        let src = item.querySelector('.video-iframe__video-conference iframe').getAttribute('src');
        const source = item.querySelector('.video-iframe__video-conference').getAttribute('data-source');
        if (source === 'youtube') {
          src = `${src}?autoplay=1`;
        }
        if (source === 'vk' || source === '') {
          src = `${src}&autoplay=1`;
        }
        item.querySelector('.video-iframe__video-conference iframe').setAttribute('src', src);
        item.querySelector('.video-iframe__video-conference')
          .setAttribute('style', 'display:block');
        resolve();
      })).then(() => new Promise(((resolve) => {
        setTimeout(() => {
          item.querySelector('.video-iframe__video-conference')
            .classList
            .add('active');
          resolve();
        }, 500);
      })));
    };
  });
}
