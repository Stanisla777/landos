// eslint-disable-next-line no-unused-vars
import axios from 'axios-jsonp-pro';
// eslint-disable-next-line no-unused-vars
function picturesInPreview() {
  // eslint-disable-next-line camelcase,no-unused-vars
  const video_prev = document.querySelectorAll('.card-video__preview');
  video_prev.forEach((item) => {
    // debugger;
    // eslint-disable-next-line camelcase
    const src_img = item.querySelector('picture img').getAttribute('src');
    // eslint-disable-next-line camelcase,no-unused-vars
    const src_source = item.querySelector('picture source');
    // eslint-disable-next-line camelcase
    if (src_img === '' || src_img === 'img/') {
      item.querySelector('picture img').setAttribute('src', 'img/preload-img.jpg');
      src_source.setAttribute('srcset', '');
    }
  });
}
export default function checkId() {
  picturesInPreview();
  const videos = document.querySelectorAll('.separate-video');
  for (let i = 0; i < videos.length; i++) {
    //  миниатюра ютуб
    // eslint-disable-next-line camelcase,no-use-before-define,no-undef
    const id_video = videos[i].getAttribute('for-id');// получаю id видео
    const videoItem = videos[i].querySelectorAll('picture img'); // картинки к видео при первоначальной загрузки
    for (let f = 0; f < videoItem.length; f++) {
      const srcImg = videoItem[f].getAttribute('src'); // получаю путь к видео
      // eslint-disable-next-line camelcase
      if (srcImg === '' || srcImg === 'img/') {
        // eslint-disable-next-line camelcase,no-unused-vars
        const type_video = videos[i].getAttribute('for-category');
        // eslint-disable-next-line camelcase
        if (type_video === 'youtube') {
          // eslint-disable-next-line camelcase
          videos[i].querySelector('picture img').setAttribute('src', `http://i.ytimg.com/vi/${id_video}/sddefault.jpg`);
          // eslint-disable-next-line camelcase
          videos[i].querySelector('picture source').setAttribute('srcset', '');
        }
        // eslint-disable-next-line camelcase
        if (type_video === 'vimeo') {
          // eslint-disable-next-line camelcase
          videos[i].querySelector('picture img').setAttribute('src', `https://i.vimeocdn.com/video/${id_video}.jpg`);
          // eslint-disable-next-line camelcase
          videos[i].querySelector('picture source').setAttribute('srcset', '');
        }
        // eslint-disable-next-line camelcase
        if (type_video === 'file') {
          videos[i].querySelector('picture img').setAttribute('src', 'img/preload-img.jpg');
          // eslint-disable-next-line camelcase
          videos[i].querySelector('picture source').setAttribute('srcset', '');
        }
      }
    }
    videos[i].querySelector('.card-video__prev').onclick = function () {
      // eslint-disable-next-line camelcase,no-unused-vars
      const type_video = videos[i].getAttribute('for-category');// получаю тип видео
     videos[i].querySelector('picture').setAttribute('style', 'display:none');
     videos[i].querySelector('.card-video__icon-play').setAttribute('style', 'display:none');
      // создаем iframe со включенной опцией autoplay
      // eslint-disable-next-line camelcase
      if (type_video === 'youtube') {
        const iframe = document.createElement('iframe');
        // eslint-disable-next-line camelcase
        let iframeUrl = `https://www.youtube.com/embed/${id_video}?autoplay=1&amp;loop=1&amp;playlist=${id_video}`;
        if (videos[i].getAttribute('data-params')) iframeUrl += `&${videos[i].getAttribute('data-params')}`;
        iframe.setAttribute('src', iframeUrl);
        iframe.setAttribute('frameborder', '0');
        iframe.setAttribute('allow', 'autoplay');
        iframe.style.width = videos[i].style.width;
        iframe.style.height = videos[i].style.height;
        // Заменяем миниатюру плеером с YouTube
       videos[i].querySelector('.card-video__content').append(iframe);
        // eslint-disable-next-line camelcase
      } else if (type_video === 'vimeo') {
        const iframe = document.createElement('iframe');
        // eslint-disable-next-line camelcase
        let iframeUrl = `https://player.vimeo.com/video/${id_video}?autoplay=1&loop=1&autopause=0&amp;mute=1&amp;playlist=${id_video}`;
        if (videos[i].getAttribute('data-params')) iframeUrl += `&${videos[i].getAttribute('data-params')}`;
        iframe.setAttribute('src', iframeUrl);
        iframe.setAttribute('frameborder', '0');
        iframe.setAttribute('allow', 'autoplay');
        iframe.style.width = videos[i].style.width;
        iframe.style.height = videos[i].style.height;
        // Заменяем миниатюру плеером с YouTube
       videos[i].querySelector('.card-video__content').append(iframe);
        // eslint-disable-next-line no-empty,camelcase
      } else if (type_video === 'file') {
        // eslint-disable-next-line no-unused-vars,camelcase
        const source_video = document.createElement('source');
        // eslint-disable-next-line camelcase
        source_video.setAttribute('src', `${id_video}`);
        source_video.setAttribute('type', 'video/mp4');
        // eslint-disable-next-line no-unused-vars
        const len = videos[i].querySelectorAll('video source').length;
        if (len === 0) {
          videos[i].querySelector('.card-video__content video').append(source_video);
        }
        videos[i].querySelector('video').setAttribute('style', 'display:block');
        setTimeout(() => {
          videos[i].querySelector('.before-load').setAttribute('style', 'display:none');
        }, 1000);
        videos[i].querySelector('video').play();
      }
    };
  }
}
