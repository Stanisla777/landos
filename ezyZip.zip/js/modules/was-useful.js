/**
 * @deprecated
 * Не нужен, вместо этого используется
 * дополненная вебформа рейтинга
 * с комментарием /src/js/modules/form-rating.js
 */
export default function wasUseful() {
    const form = document.querySelector('.js--was-useful');
    if (form) {
        const isLike = form.querySelector('input[type=\'checkbox\']');
        const likeBtn = form.querySelector('.was-useful__button_like');
        const dislikeBtn = form.querySelector('.was-useful__button_dislike');
        const comment = form.querySelector('.was-useful__comment');
        const commentArea = form.querySelector('.was-useful__comment textarea');
        const commentBtn = form.querySelector('.was-useful__comment .btn');

        likeBtn.addEventListener('click', (e) => {
            e.preventDefault();
            isLike.checked = true;

            commentArea.value = '';
            commentBtn.disabled = true;
            dislikeBtn.classList.remove('active');
            dislikeBtn.classList.add('disabled');
            likeBtn.classList.add('active');
            comment.classList.remove('show');
            comment.querySelector('.textarea')
                .classList
                .remove('textarea_error');
            localStorage.setItem(window.location.pathname, 'like');
            likeBtn.disabled = true;
            dislikeBtn.disabled = true;
        });

        dislikeBtn.addEventListener('click', (e) => {
            e.preventDefault();
            isLike.checked = false;
            dislikeBtn.classList.toggle('active');
            comment.classList.toggle('show');
        });

        commentArea.addEventListener('input', () => {
            if (commentArea.value.length > 0) {
                commentBtn.disabled = false;
            } else {
                commentBtn.disabled = true;
            }
        });

        commentBtn.addEventListener('click', (e) => {
            if (commentArea.value.length > 300) {
                e.preventDefault();
                comment.querySelector('.textarea')
                    .classList
                    .add('textarea_error');
            } else {
                comment.querySelector('.textarea')
                    .classList
                    .remove('textarea_error');
                commentBtn.disabled = true;
                comment.classList.remove('show');
                localStorage.setItem(window.location.pathname, 'dislike');
                likeBtn.disabled = true;
                dislikeBtn.disabled = true;
            }
        });

        if (localStorage.getItem(window.location.pathname)) {
            const value = localStorage.getItem(window.location.pathname);
            likeBtn.disabled = true;
            dislikeBtn.disabled = true;
            if (value === 'like') {
                likeBtn.classList.add('active');
            } else if (value === 'dislike') {
                dislikeBtn.classList.add('active');
            }
        }
    }
}
