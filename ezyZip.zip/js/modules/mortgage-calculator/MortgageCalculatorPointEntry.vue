<template lang="pug">
  .property-calculator__body.refinancing-calc__body.white
    template
      mortgage-calculator(
        :tooltip="tooltip"
        :max_maternity_capital="max_maternity_capital"

      )
</template>
<script>
// import DduCalculator from './DduCalculator.vue';
import Storage from './development-tools/state.vue';
const MortgageCalculator = () => import ("./MortgageCalculator.vue");


export default {
  name: 'MortgageCalculatorPointEntry',
  data(){
    return {
      tooltip:'',
      max_maternity_capital:693000
    }
  },
  methods:{
    receivedTooltip(){
      if (this.$attrs.tooltip_maternity_capital) {
        this.tooltip = this.$attrs.tooltip_maternity_capital
        console.log(this.$attrs);
      }
      if (this.$attrs.maximum_maternity_capital) {
        console.log(this.$attrs.maximum_maternity_capital);
        this.max_maternity_capital = parseInt(this.$attrs.maximum_maternity_capital)
        console.log(this.max_maternity_capital);
      }


    },
  },
  mounted(){
    this.receivedTooltip()
  },
  computed:{
  },
  watch:{
  },
  components:{
    MortgageCalculator
  }
};
</script>
<style scoped>
</style>
