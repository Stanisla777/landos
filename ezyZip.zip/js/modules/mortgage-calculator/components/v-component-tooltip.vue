<template lang="pug">
  .calculator_s__tooltip
    .calculator_s__tooltip-wrap(
      v-html="tooltip"
    )
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';

export default {
  name: 'v-tooltip',
  props:['tooltip'],
  data(){
    return {

    }
  },
  methods:{

  },
  mounted(){

  },
  computed:{},
  watch:{
  },
  components:{}
};
</script>
<style scoped>
</style>
