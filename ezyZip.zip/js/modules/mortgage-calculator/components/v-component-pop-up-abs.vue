<template lang="pug">
  .calculator_s__pop-up-abs.js--pop-up-abs
    .calculator_s__tooltip-icon-close(@click="closePopUp")
      svg(xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewbox='0 0 16 16')
        g(fill='#000' fill-rule='evenodd' transform='translate(0 -1)')
          rect(width='2' height='20' x='7.2643' y='-1.2357' transform='rotate(45 8.264 8.764)' rx='1')
          rect(width='2' height='20' x='7.2643' y='-1.2357' transform='rotate(135 8.264 8.764)' rx='1')
    p Вы не можете ввести сумму больше {{max_maternity_capital | formatNumber}} рублей. Это максимальная сумма материнского капитала на данный момент.
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';

export default {
  name: 'pop-up-abs',
  props:['max_maternity_capital'],
  data(){
    return {

    }
  },
  methods:{
    closePopUp(el){
      const element = el.currentTarget
      element.closest('.js--pop-up-abs').classList.remove('active')
    }
  },
  mounted(){

  },
  computed:{},
  watch:{
  },
  filters: {
    formatNumber: (num) => {

      return num.toFixed(0).toString().replace(/(\d)(?=(\d{3})+$)/g, '$1 ')
    },
  },
  components:{}
};
</script>
<style scoped>
</style>
