<template lang="pug">
  .property-calculator__row.js--tax_checkbox
    .property-calculator__switch

      label.property-calculator__toggle
        input.property-calculator__toggle-checkbox(type='checkbox')(@change="checkboxChanged")
        .property-calculator__toggle-switch
        span.property-calculator__toggle-label Использовать материнский капитал

</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import ToolTip from '../components/v-component-tooltip.vue';
import Storage from '../development-tools/state.vue';

export default {
  name: 'v-checkbox-other-means',
  data(){
    return {

    }

  },
  methods:{
    checkboxChanged(el){
      const element = el.currentTarget
      if(!element.checked){
        Storage.dispatch('ActionMaternalCapitalCalculation',false)
        eventBus.$emit('eventcheckboxChanged',false)
      }
      else{
        Storage.dispatch('ActionMaternalCapitalCalculation',true)
        eventBus.$emit('eventcheckboxChanged',true)
      }
    }


  },
  mounted(){

  },
  computed:{},
  watch:{
  },
  components:{
    ToolTip
  }
};
</script>
<style scoped>
</style>
