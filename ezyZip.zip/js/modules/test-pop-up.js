function closeOfferTest(elem) {
  // eslint-disable-next-line no-unused-vars
  const promice = new Promise(((resolve) => {
    elem.classList.remove('fadeIn');
    elem.classList.add('fadeOut');
    resolve();
  })).then(() => new Promise(((resolve) => {
    setTimeout(() => {
      elem.setAttribute('style', 'display:none');
      resolve();
    }, 1000);
  })));
}
function offerPopUpAppearance(elem) {
  elem.setAttribute('style', 'display:block');
  elem.classList.add('fadeIn');
}
// eslint-disable-next-line camelcase
function commonPopUpAppearance(elem, elem_2) {
  // eslint-disable-next-line no-unused-vars
  const promice = new Promise(((resolve) => {
    // document.body.setAttribute('style', 'overflow-y: hidden');
    elem.classList.remove('fadeIn');
    elem.classList.add('fadeOut');
    resolve();
  })).then(() => new Promise(((resolve) => {
      setTimeout(() => {
        elem.classList.remove('fadeOut');
        elem_2.querySelector('.common-test-pop-up__wrapper').classList.remove('zoomOut');
        elem_2.classList.add('open');
        resolve();
      }, 100);
    }))).then(() => new Promise(((resolve) => {
      setTimeout(() => {
        elem_2.querySelector('.common-test-pop-up__wrapper').classList.add('zoomIn');
        resolve();
      }, 200);
    })));
}
// eslint-disable-next-line camelcase
function commonPopUpHiding(elem, elem_2) {
  // eslint-disable-next-line no-unused-vars
  const promice = new Promise(((resolve) => {
    // document.body.setAttribute('style', 'overflow-y: auto');
    elem_2.querySelector('.common-test-pop-up__wrapper').classList.remove('zoomIn');
    elem_2.querySelector('.common-test-pop-up__wrapper').classList.add('zoomOut');
    resolve();
  })).then(() => new Promise(((resolve) => {
    setTimeout(() => {
      elem_2.classList.remove('open');
      resolve();
    }, 500);
  }))).then(() => new Promise(((resolve) => {
    setTimeout(() => {
      elem.classList.add('fadeIn');
      resolve();
    }, 100);
  })));
}
export default function testPopUp() {
  // eslint-disable-next-line camelcase
  const pop_up = document.querySelector('.offer-test-pop-up-js');
  // eslint-disable-next-line camelcase
  if (pop_up) {
    let dataTime = pop_up.getAttribute('data-time');
    // eslint-disable-next-line radix,no-const-assign
    dataTime = parseInt(dataTime);
    setTimeout(offerPopUpAppearance, dataTime, pop_up);
    // eslint-disable-next-line camelcase
    const common_pop_up = document.querySelector('.common-test-pop-up');
    const btn = pop_up.querySelector('.offer-test-pop-up__btn');
    const close = common_pop_up.querySelector('.modal__closer');
    // eslint-disable-next-line camelcase
    const close_offer_test = pop_up.querySelector('.offer-test-pop-up__close');
    close_offer_test.onclick = function () {
      closeOfferTest(pop_up);
    };
    btn.onclick = function () {
      commonPopUpAppearance(pop_up, common_pop_up);
    };
    close.onclick = function () {
      commonPopUpHiding(pop_up, common_pop_up);
    };
  }
}
