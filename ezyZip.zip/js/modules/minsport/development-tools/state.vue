<script>
import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios';
import VueAxios from 'vue-axios';
Vue.use(VueAxios, axios);
Vue.use(Vuex);

export default new Vuex.Store({
  state:{
    year:null,
    query_result:null
  },
  getters:{
    YEAR(state){
      return state.year
    },
    QUERYRESULT(state){
      return state.query_result
    },

  },
  mutations:{
    mutationGetYear(state,received_perem){
      state.year=received_perem
    },
    mutationQueryResult(state,received_perem){
      state.query_result=received_perem
    },
    mutationNullQueryResult(state,received_perem){
      state.query_result=null
    },
  },
  actions:{
    ActionGetYear({commit,state},param){
      const config_header = {
        headers: {
          'Content-Type': 'application/json',
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
          Accept: 'application/json',
        }
      }

      return axios.get(`/api/local/minsport/years/`,config_header)
        .then((res)=>{
          commit('mutationGetYear',res.data.result) //для боя
        }).catch((error) => {
          if (error) {
            commit('mutationGetYear',[2022,2023])
          }
        });
    },

    ActionSendingData({commit,state},param){
      const uri = `/api/local/minsport/?year=${param[0]}&search=${param[1]}`
      const encoded = encodeURI(uri);
      const config_header = {
        headers: {
          'Content-Type': 'application/json',
          'X-Bitrix-Csrf-Token': window.BX.bitrix_sessid(),
          Accept: 'application/json',
        }
      }
      return axios.get(encoded,config_header) //нужно
        .then((res)=>{
          commit('mutationQueryResult',res.data.result)
        }).catch((error) => {
          if (error) {
            commit('mutationQueryResult','error')
          }
        });
    },
    ActionNullQueryResult({commit,state}){
      commit('mutationNullQueryResult')
    }
  },
})
</script>
